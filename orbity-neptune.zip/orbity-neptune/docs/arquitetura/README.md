# Arquitetura — ORBITY-NEPTUNE

> INTELLIGENCE. AUTOMATION. GROWTH.

## 1. Visão geral

```
                    ┌──────────────────────────── Next.js 15 (App Router) ────────────────────────────┐
 Navegador / PWA ──►│  Páginas (RSC)  ·  Componentes cliente  ·  Rotas /api (BFF / API gateway)        │
                    │        │                         │                                               │
                    │        ▼                         ▼                                               │
                    │  TenantContext (sessão → organização → cargo → permissões)  ◄── middleware        │
                    │        │                                                                         │
                    │  Domínios: identity · crm · prospect · closer · intelligence · billing ·          │
                    │  entitlements · goals · integrations · data-intelligence · customer-success ·    │
                    │  support · experimentation · incidents · notifications · audit                   │
                    │        │                 │                    │                                  │
                    │  AI Orchestration   Event Engine (outbox) Workflow Engine                        │
                    └────────┼─────────────────┼────────────────────┼──────────────────────────────────┘
                             ▼                 ▼                    ▼
                    Provedores IA      PostgreSQL + pgvector   Worker (npm run worker)
                    (Anthropic/OpenAI/  (PGlite em dev)         processa outbox: retry/backoff/DLQ
                     local-heuristic)
```

- **Next.js** é a aplicação principal e o BFF/API gateway (seção 4.3). Os domínios vivem em `src/server/domains/*`
  como módulos desacoplados (funções puras sobre `TenantContext`), prontos para extração em serviços independentes
  quando houver justificativa (carga, time dedicado, isolamento). Nenhum microserviço foi criado sem necessidade.
- **Worker** separado (`scripts/worker.ts`) consome o outbox. Em produção roda como processo/contêiner próprio.

## 2. Decisões técnicas (resumo — ver `docs/adr/`)

| Tema | Decisão | Justificativa |
|---|---|---|
| ORM | **Drizzle ORM** | SQL-first e tipado; suporte nativo a pgvector, `FOR UPDATE`, `ON CONFLICT`; migrações SQL versionadas e legíveis; sem engine binária; roda igual em PGlite e Postgres. Prisma foi descartado por exigir engine nativa e suporte limitado a pgvector/RLS. |
| Banco | **PostgreSQL 16 + pgvector** | Requisito. Em desenvolvimento usa **PGlite** (Postgres em WASM) — zero instalação, mesmo dialeto. |
| Filas | **Outbox transacional no Postgres** (padrão) + Redis opcional | Garante atomicidade evento/dado sem 2PC. Redis entra para escala horizontal do worker (dependência registrada). |
| Auth | Sessões opacas em banco (hash SHA-256), cookie httpOnly/SameSite=Lax, bcrypt (12), TOTP RFC 6238, OAuth Google/Microsoft | Revogação imediata, auditoria, sem dependência de terceiros. |
| IA | Camada de provedores com fallback (`src/server/ai/providers`) | Independência de fornecedor (seção 19). |
| Hospedagem | Vercel/Render/Fly ou contêiner + Postgres gerenciado (Neon/Supabase/RDS com pgvector) | Ver `docs/operacao/deploy.md`. |

## 3. Multi-tenancy

- Toda tabela de dados de cliente possui `organization_id`.
- O acesso passa por `TenantContext` montado no servidor a partir da sessão: só há contexto com **membership ativa**
  e organização não suspensa (`contextFor`).
- Todas as funções de domínio filtram por `ctx.organizationId` e validam IDs referenciados com `assertOwned`
  (evita IDOR entre tenants).
- A busca vetorial (RAG) filtra por organização antes da ordenação por similaridade.
- Permissões verificadas no backend (`requirePerm`) — catálogo em `src/server/permissions`.
- Testes de isolamento: `tests/integration/core.test.ts › Isolamento multi-tenant`.
- **RLS**: recomendado em produção como defesa em profundidade (policy `organization_id = current_setting('app.org')`).
  Planejado para a versão 0.3 (requer conexão por requisição com `SET LOCAL`). Registrado na matriz (REQ-SEC-07).

## 4. Event Engine (`src/server/events`)

- `publish(tx, org, type, payload, { idempotencyKey, correlationId, causationId, version })` grava na tabela `events`
  **dentro da mesma transação** da mudança de domínio (Transactional Outbox).
- `processPending` faz *claim* otimista (`pending|failed → processing`), executa os handlers registrados,
  registra `event_handler_runs` (cada handler conclui **uma vez** por evento), aplica **retry com backoff exponencial**
  e move para **`dead`** (DLQ) após `maxAttempts`. `replayEvent` faz recuperação manual.
- Eventos: `lead.created`, `lead.qualified`, `opportunity.created|stage_changed|won|lost`, `conversation.received`,
  `message.replied`, `meeting.scheduled`, `proposal.sent`, `payment.confirmed`, `credit.consumed`, `limit.reached`,
  `approval.decided`, `workflow.resume` (interno).

## 5. Workflow Engine (`src/server/workflows`)

- Definição = grafo `{ entry, nodes[] }` com nós `trigger | condition | action | wait | approval | end`, versionado em
  `workflow_versions`.
- Proteções: validação de ciclos, **1 execução por (workflow, evento)** (índice único), profundidade máxima de
  encadeamento (`_wfDepth`, MAX_DEPTH=3), máx. 50 passos, ações sensíveis (`send_message`, `webhook`) e nós `approval`
  criam `approval_requests` — **execução só continua após decisão humana**.
- Esperas agendam `workflow.resume` com `next_attempt_at` futuro.
- Simulação sem efeitos colaterais; reprocessamento de execuções com falha; criação por modelos e por linguagem natural
  (gera **rascunho**, nunca publica).

## 6. IA (`src/server/ai`)

- `runAgent(ctx, { agentKey, input, context })`: guardrails de entrada (prompt injection, tamanho), dados não confiáveis
  delimitados, versão de prompt ativa, limite diário por agente, saldo de créditos, cadeia de provedores com fallback,
  verificação de saída (não alegar execução, remover PII), cobrança de créditos, registro em `ai_executions` e auditoria.
- Provedor `local-heuristic` é determinístico e **sempre sinalizado como simulação** na interface.
- Embeddings locais (hashing 256-d) armazenados em `pgvector`; substituíveis por embeddings de provedor.
- AI Evaluation Center: casos (inclusive adversariais), execuções de avaliação, **ativação de versão exige ≥ 90%**,
  rollback para versões aprovadas.

## 7. Modelo de dados

Ver `src/server/db/schema.ts` (fonte da verdade) e migrações em `drizzle/`. Entidades: Organization, User, Team, Role,
Membership, Session, Company, Contact, Lead, Opportunity, Pipeline/Stage, Activity, Task, Meeting, Proposal, Product,
Campaign, ICP, Cadence, Conversation, Message, KnowledgeDocument/Chunk, Event, Workflow/Version/Run, ApprovalRequest,
AIAgent, AIPromptVersion, AIExecution, AIEvalCase/Run, Plan, Subscription, CreditWallet/Transaction, UsageRecord,
Invoice, Payment, Coupon, FeatureFlag/Override, Goal, CommissionRule, MetricDefinition, DataSource, Integration/Log,
Notification, AuditLog, HealthScoreConfig, CSInteraction, SupportTicket, Experiment, Incident.

## 8. Segurança

Ver `docs/operacao/seguranca-lgpd.md`.
