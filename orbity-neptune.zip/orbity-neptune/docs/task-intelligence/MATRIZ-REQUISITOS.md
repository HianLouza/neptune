# ORBITY TASK INTELLIGENCE — auditoria e matriz de requisitos

Auditoria feita antes do desenvolvimento (Master Prompt, §23) e estado após a implementação.
Legenda: **Existente** (já havia) · **Implementado** (feito agora e testado) · **Parcial** · **Ausente** · **Bloqueado** (depende de algo externo) · **Planejado**.

## 1. Auditoria do que já existia (reaproveitado, nada removido)

| Área | Estado antes | Decisão |
|---|---|---|
| Tarefas & Metas (`tasks`, `/tarefas`, `/api/tasks`) | Existente. Status aberta/concluída/cancelada, prioridade baixa/média/alta, responsável, prazo. | Reaproveitado. Acrescentadas colunas `blocked_reason`, `progress_pct`, `goal_id`, `updated_at`. |
| Central de Notificações (`notifications`) | Existente, só notificação interna (sino). | Reaproveitada como canal "interno". Acrescentadas `alert_id` e `priority`. |
| Serviços de envio | Nenhum canal tem envio real (documentado em `closer/index.ts`). | Mantido: canais externos ficam **bloqueados** e nunca aparecem como enviados. |
| Automações (`workflows`) | Existente, voltado a funil/CRM. | Não estendido; regras de alerta têm tabela e motor próprios (evita acoplar com o Workflow Engine). |
| Flávio (`ai/flavio`, `runAgent`) | Existente: governança, créditos, kill switch, auditoria. | Reaproveitado para gerar mensagens. Nova ferramenta `execucao_e_alertas`. |
| Business Brain / Intelligence Layer | Existente. | Alimentado pela ferramenta do Flávio (ver §17 abaixo). |
| RBAC e auditoria | Existente. | Novas permissões `alerts:send` e `alerts:manage` (gestor/admin). Auditoria em todas as mutações. |
| Event Engine (outbox) | Existente. | **Não** usado pelos alertas (ver §18). |

## 2. Estado por requisito

| § | Requisito | Estado | Observações |
|---|---|---|---|
| 2 | Botão "Gerar alerta" ao lado de "Concluir", painel com todos os campos | **Implementado** | Destinatário preenchido (editável), tarefa, título, mensagem, prioridade, agendamento, prazo e remetente. O **prazo da tarefa** é exibido, mas não é editável nesse painel. |
| 3 | Mensagens com Flávio, versões ilimitadas, edição manual | **Implementado** | Com `ANTHROPIC_API_KEY`, texto do modelo (com governança/créditos). Sem chave, texto do compositor local, rotulado **"simulado"**; nesse modo a "orientação do gestor" não altera o texto. A sugestão original é guardada ao lado do texto enviado. Nada é enviado pela geração. |
| 4 | Quatro níveis de prioridade com identidade visual | **Implementado** | Baixa, média, alta, urgente (Badges do design system). |
| 5 | Canais | **Parcial / Bloqueado** | Interno e Central: reais. **Push, e-mail e WhatsApp: bloqueados** — não há remetente real implementado; aparecem desabilitados com o motivo e a API recusa o envio (409). Basta registrar o remetente em `EXTERNAL_SENDERS` quando existir. Preferências/consentimento do destinatário por canal: **Planejado**. |
| 6 | Automação de alertas | **Implementado** | Antes do vencimento, no vencimento, atrasada, repetição, máximo de lembretes, horário permitido (fuso da organização), tarefa sem atualização (avisa gestores), tarefa prioritária pendente, meta em risco (notificação semanal). Intervalo mínimo global de 60 min por tarefa/destinatário. "Meta atingida": **Planejado**. |
| 7 | Resposta do colaborador | **Implementado** | Confirmar, trabalhando, andamento, impedimento, ajuda, justificar atraso, comentário, concluir (exige `crm:write`). Evidência = **link** (upload de arquivo: **Planejado**). |
| 8 | Escalonamento automático | **Implementado (parcial na hierarquia)** | Degraus configuráveis por regra (intervalo, máximo de tentativas, pessoas). Para ao haver resposta/atualização, conclusão, cancelamento ou bloqueio justificado. Não existe organograma no sistema: o "superior hierárquico" é uma pessoa escolhida no degrau. |
| 9 | Prorrogação inteligente | **Implementado** | Pedido com justificativa/impedimentos/impacto. A recomendação do Flávio é por **regras** (fatos e inferências separados), não por LLM. Aprovar, rejeitar ou propor data (a data proposta **vale na hora**; o colaborador não precisa aceitar). Ninguém decide o próprio pedido. |
| 10 | Central de Alertas do gestor | **Implementado** | 10 indicadores reais + filtros (responsável, equipe, prioridade, período, status, tarefa, canal) + acesso à tarefa. |
| 11 | Inteligência de produtividade | **Parcial** | Atrasos por equipe, carga, bloqueios, motivos declarados, prorrogações. Não há dados de dependências nem de retrabalho, então gargalos entre equipes e processos com retrabalho estão **Ausentes**. Sem notas de pessoas; carga é sinal de planejamento. |
| 12 | Modo de comunicação | **Parcial** | Tom por organização, por regra e por tipo de mensagem (API) e por equipe (API). A **interface** só edita o tom da organização; equipe/tipo: **Planejado** na UI. |
| 13 | Inteligência de resultados dos alertas | **Parcial** | Taxa de resposta por tipo/prioridade/origem e horas do 1º alerta à conclusão, com aviso de correlação ≠ causalidade. O tom usado não é gravado por alerta, então "qual tom funciona melhor" é **Planejado**. |
| 14 | Histórico e auditoria | **Implementado** | Linha do tempo imutável por tarefa; estados rascunho→agendado→enviado→entregue→lido→respondido/falhou/cancelado; mensagem original × enviada. |
| 15 | Experiência do colaborador | **Implementado** | "Meus alertas" em `/alertas`, notificação interna, acesso à tarefa, histórico via tarefa. |
| 16 | Metas e comissões | **Parcial** | Aviso de meta em risco. Comissões e metas **nunca** são alteradas por alertas ou IA (garantido: o módulo não escreve nessas tabelas). |
| 17 | Business Brain | **Parcial** | Ferramenta `execucao_e_alertas` no Flávio (fatos / inferências / recomendações). O Business Brain (`brain.ts`) em si não ganhou análises novas. |
| 18 | Arquitetura | **Parcial** | Serviços modulares em `src/server/domains/task-alerts`, idempotência por chave única, entrega sob lock de linha, sem acesso livre da IA ao banco. Alertas rodam num laço do worker (1 min), **não** na fila do Event Engine; falha de canal não tem retentativa automática (reenvio manual). |
| 19 | Segurança e governança | **Parcial** | RBAC e isolamento entre organizações testados. Política de retenção e consentimento LGPD por canal: **Planejado**. |
| 20 | UX/UI responsiva | **Implementado** | Verificado em desktop e 375 px (ícones com tooltip na tabela). |
| 21 | Critérios de aceitação | **Parcial** | Todos cobertos exceto: canais externos integrados (bloqueado) e testes de **desempenho** (não executados). |

## 3. Como rodar

- Migração: `drizzle/0003_task_intelligence.sql` (aplicada automaticamente por `runMigrations`).
- Testes: `npx vitest run tests/integration/task-alerts.test.ts` (21 testes: entrega, agendamento, idempotência, escalonamento, prorrogação, isolamento, RBAC).
- Automação: roda no `npm run worker` a cada minuto; um administrador pode disparar agora em **Alertas → Executar automação agora**.
- IA real: preencha `ANTHROPIC_API_KEY`; sem ela as mensagens do Flávio são simuladas e rotuladas.

## 4. Decisões que merecem revisão do produto

1. **Prazo da tarefa não é editável no painel de alerta** (mudar prazo é outra operação, com a prorrogação).
2. **Data proposta pelo gestor vale imediatamente**; se quiser aceite do colaborador, é uma mudança de regra de negócio.
3. **Leitura** só é registrada quando o destinatário abre/interage com o alerta, nunca pela notificação em si.
