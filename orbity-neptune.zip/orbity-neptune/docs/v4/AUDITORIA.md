# Relatório de auditoria — Fase 0 (Master Prompt 4.0)

Data: 10/11/2026 · Base auditada: ORBITY-NEPTUNE v0.1.0 + esquema do ciclo 1 (`drizzle/0001_ciclo1_v4.sql`).
Método: leitura do código-fonte, migrações, testes e execução do app em desenvolvimento. Cada afirmação cita o arquivo de origem.

## 1. Stack e arquitetura

| Camada | Tecnologia | Onde |
|---|---|---|
| Aplicação / BFF | Next.js 15 App Router (server components + rotas `/api`) | `src/app` |
| Linguagem | TypeScript 5 estrito | `tsconfig.json` |
| UI | Tailwind v4 com tokens CSS (tema escuro/claro), recharts, lucide-react | `src/app/globals.css`, `src/components` |
| ORM | Drizzle ORM (justificativa em `docs/adr/0001-stack.md`) | `src/server/db/schema.ts` |
| Banco | PostgreSQL + pgvector. Dev/testes: PGlite (Postgres WASM). Produção: `DATABASE_URL` (postgres-js) | `src/server/db/client.ts` |
| Fila / eventos | Outbox transacional na tabela `events` + worker | `src/server/events`, `scripts/worker.ts` |
| IA | Camada própria multi-provedor: Anthropic (SDK oficial) → OpenAI → heurística local simulada | `src/server/ai/providers/index.ts` |
| Testes | Vitest (unitários + integração com Postgres em memória) | `tests/` |
| CI | GitHub Actions: typecheck, testes, build | `.github/workflows/ci.yml` |
| PWA | manifest + service worker básico | `public/manifest.webmanifest`, `public/sw.js` |

Arquitetura: monólito modular. Domínios em `src/server/domains/*` (admin, billing, closer, crm, customer-success, data-intelligence, entitlements, experimentation, goals, incidents, integrations, intelligence, notifications, platform, prospect, reporting, support) + núcleos transversais (`auth`, `tenancy`, `permissions`, `audit`, `events`, `workflows`, `ai`). Não há microserviços; o worker é um processo separado que reutiliza o mesmo código.

**Redis não está implementado.** Rate limit e cache são em memória (`src/server/auth/service.ts:102`). Previsto para produção.

## 2. Banco de dados

- 63 tabelas na migração `0000_init.sql` + 9 tabelas novas e 5 colunas em `ai_agents` na migração `0001_ciclo1_v4.sql` (finance_categories, finance_entries, finance_budgets, insights, decisions, scenarios, briefings, kill_switches, ai_budgets).
- Toda tabela de cliente tem `organization_id` com `ON DELETE CASCADE`. Exceções intencionais: `plans`, `feature_flags`, `experiments`, `incidents` (plataforma) e `kill_switches` (nulo = interrupção global).
- Dinheiro em centavos (`bigint`/`integer`) + moeda; nunca BRL fixo.
- Embeddings vetoriais em `knowledge_chunks` (pgvector 256-d, embeddings locais por hashing — não semânticos de LLM).
- Migrações versionadas e aplicadas automaticamente na inicialização (`src/server/db/migrate.ts`). `syncSystemRoles` acrescenta permissões novas aos cargos de sistema existentes.

## 3. Telas (22)

| Rota | Função | Estado |
|---|---|---|
| `/login`, `/cadastro`, `/onboarding` | Autenticação, criação de organização, configuração inicial | Existing |
| `/dashboard` | Painel comercial (KPIs, gráfico, origem, pipeline, ações da IA, metas, assistente) | Existing |
| `/prospect` | Leads, ICP, importação CSV, score explicável, exportação | Existing |
| `/closer` | Inbox, aprovações, base de conhecimento, SLA | Existing (envio real Partial — ver §6) |
| `/intelligence` | KPIs, perguntas mapeadas, funil, previsão, vendedores, recomendações | Existing |
| `/crm`, `/crm/oportunidade/[id]` | Funil kanban, empresas, contatos, detalhe da oportunidade | Existing (pipeline único na UI) |
| `/automacoes` | Workflows, modelos, rascunho por linguagem natural, simulação, versões | Existing |
| `/agentes`, `/agentes/[key]` | Centro de IA: agentes, versões, avaliações, execuções | Existing |
| `/tarefas` | Tarefas, metas, comissões | Existing |
| `/relatorios` | Relatórios e exportação CSV | Existing |
| `/integracoes` | Catálogo e conexão com validação no provedor | Partial (validação real; sincronização ausente) |
| `/billing` | Plano, créditos, previsão, excedentes autorizados, faturas | Existing (sem cobrança real) |
| `/customer-success` | Health Score, riscos, interações (admin global) | Existing |
| `/admin`, `/admin/plataforma` | Administração da empresa e painel global | Existing |
| `/suporte` | Chamados e assistente de suporte | Existing |
| `/configuracoes` | Perfil, 2FA, sessões, preferências | Existing |
| `/` | Redireciona para a última rota usada | Existing |

Telas do ciclo 1 (Planned — ciclo 1, em implementação): `/command-center`, `/financeiro`, `/simulador`, `/ai-control` (já presentes na navegação em `src/components/layout/nav.ts`).

## 4. Rotas de API (60)

Agrupadas por domínio (todas usam `handle()` e `requireApiContext(perm)`; mutações verificam origem com `assertSameOrigin`):

- **auth**: `login`, `register`, `logout`, `2fa`, `me`, `oauth/[provider]`
- **organização**: `onboarding`, `preferences`, `me`, `notifications`, `search`, `health`
- **prospect**: `icp`, `import`, `leads`, `leads/[id]`, `rescore`, `export`
- **crm**: `companies`, `contacts`, `opportunities`, `opportunities/[id]`
- **closer**: `conversations`, `conversations/[id]`, `.../reply`, `.../suggest`, `.../summary`, `approvals`, `approvals/[id]`, `knowledge`, `knowledge/search`
- **workflows**: `workflows`, `workflows/[id]`, `.../simulate`, `runs/[runId]/reprocess`, `test-event`
- **intelligence**: `overview`, `query`; `reports`
- **ai**: `chat`, `agents/[key]`, `.../activate`, `.../evaluate`, `.../test`, `.../versions`, `eval-cases`, `executions/[id]/feedback`
- **metas**: `goals`, `goals/commission`, `tasks`, `tasks/[id]`
- **integrações**: `integrations`, `integrations/events`, `webhooks/webchat`, `webhooks/whatsapp`
- **billing/admin/plataforma**: `billing`, `admin`, `export`, `platform`, `platform/cs`, `support`, `support/ai`

## 5. Funcionalidades concluídas vs. incompletas

Concluídas e cobertas por teste (ver §8): identidade com 2FA TOTP; convites com aprovação; RBAC verificado no backend; isolamento por organização; CRM com deduplicação e motivo de perda; Event Engine (outbox, idempotência, retry com backoff, DLQ, replay); Workflow Engine (validação de ciclo, profundidade máxima, aprovação humana, simulação, versões); Closer com sugestão por IA e aprovação; guardrails de IA; avaliação de prompts com ativação condicionada (≥ 90%) e rollback; créditos com bloqueio sem saldo e excedente autorizado com teto; importação CSV; previsão com cenários; exportação LGPD e anonimização de titular; relatórios; experimentos com significância.

Incompletas (Partial/Missing), com evidência:

| Item | Evidência | Estado |
|---|---|---|
| Envio real em canais (WhatsApp/e-mail) | `closer/index.ts:136` marca `sent` quando a integração está conectada, **sem chamada à API do canal** | Partial — risco alto (ver dívida D-01) |
| Ações sensíveis de workflow após aprovação (`send_message`, `webhook`) | `workflows/engine.ts` cria `approval_requests` sem `resumeNode`; `handlers.ts:41` encerra a execução sem executar a ação | Partial |
| Evento `payment.confirmed` | declarado em `EVENT_TYPES`, nenhum publicador | Missing |
| Sincronização com CRMs externos | só validação de credencial (`integrations/index.ts`) | Missing |
| Múltiplos pipelines / campos personalizados | tabela `pipelines` existe; UI usa um; sem campos personalizados | Partial/Missing |
| 2FA por SMS/e-mail, retenção automática, RLS, Redis, OpenTelemetry | não encontrados no código | Missing |
| Leitura de PDF/OCR na base de conhecimento | não encontrado | Missing |
| i18n completo | `en.json` contém só rótulos de navegação | Partial |

## 6. Integrações reais vs. simuladas

- **Reais:** webchat (`/api/webhooks/webchat`), recebimento WhatsApp por webhook (`/api/webhooks/whatsapp`), validação de credenciais em WhatsApp, HubSpot, Pipedrive, Stripe, Mercado Pago e Asaas (`integrations/index.ts`), IA Anthropic/OpenAI quando há chave.
- **Simuladas e sinalizadas na UI:** IA sem chave (`local-heuristic`), envio de mensagem sem integração (`status: simulated`), faturas sem provedor de pagamento.
- **Inconsistência encontrada:** com integração conectada, a mensagem é marcada `sent` sem envio efetivo (D-01). Isso viola a regra "não apresentar simulação como real" e deve ser corrigido antes de qualquer cliente conectar um canal.

## 7. Segurança e multi-tenancy

Controles existentes: senha bcrypt custo 12; sessão opaca com hash SHA-256; 2FA TOTP; rate limit de login em memória (8 tentativas/15 min); verificação de mesma origem nas mutações; credenciais de integrações cifradas com AES-256-GCM (`auth/crypto.ts`); cabeçalhos `X-Frame-Options`, `nosniff`, `Referrer-Policy`, `Permissions-Policy` (`next.config.ts`); auditoria imutável (`audit/index.ts`); guardrails contra prompt injection, mascaramento de PII e bloqueio de alegação falsa de execução (`ai/guardrails`); exportação CSV com proteção contra injeção de fórmula.

Multi-tenancy: isolamento **na aplicação** — todas as consultas filtram por `organizationId` do `TenantContext` e `assertOwned` evita IDOR. Testes negativos em `core.test.ts`, `prospect-crm.test.ts`, `intelligence-ai.test.ts`, `admin-billing.test.ts`. **Não há RLS no banco**: um erro de programação em uma consulta nova pode vazar dados. RLS é item de habilitação prioritário (ciclo 2).

Lacunas: sem Content-Security-Policy nem HSTS; rate limit não distribuído; sem varredura de dependências no CI; sem testes de vulnerabilidade; backups/DR dependem do provedor de banco.

## 8. Testes (44)

7 arquivos, 44 casos, todos passando. Cobertura por arquivo:
- `unit/pure.test.ts` (13): scoring explicável, CSV, guardrails, experimentos, comissão, workflow, TOTP, embeddings, health score, intenção, criptografia.
- `integration/core.test.ts` (16): identidade/2FA, convites, isolamento, permissões, CRM+eventos+workflow, idempotência/DLQ, ciclo de workflow, perda com motivo, aprovação no Closer, prompt injection, créditos, CSV, previsão, LGPD, governança de prompts.
- `integration/prospect-crm.test.ts` (3), `closer-workflows.test.ts` (3), `intelligence-ai.test.ts` (2), `admin-billing.test.ts` (4), `ai-provider.test.ts` (3).

Ausentes: E2E de navegador (pasta `tests/e2e` vazia), carga/performance, acessibilidade automatizada, segurança (DAST/SAST), migração com dados, recuperação de desastre.

## 9. Dívida técnica

| ID | Descrição | Severidade |
|---|---|---|
| D-01 | Mensagem marcada `sent` sem envio real quando o canal está conectado | Crítica |
| D-02 | Sem RLS: isolamento depende só da aplicação | Alta |
| D-03 | Ações sensíveis de workflow aprovadas não são executadas | Alta |
| D-04 | Rate limit e cache em memória (não funcionam com várias instâncias) | Alta (produção) |
| D-05 | Sem CSP/HSTS | Média |
| D-06 | Sem E2E, carga e acessibilidade automatizados | Média |
| D-07 | Embeddings por hashing (busca semântica limitada) | Média |
| D-08 | `payment.confirmed` sem publicador; webhooks de pagamento ausentes | Média |
| D-09 | i18n parcial (só pt-BR completo) | Baixa |
| D-10 | Coluna `autonomy` (texto) duplicada com `autonomy_level` (1–5) até a migração completa do AI Control Plane | Baixa |

## 10. Conclusão

O núcleo (Fase 1) e o núcleo comercial (Fase 2) estão majoritariamente implementados e testados. As capacidades novas da v4 (Intelligence Layer, Business Brain, Financial Intelligence, Strategy Simulator, AI Control Plane) têm o esquema criado e estão em implementação no ciclo 1. Antes de clientes reais conectarem canais, D-01 e D-03 precisam ser corrigidas; antes de produção multi-cliente, D-02 e D-04.

## 11. Situação após o ciclo 1 (v0.2.0, 2026-11-10)

| Item | Situação |
|---|---|
| D-01 (mensagem "enviada" sem envio real) | **Corrigido.** `sent` só após chamada real ao provedor (`OUTBOUND_SENDERS`, vazio hoje); canal conectado sem envio implementado aparece como "não entregue". |
| D-03 (ação sensível aprovada não executava) | **Corrigido.** A automação para na ação sensível, executa só após aprovação e retoma. Webhook limitado a https público. Teste: `tests/integration/workflow-sensitive.test.ts`. |
| Webhook WhatsApp sem assinatura | **Corrigido.** `WHATSAPP_APP_SECRET` obrigatório em produção; variáveis faltantes adicionadas ao `.env.example`. |
| D-10 (`autonomy` × `autonomy_level`) | Mitigado: as duas colunas são mantidas sincronizadas a cada alteração. |
| Entregas do ciclo 1 | Command Center, Intelligence Layer, Business Brain, Financial Intelligence, Strategy Simulator e AI Control Plane — ver estados na `MATRIZ-RASTREABILIDADE.md`. |
| Testes | 115 testes em 13 arquivos (era 44 em 7). Build de produção aprovado. Telas verificadas no navegador. |
