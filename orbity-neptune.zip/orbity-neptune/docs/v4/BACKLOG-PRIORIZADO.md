# Backlog priorizado — regra obrigatória de priorização

Toda funcionalidade é pontuada de 0 a 10 em cinco critérios, com pesos fixos:

| Critério | Peso | Como ler a nota |
|---|---|---|
| Valor gerado para o cliente | 25% | Quanto resolve um problema real e frequente |
| Potencial de receita | 25% | Ajuda a vender, reter ou expandir planos/créditos |
| Diferenciação competitiva | 20% | Quanto nos separa de HubSpot, Ploomes, RD etc. |
| Viabilidade técnica | 15% | Quanto conseguimos entregar bem com o que já existe |
| Custo de manutenção | 15% | **Nota alta = manutenção barata** |

Nota final = 0,25·V + 0,25·R + 0,20·D + 0,15·Vt + 0,15·M. Nenhum item entra só por parecer inovador: a coluna "Justificativa" registra a contribuição estratégica, o que é preservado e duplicidades evitadas.

## 1. Funcionalidades

| # | Item | V | R | D | Vt | M | **Nota** | Ciclo | Justificativa |
|---|---|---|---|---|---|---|---|---|---|
| 1 | Intelligence Layer: Evidence, Decision e Outcome Engine | 9 | 8 | 10 | 8 | 7 | **8,50** | 1 | Base de todas as análises da v4; reaproveita as recomendações do Sales Intelligence em vez de duplicá-las |
| 2 | Business Brain + Command Center | 9 | 8 | 9 | 8 | 7 | **8,30** | 1 | Responde "o que mudou / o que merece atenção" com fatos; usa KPIs existentes |
| 3 | Strategy Simulator | 8 | 7 | 9 | 9 | 8 | **8,10** | 1 | Modelo determinístico sobre dados reais; baixo custo e alta diferenciação |
| 4 | AI Control Plane (níveis 1–5, kill switch, orçamentos, monitoramento) | 8 | 7 | 8 | 9 | 8 | **7,90** | 1 | Pré-requisito de segurança para qualquer autonomia; estende `/agentes` sem duplicar |
| 5 | Financial Intelligence (núcleo: lançamentos, fluxo de caixa, DRE, projeção) | 9 | 9 | 7 | 7 | 6 | **7,85** | 1 | Abre o público de gestão empresarial; alimenta Command Center e Simulador |
| 6 | Value Realization | 7 | 8 | 8 | 8 | 8 | **7,75** | 2 | Prova o ROI e reduz churn; depende do Outcome Engine (item 1) |
| 7 | Customer 360 | 8 | 7 | 6 | 9 | 8 | **7,50** | 2 | Agrega dados já existentes (CRM, Closer, financeiro) numa visão por cliente |
| 8 | Envio real nos canais (corrige D-01) | 9 | 8 | 5 | 7 | 6 | **7,20** | 2 (correção prioritária) | Hoje uma mensagem pode aparecer como enviada sem ter sido; bloqueia uso real do Closer |
| 9 | Onboarding com diagnóstico empresarial | 7 | 6 | 6 | 9 | 9 | **7,15** | 2 | Ativação mais rápida; reaproveita o onboarding atual |
| 10 | Forecast gerencial (submission, rollup, acurácia) | 7 | 7 | 6 | 8 | 7 | **6,95** | 3 | Estende a previsão existente |
| 11 | Execução de ações sensíveis aprovadas (corrige D-03) | 8 | 6 | 5 | 8 | 7 | **6,75** | 2 | Fecha o ciclo de aprovação das automações |
| 12 | Document Intelligence | 8 | 7 | 7 | 4 | 5 | **6,50** | 3 | Alto valor, mas exige pipeline de PDF/OCR e armazenamento |
| 13 | Cobrança real (webhooks de pagamento, add-ons) | 6 | 10 | 3 | 6 | 5 | **6,25** | 3 | Bloqueado por credenciais e validação comercial de preços |
| 14 | Enriquecimento e sinais de intenção (Prospect) | 8 | 8 | 6 | 3 | 4 | **6,25** | Bloqueado | Depende de contratos com provedores de dados e base legal (LGPD) |
| 15 | Conversation intelligence / coaching / reuniões | 7 | 7 | 7 | 4 | 4 | **6,10** | 3+ | Exige transcrição e consentimento |
| 16 | CRM avançado (múltiplos pipelines, campos personalizados) | 7 | 7 | 3 | 7 | 6 | **6,05** | 3 | Paridade competitiva, pouca diferenciação |
| 17 | CPQ / Contratos (CLM) | 7 | 7 | 4 | 6 | 5 | **5,95** | 4 | Depende de Financial Intelligence e Customer 360 |
| 18 | Knowledge Graph | 6 | 5 | 7 | 6 | 5 | **5,80** | 4 | Primeiro com SQL relacional; grafo dedicado só com justificativa técnica |
| 19 | Business Benchmark | 7 | 6 | 8 | 2 | 4 | **5,75** | Bloqueado | Sem amostra real anonimizada nem base legal; benchmark inventado é proibido |
| 20 | Marketplace + Developer Portal | 6 | 8 | 6 | 3 | 3 | **5,60** | Fase 7 | Infraestrutura pesada (sandbox, revisão, cobrança) antes de existir demanda |
| 21 | Market Radar | 6 | 6 | 7 | 3 | 4 | **5,45** | Bloqueado | Exige fontes externas licenciadas |
| 22 | Business Workspace (projetos, Gantt, sprints) | 6 | 6 | 3 | 6 | 5 | **5,25** | Fase 7 | Muitos concorrentes fazem bem; baixa diferenciação |

## 2. Itens habilitadores (infraestrutura e qualidade)

Não competem pela nota: entram quando um item funcional depende deles ou quando há risco de segurança. A nota é informativa.

| Item | V | R | D | Vt | M | Nota | Ciclo | Por que é necessário |
|---|---|---|---|---|---|---|---|---|
| RLS no Postgres | 7 | 5 | 3 | 8 | 7 | 5,85 | 2 | Isolamento hoje depende só da aplicação (D-02) |
| CSP, HSTS e varredura de dependências | 6 | 4 | 2 | 9 | 9 | 5,60 | 2 | Endurecimento básico antes de produção (D-05) |
| Testes E2E, carga e acessibilidade | 6 | 4 | 2 | 8 | 6 | 5,00 | 2–3 | Definition of Done exige; hoje ausentes (D-06) |
| Redis (rate limit, cache, filas) | 5 | 4 | 2 | 8 | 6 | 4,75 | 3 | Necessário com mais de uma instância (D-04) |
| Observabilidade (OpenTelemetry, SLOs) | 5 | 3 | 2 | 7 | 6 | 4,35 | 3 | Operação em produção |

## 3. Ciclos

- **Ciclo 1 (em implementação):** itens 1–5. São os de maior nota e dependem apenas do núcleo existente. Esquema já criado (`drizzle/0001_ciclo1_v4.sql`).
- **Ciclo 2:** Value Realization, Customer 360, correção do envio real (D-01) e das ações aprovadas (D-03), onboarding com diagnóstico, RLS, CSP/HSTS, início dos testes E2E. Value Realization depende do Outcome Engine; Customer 360 depende do Financial Intelligence.
- **Ciclo 3:** forecast gerencial, Document Intelligence, CRM avançado, cobrança real (se credenciais e preços validados), Redis, carga e observabilidade.
- **Depois (fases 6–8):** CPQ/contratos, Knowledge Graph, Marketplace, Workspace. Market Radar, Benchmark e enriquecimento ficam **Bloqueados** até existir fonte licenciada, amostra real e base legal.

Recomendação: a correção D-01 (mensagem marcada como enviada sem envio real) deve ser feita antes de qualquer cliente conectar WhatsApp ou e-mail, mesmo que o restante do ciclo 2 ainda não tenha começado.
