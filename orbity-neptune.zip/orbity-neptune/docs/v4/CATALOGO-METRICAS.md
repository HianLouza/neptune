# Catálogo de métricas canônicas

Fonte oficial: `METRIC_CATALOG` em `src/server/domains/data-intelligence/index.ts` (gravado na tabela `metric_definitions`) e as funções de cálculo em `src/server/domains/intelligence/index.ts`. Métricas do ciclo 1 estão marcadas e calculadas em `src/server/domains/finance/snapshot.ts`.
Regra: uma métrica só aparece em painel ou resposta de IA se estiver neste catálogo, com fórmula e fonte.

## Comerciais (implementadas)

| Chave | Nome | Fórmula | Tabela fonte | Dono | Implementação |
|---|---|---|---|---|---|
| `leads_generated` | Leads gerados | `COUNT(leads) WHERE created_at ∈ período` | leads | Prospect.AI | `kpisFor` |
| `opportunities_created` | Oportunidades criadas | `COUNT(opportunities) WHERE created_at ∈ período` | opportunities | Sales Intelligence | `kpisFor` (não está no `METRIC_CATALOG` — incluir) |
| `won_deals` | Vendas realizadas | `COUNT(opportunities) WHERE status='won' AND closed_at ∈ período` | opportunities | Sales Intelligence | `kpisFor` (incluir no catálogo) |
| `revenue` | Receita | `SUM(amount_cents) WHERE status='won' AND closed_at ∈ período` | opportunities | Sales Intelligence | `kpisFor` |
| `win_rate` | Taxa de conversão | `COUNT(won) / COUNT(won + lost)` fechadas no período | opportunities | Sales Intelligence | `kpisFor` |
| `average_ticket` | Ticket médio | `revenue / won_deals` | opportunities | Sales Intelligence | derivável; não exposto ainda |
| `pipeline_value` | Pipeline aberto | `SUM(amount_cents) WHERE status='open'` | opportunities | Sales Intelligence | `revenueForecast` |
| `forecast_weighted` | Receita prevista | `SUM(amount × probabilidade da etapa)`; faixa ±15/25/40% conforme amostra (≥30, ≥10, <10 fechadas em 90 dias) | opportunities, pipeline_stages | Sales Intelligence | `revenueForecast` |
| `stage_pass_rate` | Passagem entre etapas | `n(etapa i) / n(etapa i−1)` posição atual | opportunities | Sales Intelligence | `funnelAnalysis` |
| `first_response_time` | Tempo de primeira resposta | `AVG(primeira saída − primeira entrada)` | messages | Closer.AI | catálogo (cálculo no painel ⏳) |
| `productivity` | Produtividade | `COUNT(activities) / COUNT(DISTINCT usuários ativos)` | activities | Sales Intelligence | catálogo |
| `goal_progress` | Progresso da meta | `realizado / alvo` | goals, opportunities | Tarefas & Metas | `goalsWithProgress` |

## Plataforma (ORBITY)

| Chave | Nome | Fórmula | Fonte | Dono |
|---|---|---|---|---|
| `mrr` | MRR | `SUM(plans.monthly_price) WHERE subscription ativa` — hoje preços nulos ("A definir") ⇒ MRR não calculável | subscriptions, plans | Billing |
| `churn` | Churn de clientes | `canceladas no mês / ativas no início do mês` | subscriptions | Customer Success |
| `health_score` | Health Score | média ponderada de sinais (uso, usuários ativos, integrações, adoção, billing) com pesos configuráveis em `health_score_config` | vários | Customer Success |
| `ai_credits_used` | Créditos de IA consumidos | `SUM(credit_transactions)` do tipo consumo | credit_transactions | Billing |

## Financeiras (ciclo 1 — Planned, em implementação)

| Chave | Nome | Fórmula | Fonte |
|---|---|---|---|
| `cash_in` | Recebimentos | `SUM(amount) kind='receivable' status='paid' paid_at ∈ período` | finance_entries |
| `cash_out` | Pagamentos | `SUM(amount) kind='payable' status='paid' paid_at ∈ período` | finance_entries |
| `operating_result` | Resultado | `cash_in − cash_out` | finance_entries |
| `margin_pct` | Margem | `resultado / cash_in` (nulo se `cash_in = 0`) | finance_entries |
| `receivable_overdue` | Inadimplência | `SUM(receivable aberto com due_date < hoje)` | finance_entries |
| `cash_next_30` | Saldo projetado 30 dias | `recebíveis − pagáveis abertos com vencimento em 30 dias` | finance_entries |
| `break_even` | Ponto de equilíbrio | `custos fixos / margem de contribuição %` (premissas exibidas) | finance_entries + categorias |

Sem lançamentos financeiros, as métricas financeiras retornam "sem dados" (`hasData = false`). Nunca são estimadas a partir do CRM.

## Pendências do catálogo
- Incluir `opportunities_created`, `won_deals`, `average_ticket`, `pipeline_value`, `forecast_weighted` e as financeiras no `METRIC_CATALOG` (hoje só 7 chaves).
- CAC, LTV e retenção de clientes do cliente exigem custo de aquisição e assinaturas do cliente registrados (ver V4-CMD-03).
