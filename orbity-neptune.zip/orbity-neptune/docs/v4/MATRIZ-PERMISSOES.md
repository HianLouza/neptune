# Matriz de permissões

Fonte: `PERMISSIONS` e `SYSTEM_ROLES` em `src/server/permissions/index.ts`. Verificação **sempre no backend** com `requirePerm` / `requireApiContext(perm)`. Cargos de sistema recebem permissões novas automaticamente na migração (`syncSystemRoles` em `src/server/db/migrate.ts`); cargos personalizados não são alterados. O administrador global da plataforma (`isPlatformAdmin`) é uma flag separada, não uma permissão.

✅ concedida · — não concedida

| Permissão | O que libera | Administrador | Gestor | Colaborador |
|---|---|---|---|---|
| `crm:read` | Ver empresas, contatos, oportunidades | ✅ | ✅ | ✅ |
| `crm:write` | Criar e editar registros do CRM | ✅ | ✅ | ✅ |
| `crm:delete` | Excluir registros (declarada; nenhuma rota usa ainda) | ✅ | ✅ | — |
| `prospect:read` | Ver leads e ICP | ✅ | ✅ | ✅ |
| `prospect:write` | Importar, editar e pontuar leads | ✅ | ✅ | ✅ |
| `closer:read` | Ver conversas | ✅ | ✅ | ✅ |
| `closer:write` | Responder e pedir sugestão de IA | ✅ | ✅ | ✅ |
| `intelligence:read` | Painéis, relatórios, Command Center | ✅ | ✅ | ✅ |
| `automations:read` | Ver automações | ✅ | ✅ | ✅ |
| `automations:write` | Criar rascunhos e simular | ✅ | ✅ | — |
| `automations:publish` | Ativar automações (`workflows/engine.ts:226`) | ✅ | ✅ | — |
| `ai:use` | Usar assistente e agentes | ✅ | ✅ | ✅ |
| `ai:manage` | Configurar agentes, versões, avaliações; ver AI Control Plane | ✅ | ✅ | — |
| `ai:govern` | **Novo (ciclo 1).** Kill switch, orçamentos de IA, níveis de autonomia | ✅ | — | — |
| `approvals:decide` | Aprovar respostas de IA, etapas de automação e decisões | ✅ | ✅ | — |
| `goals:read` | Ver tarefas, metas e comissões | ✅ | ✅ | ✅ |
| `goals:manage` | Criar metas e regras de comissão | ✅ | ✅ | — |
| `integrations:read` | Ver integrações | ✅ | ✅ | ✅ |
| `integrations:manage` | Conectar/desconectar, reprocessar DLQ | ✅ | — | — |
| `billing:read` | Ver plano, créditos, faturas | ✅ | ✅ | — |
| `billing:manage` | Trocar plano, autorizar excedentes | ✅ | — | — |
| `admin:users` | Aprovar usuários, cargos, equipes | ✅ | ✅ | — |
| `admin:settings` | Configurações da organização | ✅ | — | — |
| `audit:read` | Ver auditoria | ✅ | ✅ | — |
| `export:data` | Exportar dados e direitos do titular (LGPD) | ✅ | ✅ | — |
| `support:use` | Abrir chamados | ✅ | ✅ | ✅ |
| `finance:read` | **Novo (ciclo 1).** Ver lançamentos, fluxo de caixa, DRE | ✅ | ✅ | — |
| `finance:write` | **Novo (ciclo 1).** Criar e baixar lançamentos, orçamentos | ✅ | ✅ | — |
| `strategy:read` | **Novo (ciclo 1).** Ver simulações | ✅ | ✅ | — |
| `strategy:write` | **Novo (ciclo 1).** Criar e salvar cenários | ✅ | ✅ | — |

## Regras especiais
- Ações sensíveis da IA (enviar mensagem, chamar webhook) exigem aprovação humana independentemente do cargo e do nível de autonomia do agente.
- Nenhum agente pode ampliar as próprias permissões: as permissões do agente vêm do catálogo e da configuração feita por quem tem `ai:manage`.
- Dados financeiros ficam fora do cargo Colaborador por padrão; a empresa pode criar cargo personalizado se quiser liberar.

## Lacunas
- `crm:delete` está no catálogo, mas nenhuma rota a verifica (exclusão de registros do CRM não existe hoje).
- Permissões por equipe, registro, campo e canal (§9.4, §35) ainda não existem: o escopo é organização + módulo + ação.
