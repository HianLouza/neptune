# Plano de segurança (§34)

## 1. Controles existentes (verificados no código)

| Área | Controle | Onde |
|---|---|---|
| Senhas | bcrypt custo 12, política de senha forte | `auth/password.ts` |
| Sessões | token opaco; só o hash SHA-256 fica no banco; listagem e revogação | `auth/service.ts`, `/configuracoes` |
| 2FA | TOTP (app autenticador) | `auth/totp.ts` |
| Força bruta | 8 tentativas por 15 min por chave, em memória | `auth/service.ts:102` |
| CSRF | verificação de mesma origem em mutações | `http.ts` (`assertSameOrigin`) |
| Segredos de integração | AES-256-GCM com `ENCRYPTION_KEY` | `auth/crypto.ts` |
| Cabeçalhos | X-Frame-Options DENY, nosniff, Referrer-Policy, Permissions-Policy; `poweredByHeader: false` | `next.config.ts` |
| Isolamento | filtro por `organizationId` + `assertOwned` contra IDOR; testes negativos | `tenancy/context.ts`, testes |
| Permissões | RBAC verificado no backend | `permissions/index.ts` |
| Auditoria | registro de login, IA, aprovações, exportações, integrações | `audit/index.ts` |
| Exportação | proteção contra injeção de fórmula em CSV | `prospect` (testado) |
| LGPD | exportação da organização, busca e anonimização de titular | `data-intelligence` |
| IA | detecção de prompt injection (PT/EN), dados externos marcados como não confiáveis, mascaramento de PII, bloqueio de alegação falsa de execução, aprovação humana para ações sensíveis, limites de tokens/créditos, avaliação antes de ativar prompt, recusa do modelo tratada sem cair para simulação | `ai/guardrails`, `ai/orchestrator.ts`, `ai/evaluation` |

## 2. Lacunas e plano

| # | Lacuna | Risco | Ação | Ciclo |
|---|---|---|---|---|
| S-01 | Mensagem marcada `sent` sem envio real (D-01) | Alegação falsa de entrega a cliente | Enviar pela API do canal e só marcar `sent` com confirmação; senão `failed` | 2 (prioritário) |
| S-02 | Sem RLS | Vazamento entre empresas por erro em consulta nova | Políticas RLS por `organization_id` com `SET app.org_id` por transação; teste que consulta sem contexto retorna vazio | 2 |
| S-03 | Sem CSP e HSTS | XSS e downgrade | CSP com nonce para scripts; HSTS 1 ano em produção | 2 |
| S-04 | Rate limit em memória | Ineficaz com várias instâncias | Redis com janela deslizante; limites também em `/api/ai/*` e webhooks | 3 |
| S-05 | Sem varredura de dependências e SAST no CI | Vulnerabilidade conhecida em produção | `npm audit --audit-level=high` e CodeQL no CI | 2 |
| S-06 | Assinatura do webhook do WhatsApp só é exigida se `WHATSAPP_APP_SECRET` estiver definido (sem ele, aceita sem assinatura); webhook do webchat é público por natureza | Mensagens forjadas | Tornar `WHATSAPP_APP_SECRET` obrigatório em produção; rate limit e captcha leve no webchat; assinatura Stripe quando houver cobrança | 2 |
| S-07 | Retenção sem rotina de purga | Guardar dados além do necessário | Job de retenção com auditoria | 3 |
| S-08 | Backups e DR dependem do provedor | Perda de dados | PITR no Postgres gerenciado + teste trimestral de restauração | Antes de produção |
| S-09 | 2FA só por app | Usuários sem autenticador | E-mail/SMS como segundo fator alternativo | 3 |
| S-10 | Sem teste de intrusão | Falhas não detectadas | Pentest externo antes do primeiro cliente pagante | Antes de produção |

## 3. Segurança de IA (§34)

| Requisito | Estado | Ação |
|---|---|---|
| Proteção contra prompt injection | Implementado (padrões + isolamento de dados não confiáveis) | Ampliar casos adversariais na avaliação |
| Isolamento de contexto | Implementado por organização | Context Engine respeitando permissões do usuário (ciclo 3) |
| Permissões de ferramentas | Ferramentas declaradas por agente | Verificar ferramenta × permissão na execução (ciclo 1, AI Control Plane) |
| Identidade do agente | Auditoria com `ai:<agente>` | Dono e domínio do agente (ciclo 1) |
| Aprovação humana | Implementado para envio e webhook | Executar ação aprovada (D-03, ciclo 2) |
| Controle de custos | Créditos + limite diário por agente | Orçamentos mensais por agente/modelo/organização (ciclo 1) |
| Validação de saída | Implementado (`checkOutput`) | — |
| Trilha de auditoria | Implementado (`ai_executions` + `audit_logs`) | — |
| Desligamento de emergência | Desativar agente individual | Kill switch por agente, grupo, integração, ferramenta, workflow e categoria (ciclo 1) |
| Avaliação de modelos | Implementado (≥ 90% para ativar, rollback) | Casos de avaliação para todos os agentes (hoje só `support_chat` tem casos semeados) |

## 4. LGPD

| Requisito | Estado |
|---|---|
| Direitos do titular (acesso, anonimização) | Implementado |
| Portabilidade (exportação JSON) | Implementado |
| Registro de operações | Auditoria implementada |
| Inventário de dados, finalidade e bases legais | Pendente: documento de ROPA por tabela (ciclo 2) |
| Consentimento para gravação/transcrição | Pendente (dependente de telefonia/reuniões) |
| Controle de operadores (subprocessadores: Anthropic, OpenAI, provedores de canal) | Pendente: lista pública de subprocessadores e DPA |
| Retenção e exclusão segura | Parcial (campo de retenção sem rotina) |
