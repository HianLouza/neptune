# ORBITY-NEPTUNE — Master Prompt 4.0

Entregáveis da Fase 0 (auditoria) e do planejamento por ciclos. Tudo foi conferido com o código em 10/11/2026.

| Documento | Conteúdo |
|---|---|
| [AUDITORIA.md](AUDITORIA.md) | Stack, telas, rotas, domínios, o que está pronto ou incompleto, integrações reais vs. simuladas, segurança, testes e dívida técnica |
| [MATRIZ-RASTREABILIDADE.md](MATRIZ-RASTREABILIDADE.md) | Requisitos das seções 5–38 com estado atual (Existing/Partial/Missing/Blocked/Planned), critério de aceite, testes, riscos e versão |
| [BACKLOG-PRIORIZADO.md](BACKLOG-PRIORIZADO.md) | Notas pela regra obrigatória (valor 25%, receita 25%, diferenciação 20%, viabilidade 15%, manutenção 15%) e divisão em ciclos |
| [ROADMAP.md](ROADMAP.md) | Fases 0–8 aplicadas ao estado atual, com entregas, dependências e critérios de aceite |
| [MATRIZ-DEPENDENCIAS.md](MATRIZ-DEPENDENCIAS.md) | Grafo de dependências entre módulos |
| [MATRIZ-PERMISSOES.md](MATRIZ-PERMISSOES.md) | Permissão × cargo, incluindo `finance:*`, `strategy:*` e `ai:govern` |
| [CATALOGO-METRICAS.md](CATALOGO-METRICAS.md) | Métricas canônicas com fórmula e fonte |
| [CATALOGO-EVENTOS.md](CATALOGO-EVENTOS.md) | Eventos de domínio, publicadores e consumidores |
| [CATALOGO-AGENTES.md](CATALOGO-AGENTES.md) | Agentes de IA, ferramentas, permissões e níveis de autonomia 1–5 |
| [CATALOGO-INTEGRACOES.md](CATALOGO-INTEGRACOES.md) | Integrações reais, que dependem de credencial, só cadastradas ou não construídas |
| [PLANO-SEGURANCA.md](PLANO-SEGURANCA.md) | Controles atuais, lacunas, segurança de IA e LGPD |
| [PLANO-IMPLANTACAO.md](PLANO-IMPLANTACAO.md) | Ambientes, componentes, segredos, migrações, pipeline, backups |
| [PLANO-CUSTOS.md](PLANO-CUSTOS.md) | Custo de IA por crédito e por modelo, implicações de margem e direcionadores de infraestrutura |

## Situação em uma frase
O núcleo e o módulo comercial estão prontos e testados; o ciclo 1 (Intelligence Layer, Business Brain/Command Center, Strategy Simulator, AI Control Plane e Financial Intelligence) está em implementação; antes de clientes reais, é preciso corrigir o envio de mensagens marcadas como enviadas sem envio real (D-01) e ativar RLS.
