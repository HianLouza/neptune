# Roadmap — fases do Master Prompt 4.0 aplicadas ao estado atual

Legenda de estado da fase: ✅ concluída · 🟡 parcial · 🔵 em implementação · ⬜ não iniciada.
Cada entrega tem dependências e critério de aceite. Uma entrega só é dada como pronta quando cumpre a Definition of Done (§41).

## Fase 0 — Auditoria ✅
Entregas: relatório de auditoria, matriz de rastreabilidade, backlog priorizado, catálogos e planos (`docs/v4`).
Aceite: todo estado "Existing" citado com arquivo ou teste. **Concluída nesta documentação.**

## Fase 1 — Unified Core 🟡
| Entrega | Estado | Dependências | Critério de aceite |
|---|---|---|---|
| 1.1 Identidade, 2FA TOTP, sessões | ✅ | — | Testes de login/2FA passando |
| 1.2 Multi-tenancy na aplicação + RBAC no backend | ✅ | 1.1 | Testes negativos entre tenants |
| 1.3 RLS no Postgres | ⬜ (ciclo 2) | 1.2, Postgres em produção | Consulta sem `organization_id` configurado retorna vazio |
| 1.4 Event Engine e Workflow Engine | ✅ | — | Idempotência, DLQ e anti-loop testados |
| 1.5 Billing com créditos e entitlements | ✅ (sem cobrança real) | — | Bloqueio sem saldo testado |
| 1.6 Auditoria, design system, CI | ✅ | — | CI com typecheck, testes e build |
| 1.7 Observabilidade e Redis | ⬜ (ciclo 3) | infraestrutura | Funciona com 2+ instâncias; traces por requisição |

## Fase 2 — Commercial Core 🟡
| Entrega | Estado | Dependências | Critério de aceite |
|---|---|---|---|
| 2.1 Prospect.AI núcleo (ICP, score, CSV) | ✅ | 1.x | Testes de importação e score |
| 2.2 Closer.AI núcleo (inbox, IA com aprovação, KB, SLA) | ✅ | 1.x | Testes de aprovação e handoff |
| 2.3 Envio real pelos canais (corrige D-01) | 🟡 (ciclo 2, prioritário) | credenciais | `sent` só com confirmação do provedor |
| 2.4 CRM núcleo | ✅ | 1.x | — |
| 2.5 CRM avançado (pipelines múltiplos, campos personalizados) | ⬜ (ciclo 3) | 2.4 | Pipeline por oportunidade |
| 2.6 Sales Intelligence inicial | ✅ | 2.4 | Previsão com cenários e limitações |
| 2.7 Sincronização com CRMs externos | ⬜ | credenciais | Log e retry por sincronização |

## Fase 3 — Intelligence Layer 🔵 (ciclo 1)
| Entrega | Estado | Dependências | Critério de aceite |
|---|---|---|---|
| 3.1 Evidence Engine | 🔵 | — | Nenhum insight sem fato com fonte |
| 3.2 Insights proativos com deduplicação | 🔵 | 3.1 | Execução repetida não duplica insight aberto |
| 3.3 Decision Engine | 🔵 | 3.1 | Aprovação exige `approvals:decide`; isolamento testado |
| 3.4 Outcome Engine | 🔵 | 3.2 | Resultado observado comparado à linha de base |
| 3.5 Business Brain (perguntas + resposta em 10 partes) e briefings | 🔵 | 3.1–3.2 | Perguntas desconhecidas respondem "não sei"; fatos determinísticos |
| 3.6 Command Center | 🔵 | 3.5, 4.1 | Responde às 6 perguntas do §5 com fontes |
| 3.7 Context Engine com memória autorizada | ⬜ (ciclo 3) | 3.5 | Contexto respeita permissões |
| 3.8 Knowledge Graph (consultas relacionais) | ⬜ | 2.4 | Pergunta do §14.3 respondida |

## Fase 4 — Revenue & Financial Intelligence 🔵/⬜
| Entrega | Estado | Dependências | Critério de aceite |
|---|---|---|---|
| 4.1 Financial Intelligence núcleo (lançamentos, fluxo, DRE, orçamento, projeção) | 🔵 (ciclo 1) | 1.x | Totais conferem com lançamentos; isolamento testado |
| 4.2 Customer 360 | ⬜ (ciclo 2) | 4.1, 2.x | Linha do tempo única do cliente |
| 4.3 Forecast gerencial (rollup, acurácia) | ⬜ (ciclo 3) | 2.6 | Acurácia histórica calculada |
| 4.4 CPQ, contratos, renovações | ⬜ (fase posterior) | 4.1, 4.2 | Contrato gera receita recorrente |
| 4.5 Integrações financeiras (Stripe, bancos, ERP) | ⬜ bloqueado | credenciais/contratos | Nada aparece conectado sem integração efetiva |

## Fase 5 — Autonomous Operations 🔵/⬜
| Entrega | Estado | Dependências | Critério de aceite |
|---|---|---|---|
| 5.1 AI Control Plane: níveis 1–5, pausa/suspensão, kill switch, orçamentos, monitoramento | 🔵 (ciclo 1) | — | Agente pausado ou com kill switch ativo não executa |
| 5.2 Digital Workforce (inventário com indicadores) | 🔵 (ciclo 1, dentro do 5.1) | 5.1 | Agente distinguido de colaborador humano |
| 5.3 Execução de ações aprovadas (corrige D-03) | ⬜ (ciclo 2) | 1.4 | Ação aprovada executa uma única vez |
| 5.4 Next Best Action e operações autônomas controladas | ⬜ | 3.x, 5.1, 5.3 | Plano → aprovação → execução → medição |
| 5.5 Agent Builder e memória de IA | ⬜ | 5.1 | Memória com exclusão e permissões |

## Fase 6 — Strategic Intelligence 🔵/⬜
| Entrega | Estado | Dependências | Critério de aceite |
|---|---|---|---|
| 6.1 Strategy Simulator | 🔵 (ciclo 1) | 4.1, 2.6 | Mesmo input → mesmo resultado; premissas visíveis |
| 6.2 Value Realization | ⬜ (ciclo 2) | 3.4 | Separa observado, associado e causal |
| 6.3 Document Intelligence | ⬜ (ciclo 3) | storage + OCR | Extração com origem e versão |
| 6.4 Market Radar | ⬜ bloqueado | fontes licenciadas | Fonte, data e confiabilidade por informação |
| 6.5 Business Benchmark | ⬜ bloqueado | amostra real + base legal | Amostra mínima e metodologia publicada |

## Fase 7 — Business Ecosystem ⬜
Customer & Partner Hub, Business Workspace, Marketplace, Developer Portal, extensões. Dependem de 1.3 (RLS), sandbox de execução de terceiros e cobrança real.

## Fase 8 — Enterprise Excellence ⬜
Segurança avançada (testes de intrusão, CSP estrita), escala (Redis, réplicas), internacionalização completa, portabilidade, DR testado.

## Ciclos

| Ciclo | Conteúdo | Saída esperada |
|---|---|---|
| **1** (atual) | Intelligence Layer, Business Brain + Command Center, Strategy Simulator, AI Control Plane, Financial Intelligence núcleo | 4 telas novas, APIs, testes de isolamento e cálculo, documentação |
| **2** | Value Realization, Customer 360, onboarding com diagnóstico, RLS, correções D-01 e D-03, CSP/HSTS, primeiros E2E | Isolamento no banco; mensagens só "enviadas" quando enviadas |
| **3** | Forecast gerencial, Document Intelligence, CRM avançado, Redis, carga, observabilidade, cobrança real (se liberada) | Pronto para várias instâncias e primeiros clientes pagantes |
