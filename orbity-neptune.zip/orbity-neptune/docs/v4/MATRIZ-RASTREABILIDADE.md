# Matriz de rastreabilidade — Master Prompt 4.0

Estados: **Existing** (implementado e comprovado por código/teste) · **Partial** (parte implementada) · **Missing** (não existe) · **Blocked** (depende de dado, fornecedor ou decisão externa) · **Planned** (no plano, ainda não iniciado ou em implementação) · **Released** (entregue a clientes — nenhum item ainda).

Responsável de todos os itens: **Equipe ORBITY**. Prioridade: A (alta), M (média), B (baixa). Versões: 0.1 (atual), 0.2 (ciclo 1), 0.3 (ciclo 2), 0.4 (ciclo 3), 1.x (fases 6–8).
Uma tela existir não torna o item Existing (§40): exige backend, persistência, permissão e teste.

## §5 Command Center

| ID | Nome | Domínio | Descrição | Prior. | Depend. | Estado atual | Desejado | Critério de aceite | Testes | Riscos | Versão |
|---|---|---|---|---|---|---|---|---|---|---|---|
| V4-CMD-01 | KPIs comerciais | Revenue Intel | Receita, leads, oportunidades, conversões, ticket, pipeline, forecast, metas | A | CRM | Existing (`/dashboard`, `intelligence/index.ts`) | Existing | Valores vêm do banco e comparam período anterior | core.test › previsão | — | 0.1 |
| V4-CMD-02 | KPIs financeiros no painel | Financial | Despesas, margem, fluxo de caixa, inadimplência | A | V4-FIN-01 | Released — ciclo 1 (v0.2.0) | Existing | Sem lançamentos mostra "sem dados", nunca estimativa | finance tests | Dados manuais incompletos | 0.2 |
| V4-CMD-03 | CAC, LTV, churn, retenção | Revenue Intel | Indicadores de unidade econômica | M | V4-FIN-01, custos de marketing | Missing | Existing | Fórmula documentada no catálogo de métricas | unit | Exige custo de aquisição registrado | 0.3 |
| V4-CMD-04 | Resumo executivo e "o que mudou/merece atenção" | Intelligence Layer | Respostas às 6 perguntas do §5 | A | V4-IL-01 | Released — ciclo 1 (v0.2.0) | Existing | Cada item cita fonte e período | brain tests | — | 0.2 |
| V4-CMD-05 | Widgets, layouts, favoritos, visões por equipe/unidade/produto | UX | Personalização | M | Design system | Partial — ciclo 1 (mostrar/ocultar widgets por usuário; layouts, favoritos e visões por equipe pendentes) | Existing | Layout persistido por usuário | E2E | Complexidade de UI | 0.4 |
| V4-CMD-06 | Temas claro/escuro | UX | Alternância | B | — | Existing (`app-shell.tsx`) | Existing | Persistência da preferência | — | — | 0.1 |

## §6 Intelligence Layer

| ID | Nome | Domínio | Descrição | Prior. | Depend. | Estado atual | Desejado | Critério de aceite | Testes | Riscos | Versão |
|---|---|---|---|---|---|---|---|---|---|---|---|
| V4-IL-01 | Evidence Engine | Intelligence Layer | Fonte, período, premissas, cálculos, confiança, dados ausentes, limitações | A | — | Released — ciclo 1 (v0.2.0) (`evidence.ts` usado por insights, decisões, cenários, briefings e Brain; recomendações antigas do Sales Intelligence seguem sem a estrutura) | Existing | Nenhum insight salvo sem fato com fonte | unit | — | 0.2 |
| V4-IL-02 | Insights proativos com deduplicação | Intelligence Layer | Regras determinísticas geram insights por domínio | A | V4-IL-01 | Released — ciclo 1 (v0.2.0) | Existing | Rodar duas vezes não duplica insight aberto | integração | Ruído de alertas | 0.2 |
| V4-IL-03 | Decision Engine | Intelligence Layer | Alternativas, aprovação, registro e revisão | A | V4-IL-01 | Released — ciclo 1 (v0.2.0) | Existing | Decisão só muda para aprovada com `approvals:decide` | integração + isolamento | — | 0.2 |
| V4-IL-04 | Outcome Engine | Intelligence Layer | Aceita/rejeitada/alterada/executada/cancelada + resultado observado | A | V4-IL-02 | Released — ciclo 1 (v0.2.0) | Existing | Resultado compara linha de base vs. observado | integração | Causalidade não comprovada | 0.2 |
| V4-IL-05 | Context Engine | Intelligence Layer | Contexto filtrado por identidade e permissões | A | RBAC | Partial (contexto por tenant no orquestrador; sem memória) | Existing | Contexto nunca inclui dado sem permissão | isolamento | Vazamento entre módulos | 0.3 |
| V4-IL-06 | Aprendizado com feedback | Intelligence Layer | Feedback ajusta prioridade das regras | M | V4-IL-04 | Partial — ciclo 1 (precisão por regra; regra com ≥70% de rejeição tem prioridade rebaixada) | Existing | Taxa de aceitação por regra visível | unit | — | 0.4 |

## §7 Business Brain

| ID | Nome | Domínio | Descrição | Prior. | Depend. | Estado atual | Desejado | Critério de aceite | Testes | Riscos | Versão |
|---|---|---|---|---|---|---|---|---|---|---|---|
| V4-BB-01 | Perguntas em linguagem natural | Business Brain | Perguntas mapeadas a análises conhecidas | A | V4-IL-01 | Released — v0.3.0 (perguntas livres via Flávio; motor de investigação com ferramentas autorizadas) | Existing | Pergunta não reconhecida responde que não sabe | integração | Alucinação se usar LLM sem fatos | 0.2 |
| V4-BB-02 | Resposta executiva em 10 partes | Business Brain | Resumo, diagnóstico, dados, evidências, causas, impacto, alternativas, recomendações, plano, indicadores | A | V4-BB-01 | Released — ciclo 1 (v0.2.0) | Existing | As 10 seções presentes; fatos determinísticos | integração | — | 0.2 |
| V4-BB-03 | Executive briefing (diário/semanal/mensal/trimestral) | Business Brain | Briefing persistido | A | V4-IL-02 | Released — ciclo 1 (v0.2.0) | Existing | Briefing salvo em `briefings` com período | integração | — | 0.2 |
| V4-BB-04 | Notificações proativas com preferências | Business Brain | Frequência e prioridade | M | V4-IL-02, notificações | Released — v0.3.0 (preferências por usuário: domínios, prioridade mínima, frequência) | Existing | Usuário escolhe frequência | integração | Excesso de alertas | 0.3 |

## §8 Autonomous Operations

| ID | Nome | Domínio | Descrição | Prior. | Depend. | Estado atual | Desejado | Critério de aceite | Testes | Riscos | Versão |
|---|---|---|---|---|---|---|---|---|---|---|---|
| V4-AO-01 | Níveis de autonomia 1–5 | AI Control Plane | Observe → Controlled Autonomous | A | — | Released — ciclo 1 (v0.2.0) | Existing | Nível impede execução acima do permitido | integração | — | 0.2 |
| V4-AO-02 | Ações sensíveis com aprovação humana | Workflow | Envio e webhooks aprovados | A | — | Released — ciclo 1 (v0.2.0) (D-03 corrigido: ação aprovada executa; webhook só https público; send_message registrado como não entregue) | Existing | Ação aprovada executa uma vez; rejeitada nunca | integração | Execução duplicada | 0.3 |
| V4-AO-03 | Reversão/compensação | Workflow | Desfazer operações críticas | M | V4-AO-02 | Missing | Existing | Compensação registrada | integração | Nem toda ação é reversível | 0.4 |
| V4-AO-04 | Operação "queda de vendas" ponta a ponta | Autonomous Ops | 10 passos do §8.4 | M | V4-IL-*, V4-AO-01 | Missing | Existing | Plano criado, aprovado e medido | E2E | — | 0.4 |

## §9 AI Control Plane

| ID | Nome | Domínio | Descrição | Prior. | Depend. | Estado atual | Desejado | Critério de aceite | Testes | Riscos | Versão |
|---|---|---|---|---|---|---|---|---|---|---|---|
| V4-ACP-01 | Inventário de agentes | AI | Identidade, função, ferramentas, permissões, modelo, limites | A | — | Released — ciclo 1 (v0.2.0) (`/ai-control` → Força de trabalho digital) | Existing | Todos os campos do §9.1 visíveis | integração | — | 0.2 |
| V4-ACP-02 | Governança: pausar, suspender, versionar, rollback | AI | Ciclo de vida | A | V4-ACP-01 | Released — ciclo 1 (v0.2.0) (pausar/suspender/aposentar + versões e rollback existentes) | Existing | Agente pausado não executa | integração | — | 0.2 |
| V4-ACP-03 | Monitoramento | AI | Execuções, falhas, latência, tokens, custo, intervenções | A | — | Released — ciclo 1 (v0.2.0) (métricas por agente: execuções, falhas, latência, tokens, créditos, intervenções) | Existing | Painel por agente e período | integração | — | 0.2 |
| V4-ACP-04 | Kill switch | AI | Agente, grupo, integração, ferramenta, workflow, categoria | A | — | Released — ciclo 1 (v0.2.0) | Existing | Interrompe em < 1 requisição; só `ai:govern` | integração + permissão | Esquecer de checar em novo ponto | 0.2 |
| V4-ACP-05 | Orçamentos de IA | AI | Por organização, agente e modelo | A | billing | Released — ciclo 1 (v0.2.0) (`ai_budgets` + orçamento mensal por agente; roteamento por custo só emite aviso) | Existing | Bloqueio ao atingir teto com `hardStop` | integração | — | 0.2 |
| V4-ACP-06 | Prevenção de conflitos | AI | Duplicidade, ciclos, excesso de chamadas | M | Workflow | Released — ciclo 1 (v0.2.0) (relatório de conflitos: duplicadas, excesso de chamadas, sobreposição, loops) | Existing | Relatório de conflitos | integração | — | 0.3 |
| V4-ACP-07 | Permissões por registro/campo/canal | AI | Escopo fino | M | RBAC | Missing | Existing | Teste negativo por escopo | isolamento | — | 0.4 |

## §10 Financial Intelligence 360

| ID | Nome | Domínio | Descrição | Prior. | Depend. | Estado atual | Desejado | Critério de aceite | Testes | Riscos | Versão |
|---|---|---|---|---|---|---|---|---|---|---|---|
| V4-FIN-01 | Contas a pagar/receber e categorias | Financial | Lançamentos, baixa, centros de custo | A | — | Released — ciclo 1 (v0.2.0) | Existing | CRUD isolado por tenant com auditoria | integração + isolamento | Dados manuais | 0.2 |
| V4-FIN-02 | Fluxo de caixa e projeção | Financial | Realizado + previsto com premissas | A | V4-FIN-01 | Released — ciclo 1 (v0.2.0) | Existing | Projeção mostra premissas e incerteza | unit (cálculo) | — | 0.2 |
| V4-FIN-03 | DRE gerencial | Financial | Por grupo de categoria | A | V4-FIN-01 | Released — ciclo 1 (v0.2.0) | Existing | Totais batem com lançamentos | unit | Não substitui contabilidade | 0.2 |
| V4-FIN-04 | Orçamentos e desvios | Financial | Orçado vs. realizado | M | V4-FIN-01 | Released — ciclo 1 (v0.2.0) | Existing | Desvio por categoria/mês | integração | — | 0.2 |
| V4-FIN-05 | Rentabilidade por produto/cliente/unidade | Financial | Margens | M | V4-FIN-01, produtos | Partial — ciclo 1 (margem direta por cliente e produto quando vinculados; unidade e rateio de custos fixos pendentes) | Existing | Requer vínculo do lançamento | integração | Custos não alocados | 0.3 |
| V4-FIN-06 | Ponto de equilíbrio, liquidez, capital | Financial | Indicadores | M | V4-FIN-02 | Partial — ciclo 1 (ponto de equilíbrio; liquidez e capital pendentes) | Existing | Fórmula exibida | unit | — | 0.2–0.3 |
| V4-FIN-07 | Assistente financeiro | Financial | Perguntas do §10.4 | M | V4-BB-01 | Released — ciclo 1 (v0.2.0) (6 intenções determinísticas; nunca estima salário) | Existing | Explica cálculo e fonte | integração | — | 0.3 |
| V4-FIN-08 | Integrações financeiras (Stripe, bancos, ERP, fiscal) | Integrations | Sincronização | M | provedores | Blocked (credenciais/contratos) | Existing | Sem integração efetiva, nada aparece como conectado | integração | Regulatório | 0.4+ |

## §11 Strategy Simulator

| ID | Nome | Domínio | Descrição | Prior. | Depend. | Estado atual | Desejado | Critério de aceite | Testes | Riscos | Versão |
|---|---|---|---|---|---|---|---|---|---|---|---|
| V4-SIM-01 | Simulações (preço, custo, contratação, volume, conversão…) | Strategy | Modelo determinístico | A | V4-FIN-01, KPIs | Released — ciclo 1 (v0.2.0) | Existing | Mesmo input → mesmo output; premissas visíveis | unit | Elasticidade estimada | 0.2 |
| V4-SIM-02 | Cenários otimista/base/pessimista/personalizado | Strategy | Faixas | A | V4-SIM-01 | Released — ciclo 1 (v0.2.0) | Existing | Três cenários + personalizado | unit | — | 0.2 |
| V4-SIM-03 | Histórico, comparação e aprovação de cenários | Strategy | Persistência | M | V4-SIM-01 | Released — ciclo 1 (v0.2.0) | Existing | Aprovação exige permissão | integração | — | 0.2 |
| V4-SIM-04 | Resultado real posterior | Strategy | Comparar previsto vs. real | M | V4-IL-04 | Missing | Existing | Vinculado ao Outcome Engine | integração | — | 0.3 |

## §12 Market Radar

| ID | Nome | Domínio | Descrição | Prior. | Depend. | Estado atual | Desejado | Critério de aceite | Testes | Riscos | Versão |
|---|---|---|---|---|---|---|---|---|---|---|---|
| V4-MR-01 | Cadastro de concorrentes e comparações | Market | Manual + menções em conversas | M | Closer | Missing | Existing | Concorrente vinculado a perdas | integração | — | 0.4 |
| V4-MR-02 | Monitoramento externo (preços, notícias, regulação) | Market | Fontes externas | B | fontes licenciadas | Blocked (sem fonte licenciada) | Existing | Toda informação com fonte, data e confiabilidade | integração | Termos de uso das fontes | 1.x |

## §13 Customer 360

| ID | Nome | Domínio | Descrição | Prior. | Depend. | Estado atual | Desejado | Critério de aceite | Testes | Riscos | Versão |
|---|---|---|---|---|---|---|---|---|---|---|---|
| V4-C360-01 | Perfil e timeline unificados | Customer | Cadastro, conversas, oportunidades, tarefas, pagamentos | A | CRM, Closer, Financial | Partial (detalhe da oportunidade; sem visão por cliente) | Existing | Uma tela com todos os eventos do cliente | integração | — | 0.3 |
| V4-C360-02 | Health Score, churn, expansão, próxima melhor ação | Customer | Inteligência do cliente | M | V4-C360-01 | Partial (Health Score da plataforma, não do cliente do cliente) | Existing | Recomendação fundamentada | integração | — | 0.3 |

## §14 Knowledge Graph

| ID | Nome | Domínio | Descrição | Prior. | Depend. | Estado atual | Desejado | Critério de aceite | Testes | Riscos | Versão |
|---|---|---|---|---|---|---|---|---|---|---|---|
| V4-KG-01 | Entidades e relacionamentos | Data | Modelo relacional existente + consultas relacionais | M | CRM | Partial (relações por chaves estrangeiras; sem consultas compostas) | Existing | Pergunta do §14.3 respondida com SQL parametrizado | integração | Infra de grafo desnecessária | 0.4 |

## §15 Marketplace · §16 Digital Workforce · §17 Benchmark

| ID | Nome | Domínio | Descrição | Prior. | Depend. | Estado atual | Desejado | Critério de aceite | Testes | Riscos | Versão |
|---|---|---|---|---|---|---|---|---|---|---|---|
| V4-MKT-01 | Catálogo, instalação, permissões de extensões | Marketplace | Ecossistema | B | SDK, sandbox | Missing | Existing | Extensão instalada só com permissões aprovadas | segurança | Código de terceiros | 1.x |
| V4-MKT-02 | Developer Portal, SDK, monetização | Marketplace | Desenvolvedores | B | V4-MKT-01 | Missing | Existing | Revisão antes de publicar | — | — | 1.x |
| V4-DW-01 | Força de trabalho digital (inventário + indicadores) | AI | Agente como "colaborador digital" | M | V4-ACP-01, V4-ACP-03 | Released — ciclo 1 (v0.2.0) | Existing | Agente distinguido de humano | integração | — | 0.2 |
| V4-DW-02 | Planejador de capacidade de agentes | AI | Distribuição e custos | B | V4-DW-01 | Missing | Existing | — | — | — | 0.4 |
| V4-BMK-01 | Benchmark por segmento/porte | Data | Comparações anônimas | B | base multi-cliente, LGPD | Blocked (sem amostra real e base legal) | Existing | Nunca exibir benchmark inventado; amostra mínima e metodologia | estatística | Dados frágeis | 1.x |

## §18 Document Intelligence · §19 Value Realization

| ID | Nome | Domínio | Descrição | Prior. | Depend. | Estado atual | Desejado | Critério de aceite | Testes | Riscos | Versão |
|---|---|---|---|---|---|---|---|---|---|---|---|
| V4-DOC-01 | Upload, extração, OCR, classificação | Documents | PDF/DOCX/XLSX/imagens | M | storage, OCR | Missing (só texto na base de conhecimento) | Existing | Extração com origem e versão | integração | Custo de OCR | 0.4 |
| V4-DOC-02 | Perguntas sobre documentos e vencimentos | Documents | Assistente | M | V4-DOC-01 | Missing | Existing | Resposta cita documento e trecho | integração | — | 0.4 |
| V4-VAL-01 | Value dashboard (horas, processos, conversões influenciadas) | Value | Mensuração de valor | A | V4-IL-04, ai_executions | Missing | Existing | Separa observado, associado e causal | integração | Superestimar valor | 0.3 |
| V4-VAL-02 | Relatório mensal "What ORBITY-NEPTUNE helped…" | Value | Relatório | M | V4-VAL-01 | Missing | Existing | Metodologia e confiança no relatório | integração | — | 0.3 |

## §20–§24 Prospect.AI, Closer.AI, CRM, Sales Intelligence, Revenue Operations

| ID | Nome | Domínio | Descrição | Prior. | Depend. | Estado atual | Desejado | Critério de aceite | Testes | Riscos | Versão |
|---|---|---|---|---|---|---|---|---|---|---|---|
| V4-PRO-01 | ICP, scoring explicável, importação, exportação | Prospecting | Núcleo do Prospect | A | CRM | Existing | Existing | — | pure, core, prospect-crm | — | 0.1 |
| V4-PRO-02 | Enriquecimento em cascata, intenção, visitantes, job change, tecnografia | Prospecting | Dados externos | M | provedores de dados | Blocked (contratos de dados/LGPD) | Existing | Fonte e base legal por dado | integração | LGPD | 0.4+ |
| V4-PRO-03 | Data Quality Center, Next Best Prospect | Prospecting | Qualidade e priorização | M | V4-PRO-01 | Partial (score com confiança) | Existing | Relatório de completude | unit | — | 0.3 |
| V4-CLO-01 | Inbox omnichannel, IA com aprovação, base de conhecimento, SLA | Engagement | Núcleo do Closer | A | — | Existing | Existing | — | core, closer-workflows | — | 0.1 |
| V4-CLO-02 | Envio real pelos canais | Engagement | WhatsApp/e-mail | A | credenciais | Partial (D-01: marca `sent` sem envio) | Existing | Status `sent` só com confirmação do provedor | integração | Falsa alegação de entrega | 0.2 (correção) |
| V4-CLO-03 | Conversation intelligence, objeções, concorrentes, coaching, dialer, reuniões | Engagement | Análise avançada | M | transcrição | Missing | Existing | Consentimento registrado | integração | Privacidade | 0.4+ |
| V4-CRM-01 | Empresas, contatos, leads, oportunidades, atividades, tarefas, reuniões, propostas | CRM | Objetos centrais | A | — | Existing | Existing | — | core, prospect-crm | — | 0.1 |
| V4-CRM-02 | Múltiplos pipelines, campos personalizados, blueprint, team selling, splits | CRM | CRM avançado | M | V4-CRM-01 | Partial (tabela `pipelines`; UI única; sem campos personalizados) | Existing | Pipeline escolhido por oportunidade | integração | Migração de dados | 0.3 |
| V4-SI-01 | Dashboards, forecast, funil, recomendações, NL analytics | Revenue Intel | Núcleo | A | CRM | Existing | Existing | — | core | — | 0.1 |
| V4-SI-02 | Forecast submission/rollup/accuracy, deal risk | Revenue Intel | Forecast gerencial | M | V4-SI-01 | Missing | Existing | Acurácia histórica calculada | unit | — | 0.3 |
| V4-RO-01 | Metas e comissões com acelerador | RevOps | Compensação | A | — | Existing (`goals`) | Existing | — | pure (comissão) | — | 0.1 |
| V4-RO-02 | Territórios, account planning, CPQ, contratos (CLM), renovações | RevOps | RevOps avançado | M | Financial, CRM | Missing | Existing | Contrato vinculado a cliente e receita | integração | — | 0.4 |

## §25–§31 CS, Hub, Workspace, Automação, Dados, IA, Integrações, Billing

| ID | Nome | Domínio | Descrição | Prior. | Depend. | Estado atual | Desejado | Critério de aceite | Testes | Riscos | Versão |
|---|---|---|---|---|---|---|---|---|---|---|---|
| V4-CS-01 | Health Score, interações, renovações (plataforma) | Customer Success | CS da ORBITY | A | — | Existing (`/customer-success`) | Existing | — | pure (health) | — | 0.1 |
| V4-CS-02 | Portal do cliente e de parceiros (PRM) | Hub | Portais externos | B | auth externa | Missing | Existing | Acesso isolado ao próprio cliente | isolamento | — | 1.x |
| V4-WS-01 | Projetos (kanban, Gantt, sprints), tempo, colaboração, assinatura eletrônica | Workspace | Gestão de projetos | B | — | Missing (só tarefas) | Existing | — | — | Escopo grande, baixa diferenciação | 1.x |
| V4-AUT-01 | Event Engine + Workflow Engine | Automation | Gatilhos, condições, esperas, aprovações, DLQ, versões | A | — | Existing | Existing | — | core, closer-workflows | — | 0.1 |
| V4-AUT-02 | Next Best Action, orquestração multiagente, compensação | Automation | Autonomia | M | V4-IL-*, V4-ACP-* | Missing | Existing | — | integração | — | 0.4 |
| V4-DAT-01 | Catálogo de métricas, linhagem, exportação, LGPD | Data | Governança | A | — | Existing (`data-intelligence`) | Existing | — | core (LGPD) | — | 0.1 |
| V4-DAT-02 | Reverse ETL, Data Quality Center, linhagem de recomendações | Data | Dados avançados | M | V4-IL-04 | Missing | Existing | — | — | — | 0.4 |
| V4-AI-01 | Agentes, avaliação, versões, rollback, provedores | AI | AI Command Center | A | — | Existing | Existing | — | core, intelligence-ai, ai-provider | — | 0.1 |
| V4-AI-02 | Memória de IA e Agent Builder | AI | Agentes personalizados | M | V4-ACP-* | Missing | Existing | Memória com permissão e exclusão | isolamento | Privacidade | 0.4 |
| V4-INT-01 | Catálogo com validação real de credenciais | Integrations | Conexão | A | — | Existing (`integrations/index.ts`) | Existing | — | — | — | 0.1 |
| V4-INT-02 | Sincronização, rate limit por provedor, revogação OAuth | Integrations | Operação | M | V4-INT-01 | Missing | Existing | Log e retry por sincronização | integração | APIs de terceiros | 0.3+ |
| V4-BIL-01 | Planos, créditos, entitlements, excedentes autorizados, cupons | Billing | Monetização | A | — | Existing (preços "A definir") | Existing | — | core, admin-billing | Preço não validado | 0.1 |
| V4-BIL-02 | Cobrança real, webhooks de pagamento, add-ons, licenças de agentes | Billing | Cobrança | A | provedor de pagamento | Blocked (credenciais + validação comercial de preços) | Existing | Nenhuma cobrança sem autorização | integração | Financeiro | 0.3 |

## §32–§38 UX, Admin, Segurança, Arquitetura, Qualidade, Onboarding, Mobile

| ID | Nome | Domínio | Descrição | Prior. | Depend. | Estado atual | Desejado | Critério de aceite | Testes | Riscos | Versão |
|---|---|---|---|---|---|---|---|---|---|---|---|
| V4-UX-01 | Design system, sidebar, busca global, command palette, notificações, temas | UX | Navegação unificada | A | — | Existing | Existing | — | — | — | 0.1 |
| V4-UX-02 | Densidade configurável, favoritos, histórico | UX | Preferências | B | — | Missing | Existing | — | E2E | — | 0.4 |
| V4-ADM-01 | Usuários, cargos, equipes, auditoria, flags, incidentes, cupons, painel global | Admin | Administração | A | — | Existing | Existing | — | admin-billing | — | 0.1 |
| V4-ADM-02 | Controle global das capacidades v4 | Admin | Flags por módulo novo | M | ciclo 1 | Planned | Existing | Módulo v4 desligável por flag | integração | — | 0.3 |
| V4-SEC-01 | Criptografia, sessões, 2FA, auditoria, rate limit, guardrails de IA | Segurança | Controles base | A | — | Existing (rate limit em memória) | Existing | — | core, pure | — | 0.1 |
| V4-SEC-02 | RLS no Postgres | Segurança | Isolamento no banco | A | Postgres | Missing | Existing | Consulta sem tenant retorna vazio | isolamento | Desempenho | 0.3 |
| V4-SEC-03 | CSP, HSTS, varredura de dependências, testes de vulnerabilidade | Segurança | Endurecimento | A | — | Missing | Existing | CI falha com vulnerabilidade alta | CI | — | 0.3 |
| V4-SEC-04 | Retenção automática, backups, DR | Segurança/LGPD | Ciclo de vida de dados | M | infra | Partial (campo `retention_days` sem rotina) | Existing | Purga agendada auditada | integração | — | 0.3 |
| V4-ARC-01 | Redis para rate limit, cache e jobs | Arquitetura | Escala horizontal | A | infra | Missing | Existing | Funciona com 2+ instâncias | carga | — | 0.3 |
| V4-ARC-02 | Observabilidade (OpenTelemetry, SLOs) | Arquitetura | Operação | M | infra | Partial (`/api/health`) | Existing | Traces por requisição | — | — | 0.4 |
| V4-QA-01 | E2E, carga, acessibilidade, migração, recuperação | Qualidade | Testes | A | — | Missing | Existing | Suíte no CI | — | — | 0.3 |
| V4-ONB-01 | Diagnóstico empresarial inicial com sugestão de configuração | Onboarding | §37 | A | Business Brain | Partial (onboarding sem diagnóstico) | Existing | Configuração sugerida a partir das respostas | integração | — | 0.3 |
| V4-AUTH-01 | 2FA por SMS/e-mail | Identity | §35 | M | SMS/SMTP | Missing | Existing | Código expira e é auditado | integração | Custo SMS | 0.3 |
| V4-MOB-01 | PWA, notificações push, aprovações no celular | Mobile | §38 | M | — | Partial (manifest + service worker; sem push) | Existing | Aprovação funciona em 375px | E2E | — | 0.3 |
| V4-I18N-01 | Internacionalização completa | Plataforma | pt-BR/en/es | B | — | Partial (só rótulos de navegação em `en.json`) | Existing | Telas sem texto fixo | — | — | 0.4 |

## Adições ao Master Prompt 4.0 (v0.3.0)
| ID | Nome | Domínio | Descrição | Prioridade | Dependências | Estado atual | Estado desejado | Responsável | Critério de aceite | Testes | Riscos | Versão |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| V4-COL-01 | Sugestões ilimitadas e versionadas | IA transversal | Gerar novas sugestões sem limite; cada geração é uma versão | A | V4-AI | Released — v0.3.0 | Existing | Equipe ORBITY | 25 regenerações seguidas funcionam; nada é sobrescrito | `ai-collab.test.ts` | Custo de créditos | 0.3 |
| V4-COL-02 | Descartar com A/B/C | Closer.AI / Prospect.AI | Gerar outra, pedir com instruções, escrever manualmente | A | V4-COL-01 | Released — v0.3.0 | Existing | Equipe ORBITY | Opções na própria tela, sem perder conteúdo | `ai-collab.test.ts` + navegador | — | 0.3 |
| V4-COL-03 | Assistente de Respostas | IA transversal | 10 operações + instrução livre + melhorar trecho selecionado | A | V4-COL-01 | Released — v0.3.0 | Existing | Equipe ORBITY | Trecho fora da seleção permanece idêntico | `ai-collab.test.ts` | — | 0.3 |
| V4-COL-04 | Edição manual protegida | IA transversal | Edição salva como versão humana; IA nunca sobrescreve | A | V4-COL-01 | Released — v0.3.0 | Existing | Equipe ORBITY | Edição preservada após nova geração | `ai-collab.test.ts` + navegador | — | 0.3 |
| V4-COL-05 | Histórico, comparação e recuperação | IA transversal | Autor, operação, instrução, horário; diff por palavras | A | V4-COL-01 | Released — v0.3.0 | Existing | Equipe ORBITY | Recuperar e continuar qualquer versão não enviada | `ai-collab.test.ts` | — | 0.3 |
| V4-COL-06 | Envio com política e sem duplicidade | Closer.AI | Confirmação, aprovação conforme cargo, bloqueio de duplicado, registro do que foi enviado | A | V4-COL-01 | Released — v0.3.0 | Existing | Equipe ORBITY | Descartada nunca é enviada; segundo envio recusado | `ai-collab.test.ts` + navegador | Canal ainda sem envio real | 0.3 |
| V4-COL-07 | Aprendizado com descartes | IA transversal | Versões rejeitadas entram como "não repita"; checagem de similaridade | M | V4-COL-01 | Partial — v0.3.0 (por rascunho; sem modelo de preferências da organização) | Existing | Equipe ORBITY | Nova sugestão diferente das rejeitadas | `ai-collab.test.ts` | — | 0.4 |
| V4-COL-08 | Métricas de sugestões | AI Control Plane / Sales Intelligence | Geradas, enviadas, descartadas, regenerações, % editadas, tempo, motivos, por agente/pessoa/equipe, conversão associada | M | V4-COL-01 | Released — v0.3.0 | Existing | Equipe ORBITY | Números conferidos em base conhecida | `ai-collab.test.ts` | Associação ≠ causalidade | 0.3 |
| V4-BBF-01 | Flávio como interface do Business Brain | Business Brain | Conversa livre em `/business-brain` | A | V4-BB | Released — v0.3.0 | Existing | Equipe ORBITY | Pergunta inédita gera investigação com etapas e fontes | `brain-flavio.test.ts` + navegador | — | 0.3 |
| V4-BBF-02 | Motor de investigação com ferramentas autorizadas | Intelligence Layer | Registro de ferramentas com permissão, auditoria e limite; modelo nunca acessa o banco | A | V4-BBF-01 | Released — v0.3.0 | Existing | Equipe ORBITY | Ferramenta não autorizada recusada mesmo se o modelo pedir | `brain-flavio.test.ts` | Ciclo com IA real só testado com SDK simulado | 0.3 |
| V4-BBF-03 | Continuidade e investigações salvas | Business Brain | Contexto entre perguntas; retomar, nova, apagar, exportar | A | V4-BBF-01 | Released — v0.3.0 | Existing | Equipe ORBITY | "O que podemos fazer?" usa a investigação anterior | `brain-flavio.test.ts` + navegador | — | 0.3 |
| V4-BBF-04 | Ações a partir de recomendações | Business Brain | Tarefa, decisão, cenário com confirmação e permissão atual | A | V4-BBF-01 | Released — v0.3.0 | Existing | Equipe ORBITY | Sem confirmação nada acontece; não executa duas vezes | `brain-flavio.test.ts` | — | 0.3 |
| V4-BBF-05 | Fontes de módulos ainda não construídos | Business Brain | Market Radar, Benchmark, Document Intelligence, Revenue Operations | B | módulos | Blocked (módulos não existem; ferramenta informa) | Existing | Equipe ORBITY | Resposta diz o que falta | `brain-flavio.test.ts` | — | 0.5 |
