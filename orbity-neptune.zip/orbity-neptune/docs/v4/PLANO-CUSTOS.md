# Plano de custos

Preços dos planos continuam **"A definir"** até a validação comercial. Este documento trata só de custos (o que a ORBITY paga) e de como eles se relacionam com os créditos de IA.

## 1. Custo de IA por crédito

Regra implementada (`creditsFor` em `src/server/ai/providers/index.ts`): **1 crédito a cada 1.000 tokens** (entrada + saída somados), mínimo 1 por execução real. Respostas simuladas custam 0.

Preços oficiais por milhão de tokens (US$):

| Modelo | Entrada | Saída |
|---|---|---|
| Claude Opus 5.5 (`claude-opus-5-5`, padrão do app) | 4,00 | 20,00 |
| Claude Sonnet 5.5 | 2,00 | 10,00 |
| Claude Haiku 5.5 (prompts até 100 mil tokens) | 0,10 | 0,50 |

Custo de 1 crédito (1.000 tokens) conforme a proporção entrada/saída:

| Modelo | 100% entrada | 80% entrada / 20% saída | 50% / 50% | 100% saída |
|---|---|---|---|---|
| Opus 5.5 | US$ 0,0040 | US$ 0,0072 | US$ 0,0120 | US$ 0,0200 |
| Sonnet 5.5 | US$ 0,0020 | US$ 0,0036 | US$ 0,0060 | US$ 0,0100 |
| Haiku 5.5 | US$ 0,0001 | US$ 0,00018 | US$ 0,0003 | US$ 0,0005 |

Cálculo: `custo = (tokens_entrada × preço_entrada + tokens_saída × preço_saída) / 1.000.000`. Exemplo Opus 80/20: 800 × 4/10⁶ + 200 × 20/10⁶ = 0,0032 + 0,0040 = US$ 0,0072.

Observações:
- No Opus 5.5 o raciocínio interno (thinking) está sempre ligado e é cobrado como saída; ele entra em `output_tokens` e, portanto, nos créditos. Por isso a proporção real de saída tende a ser maior do que o texto visível sugere.
- O nível de esforço (`ANTHROPIC_EFFORT`, padrão `medium`) é a principal alavanca de custo: `low` para chat e classificação, `medium`/`high` para análises.
- Cache de prompt reduz o custo de entrada repetida (leituras de cache do Opus 5.5 custam US$ 0,20 por milhão). Ainda não está implementado no provedor.

## 2. Implicação para margem

Hoje **um crédito vale o mesmo para qualquer modelo**, mas o custo de um crédito no Opus 5.5 é cerca de 40 vezes o do Haiku 5.5.

O preço de excedente está parametrizado em R$ 0,02 por crédito (`OVERAGE_CENTS_PER_CREDIT`, "hipótese a validar"). Com Opus 5.5 na proporção 80/20, o excedente só cobre o custo de API se o câmbio for menor que **R$ 2,78 por dólar** (0,02 ÷ 0,0072). Confira a cotação vigente: acima desse valor, cada crédito excedente com Opus é vendido abaixo do custo, sem contar infraestrutura e impostos.

Opções para a validação comercial (não implementadas, decisão de negócio):
1. Créditos ponderados por modelo (ex.: Opus consome mais créditos por 1.000 tokens que Haiku).
2. Roteamento por custo no AI Control Plane: tarefas simples (classificação, qualificação, resumo curto) em Haiku 5.5; análises executivas em Opus 5.5.
3. Recalcular o preço do excedente a partir do custo médio real medido em `ai_executions`.

## 3. Infraestrutura (direcionadores, sem valores inventados)

| Direcionador | Cresce com | Como medir |
|---|---|---|
| Postgres gerenciado (+ pgvector, PITR, réplica) | volume de leads, mensagens, eventos, embeddings | tamanho do banco e IOPS |
| Instâncias web | usuários simultâneos | CPU/latência p95 |
| Worker | eventos por minuto | profundidade da fila `events` |
| Redis (ciclo 3) | instâncias e rate limit | memória |
| Armazenamento de documentos (futuro) | Document Intelligence | GB armazenados |
| OCR/transcrição (futuro) | páginas e minutos processados | uso por organização |
| Canais (WhatsApp) | conversas iniciadas | cobrado pela Meta ao cliente ou repassado |

Os medidores de uso por organização já existem em `usage_records` e no `entitlements`; o próximo passo é registrar o custo real de IA por execução (tokens × preço do modelo) em `ai_executions` para o painel global calcular margem por cliente.
