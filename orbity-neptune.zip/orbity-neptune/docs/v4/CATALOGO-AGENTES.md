# Catálogo de agentes de IA

Fonte: `src/server/ai/agents/catalog.ts` (criados para cada organização no cadastro). Execução: `runAgent` em `src/server/ai/orchestrator.ts` com guardrails, limites, créditos, auditoria e fallback de provedor (Anthropic → OpenAI → heurística local simulada).

## Níveis de autonomia (AI Control Plane, §8.2)

| Nível | Nome | Significado |
|---|---|---|
| 1 | Observe | Só monitora |
| 2 | Analyze | Analisa e recomenda |
| 3 | Prepare | Prepara ações (rascunhos) |
| 4 | Approve & Execute | Executa após aprovação humana |
| 5 | Controlled Autonomous | Executa sozinho dentro de limites e políticas; ações sensíveis continuam exigindo aprovação |

Migração `0001_ciclo1_v4.sql`: `suggest → 2`, `approve → 4`, `autonomous → 5`. A coluna antiga `autonomy` permanece por compatibilidade até o AI Control Plane do ciclo 1 ser concluído.

## Agentes

| Chave | Nome | Função | Ferramentas | Permissão | Autonomia atual → nível |
|---|---|---|---|---|---|
| `executive` | ORBITY AI (Executivo) | Coordenar agentes, responder sobre a operação, sugerir ações | metrics.read, crm.read, recommendations.read | intelligence:read | suggest → 2 |
| `prospecting` | Agente de Prospecção | Encontrar e priorizar empresas do ICP | icp.read, companies.search | prospect:read | suggest → 2 |
| `research` | Agente de Pesquisa | Resumir informações autorizadas sobre empresas | companies.read | prospect:read | suggest → 2 |
| `scoring` | Agente de Lead Scoring | Explicar pontuação dos leads | leads.read | prospect:read | autonomous → 5 |
| `outreach` | Agente de Abordagem | Gerar mensagens de abordagem | leads.read, templates.read | prospect:write | approve → 4 |
| `support_chat` | Agente de Atendimento | Responder clientes pela base de conhecimento | knowledge.search | closer:write | approve → 4 |
| `qualification` | Agente de Qualificação | Classificar intenção (BANT) | conversations.read | closer:read | autonomous → 5 |
| `follow_up` | Agente de Follow-up | Recuperar conversas e oportunidades paradas | conversations.read, opportunities.read | closer:write | approve → 4 |
| `intelligence` | Agente de Inteligência | Analisar funil e recomendar com evidências | metrics.read | intelligence:read | suggest → 2 |
| `reporting` | Agente de Relatórios | Gerar relatórios gerenciais | metrics.read | intelligence:read | suggest → 2 |
| `automation` | Agente de Automação | Rascunhos de automação por linguagem natural | workflows.draft | automations:write | approve → 4 |
| `support` | Agente de Suporte da Plataforma | Ajudar usuários e abrir chamados | docs.search, tickets.create | support:use | suggest → 2 |

Limites padrão por agente: 4.000 tokens por execução e 500 créditos por dia (`ai_agents.limits`). Agentes de nível 5 (`scoring`, `qualification`) só fazem leitura e classificação; nenhum deles envia mensagens.

## Correspondência com a Digital Workforce (§16)

| Exemplo do prompt | Agente atual | Lacuna |
|---|---|---|
| Prospect Agent | `prospecting` | — |
| Research Agent | `research` | Sem fontes externas conectadas |
| Sales Agent | `outreach`, `follow_up` | — |
| Support Agent | `support_chat`, `support` | — |
| Data Analyst Agent | `intelligence`, `reporting` | — |
| Finance Agent | — | Criar após Financial Intelligence (ciclo 2) |
| Customer Success Agent | — | Criar com Customer 360 (ciclo 2) |
| Project / Operations Agent | — | Depende do Business Workspace e de Autonomous Operations |

Campos do inventário do §9.1 ainda ausentes (dono, domínio, orçamento mensal, status pausado/suspenso) foram adicionados ao esquema no ciclo 1 (`owner_user_id`, `domain`, `monthly_credit_budget`, `status`) e estão em implementação.
