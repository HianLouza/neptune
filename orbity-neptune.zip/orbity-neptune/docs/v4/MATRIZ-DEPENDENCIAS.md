# Matriz de dependências entre módulos

Setas: "A → B" significa **B depende de A** (A precisa existir antes). Módulos tracejados estão planejados.

```mermaid
flowchart LR
  subgraph Core["Núcleo (Fase 1)"]
    AUTH[Identidade + 2FA]
    TEN[Tenancy + RBAC]
    AUD[Auditoria]
    EVT[Event Engine]
    WF[Workflow Engine]
    BIL[Billing + créditos]
    AI[Orquestrador de IA + guardrails]
  end
  subgraph Comercial["Núcleo comercial (Fase 2)"]
    CRM[CRM]
    PRO[Prospect.AI]
    CLO[Closer.AI]
    SI[Sales Intelligence]
    GOA[Metas e comissões]
    INT[Integrações]
  end
  subgraph Ciclo1["Ciclo 1 (em implementação)"]
    EVI[Evidence Engine]
    FIN[Financial Intelligence]
    IL[Insights + Decision + Outcome]
    BB[Business Brain + Command Center]
    SIM[Strategy Simulator]
    ACP[AI Control Plane]
  end
  subgraph Futuro["Ciclos 2+"]
    VAL[Value Realization]:::plan
    C360[Customer 360]:::plan
    ONB[Onboarding com diagnóstico]:::plan
    AO[Autonomous Operations]:::plan
    DOC[Document Intelligence]:::plan
    MKT[Marketplace]:::plan
  end

  AUTH --> TEN --> CRM
  TEN --> AUD
  CRM --> PRO & CLO & SI & GOA
  EVT --> WF
  CRM --> EVT
  CLO --> EVT
  AI --> CLO & SI
  BIL --> AI
  INT --> CLO

  EVI --> IL & BB & SIM & FIN
  SI --> IL
  CLO --> IL
  PRO --> IL
  FIN --> IL & BB & SIM
  IL --> BB
  SI --> BB & SIM
  AI --> ACP
  WF --> ACP

  IL --> VAL
  ACP --> VAL
  FIN --> C360
  CRM --> C360
  CLO --> C360
  BB --> ONB
  IL --> AO
  ACP --> AO
  WF --> AO
  ACP --> MKT

  classDef plan stroke-dasharray: 4 3;
```

## Tabela

| Módulo | Depende de | É pré-requisito para |
|---|---|---|
| Identidade, Tenancy, RBAC | — | todos |
| Event Engine | CRM, Closer (publicadores) | Workflow Engine, notificações |
| Workflow Engine | Event Engine | AI Control Plane (kill switch de workflow), Autonomous Operations |
| Orquestrador de IA | Billing (créditos), guardrails | Closer, Sales Intelligence, Business Brain (narração opcional), AI Control Plane |
| Evidence Engine | — | Insights, Business Brain, Simulador, Financeiro |
| Financial Intelligence | Tenancy, RBAC (`finance:*`) | Command Center, Business Brain, Simulador, Customer 360 |
| Insights / Decision / Outcome | Evidence, Sales Intelligence, Closer, Prospect, Financeiro | Business Brain, Value Realization, Autonomous Operations |
| Business Brain + Command Center | Insights, Sales Intelligence, Financeiro | Onboarding com diagnóstico |
| Strategy Simulator | Evidence, Sales Intelligence, Financeiro | Decision Engine (cenário vinculado à decisão) |
| AI Control Plane | Orquestrador, Workflow Engine | Autonomous Operations, Value Realization, Marketplace (agentes de terceiros) |
| Value Realization | Outcome Engine, AI Control Plane | Relatório mensal de valor |
| Customer 360 | CRM, Closer, Financeiro | Expansion Intelligence, Customer Success Agent |
| RLS (habilitador) | Postgres em produção | Marketplace, portais externos, operação multi-cliente em escala |
