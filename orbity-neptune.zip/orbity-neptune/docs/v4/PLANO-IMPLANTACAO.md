# Plano de implantação

Complementa `docs/operacao/deploy.md`. O CI atual (`.github/workflows/ci.yml`) **só valida** (typecheck, testes, build); o deploy automático descrito abaixo ainda não está configurado.

## 1. Ambientes

| Ambiente | Banco | Processos | Dados |
|---|---|---|---|
| Desenvolvimento | PGlite local (`.data/pglite`) | `npm run dev` + `npm run worker` opcional | Organização de demonstração (`npm run db:seed`) |
| Homologação | Postgres gerenciado com pgvector | web + worker | Dados sintéticos; seed de demonstração permitido |
| Produção | Postgres gerenciado com pgvector, PITR e réplica | web (2+ instâncias) + worker | Somente dados reais; seed bloqueado com `APP_ENV=production` |

## 2. Componentes

| Componente | Requisito | Observação |
|---|---|---|
| Aplicação web | Node 22, `npm run build` + `next start` | Stateless, exceto o rate limit em memória (Redis no ciclo 3) |
| Worker | `npm run worker` (`scripts/worker.ts`) | Processa o outbox de eventos; uma instância basta, `claim` otimista permite mais |
| PostgreSQL | 15+ com extensão `vector` | Migrações aplicam `CREATE EXTENSION IF NOT EXISTS vector` |
| Redis | Opcional hoje (`REDIS_URL` está no `.env.example`, mas **não é usado pelo código**) | Necessário para várias instâncias |
| Armazenamento de arquivos | Ainda não usado | Necessário para Document Intelligence |

## 3. Segredos

Obrigatórios: `DATABASE_URL`, `APP_URL`, `APP_ENV=production`, `SESSION_SECRET` (64+ caracteres aleatórios), `ENCRYPTION_KEY` (32 bytes em base64).
Opcionais: `ANTHROPIC_API_KEY` (+ `ANTHROPIC_MODEL`, `ANTHROPIC_EFFORT`), `OPENAI_*`, OAuth Google/Microsoft, Stripe/Mercado Pago/Asaas, WhatsApp, `SMTP_URL`, `OVERAGE_CENTS_PER_CREDIT` (preço de excedente) e `WHATSAPP_APP_SECRET` (assinatura do webhook) — ambos ausentes do `.env.example`.
Guardar em cofre do provedor de hospedagem; nunca no repositório (`.env` está no `.gitignore`). Trocar `ENCRYPTION_KEY` exige recriptografar as credenciais de integrações.

## 4. Migrações

1. Migrações versionadas em `drizzle/` (geradas com `npm run db:generate`).
2. Executar `npm run db:migrate` **antes** de publicar a versão nova.
3. Migrações só aditivas (expand/contract): colunas novas com padrão; remoções em versão posterior.
4. `syncSystemRoles` roda junto com a migração e acrescenta permissões novas aos cargos de sistema.
5. A migração `0001_ciclo1_v4.sql` cria 9 tabelas e 5 colunas em `ai_agents`, e converte `autonomy` em `autonomy_level`.

## 5. Pipeline proposto

1. Pull request → CI (typecheck, testes, build) — **existe**.
2. Acrescentar ao CI: `npm audit --audit-level=high`, CodeQL, testes E2E (Playwright) — ciclo 2.
3. Merge em `develop` → deploy automático em homologação — **a configurar**.
4. Tag `vX.Y.Z` → aprovação manual → migração → deploy gradual em produção com feature flags — **a configurar**.
5. Pós-deploy: `/api/health`, taxa de erro, latência, fila de eventos (status `dead`).

## 6. Backups e recuperação

- PITR com retenção de 7 dias no mínimo; backup diário lógico (`pg_dump`) guardado em outra região.
- Objetivos iniciais: RPO 15 min, RTO 4 h.
- Teste de restauração trimestral registrado como incidente de manutenção.
- Exportação por organização (`/api/export`) atende portabilidade, não substitui backup.

## 7. Checklist antes do primeiro cliente real

- [ ] Correção D-01 (envio real) e D-03 (ação aprovada)
- [ ] RLS ativo e testado
- [ ] CSP/HSTS
- [ ] Assinatura de webhooks verificada
- [ ] Backups com restauração testada
- [ ] Preços validados comercialmente (hoje "A definir")
- [ ] Pentest externo
