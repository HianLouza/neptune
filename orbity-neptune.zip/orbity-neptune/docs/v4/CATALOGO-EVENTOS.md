# Catálogo de eventos

Fonte: `EVENT_TYPES` e `EVENT_LABELS` em `src/server/events/index.ts`. Entrega por outbox transacional (tabela `events`) com idempotência (`idempotency_key`), retry com backoff exponencial (máx. 1h), status `dead` (DLQ) e reprocessamento (`replayEvent`). Cada handler roda uma vez por evento (`event_handler_runs`).

## Eventos de domínio

| Tipo | Rótulo | Publicado por | Consumido por |
|---|---|---|---|
| `lead.created` | Lead criado | `domains/crm` | workflow-engine |
| `lead.qualified` | Lead qualificado | `domains/crm`, `domains/prospect` | workflow-engine, notifications |
| `opportunity.created` | Oportunidade criada | `domains/crm` | workflow-engine |
| `opportunity.stage_changed` | Etapa alterada | `domains/crm` | workflow-engine |
| `opportunity.lost` | Oportunidade perdida | `domains/crm` | workflow-engine |
| `opportunity.won` | Oportunidade ganha | `domains/crm` | workflow-engine, notifications |
| `conversation.received` | Conversa recebida | `domains/closer` | workflow-engine, notifications |
| `message.replied` | Mensagem respondida | `domains/closer` | workflow-engine |
| `meeting.scheduled` | Reunião agendada | `domains/crm` | workflow-engine |
| `proposal.sent` | Proposta enviada | `domains/crm` | workflow-engine |
| `payment.confirmed` | Pagamento confirmado | **ninguém** (aguarda webhooks de pagamento) | workflow-engine (se publicado) |
| `credit.consumed` | Crédito consumido | `domains/billing` | workflow-engine |
| `limit.reached` | Limite atingido | `domains/billing` | workflow-engine, notifications |
| `approval.decided` | Aprovação decidida | `domains/closer` | workflow-approval-resume, workflow-engine |

## Eventos internos do motor

| Tipo | Uso | Consumido por |
|---|---|---|
| `workflow.resume` | Retomada após etapa de espera | workflow-resume |
| `workflow.*` | Ignorados pelo workflow-engine para evitar recursão | — |

## Handlers registrados (`src/server/events/handlers.ts`)

| Nome | Tipos | Função |
|---|---|---|
| `workflow-engine` | todos, exceto `workflow.*` | Dispara automações publicadas cujo gatilho é o tipo do evento (profundidade máx. 3) |
| `workflow-resume` | `workflow.resume` | Continua execuções em espera |
| `workflow-approval-resume` | `approval.decided` | Retoma ou encerra execuções após decisão humana |
| `notifications` | `lead.qualified`, `limit.reached`, `opportunity.won`, `conversation.received` | Cria notificações |

## Eventos previstos no ciclo 1 (Planned)
A Intelligence Layer poderá publicar `insight.created`, `decision.approved` e `scenario.approved`; ainda não fazem parte do `EVENT_TYPES` nesta auditoria. Ao incluí-los, registrar aqui publicador e consumidores.

## Observações
- A tela de automações lista `payment.confirmed` como gatilho disponível (`automacoes/page.tsx:16`), mas nenhum código publica esse evento. Um workflow com esse gatilho nunca dispara até existirem webhooks de pagamento.
