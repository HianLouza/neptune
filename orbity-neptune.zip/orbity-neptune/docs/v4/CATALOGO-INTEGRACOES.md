# Catálogo de integrações

Fonte: `CATALOG` em `src/server/domains/integrations/index.ts`. Credenciais por organização, cifradas com AES-256-GCM, validadas no provedor ao conectar e auditadas. Nenhuma integração aparece como conectada sem validação bem-sucedida.

Legenda: **Real** (funciona sem configuração extra) · **Credencial** (código pronto, valida no provedor; requer chave da empresa) · **Só cadastro** (aparece no catálogo, sem validação nem sincronização) · **Não construída**.

| Integração | Categoria | Autenticação | Estado | O que funciona hoje | O que falta |
|---|---|---|---|---|---|
| Webchat ORBITY | Comunicação | interno | Real | Recebimento por `/api/webhooks/webchat` | Widget publicável para sites |
| WhatsApp Business Platform | Comunicação | API key | Credencial | Validação em `graph.facebook.com`; recebimento por `/api/webhooks/whatsapp` | **Envio** (hoje a mensagem fica `sent` sem chamada à API — dívida D-01) |
| E-mail (SMTP) | Comunicação | API key | Só cadastro | Credencial cifrada | Validação e envio |
| Instagram Direct | Comunicação | OAuth | Só cadastro | — | OAuth e mensagens |
| Telefonia | Comunicação | — | Não construída | — | Provedor e consentimento de gravação |
| HubSpot | CRM | API key | Credencial | Validação de token | Sincronização |
| Pipedrive | CRM | API key | Credencial | Validação de token | Sincronização |
| RD Station | CRM | OAuth | Só cadastro | — | OAuth e sincronização |
| Salesforce, Zoho | CRM | — | Não construída | — | — |
| Google Workspace | Produtividade | OAuth | Só cadastro (login Google existe em `auth/oauth`) | Login com Google se credenciais configuradas | Gmail, Drive, Calendar |
| Microsoft 365 | Produtividade | OAuth | Só cadastro (login Microsoft existe) | Login com Microsoft se credenciais configuradas | Outlook, OneDrive, Teams |
| Zapier, Make, n8n | Automação | webhook | Só cadastro | — | Endpoint de entrada genérico e chamadas de saída aprovadas (D-03) |
| Google Sheets | Dados | OAuth | Só cadastro | — | OAuth |
| Importação CSV | Dados | interno | Real | Importação com deduplicação | — |
| API REST / Webhooks | Dados | webhook | Só cadastro | API interna autenticada por sessão (rotas `/api`); `/api/integrations/events` serve só para reprocessar eventos da DLQ | Chaves de API públicas, webhooks de entrada e saída |
| Stripe | Pagamentos | API key | Credencial | Validação em `api.stripe.com/v1/balance` | Cobrança, webhooks, `payment.confirmed` |
| Mercado Pago | Pagamentos | API key | Credencial | Validação em `users/me` | Cobrança e webhooks |
| Asaas | Pagamentos | API key | Credencial | Validação em `myAccount` | Cobrança e webhooks |
| Anthropic (Claude) | IA | API key (ambiente) | Credencial | SDK oficial, modelo `claude-opus-5-5`, recusa tratada | — |
| OpenAI | IA | API key (ambiente) | Credencial | Provedor reserva | — |
| ERPs, bancos, fiscal | Financeiro | — | Não construída | — | Provedores especializados (bloqueado) |

## Requisitos transversais (§30)

| Requisito | Estado |
|---|---|
| Credenciais por tenant, cifradas | Implementado |
| Auditoria de conexão/desconexão | Implementado |
| Logs de integração | Tabela `integration_logs` existe; uso parcial |
| Retry e DLQ | Implementado para eventos internos; não para chamadas de saída |
| Rate limit por provedor | Não implementado |
| Revogação OAuth | Desconexão apaga credencial; revogação no provedor não implementada |
| Sincronização | Não implementada |
