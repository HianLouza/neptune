# Diagnóstico — Prompts 34 (Dashboard interativo) e 35 (Flávio)

Data: 2026-11-10. Base auditada: código em `src/`, testes em `tests/`, documentação em `docs/`.
Linha de base antes de qualquer alteração: `npm run typecheck` sem erros; `npm test` com 44 testes passando em 7 arquivos.

> Observação de ambiente: durante a auditoria, outro processo estava alterando o NEPTUNE ao mesmo tempo
> (`drizzle/0001_ciclo1_v4.sql`, `src/server/db/schema.ts`, `src/server/db/migrate.ts`, `src/server/permissions/index.ts`,
> trabalho identificado como "Master Prompt 4.0 — ciclo 1"). Para não colidir, esta entrega **não altera o schema nem cria
> migrações** e concentra o código novo em arquivos próprios. Ver "Riscos".

## 1. O que existe

### Gráficos, dashboards e dados
| Item | Onde | Situação |
|---|---|---|
| Dashboard (`/dashboard`) | `src/app/(app)/dashboard/page.tsx` | Server Component. 5 cards (leads, oportunidades, vendas, receita, conversão) com variação contra o período anterior; gráfico de receita e leads acumulados; rosca de origem; mini pipeline; ações sugeridas; atividades do time; meta. Filtro único de período (7/30/90 dias) por URL. |
| Gráficos do dashboard | `src/components/dashboard/charts.tsx` | Recharts 3. Tooltip simples (valor acumulado), sem legenda interativa, sem clique, sem tabela alternativa (só `aria-label`). |
| Sales Intelligence (`/intelligence`) | `src/app/(app)/intelligence/page.tsx`, `src/components/intelligence/charts.tsx` | Funil, vendedores, origens, previsão e recomendações; cada gráfico já tem uma tabela visível ao lado. Tooltips simples, sem drill-down. |
| Relatórios (`/relatorios`) | `src/server/domains/reporting/index.ts`, `/api/reports` | 5 tipos, CSV auditado, resumo por IA (agente `reporting`). Usa as funções do Sales Intelligence. |
| Serviço de métricas | `src/server/domains/intelligence/index.ts` | `dashboardKpis`, `performanceSeries`, `leadOrigins`, `funnelAnalysis`, `sellerPerformance`, `revenueForecast`, `recommendations`, `naturalLanguageQuery`. Todas exigem `intelligence:read` e filtram por `organizationId`. **Não aceitam filtros** além do período. |
| Catálogo de métricas | `src/server/domains/data-intelligence/index.ts` (`METRIC_CATALOG`) | Definições canônicas (receita, taxa de conversão, leads gerados...). |
| Consulta em linguagem natural | `/api/intelligence/query` | Mapeia a pergunta para métricas conhecidas por regex (sem SQL gerado por IA). |

### Recursos de interação já disponíveis
- Tooltip padrão do Recharts; Recharts 3 já liga a `accessibilityLayer` (setas do teclado movem o tooltip).
- Troca de período por URL; links das ações sugeridas para telas filtradas (`/crm?filtro=paradas`, `/prospect?filtro=quentes`).
- Página de oportunidade (`/crm/oportunidade/[id]`) e lead aberto por `?lead=<id>` em `/prospect`: destinos prontos para o drill-down.

### Camada de IA
| Item | Onde | Situação |
|---|---|---|
| Orquestrador | `src/server/ai/orchestrator.ts` (`runAgent`) | Guardrails de entrada e saída, versão de prompt, limite diário por agente, saldo de créditos, cadeia de provedores com fallback, cobrança, `ai_executions` e auditoria. |
| Provedores | `src/server/ai/providers/index.ts` | Anthropic (SDK oficial, `ANTHROPIC_MODEL`, padrão `claude-opus-5-5`), OpenAI (só com chave e modelo) e `local-heuristic` (determinístico, marcado como simulação). |
| Assistente "ORBITY AI" | `src/components/dashboard/assistant.tsx` + `/api/ai/chat` | Card dentro do dashboard. Monta contexto com KPIs de 30 dias e chama o agente `executive`. Histórico só em memória do navegador; sem contexto de tela; sem ações; sem respostas estruturadas. Sem chave de API, devolve o texto genérico do `local-heuristic`. |
| Agentes | `src/server/ai/agents/catalog.ts` | 12 agentes; `executive` é o assistente geral. |

### Permissões e isolamento
- `TenantContext` por sessão; `requirePerm` no backend; `assertOwned` para IDs referenciados.
- Escopo por equipe/vendedor nas consultas **não existe** (REQ-PERM-03 pendente): quem tem `crm:read` vê todas as oportunidades da organização.

## 2. O que já atende
- Cálculos no servidor, com definição canônica e isolamento por organização.
- Estados vazios em quase todas as telas; previsão com premissas e incerteza; recomendações com evidência.
- Provedor real com fallback e marcação de simulação.

## 3. Lacunas
| Requisito | Lacuna |
|---|---|
| 34.1 | Sem legenda interativa, sem ponto ativo controlado, sem tooltip com período, comparação e origem; sem alternativa em tabela nos gráficos do dashboard; teclado sem ação (Enter não abre nada). |
| 34.2 | Sem drill-down até registros; sem filtros por vendedor, equipe, campanha, origem, etapa; sem filtro cruzado; comparação só com período anterior fixo; exportação só nos relatórios. |
| 34.3 | Serviço não aceita filtros; sem metadados de auditoria (definição, período, filtros aplicados) junto do número; sem estado de erro nos gráficos; sem atualização periódica. |
| 34.4 | Gráficos do dashboard só com `aria-label`. |
| 35 | Não há Flávio: assistente genérico, sem painel persistente, sem contexto de tela, sem histórico, sem ações com confirmação, sem fallback determinístico útil. |

### Dimensões pedidas × schema
| Dimensão | Disponível? | Fonte |
|---|---|---|
| Período | Sim | `leads.created_at`, `opportunities.created_at`, `opportunities.closed_at` |
| Vendedor | Sim | `leads.owner_id`, `opportunities.owner_id` |
| Equipe | Sim | `teams` + `team_members` (pelo responsável do registro) |
| Campanha | Sim, para leads; oportunidades herdam do lead de origem | `leads.campaign_id` → `campaigns` (oportunidade via `opportunities.lead_id`) |
| Origem | Sim | `leads.source`; oportunidade usa `coalesce(opportunities.source, leads.source)` |
| Etapa comercial | Sim, só oportunidades | `opportunities.stage_id` |
| Produto | **Não** | Não há vínculo entre `opportunities` e `products` (sem itens de oportunidade). Documentado em vez de inventado. |
| "Transações" | **Não há tabela comercial de transações** | Vendas = oportunidades ganhas. `payments` é cobrança da própria plataforma, fora do escopo comercial. |

## 4. Arquitetura proposta
```
            Componentes (cards, gráficos, tabelas, relatórios)          Painel do Flávio
                         │  GET /api/metrics/*                             │ POST /api/flavio/ask
                         ▼                                                 ▼
   src/server/domains/metrics  ◄──── usado por ────  src/server/ai/flavio (identidade, intenções, análises, ações)
   (definições, filtros, período, comparação,                 │                         │
    séries, segmentação, drill-down, CSV)                     │  narrativa opcional      │ ações confirmadas
                         │                                    ▼                         ▼
                         │                     runAgent (orquestrador existente)   createTask / saveWorkflow /
                         │                     agente "executive", persona Flávio   updateLeadStatus (domínios existentes)
                         ▼                                    │
               PostgreSQL (sempre por organization_id)   provedores existentes (Anthropic/OpenAI/local)
```
- **Serviço central de métricas** (`src/server/domains/metrics`): definições auditáveis (fórmula, fonte, dimensões), filtros validados por Zod e
  compartilhados com o cliente (`src/lib/metrics-filters.ts`), comparação com período anterior ou mesmo período do ano anterior, séries,
  segmentação e drill-down. `dashboardKpis` passa a delegar a ele (mesmo número no card, no relatório e no Flávio).
- **Flávio não é um segundo motor**: é identidade + camada de análise determinística sobre o serviço de métricas. Quando há provedor real,
  a narrativa passa pelo `runAgent` (agente `executive`, mesmas proteções, créditos e auditoria) com a persona do Flávio; os números exibidos
  vêm sempre do serviço, não do modelo. Sem provedor ou com falha, a resposta é a narrativa determinística das próprias métricas.
- **Ações**: o Flávio só **propõe**. A proposta é assinada (HMAC com chave do servidor, expira em 15 min, vinculada a usuário e organização),
  o usuário vê o resumo e confirma; o servidor revalida permissão e posse dos registros, executa pelo domínio existente e audita.
  Reenvio da mesma proposta é recusado.
- **Histórico**: reaproveita `ai_executions` (já por organização e usuário). Conversas são agrupadas por intervalo de tempo. O usuário pode
  apagar o conteúdo do próprio histórico (o registro de uso e custo é mantido, sem texto).
- **Sem alteração de schema** nesta entrega (ver Riscos).

## 5. Dependências
Nenhuma dependência nova. Usa Recharts 3, Lucide, Zod, Drizzle e `@anthropic-ai/sdk` já instalados.

## 6. Custos de IA estimados
O código não tem preço em dinheiro por token; ele cobra **créditos internos**: `creditsFor` = 1 crédito a cada 1.000 tokens (mínimo 1);
respostas simuladas ou determinísticas custam 0.

Premissas por pergunta ao Flávio com provedor real (estimativa, não medição):
- sistema (prompt do agente + persona): ~700 tokens; contexto de análise minimizado: 800 a 2.500 tokens; histórico (até 10 mensagens): até 1.500 tokens;
- saída: 300 a 900 tokens (teto do agente: `maxTokensPerRun`, padrão 4.000; o provedor Anthropic usa no mínimo 1.024 de `max_tokens`).
- Total típico: 2.000 a 5.600 tokens → **2 a 6 créditos por pergunta**.

Custo em dinheiro = tokens de entrada × preço de entrada + tokens de saída × preço de saída do modelo configurado em `ANTHROPIC_MODEL`.
Os preços não estão no código e não foram inventados: devem ser consultados na tabela vigente do provedor. Os tokens reais de cada
execução ficam em `ai_executions.input_tokens/output_tokens`, o que permite medir o custo verdadeiro depois.
Para reduzir custo: `ANTHROPIC_EFFORT=low` no chat, limite diário por agente (`maxCreditsPerDay`) e o modo determinístico, que responde
às perguntas mapeadas sem chamar o modelo quando não há chave.

## 7. Riscos
| Risco | Mitigação |
|---|---|
| Trabalho concorrente no mesmo repositório (schema e migrações sendo alterados) | Nenhuma alteração de schema; código novo em arquivos próprios; edições pequenas e localizadas em arquivos existentes. |
| Divergência de números entre telas | Um único serviço; `dashboardKpis` delega a ele; teste de consistência card × relatório × drill-down. |
| Modelo inventar números | Números exibidos vêm do serviço; o contexto enviado ao modelo é marcado como dado; regra explícita na persona; modo determinístico como fallback. |
| Execução indevida de ações | Proposta assinada, expiração, vínculo a usuário/organização, revalidação de permissão e posse, idempotência, auditoria. |
| Vazamento entre organizações | Toda consulta filtra por `organization_id`; testes de isolamento para métricas, drill-down, ações e histórico. |
| Envio de dados a serviço não autorizado | Só os provedores já configurados por variável de ambiente; nenhum provedor novo. Gemini não foi ligado (sem credencial nem autorização). |
| Escopo por equipe inexistente (REQ-PERM-03) | O Flávio e o drill-down seguem exatamente as permissões que o app já aplica; a lacuna permanece documentada. |
| Histórico guardado em `ai_executions` | Agrupamento por tempo em vez de conversa explícita; tabela própria fica como pendência quando o schema estabilizar. |
