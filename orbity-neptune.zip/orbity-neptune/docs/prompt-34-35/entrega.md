# Entrega — Prompts 34 (Dashboard interativo) e 35 (Flávio)

Data: 2026-11-10. Diagnóstico e arquitetura: [`diagnostico.md`](diagnostico.md).

## 1. O que foi implementado

### Serviço central de métricas
| Arquivo | Conteúdo |
|---|---|
| `src/lib/metrics-filters.ts` | Filtros compartilhados servidor/cliente (Zod): período (7/30/90/180/365 ou personalizado até 366 dias), comparação (`previous`, `year`, `none`), vendedor, equipe, campanha (inclui "sem campanha"), origem, etapa. Leitura tolerante da URL, serialização, resolução de período (UTC), descrição legível dos filtros. Lista "Produto" como indisponível, com o motivo. |
| `src/server/domains/metrics/index.ts` | `METRIC_DEFINITIONS` (fórmula, fonte, campo de data, dimensões); `computeKpis`, `metricsOverview` (atual, comparação, variação, pipeline aberto, metadados), `metricsSeries` (diária até 92 dias, semanal acima, com série de comparação alinhada), `metricsBreakdown` (5 dimensões, participação e receita de comparação), `metricsDrilldown` (leads, oportunidades, vendas, perdidas, fechadas, receita, pipeline aberto; recorte de ponto preso ao período), `filterOptions`, `dashboardBundle`, CSV com neutralização de fórmulas. |
| `src/server/domains/metrics/export.ts`, `http.ts` | CSV de resumo, série, segmentação e registros; leitura estrita de filtros nas APIs. |
| `src/app/api/metrics/{dashboard,drilldown,export}/route.ts` | APIs. Exportação auditada (`metrics.exported_csv`); registros exigem `export:data`. |
| `src/server/domains/intelligence/index.ts` | `kpisFor` (usado por `dashboardKpis`, relatórios e Sales Intelligence) delega a `computeKpis`. |

### Dashboard e gráficos
| Arquivo | Conteúdo |
|---|---|
| `src/components/charts/interactive.tsx` | `InteractiveTimeSeries` e `InteractiveBars`: tooltip com valores exatos, período e comparação; legenda com botões `aria-pressed`; ponto ativo (linha de referência / destaque da barra); teclado (setas, Home/End, Enter, Esc); toque (tocar seleciona, painel de detalhe com ação); animação de 450 ms; botão "Ver tabela" com `<table>` semântica (caption, `scope`). |
| `src/components/dashboard/explorer.tsx` | Filtros globais na URL (via `history.replaceState`), chips removíveis, 6 cards clicáveis com drill-down, série com comparação, segmentação por 5 dimensões com seletor de indicador e filtro cruzado (gráfico e tabela), painel de registros (janela atual/comparação, paginação, CSV), menu de exportação, atualização a cada 60 s com aba visível, estados de carregamento, vazio e erro (mantém os últimos números e oferece tentar de novo), botão "Perguntar ao Flávio". |
| `src/app/(app)/dashboard/page.tsx` | Usa `dashboardBundle` no servidor (primeira renderização) e o explorador; mantém pipeline, ações sugeridas, atividades e metas; emoji removido do título; cartão do Flávio no lugar do "ORBITY AI". |
| `src/components/intelligence/charts.tsx` | Funil, vendedores e origens no componente interativo (clique leva ao CRM/dashboard filtrado). |
| Removidos | `src/components/dashboard/assistant.tsx` (assistente genérico) e `src/components/dashboard/charts.tsx` (substituídos). |

### Flávio
| Arquivo | Conteúdo |
|---|---|
| `src/server/ai/flavio/identity.ts` | Nome, título, saudação, persona (tom, regras: só números do bloco de análise, hipóteses marcadas, sem emojis), mapa rota → módulo e sugestões por módulo. Adaptado do Flavio do Recrut.AI (painel por tela, sugestões, dados não confiáveis, deixar claro o que é sugestão). |
| `src/server/ai/flavio/intents.ts` | Classificação determinística de 17 intenções em pt-BR, continuação de conversa ("e por vendedor?"), período citado no texto, extração de tarefa e prazo. |
| `src/server/ai/flavio/analyses.ts` | Análises: visão geral, variação de receita (decomposição exata volume × ticket e maiores variações por vendedor e origem), conversão por vendedor (amostra mínima 5), desempenho da equipe, leads de maior potencial, oportunidades paradas (critério do CRM, 5 dias), leads sem acompanhamento, melhor canal, prioridades da semana, projeção (pipeline ponderado + ritmo do mês), metas, inconsistências (8 verificações), explicação de indicadores e gráficos, campanhas e recuperação, relatório executivo, pedido de tarefa, ajuda. Narrativa determinística e contexto minimizado para o modelo. |
| `src/server/ai/flavio/actions.ts` | Propostas assinadas (HMAC-SHA256, chave derivada de `ENCRYPTION_KEY`, 15 min, usuário e organização); confirmação revalida permissão atual e posse dos registros, executa em transação com trava (`pg_advisory_xact_lock`) e auditoria; repetição recusada. Ações: criar tarefas (1 a 20; lembretes, follow-ups, planos de ação), rascunho de automação a partir de modelo (nunca publica), atualizar status de lead. |
| `src/server/ai/flavio/index.ts` | `askFlavio`, `flavioStatus`, `listConversations`, `eraseConversations`. Guardrails → intenção → análise → `runAgent` (agente `executive`, persona Flávio) → texto do modelo só quando há provedor real com sucesso; caso contrário, texto determinístico, registrado em `ai_executions` como o que o usuário recebeu. Histórico enviado ao modelo é lido do servidor. Auditoria `flavio.analysis`. |
| `src/app/api/flavio/{ask,status,history,actions/confirm}/route.ts` | APIs (POST/DELETE com verificação de origem). |
| `src/app/api/ai/chat/route.ts` | Compatibilidade: delega ao Flávio. |
| `src/server/ai/orchestrator.ts` | Campo opcional `persona` em `RunAgentInput` (acrescentado ao prompt do agente). |
| `src/components/flavio/flavio-dock.tsx` | Botão persistente com indicador de disponibilidade; painel lateral (420 px; tela cheia no celular; no desktop largo empurra o conteúdo); sugestões por tela; respostas com selo (IA ou calculado), indicadores, evidências com links, "Dados usados", ações com revisão e confirmação, estados de processamento, erro, bloqueio e indisponibilidade; histórico com exclusão. |
| `src/components/flavio/flavio-card.tsx`, `src/components/layout/app-shell.tsx` | Cartão do dashboard; montagem do painel no shell; banner de demonstração com ícone Lucide em vez de símbolo Unicode. |

## 2. Testes e evidências
- `tests/integration/metrics-flavio.test.ts`: 21 testes, com base de dados conhecida e valores esperados calculados à mão:
  KPIs e consistência com `dashboardKpis` e relatório executivo; filtros por vendedor, origem (incluindo herança da origem do lead), equipe,
  campanha, "sem campanha" e etapa; somas da segmentação (5 dimensões) e da série iguais ao card; drill-down (totais iguais ao indicador,
  links, janela de comparação, recorte de ponto e recusa fora do período); permissões; isolamento entre organizações; validação de filtros e
  comparação anual; CSV (anti-fórmula, filtros no rodapé, exigência de `export:data`); Flávio sem chave (modo determinístico, números iguais,
  sem emojis, execução registrada com o texto entregue); decomposição da receita; 9 perguntas de exemplo da especificação; continuação e
  filtros da tela; ação proposta → confirmada → auditada → repetição recusada; assinatura adulterada, outro usuário, outra organização,
  expirada, sem permissão e oportunidade de outra organização (sem efeito parcial); automação só como rascunho; pedido de tarefa não executa;
  histórico isolado e exclusão; injeção bloqueada sem consulta; agente desativado; provedor real simulado por mock (persona enviada,
  contexto delimitado, sem e-mail); falha do provedor com resposta determinística.
- Resultados nesta máquina (com a outra sessão alterando o repositório ao mesmo tempo):
  - `npx tsc --noEmit`: sem erros.
  - `npm test`: 13 arquivos, 115 testes, todos passando (inclui testes da outra sessão).
  - `NEXT_DIST_DIR=.next-build npx next build`: concluído com código 0 (`/dashboard` 9,96 kB, 284 kB na primeira carga). Uma tentativa
    anterior sem diretório separado falhou (`Invariant: no direct app page entry found for /_not-found`) por concorrência com o servidor de
    desenvolvimento da outra sessão.
- Navegador (servidor da outra sessão na porta 3050, só leitura, dados de demonstração do seed):
  - Desktop: dashboard carregou com filtros, 6 cards com variação, gráficos, segmentação e tabela; painel do Flávio abriu com indicador
    "Disponível · modo determinístico"; uma pergunta de teste ("Por que minha receita mudou neste período?") devolveu a análise com
    decomposição volume × ticket, maiores variações por vendedor e origem e hipótese marcada, selo "Calculado das métricas".
    Com o painel aberto, os cards ficavam estreitos e cortavam valores: grade ajustada para 3 colunas abaixo de 1760 px.
  - 375 px: havia rolagem horizontal da página (scrollWidth 565) causada pelo cabeçalho existente; corrigido em `app-shell.tsx`
    (busca só com ícone no celular); depois da correção, scrollWidth = 375. O painel do Flávio ocupa a tela inteira e o histórico abre.
  - Não verificado no navegador: teclado e toque nos gráficos, drill-down, exportação, confirmação de ação (não confirmada por regra).
  - Achado nos dados de demonstração: as oportunidades perdidas do seed não têm origem, então caem em "Outros" e a conversão por origem
    aparece como 100% nas demais origens. O cálculo está correto para os dados; a base de demonstração é que é inconsistente.

## 3. Limitações
- **Produto**: não há vínculo entre oportunidades e produtos; o filtro aparece como indisponível.
- **Transações**: não há tabela comercial de transações; vendas = oportunidades ganhas.
- **Escopo por equipe nas permissões** (REQ-PERM-03) continua inexistente: o drill-down segue a mesma regra do CRM (quem tem `crm:read` vê a organização inteira).
- **Tempo real**: atualização periódica (60 s, só com a aba visível) e ao voltar para a aba; não há push.
- **Fuso**: períodos e agrupamentos em UTC, como o Sales Intelligence existente.
- **Equipe na segmentação**: quem está em mais de uma equipe entra na primeira em ordem alfabética; o filtro por equipe inclui todos os membros.
- **Histórico**: guardado em `ai_executions` (sem tabela de conversa); sessões agrupadas por intervalo de 30 min; respostas antigas ficam só em texto. A exclusão apaga o texto e mantém o registro de uso.
- **Persona com provedor real**: testada com o provedor simulado por mock; não testada contra a API real (não há chave configurada).
- **Agente executivo existente** continua com o nome "ORBITY AI (Executivo)" na tela de IA e Agentes das organizações já criadas; o catálogo (`catalog.ts`) não foi alterado porque está em uso pela outra sessão.

## 4. Pendências
1. Testes E2E de interface: teclado e toque nos gráficos, drill-down, exportação e confirmação de ação no navegador.
2. Corrigir o seed (fora do meu escopo: `scripts/seed.ts` está com a outra sessão) para dar origem às oportunidades perdidas.
3. Renomear o agente `executive` no catálogo para "Flávio (Assistente de Inteligência Comercial)" — mudança em `src/server/ai/agents/catalog.ts`, a combinar com a outra sessão.
4. Tabela própria para conversas do assistente (migração 0002), a combinar com a outra sessão.
5. Vínculo oportunidade-produto para a dimensão "produto".
6. Provedor Gemini somente com credencial paga, contrato e autorização de tratamento de dados.

## 5. Riscos
- Trabalho concorrente no mesmo repositório: resultados de typecheck e testes refletem o estado combinado no momento da execução.
- O campo `persona` foi acrescentado ao orquestrador, que também está sendo alterado pela outra sessão; se for removido, `src/server/ai/flavio/index.ts` deixa de compilar.
- Custos de IA: ver estimativa no diagnóstico; o modo determinístico não consome créditos.
