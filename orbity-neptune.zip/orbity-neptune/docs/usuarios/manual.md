# Manual do usuário — ORBITY-NEPTUNE

Jornada: **ENCONTRAR → QUALIFICAR → ATENDER → CONVERTER → ANALISAR → RECOMENDAR → EVOLUIR.**

## Para todos (colaborador)
- **Entrar**: e-mail e senha (ou Google/Microsoft quando habilitados). Com 2FA ativo, informe o código do app autenticador.
- **Tela inicial**: o sistema abre na última tela que você usou.
- **Busca global**: `Ctrl + K` busca páginas, leads, empresas, contatos e negócios.
- **Tema**: ícone de sol/lua na barra superior.
- **Prospect.AI**: veja leads ordenados por pontuação. Clique na pontuação para ver os fatores e a confiabilidade.
  Gere rascunhos de abordagem com IA — **nenhuma mensagem é enviada sem aprovação**.
- **Closer.AI**: caixa de entrada compartilhada. "Sugerir resposta com IA" cria uma sugestão baseada na base de conhecimento;
  um gestor aprova (ou edita) antes do envio. Se o canal não tiver integração real conectada, a mensagem fica registrada
  como **simulada** e não chega ao cliente.
- **CRM**: funil em colunas; mova oportunidades entre etapas (perda exige motivo). Registre atividades, tarefas, reuniões e propostas.
- **Tarefas & Metas**: suas tarefas, metas e simulação de comissão.
- **Dashboard interativo**:
  - **Filtros globais** no topo: período (7 a 365 dias ou personalizado), comparação (período anterior, mesmo período do ano
    anterior ou nenhuma), vendedor, equipe, campanha, origem e etapa. Os filtros ficam na URL: copie o link para compartilhar a mesma visão.
    "Produto" aparece como indisponível porque as oportunidades ainda não têm vínculo com produtos.
  - **Cards**: clique num card para abrir os registros que compõem o número (leads ou oportunidades), com link para cada um.
    Na janela de registros dá para alternar entre o período atual e o de comparação e, com a permissão de exportação, baixar o CSV.
  - **Gráficos**: passe o mouse ou toque para ver os valores exatos; clique nos itens da legenda para mostrar ou ocultar séries;
    use **Tab** para chegar ao gráfico e as **setas** para percorrer os pontos; **Enter** abre os registros do ponto (ou aplica o filtro, nas barras);
    **Esc** limpa a seleção. O botão **Ver tabela** mostra os mesmos dados em tabela.
  - **Filtro cruzado**: clicar numa barra da segmentação ou no nome de uma linha da tabela aplica o filtro em todo o dashboard; clique de novo para remover.
  - **Exportar**: o menu Exportar baixa o resumo, a série ou a segmentação exatamente como estão filtrados (CSV, separador ";").
  - Os números se atualizam sozinhos a cada minuto enquanto a aba está aberta (desligue em "Atualizar a cada minuto") ou pelo botão Atualizar.
- **Flávio, assistente de inteligência comercial**: botão no canto inferior direito de qualquer tela.
  - Pergunte em linguagem natural: "Por que minha receita caiu neste período?", "Qual vendedor apresenta a melhor conversão?",
    "Quais oportunidades estão paradas?", "Quais ações devemos priorizar nesta semana?", "Há inconsistências nos dados?".
  - Ele considera a tela atual e os filtros do dashboard. Cada resposta mostra indicadores, evidências com links e, em
    **Dados usados nesta resposta**, o período, os filtros, as fontes e os critérios. Hipóteses aparecem marcadas como "Hipótese".
  - Selo da resposta: **Texto gerado por IA** (há provedor configurado; os números continuam vindo do sistema) ou
    **Calculado das métricas** (sem provedor de IA ou com o provedor fora do ar).
  - **Ações**: o Flávio prepara tarefas, follow-ups, planos de ação e rascunhos de automação, mas **nada é criado sem você
    clicar em "Revisar e confirmar" e depois em "Confirmar e executar"**. A proposta vale 15 minutos e fica registrada na auditoria.
  - **Histórico**: ícone de relógio no painel. Você pode apagar o texto de uma conversa ou de todo o seu histórico.

## Gestor
- Aprova respostas de IA e etapas de automação (painel de aprovações no Closer.AI).
- Acompanha Sales Intelligence: funil, vendedores, previsão (com cenários e premissas) e recomendações com evidências.
- Cria e publica automações (modelos, editor visual ou linguagem natural → rascunho → simulação → publicação).

## Administrador da empresa
- **Administração**: aprovar colaboradores (link de convite), cargos e permissões, equipes, configurações regionais
  (idioma, moeda, fuso), auditoria, exportação de dados e direitos do titular (LGPD).
- **Integrações**: conectar WhatsApp oficial, CRMs e meios de pagamento com credenciais próprias (validadas no provedor).
- **Billing**: plano, créditos de IA, consumo, previsão de gastos e **autorização de excedentes** com teto.
- **IA & Agentes**: ativar/desativar agentes, ajustar autonomia e limites, criar versões de prompt, avaliar e ativar/reverter.

## Administrador global (equipe ORBITY-NEPTUNE)
- **Painel global**: organizações, MRR/ARR, custos de IA, feature flags, experimentos, incidentes, cupons, suspensão.
- **Customer Success**: Health Score transparente (sinais e pesos configuráveis), riscos, renovações e interações.

## Novidades da versão 0.2 (Master Prompt 4.0, ciclo 1)
- **Command Center**: visão executiva da empresa. Responde o que está acontecendo, o que mudou, o que merece atenção,
  onde há oportunidades, quais decisões tomar e o que melhorar. "Gerar briefing" cria o resumo do período;
  "Analisar agora" atualiza os insights. Cada insight mostra as evidências (fonte, cálculo, confiança e limitações)
  e pode ser aceito, alterado, rejeitado, marcado como executado e ter o resultado medido.
- **Business Brain**: no Command Center, pergunte em português (ex.: "Por que minha receita caiu?"). A resposta vem em
  10 partes e separa fatos, inferências, estimativas e recomendações. Sem dados suficientes, ele diz o que falta.
- **Decisões**: registre alternativas e envie para aprovação. Quem cria não pode aprovar a própria decisão.
- **Financeiro** (administradores e gestores): lançamentos a pagar e a receber, DRE gerencial, fluxo de caixa projetado,
  inadimplência, rentabilidade, orçamento e assistente financeiro. Não substitui contabilidade nem obrigações fiscais.
  Sem banco, ERP ou meio de pagamento conectado, os números vêm só dos lançamentos cadastrados.
- **Simulador Estratégico**: teste preço, volume, custos, contratações, marketing e perda de clientes sobre a base real
  da empresa, com cenários otimista, base e pessimista. Salve, compare e envie cenários para aprovação.
  Reduções de equipe aparecem só como análise; o sistema nunca decide isso.
- **AI Control Plane** (gestores veem; só administradores alteram): níveis de autonomia de 1 (observa) a 5 (autônomo
  com limites), pausar ou suspender agentes, **kill switch** com confirmação na tela, orçamentos de IA, monitoramento
  e alertas de conflito. Ações sensíveis sempre exigem aprovação humana, em qualquer nível.
