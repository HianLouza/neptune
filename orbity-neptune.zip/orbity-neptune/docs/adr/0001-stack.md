# ADR 0001 — Stack, ORM e banco local

**Status:** aceito · **Data:** 2026-11-09

## Contexto
O master prompt exige Next.js, PostgreSQL com pgvector, Redis para filas e arquitetura independente de fornecedores.
O ambiente de desenvolvimento não possui Docker, PostgreSQL nem Redis instalados.

## Decisão
1. **Drizzle ORM** como camada de acesso a dados.
2. **PGlite** (Postgres 17 em WASM + extensão pgvector) em desenvolvimento e testes; **PostgreSQL** gerenciado em homologação/produção.
3. **Outbox transacional no Postgres** como fila padrão; Redis opcional para escalar workers.

## Consequências
- (+) Projeto roda com `npm install` apenas; testes de integração usam banco real em memória (sem mocks).
- (+) Mesmo SQL e migrações em todos os ambientes; portabilidade (seção 19).
- (−) PGlite é single-connection: código não pode usar o `db` raiz dentro de uma transação (corrigido e coberto por testes).
- (−) RLS nativa ainda não aplicada (isolamento feito na aplicação + testes); planejada para v0.3.
- Custo de substituição: trocar Drizzle exigiria reescrever a camada de domínio (~2–3 semanas); trocar provedor de IA = novo adaptador (~1 dia).
