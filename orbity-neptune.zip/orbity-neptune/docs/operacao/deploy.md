# Instalação, configuração e deploy

## Desenvolvimento local (sem instalar banco)
```bash
npm install
cp .env.example .env        # gere SESSION_SECRET e ENCRYPTION_KEY
npm run db:seed             # migra + dados de referência + organização de DEMONSTRAÇÃO
npm run dev                 # http://localhost:3000
npm run worker              # (outro terminal) processa o Event Engine continuamente
npm test                    # testes unitários e de integração (PGlite em memória)
```
Login de desenvolvimento: `admin@orbity.local` com a senha definida em `DEMO_PASSWORD` (padrão em `scripts/seed.ts`).
O seed é bloqueado quando `APP_ENV=production`.

## Variáveis de ambiente
Ver `.env.example` (comentado). Obrigatórias em produção: `DATABASE_URL`, `APP_URL`, `APP_ENV=production`,
`SESSION_SECRET`, `ENCRYPTION_KEY`. Opcionais (habilitam recursos reais): `ANTHROPIC_API_KEY`/`OPENAI_*`, OAuth Google/Microsoft,
`REDIS_URL`, Stripe/Mercado Pago/Asaas, WhatsApp, SMTP.

## Ambientes
| Ambiente | Banco | Deploy |
|---|---|---|
| Desenvolvimento | PGlite local | `npm run dev` |
| Homologação | Postgres gerenciado (branch) | automático a cada merge em `develop` |
| Produção | Postgres gerenciado + pgvector + PITR | tag `vX.Y.Z` com aprovação manual |

## Pipeline (`.github/workflows/ci.yml`)
1. `npm ci` → `npm run typecheck` → `npm test` → `npm run build`.
2. Migrações: `npm run db:migrate` executado **antes** do novo release (migrações aditivas/compatíveis com a versão anterior — expand/contract).
3. Deploy controlado com rollout gradual (feature flags) e monitoramento pós-deploy (`/api/health`, taxa de erro, latência).
4. Rollback: reimplantar a tag anterior; migrações são compatíveis com N-1.

## Monitoramento
- `/api/health`: banco, latência, filas por status, provedores de IA disponíveis.
- Logs estruturados JSON (stdout) para agregação (Datadog/Grafana Loki).
- SLOs propostos: disponibilidade 99,5%/mês; p95 de API < 500 ms; eventos processados em < 60 s (p95); DLQ = 0 em estado estável.

## Checklist de restauração (mensal)
1. Restaurar snapshot PITR em instância de homologação.
2. `npm run db:migrate` e `GET /api/health`.
3. Validar contagens por organização e login de usuário de teste.
4. Registrar tempo total (RTO) e ponto recuperado (RPO).
