# Segurança, LGPD e Governança

## Controles implementados
| Ameaça | Controle | Onde |
|---|---|---|
| Sessão roubada | Token opaco aleatório (256 bits), só o hash SHA-256 no banco, cookie httpOnly + SameSite=Lax + Secure em produção, expiração 14 dias, revogação | `src/server/auth/service.ts` |
| Força bruta | Limite de 8 tentativas / 15 min por e-mail+IP, auditoria de falhas | `login()` |
| Senhas | bcrypt custo 12, política mínima (10 caracteres, letras e números) | `password.ts` |
| 2FA | TOTP RFC 6238 com janela ±1, sessão bloqueada até verificação | `totp.ts`, `/api/auth/2fa` |
| CSRF | SameSite=Lax + verificação de `Origin` nas mutações | `assertSameOrigin()` |
| XSS | React escapa saída; nenhum `dangerouslySetInnerHTML`; cabeçalhos `X-Content-Type-Options`, `X-Frame-Options` | `next.config.ts` |
| SQL injection | Consultas parametrizadas (Drizzle); IA não gera SQL livre (consultas NL mapeadas para métricas conhecidas) | domínios |
| SSRF | Validadores de integração chamam apenas hosts fixos do catálogo; ações de webhook em automações exigem aprovação | `integrations`, `workflows` |
| IDOR / vazamento entre tenants | `TenantContext` + `assertOwned` + filtro por organização em todas as consultas + testes | `crm`, `closer` |
| Prompt injection | Detecção de padrões PT/EN, dados não confiáveis delimitados, ferramentas limitadas, bloqueio auditado | `ai/guardrails` |
| Gastos de IA | Saldo de créditos, limite diário por agente, excedente só com autorização e teto | `billing`, `orchestrator` |
| Segredos | `.env` fora do Git; credenciais de integrações criptografadas com AES-256-GCM | `auth/crypto.ts` |

## LGPD
- **Bases legais** registradas por contato (`legal_basis`) e por fonte de dados (`data_sources`).
- **Consentimento** aceito no cadastro; status de consentimento por contato.
- **Direitos do titular**: localização e anonimização (`eraseDataSubject`) com auditoria; exportação (portabilidade) em JSON.
- **Minimização**: PII removida de saídas de IA; logs de IA truncados.
- **Retenção**: `data_sources.retention_days` (job de expurgo planejado — REQ-LGPD-06).
- **Incidentes de segurança**: playbook com avaliação de notificação à ANPD (art. 48).

## Auditoria
`audit_logs` registra: login (sucesso/falha), 2FA, cadastro, permissões/aprovações, execuções de IA, decisões humanas,
cobranças/faturas/excedentes, exclusões LGPD, integrações, exportações, mudanças de workflow e de prompts.

## Backups e recuperação (produção)
- Postgres gerenciado com **PITR** (point-in-time recovery) e backups diários.
- **RPO**: 5 minutos (WAL contínuo). **RTO**: 1 hora.
- Teste de restauração mensal em homologação (checklist em `docs/operacao/deploy.md`).
- Em desenvolvimento (PGlite), o banco é a pasta `.data/pglite` — copie-a para backup.
