# Matriz de rastreabilidade — ORBITY-NEPTUNE v0.1.0

Status: ✅ Implementado e testado · 🟡 Implementado parcial / sem teste automatizado · 🔑 Implementado, depende de credencial externa · ⏳ Pendente (versão prevista)
Nenhum requisito foi removido; itens pendentes estão listados com versão prevista.

| ID | Requisito | Módulo | Prior. | Status | Evidência / teste | Versão |
|---|---|---|---|---|---|---|
| REQ-ID-01 | Cadastro e-mail/senha com política de senha | Identity | Alta | ✅ | core.test › Identidade | 0.1 |
| REQ-ID-02 | Login Google / Microsoft (OAuth + state) | Identity | Alta | 🔑 | `/api/auth/oauth/[provider]` (sem credenciais → 501 explícito) | 0.1 |
| REQ-ID-03 | 2FA por app autenticador (TOTP) | Identity | Alta | ✅ | core.test › 2FA; Configurações | 0.1 |
| REQ-ID-04 | 2FA por e-mail/SMS | Identity | Média | ⏳ | depende de SMTP/SMS | 0.2 |
| REQ-ID-05 | Gestão de sessões (listar/revogar) | Identity | Alta | ✅ | Configurações, `/api/me` | 0.1 |
| REQ-ID-06 | Proteção contra força bruta | Segurança | Alta | ✅ | `login()` (rate limit em memória; Redis em prod ⏳ 0.2) | 0.1 |
| REQ-ORG-01 | Organização com onboarding guiado | Organization | Alta | ✅ | `/onboarding`, `/api/onboarding` | 0.1 |
| REQ-ORG-02 | Colaborador por convite com aprovação do admin | Organization | Alta | ✅ | core.test › convite pendente; Admin | 0.1 |
| REQ-ORG-03 | Onboarding com sugestões por IA | Organization | Média | 🟡 | assistente guiado sem chamada de IA | 0.2 |
| REQ-PERM-01 | Cargos Admin/Gestor/Colaborador + cargos customizados | Permissions | Alta | ✅ | Admin › editor de permissões | 0.1 |
| REQ-PERM-02 | Verificação de permissão no backend | Permissions | Alta | ✅ | core.test › permissões | 0.1 |
| REQ-PERM-03 | Permissões por equipe/recurso | Permissions | Média | 🟡 | equipes existem; escopo por equipe nas consultas ⏳ | 0.3 |
| REQ-TEN-01 | Isolamento por organização + testes | Multi-tenancy | Alta | ✅ | core.test, prospect-crm.test › isolamento | 0.1 |
| REQ-SEC-07 | Row-Level Security no Postgres | Segurança | Média | ⏳ | ADR 0001 | 0.3 |
| REQ-CRM-01 | Empresas, contatos, leads, oportunidades com deduplicação | CRM | Alta | ✅ | core.test › dedupe | 0.1 |
| REQ-CRM-02 | Funil com etapas, motivo de perda, histórico | CRM | Alta | ✅ | core.test › mover oportunidade | 0.1 |
| REQ-CRM-03 | Atividades, tarefas, reuniões, propostas | CRM | Alta | ✅ | página da oportunidade | 0.1 |
| REQ-CRM-04 | Etapas personalizáveis pelo usuário | CRM | Média | ⏳ | etapas padrão provisionadas | 0.2 |
| REQ-PRO-01 | Construtor de ICP | Prospect.AI | Alta | ✅ | `/prospect` | 0.1 |
| REQ-PRO-02 | Lead scoring explicável (fatores, confiabilidade) | Prospect.AI | Alta | ✅ | pure.test › scoring | 0.1 |
| REQ-PRO-03 | Importação CSV (mapeamento, validação, dedupe) | Prospect.AI | Alta | ✅ | core.test › CSV | 0.1 |
| REQ-PRO-04 | Copiloto de abordagem (rascunho, sem envio automático) | Prospect.AI | Alta | ✅ | `/api/prospect/leads/[id]` | 0.1 |
| REQ-PRO-05 | Exportação CSV auditada | Prospect.AI | Média | ✅ | prospect-crm.test | 0.1 |
| REQ-PRO-06 | Pesquisa em fontes públicas/licenciadas e enriquecimento | Prospect.AI | Média | ⏳ | depende de provedor de dados licenciado | 0.3 |
| REQ-PRO-07 | Cadências multicanal | Prospect.AI | Média | 🟡 | tabela `cadences`; execução via Workflow Engine | 0.2 |
| REQ-CLO-01 | Caixa de entrada compartilhada | Closer.AI | Alta | ✅ | closer-workflows.test | 0.1 |
| REQ-CLO-02 | Webchat | Closer.AI | Alta | ✅ | `/api/webhooks/webchat` | 0.1 |
| REQ-CLO-03 | WhatsApp Business Platform oficial | Closer.AI | Alta | 🔑 | webhook + validação de credencial; envio real ⏳ 0.2 | 0.1 |
| REQ-CLO-04 | E-mail / Instagram Direct | Closer.AI | Média | 🔑 | catálogo; conectores de envio ⏳ | 0.2 |
| REQ-CLO-05 | Base de conhecimento com busca vetorial (pgvector) | Closer.AI | Alta | ✅ | core.test › RAG isolado | 0.1 |
| REQ-CLO-06 | Leitura de PDF/planilhas na base | Closer.AI | Média | 🟡 | .txt/.csv/.md; PDF ⏳ | 0.2 |
| REQ-CLO-07 | Resposta de IA com aprovação humana | Closer.AI | Alta | ✅ | core.test › aprovação | 0.1 |
| REQ-CLO-08 | Intenção, resumo, handoff, SLA | Closer.AI | Alta | ✅ | pure.test, dashboard SLA | 0.1 |
| REQ-SI-01 | Dashboard, funil, vendedores, canais | Sales Intelligence | Alta | ✅ | `/dashboard`, `/intelligence` | 0.1 |
| REQ-SI-02 | Previsão com cenários, premissas, incerteza, limitações | Sales Intelligence | Alta | ✅ | core.test › previsão | 0.1 |
| REQ-SI-03 | Recomendações com evidência/impacto/ação/indicador | Sales Intelligence | Alta | ✅ | `recommendations()` | 0.1 |
| REQ-SI-04 | Consultas em linguagem natural (seguras) | Sales Intelligence | Média | ✅ | mapeadas para métricas, sem SQL livre | 0.1 |
| REQ-SI-05 | Relatórios gerenciais + exportação | Sales Intelligence | Média | ✅ | `/relatorios` | 0.1 |
| REQ-EVT-01 | Outbox transacional, idempotência, retry/backoff, DLQ, versão, correlação | Event Engine | Alta | ✅ | core.test › DLQ | 0.1 |
| REQ-EVT-02 | Worker separado + monitoramento de filas | Event Engine | Alta | ✅ | `npm run worker`, `/api/health`, Integrações | 0.1 |
| REQ-EVT-03 | Redis para escala horizontal | Event Engine | Baixa | ⏳ | REDIS_URL | 0.3 |
| REQ-WF-01 | Gatilhos, condições, ramificações, ações, esperas, aprovações | Workflow | Alta | ✅ | core.test › automação | 0.1 |
| REQ-WF-02 | Modelos, editor, linguagem natural (rascunho) | Workflow | Alta | ✅ | `/automacoes` | 0.1 |
| REQ-WF-03 | Versionamento, simulação, pausa, reprocessamento, logs | Workflow | Alta | ✅ | closer-workflows.test | 0.1 |
| REQ-WF-04 | Anti-loop, anti-duplicidade, limite de passos | Workflow | Alta | ✅ | core.test › ciclo, execução única | 0.1 |
| REQ-WF-05 | Editor visual drag-and-drop em canvas | Workflow | Média | 🟡 | editor por lista de nós | 0.3 |
| REQ-AI-01 | Camada independente de provedor com fallback | IA | Alta | ✅ | providers (Anthropic/OpenAI/local) | 0.1 |
| REQ-AI-02 | 12 agentes + Agente Executivo | IA | Alta | ✅ | catálogo; `/agentes` | 0.1 |
| REQ-AI-03 | Centro de controle (modelo, autonomia, limites, versões) | IA | Alta | ✅ | `/agentes/[key]` | 0.1 |
| REQ-AI-04 | Proteções: injection, tenants, PII, alegação falsa | IA | Alta | ✅ | pure.test › guardrails | 0.1 |
| REQ-AI-05 | Limites de custo por agente e carteira | IA | Alta | ✅ | core.test › créditos | 0.1 |
| REQ-AI-06 | Memória individual/organizacional | IA | Média | 🟡 | base de conhecimento + preferências; memória individual ⏳ | 0.2 |
| REQ-AI-07 | Voz e comunicação multilíngue | IA | Baixa | ⏳ | flag `ai_voice` criada | 0.3 |
| REQ-EVAL-01 | AI Evaluation Center (casos, adversariais, governança, rollback) | IA | Alta | ✅ | core.test › governança | 0.1 |
| REQ-GOAL-01 | Metas, comissões versionadas, simulação, ranking | Metas | Alta | ✅ | pure.test › comissão; `/tarefas` | 0.1 |
| REQ-DATA-01 | Catálogo de métricas canônicas | Data | Alta | ✅ | `metric_definitions`, `/relatorios` | 0.1 |
| REQ-DATA-02 | Linhagem e classificação de fontes | Data | Média | ✅ | `data_sources`, Admin | 0.1 |
| REQ-BILL-01 | Planos, entitlements e limites no backend | Billing | Alta | ✅ | admin-billing.test | 0.1 |
| REQ-BILL-02 | Carteira de créditos, excedente só autorizado com teto | Billing | Alta | ✅ | core.test › billing | 0.1 |
| REQ-BILL-03 | Previsão de gastos antes da cobrança | Billing | Alta | ✅ | `forecastSpend` | 0.1 |
| REQ-BILL-04 | Cobrança real (Stripe/Mercado Pago/Asaas) | Billing | Alta | 🔑 | credenciais validadas; checkout/webhooks ⏳ | 0.2 |
| REQ-BILL-05 | Preços finais | Billing | Alta | ⏳ | **não inventados** — exigem validação comercial | — |
| REQ-FF-01 | Feature flags (plano, segmento, org, usuário, rollout) | Feature Mgmt | Alta | ✅ | `hasFeature`, painel global | 0.1 |
| REQ-CS-01 | Customer Health Score transparente e configurável | Customer Success | Alta | ✅ | pure.test; `/customer-success` | 0.1 |
| REQ-SUP-01 | Chamados com SLA, prioridade, satisfação, IA | Suporte | Média | ✅ | `/suporte` | 0.1 |
| REQ-EXP-01 | Experimentos com estatística honesta | Experimentation | Média | ✅ | pure.test › inconclusivo | 0.1 |
| REQ-INC-01 | Incidentes com severidade, timeline, playbooks | Incidents | Média | ✅ | painel global | 0.1 |
| REQ-LGPD-01 | Exportação e anonimização de titular, bases legais | LGPD | Alta | ✅ | core.test › LGPD | 0.1 |
| REQ-LGPD-06 | Expurgo automático por retenção | LGPD | Média | ⏳ | campo `retention_days` | 0.2 |
| REQ-AUD-01 | Auditoria de login, IA, aprovações, cobranças, exclusões, exportações | Audit | Alta | ✅ | `audit_logs`, Admin | 0.1 |
| REQ-I18N-01 | Locale/moeda/fuso por organização, dicionários pt-BR/en | i18n | Média | ✅ | `src/lib/i18n`, `format.ts` | 0.1 |
| REQ-I18N-02 | Tradução completa da interface | i18n | Baixa | 🟡 | navegação traduzida; páginas em pt-BR | 0.3 |
| REQ-UX-01 | Tema claro/escuro, busca global, command palette, notificações | UX | Alta | ✅ | AppShell | 0.1 |
| REQ-UX-02 | Tela inicial = última tela acessada | UX | Média | ✅ | `/` + preferências | 0.1 |
| REQ-UX-03 | PWA instalável, responsivo | UX | Média | ✅ | manifest + sw.js | 0.1 |
| REQ-UX-04 | Widgets personalizáveis / favoritos | UX | Baixa | ⏳ | campo `favorites` | 0.2 |
| REQ-INT-01 | Central de integrações com credenciais criptografadas e logs | Integrações | Alta | ✅ | `/integracoes` | 0.1 |
| REQ-INT-02 | HubSpot, Pipedrive, RD, Google, Microsoft, Zapier, Make, n8n, Sheets | Integrações | Média | 🔑 | validação de credencial; sincronização ⏳ | 0.2 |
| REQ-OPS-01 | CI (typecheck, testes, build) | DevOps | Alta | ✅ | `.github/workflows/ci.yml` | 0.1 |
| REQ-OPS-02 | Health check e logs estruturados | Observabilidade | Alta | ✅ | `/api/health` | 0.1 |
| REQ-OPS-03 | Tracing distribuído (OpenTelemetry) | Observabilidade | Média | ⏳ | — | 0.3 |
| REQ-QA-01 | Testes unitários e de integração | QA | Alta | ✅ | 41 testes / 6 arquivos | 0.1 |
| REQ-QA-02 | Testes E2E de navegador, carga e acessibilidade | QA | Média | ⏳ | verificação manual feita no navegador | 0.2 |
| REQ-BIZ-01 | Validação comercial (entrevistas, pilotos, preços) | Negócio | Alta | ⏳ | atividade fora do software | — |

### Prompts 34 (Dashboard interativo) e 35 (Flávio) — detalhes em [`docs/prompt-34-35`](prompt-34-35/entrega.md)

| ID | Requisito | Módulo | Prior. | Status | Evidência / teste | Versão |
|---|---|---|---|---|---|---|
| REQ-DASH-01 | Tooltip com valores exatos e período do ponto; ponto ativo; legenda que liga/desliga séries; animação discreta | Dashboard | Alta | 🟡 | `components/charts/interactive.tsx`; sem teste automatizado de interface nem verificação em navegador | 0.2 |
| REQ-DASH-02 | Teclado (setas, Enter, Esc), toque e tabela alternativa acessível | Dashboard | Alta | 🟡 | idem; não verificado em navegador nesta entrega | 0.2 |
| REQ-DASH-03 | Drill-down de indicadores até leads/oportunidades | Dashboard | Alta | ✅ | metrics-flavio.test › drill-down | 0.2 |
| REQ-DASH-04 | Filtros globais e cruzados: período, vendedor, equipe, campanha, origem, etapa | Dashboard | Alta | ✅ | metrics-flavio.test › filtros | 0.2 |
| REQ-DASH-05 | Filtro por produto | Dashboard | Média | ⏳ | sem vínculo oportunidade-produto no schema | 0.3 |
| REQ-DASH-06 | Comparação de períodos (anterior, ano anterior, personalizado) | Dashboard | Alta | ✅ | metrics-flavio.test › filtros, drill-down | 0.2 |
| REQ-DASH-07 | Exportação CSV do resultado filtrado (auditada, anti-fórmula) | Dashboard | Média | ✅ | metrics-flavio.test › exportação | 0.2 |
| REQ-DASH-08 | Serviço central e consistência card × gráfico × tabela × relatório | Dados | Alta | ✅ | metrics-flavio.test › consistência e somas | 0.2 |
| REQ-DASH-09 | Permissões e isolamento no drill-down e nos filtros | Segurança | Alta | ✅ | metrics-flavio.test › permissões, isolamento | 0.2 |
| REQ-DASH-10 | Atualização em tempo real | Dashboard | Média | 🟡 | atualização a cada 60 s com aba visível (polling); sem push | 0.2 |
| REQ-FLA-01 | Identidade Flávio substitui o assistente genérico, sem segundo motor | IA | Alta | ✅ | usa `runAgent`/agente `executive`; teste com provedor simulado | 0.2 |
| REQ-FLA-02 | Análises comerciais (35.2 e 35.4) com fonte, período e critérios | IA | Alta | ✅ | metrics-flavio.test › perguntas da especificação | 0.2 |
| REQ-FLA-03 | Ações só com confirmação, assinadas, revalidadas e auditadas | IA | Alta | ✅ | metrics-flavio.test › ações | 0.2 |
| REQ-FLA-04 | Histórico por usuário/organização com exclusão | IA | Média | ✅ | metrics-flavio.test › histórico | 0.2 |
| REQ-FLA-05 | Fallback determinístico sem chave ou com falha do provedor | IA | Alta | ✅ | metrics-flavio.test › fallback | 0.2 |
| REQ-FLA-06 | Painel lateral persistente com estados e sugestões contextuais | IA | Alta | 🟡 | `components/flavio/flavio-dock.tsx`; não verificado em navegador nesta entrega | 0.2 |
| REQ-FLA-07 | Provedor Gemini | IA | Baixa | ⏳ | abstração `AIProvider` pronta; sem credencial nem autorização | — |

> Master Prompt 4.0: a matriz de rastreabilidade ampliada (seções 5–38), a auditoria da Fase 0 e o backlog priorizado estão em [`docs/v4`](v4/README.md).
