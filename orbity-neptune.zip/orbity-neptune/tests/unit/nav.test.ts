import { describe, it, expect } from "vitest";
import { NAV, NAV_GROUPS, NAV_LABEL_KEYS, visibleNavGroups } from "../../src/components/layout/nav";
import { SYSTEM_ROLES } from "../../src/server/permissions";
import pt from "../../src/lib/i18n/messages/pt-BR.json";

const keysOf = (perms: readonly string[], platform = false) =>
  Object.fromEntries(visibleNavGroups(perms, platform).map((g) => [g.key, g.items.map((i) => i.href)]));

describe("Menu agrupado por função", () => {
  it("mantém as mesmas rotas de antes (só agrupa) e adiciona Configurações", () => {
    const before = ["/command-center", "/business-brain", "/dashboard", "/prospect", "/closer", "/intelligence", "/financeiro", "/simulador", "/crm",
      "/automacoes", "/agentes", "/ai-control", "/tarefas", "/relatorios", "/integracoes", "/billing", "/customer-success", "/admin"];
    const hrefs = NAV.map((n) => n.href);
    expect(new Set(hrefs).size).toBe(hrefs.length); // sem duplicidade
    for (const h of before) expect(hrefs).toContain(h);
    expect(hrefs.filter((h) => !before.includes(h))).toEqual(["/alertas", "/configuracoes"]); // Task Intelligence adiciona Alertas
  });

  it("segue a ordem de seções pedida", () => {
    expect(NAV_GROUPS.map((g) => g.key)).toEqual(["sell", "analyze", "automate", "account", "admin"]);
    const g = Object.fromEntries(NAV_GROUPS.map((x) => [x.key, x.items.map((i) => i.href)]));
    expect(g.sell).toEqual(expect.arrayContaining(["/prospect", "/closer", "/crm", "/tarefas"]));
    expect(g.analyze).toEqual(expect.arrayContaining(["/command-center", "/intelligence", "/simulador", "/relatorios", "/financeiro"]));
    expect(g.automate).toEqual(["/automacoes", "/agentes"]);
    expect(g.account).toEqual(["/integracoes", "/billing", "/configuracoes"]);
    expect(g.admin).toEqual(["/admin", "/ai-control", "/customer-success"]);
  });

  it("colaborador: não vê itens sem permissão nem a seção Administração vazia", () => {
    const v = keysOf(SYSTEM_ROLES.member.permissions);
    expect(Object.keys(v)).not.toContain("admin");
    expect(v.analyze).not.toContain("/financeiro"); // sem finance:read
    expect(v.analyze).not.toContain("/simulador"); // sem strategy:read
    expect(v.account).not.toContain("/billing"); // sem billing:read
    expect(v.account).toContain("/configuracoes"); // sem permissão exigida
    expect(v.sell).toEqual(["/dashboard", "/prospect", "/closer", "/crm", "/tarefas", "/alertas"]);
  });

  it("gestor vê Controle de IA mas não Administração da empresa nem Customer Success", () => {
    const v = keysOf(SYSTEM_ROLES.manager.permissions);
    expect(v.admin).toEqual(["/admin", "/ai-control"]); // gestor tem admin:users e ai:manage
    expect(v.admin).not.toContain("/customer-success");
  });

  it("Customer Success só para administrador global (platformOnly)", () => {
    expect(keysOf(["*"], false).admin).not.toContain("/customer-success");
    expect(keysOf(["*"], true).admin).toContain("/customer-success");
  });

  it("perfil sem permissões: só itens livres, seções vazias somem", () => {
    const v = keysOf([]);
    expect(Object.keys(v)).toEqual(["sell", "account"]);
    expect(v.sell).toEqual(["/dashboard"]);
    expect(v.account).toEqual(["/configuracoes"]);
  });

  it("todo texto do menu existe em pt-BR e os nomes de função estão aplicados", () => {
    const dict = pt as Record<string, string>;
    for (const k of NAV_LABEL_KEYS) expect(dict[k], k).toBeTruthy();
    expect(dict["nav.closer"]).toBe("Propostas e fechamento");
    expect(dict["nav.brain"]).toBe("Pergunte ao Flávio");
    expect(dict["nav.aicontrol"]).toBe("Controle de IA");
    expect(dict["nav.intelligence"]).toBe("Indicadores");
    expect(dict["nav.dashboard"]).toBe("Painel de vendas");
    expect(dict["nav.command"]).toBe("Visão gerencial");
  });
});
