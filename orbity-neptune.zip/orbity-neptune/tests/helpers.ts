import { createDb, type DB } from "../src/server/db/client";
import { runMigrations } from "../src/server/db/migrate";
import { seedCore } from "../src/server/db/seed-core";
import { registerUser, contextFor } from "../src/server/auth/service";
import type { TenantContext } from "../src/server/tenancy/context";

process.env.ENCRYPTION_KEY ||= Buffer.alloc(32, 7).toString("base64");
delete process.env.DATABASE_URL;
delete process.env.ANTHROPIC_API_KEY;
delete process.env.OPENAI_API_KEY;

export async function setupDb(): Promise<{ db: DB; close: () => Promise<void> }> {
  const r = await createDb({ memory: true });
  await runMigrations(r.db);
  await seedCore(r.db);
  return r;
}

let n = 0;
export async function newTenant(db: DB, name = "Org"): Promise<TenantContext> {
  n++;
  const { user, organizationId } = await registerUser(db, { name: `User ${n}`, email: `user${n}-${Date.now()}@test.dev`, password: "senhaSegura123", organizationName: `${name} ${n}` });
  return (await contextFor(db, user.id, organizationId!))!;
}
