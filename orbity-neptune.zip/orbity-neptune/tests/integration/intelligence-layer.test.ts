import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { and, eq } from "drizzle-orm";
import { setupDb, newTenant } from "../helpers";
import type { DB } from "../../src/server/db/client";
import type { TenantContext } from "../../src/server/tenancy/context";
import { events, financeEntries, insights, memberships, opportunities, organizations, roles } from "../../src/server/db/schema";
import { registerUser, contextFor } from "../../src/server/auth/service";
import { createLead, createOpportunity } from "../../src/server/domains/crm";
import { decideInsight, getInsight, listInsights, markExecuted, measureOutcome, ruleStats, scanInsights } from "../../src/server/intelligence-layer/insights";
import { createDecision, transitionDecision, getDecision } from "../../src/server/intelligence-layer/decisions";
import { askBrain } from "../../src/server/intelligence-layer/brain";
import { generateBriefing, listBriefings } from "../../src/server/intelligence-layer/briefing";
import { systemContextFor } from "../../src/server/intelligence-layer/system-context";

let db: DB, close: () => Promise<void>;
beforeAll(async () => { ({ db, close } = await setupDb()); });
afterAll(async () => { await close(); });

const DAY = 864e5;
let seq = 0;

async function addUser(owner: TenantContext, roleKey: "manager" | "member") {
  const [org] = await db.select().from(organizations).where(eq(organizations.id, owner.organizationId));
  seq++;
  const { user } = await registerUser(db, { name: `Pessoa ${seq}`, email: `il-${seq}-${Date.now()}@test.dev`, password: "senhaSegura123", inviteOrgSlug: org.slug });
  const [role] = await db.select().from(roles).where(and(eq(roles.organizationId, org.id), eq(roles.key, roleKey)));
  await db.update(memberships).set({ status: "active", roleId: role.id }).where(and(eq(memberships.userId, user.id), eq(memberships.organizationId, org.id)));
  return (await contextFor(db, user.id, org.id))!;
}

async function staleOpp(ctx: TenantContext, title: string, daysAgo = 10) {
  const o = await createOpportunity(ctx, { title, amountCents: 500_000 });
  await db.update(opportunities).set({ lastActivityAt: new Date(Date.now() - daysAgo * DAY) }).where(eq(opportunities.id, o.id));
  return o;
}

const ANSWER_PARTS = ["resumoExecutivo", "diagnostico", "dadosUtilizados", "evidencias", "causasPossiveis", "impactoFinanceiro", "alternativas", "recomendacoes", "planoDeAcao", "indicadores"];

describe("Intelligence Layer — insights", () => {
  let a: TenantContext;
  beforeAll(async () => {
    a = await newTenant(db, "IL-A");
    for (let i = 0; i < 4; i++) await createOpportunity(a, { title: `Negócio ativo ${i}`, amountCents: 100_000 });
    await staleOpp(a, "Negócio parado");
    await createLead(a, { title: "Lead sem score" });
  });

  it("gera insights com evidência e fontes, sem duplicar em varreduras repetidas", async () => {
    const r1 = await scanInsights(a);
    expect(r1.created).toBeGreaterThanOrEqual(2);
    const list = await listInsights(a, { status: ["open"] });
    const stale = list.find((i) => i.ruleKey === "stale_opportunities")!;
    expect(stale).toBeTruthy();
    expect(stale.evidence.facts.length).toBeGreaterThan(0);
    expect(stale.evidence.facts.every((f) => f.source.length > 0)).toBe(true);
    expect(stale.indicator).toMatchObject({ baseline: 1, direction: "down" });
    expect(list.find((i) => i.ruleKey === "unscored_leads")).toBeTruthy();
    const evts = await db.select().from(events).where(and(eq(events.organizationId, a.organizationId), eq(events.type, "insight.created")));
    expect(evts.length).toBe(r1.created);

    const r2 = await scanInsights(a);
    expect(r2.created).toBe(0);
    const again = await listInsights(a, { status: ["open"] });
    const keys = again.map((i) => i.dedupeKey);
    expect(new Set(keys).size).toBe(keys.length);
  });

  it("expira o insight quando a condição deixa de existir", async () => {
    await db.update(opportunities).set({ lastActivityAt: new Date() }).where(eq(opportunities.organizationId, a.organizationId));
    const r = await scanInsights(a);
    expect(r.expired).toBeGreaterThanOrEqual(1);
    const rows = await db.select().from(insights).where(and(eq(insights.organizationId, a.organizationId), eq(insights.ruleKey, "stale_opportunities")));
    expect(rows.every((x) => x.status === "expired")).toBe(true);
  });

  it("ciclo de vida: aceitar → executar → medir (inconclusivo antes de 7 dias, melhorou depois)", async () => {
    const o = await staleOpp(a, "Outro negócio parado");
    await scanInsights(a);
    const ins = (await listInsights(a, { status: ["open"] })).find((i) => i.ruleKey === "stale_opportunities")!;
    expect((await decideInsight(a, ins.id, { status: "accepted" })).status).toBe("accepted");
    expect((await markExecuted(a, ins.id)).status).toBe("executed");
    const early = await measureOutcome(a, ins.id);
    expect(early.outcome?.verdict).toBe("inconclusive");

    await db.update(insights).set({ executedAt: new Date(Date.now() - 10 * DAY) }).where(eq(insights.id, ins.id));
    await db.update(opportunities).set({ lastActivityAt: new Date() }).where(eq(opportunities.id, o.id));
    const later = await measureOutcome(a, ins.id);
    expect(later.outcome?.verdict).toBe("improved");
    expect(later.outcome?.observed).toBe(0);
    await expect(decideInsight(a, ins.id, { status: "rejected" })).rejects.toThrow(/já está/);
  });

  it("alterar exige descrição; rejeição registra quem decidiu", async () => {
    const ins = (await listInsights(a, { status: ["open"] })).find((i) => i.ruleKey === "unscored_leads")!;
    await expect(decideInsight(a, ins.id, { status: "modified" })).rejects.toThrow(/Descreva/);
    const r = await decideInsight(a, ins.id, { status: "rejected", note: "Leads de teste" });
    expect(r.decidedBy).toBe(a.userId);
  });

  it("feedback: regra com ≥ 5 decisões e ≥ 70% de rejeição tem prioridade reduzida", async () => {
    const c = await newTenant(db, "IL-Feedback");
    const old = new Date(Date.now() - 30 * DAY);
    await db.insert(insights).values(Array.from({ length: 5 }, (_, i) => ({
      organizationId: c.organizationId, ruleKey: "unscored_leads", dedupeKey: "unscored_leads", domain: "prospect", title: `antigo ${i}`, summary: "-",
      priority: "medium", status: "rejected", decidedAt: old, createdAt: old, evidence: { facts: [{ label: "x", value: "1", source: "teste" }], assumptions: [], calculations: [], confidence: 1, missingData: [], limitations: [] },
    })));
    const stats = await ruleStats(c);
    expect(stats.find((s) => s.ruleKey === "unscored_leads")?.demoted).toBe(true);
    await createLead(c, { title: "Lead novo" });
    await scanInsights(c);
    const ins = (await listInsights(c, { status: ["open"] })).find((i) => i.ruleKey === "unscored_leads")!;
    expect(ins.priority).toBe("low"); // seria "medium" (100% dos leads sem score)
    expect(ins.evidence.limitations.join(" ")).toMatch(/Prioridade reduzida/);
  });

  it("insights financeiros só aparecem para quem tem finance:read", async () => {
    await db.insert(financeEntries).values({ organizationId: a.organizationId, kind: "receivable", description: "Fatura vencida", amountCents: 300_000, dueDate: new Date(Date.now() - 10 * DAY) });
    await scanInsights(a);
    const fin = (await listInsights(a, { status: ["open"] })).find((i) => i.ruleKey === "finance_overdue_receivables");
    expect(fin).toBeTruthy();
    const member = await addUser(a, "member");
    expect(member.permissions).not.toContain("finance:read");
    expect((await listInsights(member)).some((i) => i.domain === "finance")).toBe(false);
    await expect(getInsight(member, fin!.id)).rejects.toThrow(/não encontrado/);
  });

  it("isolamento: outra organização não lê nem decide insights alheios", async () => {
    const b = await newTenant(db, "IL-B");
    const ins = (await listInsights(a))[0];
    await expect(getInsight(b, ins.id)).rejects.toThrow(/não encontrado/);
    await expect(decideInsight(b, ins.id, { status: "rejected" })).rejects.toThrow(/não encontrado/);
    expect((await listInsights(b)).some((i) => i.id === ins.id)).toBe(false);
    await expect(getInsight(b, "nao-e-uuid")).rejects.toThrow(/não encontrado/);
  });

  it("contexto de sistema do worker executa a varredura com ator 'system'", async () => {
    const sys = await systemContextFor(db, a.organizationId);
    expect(sys?.roleKey).toBe("system");
    const r = await scanInsights(sys!);
    expect(r.financeEvaluated).toBe(true);
  });
});

describe("Decision Engine", () => {
  it("segregação de funções, permissão de aprovação, auditoria e evento", async () => {
    const owner = await newTenant(db, "DE");
    const manager = await addUser(owner, "manager");
    const member = await addUser(owner, "member");
    const d = await createDecision(owner, { title: "Reduzir ciclo de vendas", problem: "Ciclo médio alto", alternatives: [{ name: "Playbook" }, { name: "Mais SDRs" }] });
    expect(d.status).toBe("draft");
    await expect(transitionDecision(owner, d.id, { action: "submit" })).rejects.toThrow(/Escolha uma alternativa/);
    await expect(transitionDecision(owner, d.id, { action: "edit", chosenAlternative: "Inexistente" })).rejects.toThrow(/não está na lista/);
    await transitionDecision(owner, d.id, { action: "edit", chosenAlternative: "Playbook", rationale: "Menor custo" });
    expect((await transitionDecision(owner, d.id, { action: "submit" })).status).toBe("pending_approval");

    await expect(transitionDecision(owner, d.id, { action: "approve" })).rejects.toThrow(/Segregação/);
    await expect(transitionDecision(member, d.id, { action: "approve" })).rejects.toThrow(/approvals:decide/);
    const ap = await transitionDecision(manager, d.id, { action: "approve" });
    expect(ap.status).toBe("approved");
    expect(ap.approvedBy).toBe(manager.userId);
    const evts = await db.select().from(events).where(and(eq(events.organizationId, owner.organizationId), eq(events.type, "decision.approved")));
    expect(evts).toHaveLength(1);

    await expect(transitionDecision(owner, d.id, { action: "close", result: "" })).rejects.toThrow();
    expect((await transitionDecision(owner, d.id, { action: "monitor", reviewAt: new Date(Date.now() + 30 * DAY) })).status).toBe("monitoring");
    expect((await transitionDecision(owner, d.id, { action: "close", result: "Ciclo caiu 10 dias" })).status).toBe("closed");

    const other = await newTenant(db, "DE-outro");
    await expect(getDecision(other, d.id)).rejects.toThrow(/não encontrada/);
    await expect(transitionDecision(other, d.id, { action: "close", result: "invasão" })).rejects.toThrow(/não encontrada/);
  });

  it("decisão criada a partir de insight copia a evidência; insight de outra org é recusado", async () => {
    const t = await newTenant(db, "DE-ins");
    await createLead(t, { title: "Lead" });
    await scanInsights(t);
    const ins = (await listInsights(t))[0];
    const d = await createDecision(t, { title: "Pontuar leads", problem: ins.summary, insightId: ins.id });
    expect(d.evidence?.facts.length).toBeGreaterThan(0);
    const x = await newTenant(db, "DE-x");
    await expect(createDecision(x, { title: "Tentativa", problem: "IDOR", insightId: ins.id })).rejects.toThrow(/não encontrado/);
  });
});

describe("Business Brain e briefing", () => {
  it("responde nas 10 partes e declara a falta de dados financeiros", async () => {
    const t = await newTenant(db, "BB");
    const r = await askBrain(t, "Posso contratar 2 funcionários de R$ 4.000?");
    for (const k of ANSWER_PARTS) expect(r).toHaveProperty(k);
    expect(r.intent).toBe("hiring");
    expect(r.resumoExecutivo).toMatch(/Não há lançamentos financeiros/);
    expect(r.evidencias.confidence).toBe(0);
    expect(r.narration).toBe("deterministic");

    const rev = await askBrain(t, "Por que minha receita caiu?");
    expect(rev.supported).toBe(true);
    expect(rev.intent).toBe("revenue_drop");
    for (const k of ANSWER_PARTS) expect(rev).toHaveProperty(k);
    expect(rev.evidencias.facts.every((f) => f.source)).toBe(true);

    const unk = await askBrain(t, "Qual a cor favorita do cliente?");
    expect(unk.supported).toBe(false);
    expect(unk.recomendacoes.length).toBeGreaterThan(5);
  });

  it("com lançamentos, responde sobre contratação com premissas e estimativa", async () => {
    const t = await newTenant(db, "BB-fin");
    const now = Date.now();
    await db.insert(financeEntries).values([
      { organizationId: t.organizationId, kind: "receivable", description: "Venda", amountCents: 9_000_000, dueDate: new Date(now - 20 * DAY), paidAt: new Date(now - 20 * DAY), status: "paid" },
      { organizationId: t.organizationId, kind: "payable", description: "Aluguel", amountCents: 3_000_000, dueDate: new Date(now - 15 * DAY), paidAt: new Date(now - 15 * DAY), status: "paid" },
    ]);
    const r = await askBrain(t, "Posso contratar 1 funcionário de R$ 5.000?");
    expect(r.evidencias.assumptions.join(" ")).toMatch(/1,7|1.7/);
    expect(r.impactoFinanceiro[0].nature).toBe("estimativa");
    expect(r.resumoExecutivo).toMatch(/sim|cautela/i);
  });

  it("briefing é gerado, persistido e responde às 6 perguntas", async () => {
    const t = await newTenant(db, "BR");
    const b = await generateBriefing(t, "weekly");
    const c = b.content as Record<string, unknown>;
    for (const k of ["acontecendo", "mudou", "atencao", "oportunidades", "decisoes", "melhorar"]) expect(Array.isArray(c[k])).toBe(true);
    expect(c.financeStatus).toBe("sem_dados");
    expect(await listBriefings(t)).toHaveLength(1);
    const other = await newTenant(db, "BR-2");
    expect(await listBriefings(other)).toHaveLength(0);
  });
});
