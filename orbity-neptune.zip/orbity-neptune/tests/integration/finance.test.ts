import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { setupDb, newTenant } from "../helpers";
import type { DB } from "../../src/server/db/client";
import { SYSTEM_ROLES } from "../../src/server/permissions";
import {
  answerFinancialQuestion, breakEvenReport, cashflowReport, computeAging, computeBreakEven, computeCashflow, computeDre,
  createEntry, dreReport, financialSnapshot, getEntry, listCategories, listEntries, parseMoney, setBudget, budgetVsActual, updateEntry,
  type CalcRow,
} from "../../src/server/domains/finance";
import { seedDemoFinance } from "../../src/server/domains/finance/demo";

let db: DB, close: () => Promise<void>;
beforeAll(async () => { ({ db, close } = await setupDb()); });
afterAll(async () => { await close(); });

const paid = (kind: "receivable" | "payable", group: string | null, amountCents: number, paidAt = new Date("2026-09-10T15:00:00Z")): CalcRow =>
  ({ kind, status: "paid", amountCents, dueDate: paidAt, paidAt, group });

describe("Cálculos financeiros (precisão)", () => {
  const sep: CalcRow[] = [
    paid("receivable", "receita_bruta", 100_000), paid("receivable", "financeiro", 500),
    paid("payable", "deducoes", 8_000), paid("payable", "custo", 22_000),
    paid("payable", "pessoal", 30_000), paid("payable", "marketing", 10_000), paid("payable", "operacional", 5_000),
    paid("payable", "financeiro", 1_000), paid("payable", "impostos", 2_000),
    { kind: "payable", status: "open", amountCents: 99_999, dueDate: new Date("2026-09-12T12:00:00Z"), paidAt: null, group: "pessoal" }, // em aberto: fora do DRE
  ];

  it("DRE gerencial: linhas e margens", () => {
    const [d] = computeDre(sep, ["2026-09"], "UTC");
    expect(d.receitaLiquida).toBe(92_000);
    expect(d.margemContribuicao).toBe(70_000);
    expect(d.margemContribuicaoPct).toBe(76.1);
    expect(d.totalDespesasFixas).toBe(45_000);
    expect(d.resultadoOperacional).toBe(25_000);
    expect(d.resultadoLiquido).toBe(22_500);
    expect(d.lancamentos).toBe(9);
  });

  it("ponto de equilíbrio = despesas fixas ÷ índice de margem de contribuição", () => {
    const dre = computeDre(sep, ["2026-09", "2026-10"], "UTC");
    const be = computeBreakEven(dre, "2026-10", (c) => String(c));
    expect(be.computable).toBe(true);
    expect(be.basisMonths).toEqual(["2026-09"]);
    expect(be.breakEvenReceitaLiquida).toBe(Math.round(45_000 / (70_000 / 92_000)));
    expect(be.breakEvenReceitaBruta).toBe(Math.round(59_143 * (100_000 / 92_000)));
    expect(be.gapReceitaBruta).toBe(100_000 - be.breakEvenReceitaBruta!);
  });

  it("ponto de equilíbrio não é calculado com margem de contribuição negativa", () => {
    const rows = [paid("receivable", "receita_bruta", 10_000), paid("payable", "custo", 12_000), paid("payable", "pessoal", 1_000)];
    const be = computeBreakEven(computeDre(rows, ["2026-09", "2026-10"], "UTC"), "2026-10", String);
    expect(be.computable).toBe(false);
    expect(be.reason).toMatch(/negativa/);
  });

  it("fluxo de caixa: só contas em aberto, por semana; vencidos ficam à parte", () => {
    const now = new Date("2026-10-01T12:00:00");
    const d = (days: number) => new Date(now.getTime() + days * 864e5);
    const rows: CalcRow[] = [
      { kind: "receivable", status: "open", amountCents: 1_000, dueDate: d(2), paidAt: null, group: null },
      { kind: "payable", status: "open", amountCents: 400, dueDate: d(9), paidAt: null, group: null },
      { kind: "receivable", status: "open", amountCents: 300, dueDate: d(-5), paidAt: null, group: null },
      { kind: "receivable", status: "paid", amountCents: 5_000, dueDate: d(3), paidAt: d(-1), group: null },
      { kind: "receivable", status: "open", amountCents: 7_000, dueDate: d(200), paidAt: null, group: null },
    ];
    const cf = computeCashflow(rows, now, 13);
    expect(cf.buckets).toHaveLength(13);
    expect(cf.buckets[0].inflowCents).toBe(1_000);
    expect(cf.buckets[1].outflowCents).toBe(400);
    expect(cf.buckets[1].cumulativeCents).toBe(600);
    expect(cf.overdueReceivableCents).toBe(300);
    expect(cf.totalInflowCents).toBe(1_000);
  });

  it("inadimplência: faixas de atraso e taxa de 90 dias", () => {
    const now = new Date("2026-10-01T12:00:00Z");
    const d = (days: number) => new Date(now.getTime() + days * 864e5);
    const r = (status: string, due: number, amountCents: number): CalcRow => ({ kind: "receivable", status, amountCents, dueDate: d(due), paidAt: status === "paid" ? d(due) : null, group: null });
    const a = computeAging([r("open", -10, 100), r("open", -45, 200), r("open", -120, 400), r("paid", -20, 300), r("canceled", -5, 999), r("open", 5, 50)], now);
    expect(a.buckets.map((b) => b.cents)).toEqual([100, 200, 0, 400]);
    expect(a.overdueCents).toBe(700);
    expect(a.overdueCount).toBe(3);
    expect(a.dueLast90Cents).toBe(600);
    expect(a.ratePct).toBe(50);
  });

  it("interpreta valores em reais", () => {
    expect(parseMoney("custo de R$ 5.000 cada")).toBe(500_000);
    expect(parseMoney("salário de 6,5 mil")).toBe(650_000);
    expect(parseMoney("posso contratar 3 pessoas?")).toBeNull();
  });
});

describe("Financeiro com banco", () => {
  it("organização vazia não tem dados (nunca estima)", async () => {
    const ctx = await newTenant(db, "FinVazia");
    const s = await financialSnapshot(ctx, 30);
    expect(s.hasData).toBe(false);
    expect(s.marginPct).toBeNull();
  });

  it("lançamentos → DRE, ponto de equilíbrio, baixa e orçamento", async () => {
    const ctx = await newTenant(db, "FinA");
    const cats = await listCategories(ctx);
    const c = (name: string) => cats.find((x) => x.name === name)!.id;
    const at = "2026-09-10T15:00:00Z";
    await createEntry(ctx, { kind: "receivable", description: "Venda setembro", categoryId: c("Vendas de produtos"), amountCents: 100_000, dueDate: at, paidAt: at });
    await createEntry(ctx, { kind: "payable", description: "Impostos", categoryId: c("Impostos sobre vendas"), amountCents: 8_000, dueDate: at, paidAt: at });
    await createEntry(ctx, { kind: "payable", description: "Custo", categoryId: c("Custo dos produtos e serviços"), amountCents: 22_000, dueDate: at, paidAt: at });
    await createEntry(ctx, { kind: "payable", description: "Folha", categoryId: c("Salários e encargos"), amountCents: 45_000, dueDate: at, paidAt: at });
    const now = new Date("2026-10-15T12:00:00Z");
    const dre = await dreReport(ctx, 2, now);
    const sep = dre.months.find((m) => m.month === "2026-09")!;
    expect(sep.resultadoOperacional).toBe(25_000);
    const be = await breakEvenReport(ctx, now);
    expect(be.breakEvenReceitaBruta).toBe(64_286);
    expect(be.evidence.facts[0].source).toBeTruthy();

    await expect(createEntry(ctx, { kind: "receivable", description: "Errado", categoryId: c("Salários e encargos"), amountCents: 10, dueDate: at })).rejects.toThrow(/não combina/);

    const open = await createEntry(ctx, { kind: "receivable", description: "Em aberto", amountCents: 5_000, dueDate: new Date(Date.now() + 3 * 864e5) });
    expect(open.status).toBe("open");
    const paidE = await updateEntry(ctx, open.id, { action: "pay" });
    expect(paidE.status).toBe("paid");
    await expect(updateEntry(ctx, open.id, { action: "pay" })).rejects.toThrow(/já está pago/);

    const month = new Date().toISOString().slice(0, 7);
    await setBudget(ctx, { categoryId: c("Vendas de produtos"), month, amountCents: 9_000 });
    const b = await budgetVsActual(ctx, month);
    expect(b.rows[0].budgetCents).toBe(9_000);

    const cf = await cashflowReport(ctx);
    expect(cf.premises.join(" ")).toMatch(/Saldo bancário inicial não é conhecido/);
  });

  it("isolamento: outra organização não lê nem altera lançamentos", async () => {
    const a = await newTenant(db, "FinIsoA"), b = await newTenant(db, "FinIsoB");
    const e = await createEntry(a, { kind: "payable", description: "Fornecedor A", amountCents: 1_234, dueDate: new Date() });
    await expect(getEntry(b, e.id)).rejects.toThrow(/não encontrado/);
    await expect(updateEntry(b, e.id, { action: "cancel" })).rejects.toThrow(/não encontrado/);
    expect((await listEntries(b)).some((x) => x.id === e.id)).toBe(false);
    const catsA = await listCategories(a);
    await expect(createEntry(b, { kind: "payable", description: "Usa categoria de A", categoryId: catsA.find((c) => c.kind === "expense")!.id, amountCents: 10, dueDate: new Date() })).rejects.toThrow(/não encontrada/);
  });

  it("colaborador (member) não acessa o financeiro", async () => {
    const admin = await newTenant(db, "FinMember");
    const member = { ...admin, roleKey: "member", permissions: [...SYSTEM_ROLES.member.permissions] };
    await expect(financialSnapshot(member, 30)).rejects.toThrow(/finance:read/);
    await expect(listEntries(member)).rejects.toThrow(/finance:read/);
    const manager = { ...admin, roleKey: "manager", permissions: [...SYSTEM_ROLES.manager.permissions] };
    await expect(financialSnapshot(manager, 30)).resolves.toBeTruthy();
  });

  it("assistente não inventa salário e mostra cálculos quando o custo é informado", async () => {
    const ctx = await newTenant(db, "FinAssist");
    const noCost = await answerFinancialQuestion(ctx, "Posso contratar três funcionários?");
    expect(noCost.intent).toBe("hiring");
    expect(noCost.needsInput).toBe("custo_por_pessoa");
    expect(noCost.calculations).toHaveLength(0);
    expect(noCost.answer).toMatch(/preciso do custo mensal/);
    const withCost = await answerFinancialQuestion(ctx, "Posso contratar 2 funcionários com custo total de R$ 5.000 cada?");
    expect(withCost.calculations[0]).toMatch(/2 ×/);
    expect(withCost.missingData.join(" ")).toMatch(/Nenhum mês completo/);
    const unknown = await answerFinancialQuestion(ctx, "Qual a cor do logo?");
    expect(unknown.intent).toBe("unknown");
  });

  it("dados de demonstração só em organização de demonstração", async () => {
    const ctx = await newTenant(db, "FinNaoDemo");
    const r = await seedDemoFinance(ctx.db, ctx.organizationId);
    expect(r.created).toBe(0);
    expect(r.skipped).toMatch(/demonstração/);
  });
});
