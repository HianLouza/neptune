import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { eq } from "drizzle-orm";
import { setupDb, newTenant } from "../helpers";
import type { DB } from "../../src/server/db/client";
import * as s from "../../src/server/db/schema";
import { registerUser } from "../../src/server/auth/service";
import { listMembers, updateMembership, saveRole, listRoles, createTeam, setTeamMember, updateOrgSettings } from "../../src/server/domains/admin";
import { platformOverview, requirePlatform, createExperiment, setExperimentStatus, createCoupon, setOrganizationStatus, saveHealthConfig, csOverview } from "../../src/server/domains/platform";
import { changePlan, getSubscription } from "../../src/server/domains/billing";

let db: DB, close: () => Promise<void>;
beforeAll(async () => { ({ db, close } = await setupDb()); });
afterAll(async () => { await close(); });

describe("Administração da empresa", () => {
  it("aprova pendente, cria cargo customizado, equipe e protege cargos de sistema", async () => {
    const ctx = await newTenant(db, "Adm");
    const [org] = await db.select().from(s.organizations).where(eq(s.organizations.id, ctx.organizationId));
    await registerUser(db, { name: "Pendente", email: `pend-${Date.now()}@t.dev`, password: "senhaSegura123", inviteOrgSlug: org.slug });
    const pending = (await listMembers(ctx)).find((m) => m.status === "pending")!;
    await updateMembership(ctx, pending.membershipId, { status: "active" });
    expect((await listMembers(ctx)).every((m) => m.status === "active")).toBe(true);
    const role = await saveRole(ctx, { name: "Analista", permissions: ["crm:read", "intelligence:read"] });
    await updateMembership(ctx, pending.membershipId, { roleId: role.id });
    const sys = (await listRoles(ctx)).find((r) => r.isSystem)!;
    await expect(saveRole(ctx, { roleId: sys.id, name: "X1", permissions: [] })).rejects.toThrow(/sistema/);
    await expect(saveRole(ctx, { name: "Ruim", permissions: ["inexistente:x"] })).rejects.toThrow();
    const team = await createTeam(ctx, "Inside Sales");
    await setTeamMember(ctx, team.id, pending.userId, true);
    await expect(updateMembership(ctx, (await listMembers(ctx)).find((m) => m.userId === ctx.userId)!.membershipId, { status: "disabled" })).rejects.toThrow(/próprio/);
    await expect(updateOrgSettings(ctx, { name: "Nova", locale: "en", currency: "USD", timezone: "Invalid/Zone" })).rejects.toThrow();
  });

  it("não altera membros de outro tenant", async () => {
    const a = await newTenant(db, "A"), b = await newTenant(db, "B");
    const mA = (await listMembers(a))[0];
    await expect(updateMembership(b, mA.membershipId, { status: "disabled" })).rejects.toThrow(/não encontrado/);
  });
});

describe("Plataforma e billing", () => {
  it("bloqueia não-admin e permite admin global", async () => {
    const ctx = await newTenant(db, "Plat");
    expect(() => requirePlatform(ctx)).toThrow(/restrito/);
    const admin = { ...ctx, isPlatformAdmin: true };
    const ov = await platformOverview(admin);
    expect(ov.orgs.length).toBeGreaterThan(0);
    expect(ov.pricedActive).toBe(0); // preços não definidos — nunca inventados
    const e = await createExperiment(admin, { key: `exp-${Date.now()}`, hypothesis: "Hipótese de teste suficiente", objective: "Ativação", audience: "Novas", primaryMetric: "act", owner: "Produto" });
    const started = await setExperimentStatus(admin, e.id, "running");
    expect(started.status).toBe("running");
    const done = await setExperimentStatus(admin, e.id, "concluded");
    expect(done.conclusion).toMatch(/INCONCLUSIVO/);
    await createCoupon(admin, { code: `PILOTO${Date.now() % 10000}`, percentOff: 20 });
    const other = await newTenant(db, "Alvo");
    await setOrganizationStatus(admin, other.organizationId, "suspended");
    const [o] = await db.select().from(s.organizations).where(eq(s.organizations.id, other.organizationId));
    expect(o.status).toBe("suspended");
    await expect(saveHealthConfig(admin, { weights: { access: 1 }, thresholds: { healthy: 50, attention: 60, risk: 10 } })).rejects.toThrow(/Limiares/);
    const cs = await csOverview(admin);
    expect(Object.keys(cs.counts)).toContain("Saudável");
  });

  it("troca de plano ajusta assinatura", async () => {
    const ctx = await newTenant(db, "Plano");
    await changePlan(ctx, "business");
    expect((await getSubscription(db, ctx.organizationId))!.plan.key).toBe("business");
  });
});
