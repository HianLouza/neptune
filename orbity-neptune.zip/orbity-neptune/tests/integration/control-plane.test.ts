import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { and, eq } from "drizzle-orm";
import { setupDb, newTenant } from "../helpers";
import type { DB } from "../../src/server/db/client";
import * as s from "../../src/server/db/schema";
import { SYSTEM_ROLES } from "../../src/server/permissions";
import type { TenantContext } from "../../src/server/tenancy/context";
import { runAgent } from "../../src/server/ai/orchestrator";
import { processPending } from "../../src/server/events";
import { registerAllHandlers } from "../../src/server/events/handlers";
import { saveWorkflow, setWorkflowStatus, emitTestEvent } from "../../src/server/workflows/engine";
import { TEMPLATES } from "../../src/server/workflows/templates";
import { receiveInbound, sendReply, getConversation, OUTBOUND_SENDERS } from "../../src/server/domains/closer";
import {
  activateKillSwitch, releaseKillSwitch, listKillSwitches, upsertBudget, listBudgets, setAgentGovernance, policyDecision,
  authorizeAgentAction, digitalWorkforce, conflictReport, BudgetExceededError, controlPlaneOverview,
} from "../../src/server/ai/control-plane";

let db: DB, close: () => Promise<void>;
beforeAll(async () => { ({ db, close } = await setupDb()); registerAllHandlers(); });
afterAll(async () => { await close(); });

const as = (ctx: TenantContext, role: "manager" | "member"): TenantContext => ({ ...ctx, roleKey: role, permissions: [...SYSTEM_ROLES[role].permissions] });

describe("AI Control Plane — kill switch", () => {
  it("bloqueia o agente e libera depois", async () => {
    const ctx = await newTenant(db, "KS");
    const sw = await activateKillSwitch(ctx, { scope: "agent", target: "executive", reason: "Respostas incorretas em análise" });
    const out = await runAgent(ctx, { agentKey: "executive", input: "Resumo da semana", chargeCredits: false });
    expect(out.status).toBe("blocked");
    expect(out.text).toMatch(/kill switch/);
    // outros agentes seguem funcionando
    expect((await runAgent(ctx, { agentKey: "reporting", input: "Relatório", chargeCredits: false })).status).not.toBe("blocked");
    await releaseKillSwitch(ctx, sw.id);
    expect((await runAgent(ctx, { agentKey: "executive", input: "Resumo da semana", chargeCredits: false })).status).not.toBe("blocked");
    await expect(releaseKillSwitch(ctx, sw.id)).rejects.toThrow(/já foi liberado/);
  });

  it("all_ai interrompe todos os agentes; status pausado também bloqueia", async () => {
    const ctx = await newTenant(db, "KSAll");
    const sw = await activateKillSwitch(ctx, { scope: "all_ai", reason: "Incidente de segurança em análise" });
    expect((await runAgent(ctx, { agentKey: "reporting", input: "x", chargeCredits: false })).status).toBe("blocked");
    await releaseKillSwitch(ctx, sw.id);
    await setAgentGovernance(ctx, "reporting", { status: "paused" });
    const out = await runAgent(ctx, { agentKey: "reporting", input: "x", chargeCredits: false });
    expect(out.status).toBe("blocked");
    expect(out.text).toMatch(/pausado/);
  });

  it("ação de automação é interrompida por kill switch de categoria e a execução fica registrada", async () => {
    const ctx = await newTenant(db, "KSWf");
    const t = TEMPLATES.find((x) => x.key === "nutricao")!;
    const wf = await saveWorkflow(ctx, { name: t.name, triggerEvent: t.triggerEvent, definition: t.definition });
    await setWorkflowStatus(ctx, wf.id, "active");
    await activateKillSwitch(ctx, { scope: "action_category", target: "create_task", reason: "Tarefas duplicadas em massa" });
    await emitTestEvent(ctx, "lead.created", { leadId: null });
    await processPending(db);
    const [run] = await db.select().from(s.workflowRuns).where(eq(s.workflowRuns.workflowId, wf.id));
    expect(run.status).toBe("failed");
    expect(run.log.some((l) => /kill switch/.test(l.message))).toBe(true);
    const tasks = await db.select().from(s.tasks).where(eq(s.tasks.organizationId, ctx.organizationId));
    expect(tasks).toHaveLength(0);
  });

  it("kill switch de integração impede o envio da mensagem e registra auditoria", async () => {
    const ctx = await newTenant(db, "KSInt");
    const org = (await db.select().from(s.organizations).where(eq(s.organizations.id, ctx.organizationId)))[0];
    const r = await receiveInbound(db, org.id, { channel: "webchat", from: { name: "Cliente" }, body: "Olá" });
    await activateKillSwitch(ctx, { scope: "integration", target: "webchat", reason: "Canal com falha de entrega" });
    const res = await sendReply(ctx, r.conversationId, "Resposta");
    expect(res.delivered).toBe(false);
    expect(res.message.status).toBe("blocked");
    const logs = await db.select().from(s.auditLogs).where(and(eq(s.auditLogs.organizationId, ctx.organizationId), eq(s.auditLogs.action, "message.blocked_by_kill_switch")));
    expect(logs).toHaveLength(1);
  });

  it("integração 'conectada' sem envio implementado não marca a mensagem como enviada", async () => {
    const ctx = await newTenant(db, "Deliv");
    await db.insert(s.integrations).values({ organizationId: ctx.organizationId, provider: "webchat", category: "communication", status: "connected", mode: "real" });
    const r = await receiveInbound(db, ctx.organizationId, { channel: "webchat", from: { name: "Cliente" }, body: "Olá" });
    const res = await sendReply(ctx, r.conversationId, "Resposta");
    expect(res.message.status).toBe("simulated");
    expect(res.delivered).toBe(false);
    expect(res.notice).toMatch(/ainda não foi implementado/);
    const conv = await getConversation(ctx, r.conversationId);
    expect(conv.channelConnected).toBe(true);
    expect(conv.outboundImplemented).toBe(false);
    expect(conv.channelReal).toBe(false);
    // Com um envio real registrado e bem-sucedido, aí sim a mensagem fica "sent".
    OUTBOUND_SENDERS.webchat = async () => ({ externalId: "ext-1" });
    try {
      const ok = await sendReply(ctx, r.conversationId, "Agora vai");
      expect(ok.message.status).toBe("sent");
      expect(ok.delivered).toBe(true);
      OUTBOUND_SENDERS.webchat = async () => { throw new Error("timeout do provedor"); };
      const fail = await sendReply(ctx, r.conversationId, "Falha");
      expect(fail.message.status).toBe("failed");
      expect(fail.delivered).toBe(false);
    } finally { delete OUTBOUND_SENDERS.webchat; }
  });

  it("isolamento: kill switch de uma organização não afeta outra; global só por admin da plataforma", async () => {
    const a = await newTenant(db, "KSA"), b = await newTenant(db, "KSB");
    await activateKillSwitch(a, { scope: "all_ai", reason: "Teste de isolamento" });
    expect((await runAgent(b, { agentKey: "reporting", input: "x", chargeCredits: false })).status).not.toBe("blocked");
    expect(await listKillSwitches(b)).toHaveLength(0);
    const [swA] = await listKillSwitches(a);
    await expect(releaseKillSwitch(b, swA.id)).rejects.toThrow(/não encontrado/);
    await expect(activateKillSwitch(a, { scope: "all_ai", reason: "Parada global", global: true })).rejects.toThrow(/plataforma/);
    await releaseKillSwitch(a, swA.id);
    const g = await activateKillSwitch({ ...b, isPlatformAdmin: true }, { scope: "agent", target: "support", reason: "Parada global de teste", global: true });
    expect(g.organizationId).toBeNull();
    expect((await runAgent(a, { agentKey: "support", input: "x", chargeCredits: false })).text).toMatch(/global/);
    await expect(releaseKillSwitch(a, g.id)).rejects.toThrow(/plataforma/);
    await releaseKillSwitch({ ...b, isPlatformAdmin: true }, g.id);
  });
});

describe("AI Control Plane — governança e política", () => {
  it("gestor visualiza, mas não governa; colaborador não visualiza", async () => {
    const ctx = await newTenant(db, "Gov");
    const mgr = as(ctx, "manager");
    const view = await controlPlaneOverview(mgr);
    expect(view.canGovern).toBe(false);
    expect(view.workforce.every((w) => w.kind === "Agente digital")).toBe(true);
    await expect(setAgentGovernance(mgr, "executive", { autonomyLevel: 5 })).rejects.toThrow(/ai:govern/);
    await expect(activateKillSwitch(mgr, { scope: "all_ai", reason: "tentativa do gestor" })).rejects.toThrow(/ai:govern/);
    await expect(upsertBudget(mgr, { scope: "organization", monthlyCredits: 10 })).rejects.toThrow(/ai:govern/);
    await expect(digitalWorkforce(as(ctx, "member"))).rejects.toThrow(/ai:manage/);
  });

  it("muda nível mantendo a coluna legada e audita antes/depois; impede escalonamento de permissões", async () => {
    const ctx = await newTenant(db, "Lvl");
    const u = await setAgentGovernance(ctx, "outreach", { autonomyLevel: 3 });
    expect(u.autonomyLevel).toBe(3);
    expect(u.autonomy).toBe("approve");
    const [log] = await db.select().from(s.auditLogs).where(and(eq(s.auditLogs.organizationId, ctx.organizationId), eq(s.auditLogs.action, "ai.agent_governance_changed")));
    expect((log.metadata as { before: { autonomyLevel: number } }).before.autonomyLevel).toBe(4);
    // um gestor com ai:govern concedido não pode dar ao agente permissão que ele não tem
    const limited: TenantContext = { ...ctx, permissions: [...SYSTEM_ROLES.manager.permissions, "ai:govern"] };
    await expect(setAgentGovernance(limited, "outreach", { permissions: ["billing:manage"] })).rejects.toThrow(/não possui/);
    await expect(setAgentGovernance(ctx, "outreach", { permissions: ["admin:users"] })).rejects.toThrow(/governança ou administração/);
    await expect(setAgentGovernance(ctx, "outreach", { permissions: ["inexistente:x"] })).rejects.toThrow(/inexistentes/);
  });

  it("ação sensível sempre exige aprovação, mesmo no nível 5", async () => {
    expect(policyDecision(5, "send_message").decision).toBe("needs_approval");
    expect(policyDecision(5, "financial_operation").decision).toBe("needs_approval");
    expect(policyDecision(5, "create_task").decision).toBe("allow");
    expect(policyDecision(4, "create_task").decision).toBe("needs_approval");
    expect(policyDecision(3, "create_task").decision).toBe("deny");
    expect(policyDecision(3, "send_message", "draft").decision).toBe("allow");
    expect(policyDecision(2, "send_message", "draft").decision).toBe("deny");
    const ctx = await newTenant(db, "Pol");
    const u = await setAgentGovernance(ctx, "follow_up", { autonomyLevel: 5 });
    expect((await authorizeAgentAction(ctx, u, "send_message")).decision).toBe("needs_approval");
    await activateKillSwitch(ctx, { scope: "action_category", target: "create_task", reason: "Pausa preventiva" });
    expect((await authorizeAgentAction(ctx, u, "create_task")).decision).toBe("deny");
  });

  it("agente provisionado só com a coluna legada aparece com o nível coerente", async () => {
    const ctx = await newTenant(db, "Norm");
    const wf = await digitalWorkforce(ctx);
    expect(wf.find((w) => w.key === "support_chat")!.autonomyLevel).toBe(4);
    expect(wf.find((w) => w.key === "scoring")!.autonomyLevel).toBe(5);
    expect(wf.find((w) => w.key === "executive")!.autonomyLevel).toBe(2);
    expect(wf.find((w) => w.key === "support_chat")!.domain).toBe("engagement");
  });
});

describe("AI Control Plane — orçamentos", () => {
  const spend = (ctx: TenantContext, agentKey: string, credits: number) =>
    db.insert(s.aiExecutions).values({ organizationId: ctx.organizationId, agentKey, provider: "anthropic", model: "claude-opus-5-5", input: "uso anterior", status: "success", credits });

  it("hard stop recusa antes de chamar o provedor; alerta é enviado uma única vez", async () => {
    const ctx = await newTenant(db, "Bud");
    await upsertBudget(ctx, { scope: "agent", target: "reporting", monthlyCredits: 100, alertPct: 50, hardStop: true });
    await spend(ctx, "reporting", 60);
    await runAgent(ctx, { agentKey: "reporting", input: "a", chargeCredits: false });
    await runAgent(ctx, { agentKey: "reporting", input: "b", chargeCredits: false });
    const alerts = await db.select().from(s.notifications).where(and(eq(s.notifications.organizationId, ctx.organizationId)));
    expect(alerts.filter((n) => /Orçamento de IA/.test(n.title))).toHaveLength(1);
    await spend(ctx, "reporting", 50);
    const before = (await db.select().from(s.aiExecutions).where(eq(s.aiExecutions.organizationId, ctx.organizationId))).length;
    await expect(runAgent(ctx, { agentKey: "reporting", input: "c", chargeCredits: false })).rejects.toBeInstanceOf(BudgetExceededError);
    const after = (await db.select().from(s.aiExecutions).where(eq(s.aiExecutions.organizationId, ctx.organizationId))).length;
    expect(after).toBe(before);
    const [b] = await listBudgets(ctx);
    expect(b.usedThisMonth).toBe(110);
  });

  it("limite flexível permite com aviso; orçamento é isolado por organização", async () => {
    const a = await newTenant(db, "BudA"), b = await newTenant(db, "BudB");
    await upsertBudget(a, { scope: "organization", monthlyCredits: 10, hardStop: false });
    await spend(a, "executive", 20);
    const out = await runAgent(a, { agentKey: "executive", input: "x", chargeCredits: false });
    expect(out.warnings.join(" ")).toMatch(/limite é flexível/);
    expect(await listBudgets(b)).toHaveLength(0);
    expect((await runAgent(b, { agentKey: "executive", input: "x", chargeCredits: false })).warnings.join(" ")).not.toMatch(/Orçamento/);
  });
});

describe("AI Control Plane — conflitos", () => {
  it("detecta execuções duplicadas e agentes com autonomia sobreposta", async () => {
    const ctx = await newTenant(db, "Conf");
    for (let i = 0; i < 3; i++) await db.insert(s.aiExecutions).values({ organizationId: ctx.organizationId, agentKey: "outreach", provider: "x", model: "x", input: "mesma entrada", status: "success" });
    await setAgentGovernance(ctx, "follow_up", { autonomyLevel: 4, domain: "engagement", tools: ["conversations.read", "messages.draft"] });
    await setAgentGovernance(ctx, "qualification", { autonomyLevel: 5, domain: "engagement", tools: ["conversations.read"] });
    const report = await conflictReport(ctx);
    expect(report.find((c) => c.kind === "duplicate_executions")?.evidence).toMatch(/2 execução/);
    expect(report.some((c) => c.kind === "overlapping_autonomy" && c.evidence.includes("conversations.read"))).toBe(true);
  });
});
