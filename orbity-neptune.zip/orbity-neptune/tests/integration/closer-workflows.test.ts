import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { eq } from "drizzle-orm";
import { setupDb, newTenant } from "../helpers";
import type { DB } from "../../src/server/db/client";
import * as s from "../../src/server/db/schema";
import { processPending } from "../../src/server/events";
import { registerAllHandlers } from "../../src/server/events/handlers";
import { saveWorkflow, setWorkflowStatus, simulateWorkflow, workflowDetail, emitTestEvent } from "../../src/server/workflows/engine";
import { TEMPLATES, draftFromText } from "../../src/server/workflows/templates";
import { decideApproval, listApprovals, receiveInbound, setConversationStatus, getConversation, sendReply } from "../../src/server/domains/closer";

let db: DB, close: () => Promise<void>;
beforeAll(async () => { ({ db, close } = await setupDb()); registerAllHandlers(); });
afterAll(async () => { await close(); });

describe("Automações (UI flows)", () => {
  it("rascunho por linguagem natural → nova versão → simulação sem efeitos", async () => {
    const ctx = await newTenant(db, "NL");
    const d = draftFromText("Quando um lead for criado, criar tarefa e notificar a equipe")!;
    const wf = await saveWorkflow(ctx, { name: d.name, triggerEvent: d.triggerEvent, definition: d.definition });
    expect(wf.status).toBe("draft");
    const v2 = await saveWorkflow(ctx, { name: "Renomeada", triggerEvent: d.triggerEvent, definition: d.definition }, wf.id);
    expect(v2.currentVersion).toBe(2);
    const sim = await simulateWorkflow(ctx, wf.id, { leadId: null });
    expect(sim.status).toBe("simulated");
    const tasks = await db.select().from(s.tasks).where(eq(s.tasks.organizationId, ctx.organizationId));
    expect(tasks).toHaveLength(0);
    const det = await workflowDetail(ctx, wf.id);
    expect(det.versions).toHaveLength(2);
  });

  it("aprovação humana de automação retoma a execução após decisão", async () => {
    const ctx = await newTenant(db, "Ap");
    const t = TEMPLATES.find((x) => x.key === "grande-negocio")!;
    const wf = await saveWorkflow(ctx, { name: t.name, triggerEvent: t.triggerEvent, definition: t.definition });
    await setWorkflowStatus(ctx, wf.id, "active");
    await emitTestEvent(ctx, "opportunity.created", { amountCents: 20000000 });
    await processPending(db);
    const [run] = await db.select().from(s.workflowRuns).where(eq(s.workflowRuns.workflowId, wf.id));
    expect(run.status).toBe("waiting_approval");
    const [ap] = await listApprovals(ctx);
    await decideApproval(ctx, ap.id, true);
    await processPending(db);
    const [after] = await db.select().from(s.workflowRuns).where(eq(s.workflowRuns.id, run.id));
    expect(after.status).toBe("completed");
    const tasks = await db.select().from(s.tasks).where(eq(s.tasks.organizationId, ctx.organizationId));
    expect(tasks.map((x) => x.title)).toContain("Revisão estratégica do negócio");
  });
});

describe("Closer.AI (UI flows)", () => {
  it("pedido de humano gera handoff; resposta humana sem integração fica simulada; isolamento de conversa", async () => {
    const a = await newTenant(db, "CA"), b = await newTenant(db, "CB");
    const r = await receiveInbound(db, a.organizationId, { channel: "webchat", from: { name: "Ana" }, body: "Quero falar com um humano" });
    let conv = await getConversation(a, r.conversationId);
    expect(conv.c.status).toBe("handoff");
    const sent = await sendReply(a, r.conversationId, "Olá, Ana! Sou da equipe.");
    expect(sent.delivered).toBe(false);
    expect(sent.notice).toMatch(/NÃO foi entregue/);
    conv = await getConversation(a, r.conversationId);
    expect(conv.c.status).toBe("open");
    await setConversationStatus(a, r.conversationId, { status: "closed", aiEnabled: false });
    await expect(getConversation(b, r.conversationId)).rejects.toThrow(/não encontrada/);
    await expect(setConversationStatus(b, r.conversationId, { status: "open" })).rejects.toThrow(/não encontrada/);
  });
});
