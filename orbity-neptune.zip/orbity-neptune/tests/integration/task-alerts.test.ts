import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { and, eq } from "drizzle-orm";
import { setupDb, newTenant } from "../helpers";
import type { DB } from "../../src/server/db/client";
import { memberships, notifications, organizations, roles, taskAlertEvents, taskAlerts, tasks } from "../../src/server/db/schema";
import { registerUser, contextFor } from "../../src/server/auth/service";
import type { TenantContext } from "../../src/server/tenancy/context";
import { createTask, setTaskStatus } from "../../src/server/domains/crm";
import { ForbiddenError } from "../../src/server/permissions";
import {
  alertCenterMetrics, cancelAlert, channelAvailability, composeAlert, createAlert, createRule, decideExtension, executionIntelligence, generateAlertMessage, getAlertDetail,
  listAlerts, listMyAlerts, markAlertRead, requestExtension, respondToAlert, runAlertAutomation, sendAlertNow, setTone, taskHistory, resolveTone, messageFacts,
} from "../../src/server/domains/task-alerts";

let db: DB, close: () => Promise<void>;
beforeAll(async () => { ({ db, close } = await setupDb()); });
afterAll(async () => { await close(); });

let seq = 0;
async function addUser(owner: TenantContext, roleKey: "manager" | "member") {
  const [org] = await db.select().from(organizations).where(eq(organizations.id, owner.organizationId));
  seq++;
  const { user } = await registerUser(db, { name: `Pessoa ${seq}`, email: `ta-${seq}-${Date.now()}@test.dev`, password: "senhaSegura123", inviteOrgSlug: org.slug });
  const [role] = await db.select().from(roles).where(and(eq(roles.organizationId, org.id), eq(roles.key, roleKey)));
  await db.update(memberships).set({ status: "active", roleId: role.id }).where(and(eq(memberships.userId, user.id), eq(memberships.organizationId, org.id)));
  return (await contextFor(db, user.id, org.id))!;
}

const HOUR = 3_600_000;
const inHours = (h: number) => new Date(Date.now() + h * HOUR);
const rawTask = async (ctx: TenantContext, assignee: TenantContext, over: Partial<Parameters<typeof createTask>[1]> = {}) =>
  createTask(ctx, { title: `Tarefa ${++seq}`, priority: "medium", assigneeId: assignee.userId, dueAt: inHours(10), ...over });
const alertRows = (orgId: string, taskId: string) => db.select().from(taskAlerts).where(and(eq(taskAlerts.organizationId, orgId), eq(taskAlerts.taskId, taskId)));

describe("Alerta individual: criação, entrega e estados", () => {
  it("destinatário padrão é o responsável; envio imediato entrega na Central e NÃO marca leitura", async () => {
    const mgr = await newTenant(db), member = await addUser(mgr, "member");
    const t = await rawTask(mgr, member);
    const r = await createAlert(mgr, { taskId: t.id, title: "Lembrete", message: "Passando para lembrar do prazo.", priority: "high" });
    expect(r.alert.recipientId).toBe(member.userId);
    expect(r.alert.senderId).toBe(mgr.userId);
    expect(r.alert.status).toBe("delivered");
    expect(r.alert.sentAt).not.toBeNull();
    expect(r.alert.deliveredAt).not.toBeNull();
    expect(r.alert.readAt).toBeNull(); // entrega ≠ leitura
    const notes = await db.select().from(notifications).where(and(eq(notifications.userId, member.userId), eq(notifications.alertId, r.alert.id)));
    expect(notes).toHaveLength(1);
    expect(notes[0].priority).toBe("high");
  });

  it("só quem tem alerts:send gera alerta; colaborador recebe mas não envia", async () => {
    const mgr = await newTenant(db), member = await addUser(mgr, "member");
    const t = await rawTask(mgr, member);
    await expect(createAlert(member, { taskId: t.id, title: "Aviso xx", message: "mensagem" })).rejects.toBeInstanceOf(ForbiddenError);
  });

  it("canais externos indisponíveis são recusados com o motivo (nada é 'enviado' de mentira)", async () => {
    const mgr = await newTenant(db), member = await addUser(mgr, "member");
    const t = await rawTask(mgr, member);
    const av = await channelAvailability(db, mgr.organizationId);
    expect(av.in_app.available).toBe(true);
    expect(av.email.available).toBe(false);
    expect(av.whatsapp.available).toBe(false);
    expect(av.push.available).toBe(false);
    await expect(createAlert(mgr, { taskId: t.id, title: "Aviso xx", message: "mensagem", channels: ["in_app", "email"] })).rejects.toThrow(/Canal indisponível/);
    expect(await alertRows(mgr.organizationId, t.id)).toHaveLength(0);
    // rascunho com canal externo é permitido, mas não pode ser enviado
    const d = await createAlert(mgr, { taskId: t.id, title: "Aviso xx", message: "mensagem", channels: ["email"], sendMode: "draft" });
    expect(d.alert.status).toBe("draft");
    await expect(sendAlertNow(mgr, d.alert.id)).rejects.toThrow(/Canal indisponível/);
  });

  it("idempotência: mesma chave não duplica alerta nem notificação", async () => {
    const mgr = await newTenant(db), member = await addUser(mgr, "member");
    const t = await rawTask(mgr, member);
    const input = { taskId: t.id, title: "Aviso", message: "Mensagem única", idempotencyKey: "dialog-key-12345" };
    const a = await createAlert(mgr, input), b = await createAlert(mgr, input);
    expect(b.duplicate).toBe(true);
    expect(b.alert.id).toBe(a.alert.id);
    expect(await alertRows(mgr.organizationId, t.id)).toHaveLength(1);
    expect(await db.select().from(notifications).where(eq(notifications.alertId, a.alert.id))).toHaveLength(1);
    // proteção contra clique duplo mesmo sem chave do cliente
    const c = await createAlert(mgr, { taskId: t.id, title: "Outro", message: "Texto repetido" }), d = await createAlert(mgr, { taskId: t.id, title: "Outro", message: "Texto repetido" });
    expect(d.duplicate).toBe(true); expect(d.alert.id).toBe(c.alert.id);
  });

  it("agendamento: fica 'agendado' (não enviado) até a hora; o worker entrega depois", async () => {
    const mgr = await newTenant(db), member = await addUser(mgr, "member");
    const t = await rawTask(mgr, member);
    await expect(createAlert(mgr, { taskId: t.id, title: "Aviso xx", message: "mensagem", sendMode: "schedule", scheduledAt: new Date(Date.now() - 3 * HOUR) })).rejects.toThrow(/já passou/);
    const r = await createAlert(mgr, { taskId: t.id, title: "Agendado", message: "Mensagem agendada", sendMode: "schedule", scheduledAt: inHours(2) });
    expect(r.alert.status).toBe("scheduled");
    expect(r.alert.sentAt).toBeNull();
    expect(await db.select().from(notifications).where(eq(notifications.alertId, r.alert.id))).toHaveLength(0);
    let s = await runAlertAutomation(db, mgr.organizationId, new Date()); // ainda não chegou a hora
    expect(s.dispatched).toBe(0);
    s = await runAlertAutomation(db, mgr.organizationId, inHours(3));
    expect(s.dispatched).toBe(1);
    const [after] = await alertRows(mgr.organizationId, t.id);
    expect(after.status).toBe("delivered");
    s = await runAlertAutomation(db, mgr.organizationId, inHours(4)); // não reenvia
    expect(s.dispatched).toBe(0);
    expect(await db.select().from(notifications).where(eq(notifications.alertId, r.alert.id))).toHaveLength(1);
  });

  it("cancelar: só antes do envio; alerta enviado não pode ser desfeito; tarefa concluída cancela o agendado", async () => {
    const mgr = await newTenant(db), member = await addUser(mgr, "member");
    const t = await rawTask(mgr, member);
    const sch = await createAlert(mgr, { taskId: t.id, title: "Aviso A", message: "agendado 1", sendMode: "schedule", scheduledAt: inHours(1) });
    expect((await cancelAlert(mgr, sch.alert.id, "mudou o plano")).status).toBe("canceled");
    const sent = await createAlert(mgr, { taskId: t.id, title: "Aviso B", message: "enviado agora" });
    await expect(cancelAlert(mgr, sent.alert.id)).rejects.toThrow(/não enviados|ainda não enviados/);
    const t2 = await rawTask(mgr, member);
    const sch2 = await createAlert(mgr, { taskId: t2.id, title: "Aviso C", message: "agendado 2", sendMode: "schedule", scheduledAt: inHours(1) });
    await setTaskStatus(mgr, t2.id, "done");
    await runAlertAutomation(db, mgr.organizationId, inHours(2));
    const [c] = await db.select().from(taskAlerts).where(eq(taskAlerts.id, sch2.alert.id));
    expect(c.status).toBe("canceled");
    expect(await db.select().from(notifications).where(eq(notifications.alertId, sch2.alert.id))).toHaveLength(0);
  });
});

describe("Leitura, resposta e histórico", () => {
  it("leitura só é registrada pelo destinatário; resposta atualiza a tarefa e avisa o gestor", async () => {
    const mgr = await newTenant(db), member = await addUser(mgr, "member"), other = await addUser(mgr, "member");
    const t = await rawTask(mgr, member);
    const { alert } = await createAlert(mgr, { taskId: t.id, title: "Aviso", message: "Atualize a tarefa" });
    await expect(markAlertRead(mgr, alert.id)).rejects.toThrow(/destinatário/);
    await expect(markAlertRead(other, alert.id)).rejects.toThrow(/destinatário/);
    const read = await markAlertRead(member, alert.id);
    expect(read.status).toBe("read"); expect(read.readAt).not.toBeNull();
    await expect(respondToAlert(other, { alertId: alert.id, kind: "ack" })).rejects.toThrow(/responsável/);
    await respondToAlert(member, { alertId: alert.id, kind: "progress", progressPct: 40, message: "metade feita" });
    const [a] = await db.select().from(taskAlerts).where(eq(taskAlerts.id, alert.id));
    expect(a.status).toBe("responded"); expect(a.respondedAt).not.toBeNull();
    const [task] = await db.select().from(tasks).where(eq(tasks.id, t.id));
    expect(task.progressPct).toBe(40);
    expect((await db.select().from(notifications).where(and(eq(notifications.userId, mgr.userId), eq(notifications.alertId, alert.id)))).length).toBe(1);
    const h = await taskHistory(mgr, t.id);
    expect(h.events.map((e) => e.type)).toEqual(expect.arrayContaining(["created", "delivered", "read", "responded"]));
    await expect(taskHistory(other, t.id)).rejects.toThrow(/acesso/);
    expect((await listMyAlerts(member)).length).toBe(1);
    expect((await listMyAlerts(other)).length).toBe(0);
  });

  it("impedimento bloqueia a tarefa; concluir exige permissão e fecha a tarefa", async () => {
    const mgr = await newTenant(db), member = await addUser(mgr, "member");
    const t = await rawTask(mgr, member);
    const { alert } = await createAlert(mgr, { taskId: t.id, title: "Aviso", message: "Como está?" });
    await expect(respondToAlert(member, { alertId: alert.id, kind: "blocker" })).rejects.toThrow(/mensagem/);
    await respondToAlert(member, { alertId: alert.id, kind: "blocker", message: "Aguardando contrato do jurídico" });
    expect((await db.select().from(tasks).where(eq(tasks.id, t.id)))[0].blockedReason).toMatch(/jurídico/);
    await respondToAlert(member, { taskId: t.id, kind: "done", evidenceUrl: "https://exemplo.com/prova" });
    const [done] = await db.select().from(tasks).where(eq(tasks.id, t.id));
    expect(done.status).toBe("done"); expect(done.blockedReason).toBeNull();
  });
});

describe("Automação e escalonamento", () => {
  const rule = (over: Record<string, unknown> = {}) => ({ name: "Regra", trigger: "before_due" as const, offsetMinutes: 24 * 60, allowedStartHour: 0, allowedEndHour: 24, ...over });

  it("lembrete antes do vencimento: um por série, sem duplicar, respeitando concluídas e bloqueadas", async () => {
    const mgr = await newTenant(db), member = await addUser(mgr, "member");
    await createRule(mgr, rule());
    const t = await rawTask(mgr, member, { dueAt: inHours(10) });
    const far = await rawTask(mgr, member, { dueAt: inHours(100) });
    const done = await rawTask(mgr, member, { dueAt: inHours(10) }); await setTaskStatus(mgr, done.id, "done");
    const blocked = await rawTask(mgr, member, { dueAt: inHours(10) });
    await db.update(tasks).set({ blockedReason: "Aguardando fornecedor" }).where(eq(tasks.id, blocked.id));
    const s1 = await runAlertAutomation(db, mgr.organizationId);
    expect(s1.created).toBe(1);
    const auto = (id: string) => db.select().from(taskAlerts).where(and(eq(taskAlerts.taskId, id), eq(taskAlerts.kind, "automation")));
    expect(await auto(t.id)).toHaveLength(1);
    expect(await auto(far.id)).toHaveLength(0);
    expect(await auto(done.id)).toHaveLength(0);
    expect(await auto(blocked.id)).toHaveLength(0);
    const s2 = await runAlertAutomation(db, mgr.organizationId);
    expect(s2.created).toBe(0); // sem repetição configurada
    expect(await auto(t.id)).toHaveLength(1);
    expect((await auto(t.id))[0].recipientId).toBe(member.userId);
  });

  it("repetição respeita intervalo e máximo de lembretes", async () => {
    const mgr = await newTenant(db), member = await addUser(mgr, "member");
    await createRule(mgr, rule({ trigger: "overdue", offsetMinutes: 0, repeatEveryMinutes: 120, maxReminders: 2 }));
    const t = await rawTask(mgr, member, { dueAt: inHours(-5) });
    const count = async () => (await db.select().from(taskAlerts).where(and(eq(taskAlerts.taskId, t.id), eq(taskAlerts.kind, "automation")))).length;
    await runAlertAutomation(db, mgr.organizationId, new Date()); expect(await count()).toBe(1);
    await runAlertAutomation(db, mgr.organizationId, inHours(1)); expect(await count()).toBe(1); // intervalo de 2h ainda não passou
    await runAlertAutomation(db, mgr.organizationId, inHours(3)); expect(await count()).toBe(2);
    await runAlertAutomation(db, mgr.organizationId, inHours(9)); expect(await count()).toBe(2); // máximo atingido
  });

  it("respeita horário permitido no fuso da organização", async () => {
    const mgr = await newTenant(db), member = await addUser(mgr, "member");
    const nowHour = Number(new Intl.DateTimeFormat("en-GB", { hour: "2-digit", hour12: false, timeZone: mgr.timezone }).format(new Date())) % 24;
    const start = (nowHour + 3) % 24, end = (nowHour + 5) % 24 || 24;
    await createRule(mgr, rule({ allowedStartHour: Math.min(start, 22), allowedEndHour: Math.min(start, 22) + 1 }));
    void end;
    const t = await rawTask(mgr, member, { dueAt: inHours(5) });
    const s = await runAlertAutomation(db, mgr.organizationId);
    expect(s.created).toBe(0);
    expect(await alertRows(mgr.organizationId, t.id)).toHaveLength(0);
  });

  it("escalona ao gestor sem resposta; não duplica; para com resposta, conclusão e bloqueio", async () => {
    const mgr = await newTenant(db), member = await addUser(mgr, "member"), boss = await addUser(mgr, "manager");
    await createRule(mgr, rule({ trigger: "overdue", offsetMinutes: 0, escalation: { enabled: true, maxAttempts: 2, steps: [{ afterMinutes: 30, userIds: [boss.userId] }] } }));
    const silent = await rawTask(mgr, member, { dueAt: inHours(-3) });
    const answered = await rawTask(mgr, member, { dueAt: inHours(-3) });
    const closed = await rawTask(mgr, member, { dueAt: inHours(-3) });
    await runAlertAutomation(db, mgr.organizationId); // 1º alerta ao responsável (3 tarefas)
    const first = await alertRows(mgr.organizationId, answered.id);
    await respondToAlert(member, { alertId: first[0].id, kind: "working" });
    await setTaskStatus(mgr, closed.id, "done");
    const later = new Date(Date.now() + 31 * 60_000);
    const s = await runAlertAutomation(db, mgr.organizationId, later);
    expect(s.escalated).toBe(1);
    const esc = (id: string) => db.select().from(taskAlerts).where(and(eq(taskAlerts.taskId, id), eq(taskAlerts.kind, "escalation")));
    const e1 = await esc(silent.id);
    expect(e1).toHaveLength(1);
    expect(e1[0].recipientId).toBe(boss.userId);
    expect(e1[0].escalationLevel).toBe(1);
    expect(e1[0].parentAlertId).toBe((await alertRows(mgr.organizationId, silent.id)).find((a) => a.kind === "automation")!.id);
    expect(await esc(answered.id)).toHaveLength(0);
    expect(await esc(closed.id)).toHaveLength(0);
    const again = await runAlertAutomation(db, mgr.organizationId, new Date(later.getTime() + 60 * 60_000));
    expect(again.escalated).toBe(0); // só havia 1 degrau configurado
    expect(await esc(silent.id)).toHaveLength(1);
    const hist = await taskHistory(mgr, silent.id);
    expect(hist.events.some((e) => e.type === "escalated")).toBe(true);
    // bloqueio justificado suspende o escalonamento
    const blocked = await rawTask(mgr, member, { dueAt: inHours(-2) });
    await runAlertAutomation(db, mgr.organizationId);
    const [ba] = await alertRows(mgr.organizationId, blocked.id);
    await respondToAlert(member, { taskId: blocked.id, kind: "blocker", message: "Depende de terceiros" });
    void ba;
    const s3 = await runAlertAutomation(db, mgr.organizationId, new Date(Date.now() + 40 * 60_000));
    expect(s3.escalated).toBe(0);
  });

  it("tarefa sem atualização notifica gestores (não o responsável)", async () => {
    const mgr = await newTenant(db), member = await addUser(mgr, "member");
    await createRule(mgr, rule({ trigger: "stale", staleAfterHours: 24 }));
    const t = await rawTask(mgr, member);
    await db.update(tasks).set({ updatedAt: inHours(-48) }).where(eq(tasks.id, t.id));
    const s = await runAlertAutomation(db, mgr.organizationId);
    expect(s.created).toBeGreaterThanOrEqual(1);
    const rows = await alertRows(mgr.organizationId, t.id);
    expect(rows.length).toBeGreaterThanOrEqual(1);
    expect(rows.every((r) => r.recipientId !== member.userId)).toBe(true);
  });

  it("regra com canal indisponível ou degrau com usuário de outra organização é recusada", async () => {
    const mgr = await newTenant(db), other = await newTenant(db);
    await expect(createRule(mgr, rule({ channels: ["whatsapp"] }))).rejects.toThrow(/Canal indisponível/);
    await expect(createRule(mgr, rule({ escalation: { enabled: true, maxAttempts: 1, steps: [{ afterMinutes: 30, userIds: [other.userId] }] } }))).rejects.toThrow(/membro ativo/);
    const member = await addUser(mgr, "member");
    await expect(createRule(member, rule())).rejects.toBeInstanceOf(ForbiddenError);
  });
});

describe("Prorrogação", () => {
  it("pedido com análise do Flávio; ninguém decide a própria solicitação; aprovação aplica o prazo e registra tudo", async () => {
    const mgr = await newTenant(db), member = await addUser(mgr, "member"), other = await addUser(mgr, "member");
    const t = await rawTask(mgr, member, { dueAt: inHours(5), priority: "medium" });
    await expect(requestExtension(other, { taskId: t.id, requestedDueAt: inHours(48), justification: "Preciso de mais tempo" })).rejects.toThrow(/responsável/);
    await expect(requestExtension(member, { taskId: t.id, requestedDueAt: inHours(1), justification: "Preciso de mais tempo" })).rejects.toThrow(/posterior/);
    const { request, recommendation } = await requestExtension(member, { taskId: t.id, requestedDueAt: inHours(48), justification: "Aguardando o cliente", blockers: "Cliente não enviou os dados" });
    expect(request.status).toBe("pending");
    expect(recommendation.facts.length).toBeGreaterThan(0);
    expect(["approve", "reject", "counter"]).toContain(recommendation.decision);
    expect(recommendation.disclaimer).toMatch(/gestor/);
    await expect(requestExtension(member, { taskId: t.id, requestedDueAt: inHours(60), justification: "Outra vez" })).rejects.toThrow(/pendente/);
    await expect(decideExtension(member, request.id, { decision: "approve" })).rejects.toBeInstanceOf(ForbiddenError);
    expect((await db.select().from(tasks).where(eq(tasks.id, t.id)))[0].dueAt!.getTime()).toBeLessThan(inHours(6).getTime()); // nada mudou sozinho
    const boss = await addUser(mgr, "manager");
    const decided = await decideExtension(boss, request.id, { decision: "approve", note: "Ok" });
    expect(decided.status).toBe("approved");
    const [after] = await db.select().from(tasks).where(eq(tasks.id, t.id));
    expect(Math.abs(after.dueAt!.getTime() - request.requestedDueAt.getTime())).toBeLessThan(1000);
    await expect(decideExtension(boss, request.id, { decision: "reject" })).rejects.toThrow(/já foi decidida/);
    const ev = await db.select().from(taskAlertEvents).where(eq(taskAlertEvents.taskId, t.id));
    expect(ev.map((e) => e.type)).toEqual(expect.arrayContaining(["extension_requested", "extension_decided"]));
    expect((await db.select().from(notifications).where(and(eq(notifications.userId, member.userId), eq(notifications.organizationId, mgr.organizationId)))).some((n) => /Prazo aprovado/.test(n.title))).toBe(true);
  });

  it("gestor que também é o responsável não decide o próprio pedido; contraproposta exige data futura", async () => {
    const mgr = await newTenant(db), boss = await addUser(mgr, "manager"), member = await addUser(mgr, "member");
    const own = await rawTask(mgr, boss, { dueAt: inHours(5) });
    const { request } = await requestExtension(boss, { taskId: own.id, requestedDueAt: inHours(30), justification: "Reunião longa" });
    await expect(decideExtension(boss, request.id, { decision: "approve" })).rejects.toThrow(/própria/);
    const t = await rawTask(mgr, member, { dueAt: inHours(5) });
    const r2 = await requestExtension(member, { taskId: t.id, requestedDueAt: inHours(24), justification: "Precisa de revisão" });
    await expect(decideExtension(mgr, r2.request.id, { decision: "counter" })).rejects.toThrow(/data futura/);
    const c = await decideExtension(mgr, r2.request.id, { decision: "counter", counterDueAt: inHours(12) });
    expect(c.status).toBe("countered");
  });
});

describe("Flávio, tom, isolamento e inteligência", () => {
  it("gera mensagem contextualizada (simulada sem IA real) e só o gestor consegue; nada é enviado pela geração", async () => {
    const mgr = await newTenant(db), member = await addUser(mgr, "member");
    const t = await rawTask(mgr, member, { dueAt: inHours(-30), priority: "high", title: "Fechar proposta Alfa" });
    const g = await generateAlertMessage(mgr, { taskId: t.id, kind: "overdue_notice", instruction: "seja gentil" });
    expect(g.simulated).toBe(true);
    expect(g.title).toContain("Fechar proposta Alfa");
    expect(g.message).toContain("Fechar proposta Alfa");
    expect(g.basedOn.join(" ")).toMatch(/Atrasada há/);
    const g2 = await generateAlertMessage(mgr, { taskId: t.id, kind: "overdue_notice", variant: 1 });
    expect(g2.message).not.toBe(g.message); // nova versão
    expect(await alertRows(mgr.organizationId, t.id)).toHaveLength(0);
    await expect(generateAlertMessage(member, { taskId: t.id })).rejects.toBeInstanceOf(ForbiddenError);
    // mensagem do Flávio editada pelo gestor fica registrada como tal
    const sent = await createAlert(mgr, { taskId: t.id, title: g.title, message: `${g.message} Obrigado.`, originalMessage: g.message, flavioExecutionId: g.executionId, simulated: true });
    expect(sent.alert.messageOrigin).toBe("flavio_edited");
    expect(sent.alert.originalMessage).toBe(g.message);
    const sent2 = await createAlert(mgr, { taskId: t.id, title: g.title, message: g2.message, originalMessage: g2.message });
    expect(sent2.alert.messageOrigin).toBe("flavio");
  });

  it("tom: hierarquia regra > organização; só alerts:manage altera", async () => {
    const mgr = await newTenant(db), member = await addUser(mgr, "member");
    await setTone(mgr, { tone: "formal" });
    expect((await resolveTone(db, mgr.organizationId, null)).tone).toBe("formal");
    expect((await resolveTone(db, mgr.organizationId, null, { ruleTone: "direct" })).tone).toBe("direct");
    await expect(setTone(member, { tone: "direct" })).rejects.toBeInstanceOf(ForbiddenError);
    await expect(setTone(mgr, { tone: "custom" })).rejects.toThrow(/personalizado/);
    const t = await rawTask(mgr, member);
    const f = await messageFacts(mgr, t.id);
    expect(composeAlert("friendly_reminder", "formal", f, mgr.timezone).message).toMatch(/Prezado/);
    expect(composeAlert("friendly_reminder", "motivational", f, mgr.timezone).message).toMatch(/juntos/);
  });

  it("isolamento entre organizações: nada vaza", async () => {
    const a = await newTenant(db), b = await newTenant(db), memberA = await addUser(a, "member");
    const t = await rawTask(a, memberA);
    const { alert } = await createAlert(a, { taskId: t.id, title: "Interno", message: "Somente da org A" });
    await expect(createAlert(b, { taskId: t.id, title: "Aviso xx", message: "invasão" })).rejects.toThrow(/não encontrada/);
    await expect(getAlertDetail(b, alert.id)).rejects.toThrow(/não encontrado/);
    await expect(taskHistory(b, t.id)).rejects.toThrow(/não encontrada/);
    expect(await listAlerts(b)).toHaveLength(0);
    await expect(createAlert(a, { taskId: t.id, recipientId: b.userId, title: "Aviso xx", message: "para outra org" })).rejects.toThrow(/membro ativo/);
    await expect(markAlertRead(b, alert.id)).rejects.toThrow(/não encontrado/);
    await expect(respondToAlert(b, { alertId: alert.id, kind: "ack" })).rejects.toThrow(/não encontrado/);
    expect((await alertCenterMetrics(b)).total).toBe(0);
  });

  it("colaborador vê só os próprios alertas; Central do gestor aplica filtros e métricas coerentes", async () => {
    const mgr = await newTenant(db), m1 = await addUser(mgr, "member"), m2 = await addUser(mgr, "member");
    const t1 = await rawTask(mgr, m1), t2 = await rawTask(mgr, m2, { priority: "high", dueAt: inHours(-2) });
    await createAlert(mgr, { taskId: t1.id, title: "Para 1", message: "mensagem 1", priority: "low" });
    const u = await createAlert(mgr, { taskId: t2.id, title: "Para 2", message: "mensagem 2", priority: "urgent" });
    await createAlert(mgr, { taskId: t2.id, title: "Agendado", message: "mensagem 3", sendMode: "schedule", scheduledAt: inHours(3) });
    await markAlertRead(m2, u.alert.id);
    expect((await listAlerts(m1)).map((r) => r.a.title)).toEqual(["Para 1"]);
    const all = await listAlerts(mgr);
    expect(all).toHaveLength(3);
    expect((await listAlerts(mgr, { priority: "urgent" })).map((r) => r.a.id)).toEqual([u.alert.id]);
    expect((await listAlerts(mgr, { recipientId: m1.userId })).length).toBe(1);
    expect((await listAlerts(mgr, { status: "scheduled" })).length).toBe(1);
    expect((await listAlerts(mgr, { channel: "in_app" })).length).toBe(3);
    expect((await listAlerts(mgr, { channel: "email" })).length).toBe(0);
    const m = await alertCenterMetrics(mgr);
    expect(m.total).toBe(2); expect(m.scheduled).toBe(1); expect(m.read).toBe(1); expect(m.pendingRead).toBe(1);
    expect(m.unanswered).toBe(2); expect(m.failed).toBe(0); expect(m.overdueTasks).toBe(1);
  });

  it("inteligência de execução separa fatos, inferências e recomendações e traz ressalvas (sem ranking de pessoas)", async () => {
    const mgr = await newTenant(db), member = await addUser(mgr, "member");
    for (let i = 0; i < 3; i++) await rawTask(mgr, member, { dueAt: inHours(-5), priority: "high", assigneeId: undefined });
    await rawTask(mgr, member, { dueAt: inHours(-5) });
    const r = await executionIntelligence(mgr, 30);
    expect(r.facts.openTasks).toBeGreaterThan(0);
    expect(r.facts.overdueTasks).toBeGreaterThan(0);
    expect(r.caveats.join(" ")).toMatch(/causalidade/);
    expect(r.caveats.join(" ")).toMatch(/produtividade/);
    expect(Array.isArray(r.inferences)).toBe(true);
    expect(Array.isArray(r.recommendations)).toBe(true);
    expect(JSON.stringify(r)).not.toMatch(/ranking|pior|melhor funcion/i);
    await expect(executionIntelligence(member, 30)).rejects.toBeInstanceOf(ForbiddenError);
  });
});
