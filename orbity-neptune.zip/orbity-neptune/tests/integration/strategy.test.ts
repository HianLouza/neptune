import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { setupDb, newTenant } from "../helpers";
import type { DB } from "../../src/server/db/client";
import type { TenantContext } from "../../src/server/tenancy/context";
import { SYSTEM_ROLES } from "../../src/server/permissions";
import { createOpportunity, getDefaultPipeline, moveOpportunity } from "../../src/server/domains/crm";
import {
  simulate, buildBaseline, saveScenario, listScenarios, updateScenarioStatus, runSimulation, MissingInputError, type Baseline,
} from "../../src/server/domains/strategy";

let db: DB, close: () => Promise<void>;
beforeAll(async () => { ({ db, close } = await setupDb()); });
afterAll(async () => { await close(); });

const BASE: Baseline = {
  revenueCents: 100000, revenueSource: "crm", leadsPerMonth: 100, dealsPerMonth: 10, conversionRate: 0.1, avgTicketCents: 10000,
  variableCostsCents: 30000, fixedCostsCents: 50000, sampleWon90d: 30,
};

describe("Strategy Simulator — modelo", () => {
  it("cenário atual reproduz a base", () => {
    const r = simulate(BASE, {});
    expect(r.current).toMatchObject({ revenueCents: 100000, variableCostsCents: 30000, fixedCostsCents: 50000, resultCents: 20000, marginPct: 20 });
    expect(r.current.breakEvenRevenueCents).toBe(71429); // 50000 / 0,7
    expect(r.delta.resultCents).toBe(0);
  });

  it("E se eu aumentar o preço em 10%? (elasticidade -0,5)", () => {
    const r = simulate(BASE, { priceChangePct: 10 });
    const b = r.scenarios.base;
    expect(b.volumeFactor).toBe(0.95);
    expect(b.revenueCents).toBe(104500); // 100000 × 1,10 × 0,95
    expect(b.variableCostsCents).toBe(28500); // 30000 × 0,95
    expect(b.resultCents).toBe(26000);
    expect(b.breakEvenRevenueCents).toBe(68750); // 50000 / (76000/104500)
    expect(r.delta.resultCents).toBe(6000);
    expect(r.assumptions.join(" ")).toMatch(/Elasticidade/);
    // incerteza de ±10% sobre o volume
    expect(r.scenarios.otimista.revenueCents).toBe(114950);
    expect(r.scenarios.pessimista.revenueCents).toBe(94050);
  });

  it("contratações, marketing e projeção de 12 meses com sazonalidade", () => {
    const season = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2];
    const r = simulate(BASE, { newHires: 2, monthlyCostPerHireCents: 5000, marketingSpendCents: 100000, leadsPerThousand: 10, seasonality: season, initialCashCents: 1000 });
    // marketing: R$ 1.000 → 10 leads extras sobre 100 → volume × 1,1; fixos = 50000 + 2×5000 + 100000
    expect(r.scenarios.base.revenueCents).toBe(110000);
    expect(r.scenarios.base.fixedCostsCents).toBe(160000);
    expect(r.projection).toHaveLength(12);
    expect(r.projection[11].revenueCents).toBe(220000);
    const sum = r.projection.reduce((a, p) => a + p.resultCents, 0);
    expect(r.projection[11].cumulativeCashCents).toBe(1000 + sum);
    expect(r.contributions.map((c) => c.variable).sort()).toEqual(["marketingSpendCents", "newHires"]);
  });

  it("redução de equipe é apenas análise", () => {
    const r = simulate(BASE, { newHires: -1, monthlyCostPerHireCents: 5000 });
    expect(r.scenarios.base.fixedCostsCents).toBe(45000);
    expect(r.notes.join(" ")).toMatch(/nunca decide/);
  });

  it("não inventa dados: sem despesas, exige informar", () => {
    expect(() => simulate({ ...BASE, fixedCostsCents: null, variableCostsCents: null }, {})).toThrow(MissingInputError);
    expect(() => simulate(BASE, { newHires: 1 })).toThrow(/custo mensal por contratação/);
    const r = simulate({ ...BASE, fixedCostsCents: null, variableCostsCents: null }, { fixedCostsCentsOverride: 50000, variableCostsCentsOverride: 30000 });
    expect(r.current.resultCents).toBe(20000);
  });

  it("sensibilidade ordenada por impacto", () => {
    const r = simulate(BASE, {});
    expect(r.sensitivity).toHaveLength(5);
    const abs = r.sensitivity.map((x) => Math.abs(x.resultDeltaCents));
    expect([...abs].sort((a, b) => b - a)).toEqual(abs);
  });
});

describe("Strategy Simulator — base real, cenários e aprovação", () => {
  it("base vem do CRM; sem financeiro, despesas ficam nulas e a simulação pede os dados", async () => {
    const ctx = await newTenant(db, "Sim");
    const o = await createOpportunity(ctx, { title: "Negócio", amountCents: 3000000 });
    const { stages } = await getDefaultPipeline(ctx);
    await moveOpportunity(ctx, o.id, stages.find((x) => x.kind === "won")!.id);
    const { baseline, evidence } = await buildBaseline(ctx);
    expect(baseline.revenueSource).toBe("crm");
    expect(baseline.revenueCents).toBe(1000000);
    expect(baseline.fixedCostsCents).toBeNull();
    expect(evidence.facts[0].source).toMatch(/CRM/);
    expect(evidence.missingData.join(" ")).toMatch(/financeiros/);
    await expect(runSimulation(ctx, {})).rejects.toThrow(/custos fixos/);
    const ok = await runSimulation(ctx, { fixedCostsCentsOverride: 200000, variableCostsCentsOverride: 100000 });
    expect(ok.result.current.resultCents).toBe(700000);
  });

  it("salva, envia e exige outra pessoa para aprovar; isolado por organização", async () => {
    const ctx = await newTenant(db, "Scn"), other = await newTenant(db, "Scn2");
    const sc = await saveScenario(ctx, { name: "Aumento de preço 10%", kind: "price", variables: { priceChangePct: 10, fixedCostsCentsOverride: 1000, variableCostsCentsOverride: 0 } });
    expect(sc.status).toBe("draft");
    expect(sc.evidence.facts.length).toBeGreaterThan(0);
    await updateScenarioStatus(ctx, sc.id, { action: "submit" });
    await expect(updateScenarioStatus(ctx, sc.id, { action: "approve" })).rejects.toThrow(/segregação/);
    const reviewer: TenantContext = { ...ctx, userId: other.userId, roleKey: "manager", permissions: [...SYSTEM_ROLES.manager.permissions] };
    const ap = await updateScenarioStatus(reviewer, sc.id, { action: "approve" });
    expect(ap.status).toBe("approved");
    expect(ap.approvedBy).toBe(other.userId);
    const member: TenantContext = { ...ctx, roleKey: "member", permissions: [...SYSTEM_ROLES.member.permissions] };
    await expect(listScenarios(member)).rejects.toThrow(/strategy:read/);
    expect(await listScenarios(other)).toHaveLength(0);
    await expect(updateScenarioStatus(other, sc.id, { action: "reject" })).rejects.toThrow(/não encontrado/);
    const [mine] = await listScenarios(ctx);
    expect(mine.createdByName).toBeTruthy();
  });
});
