import { describe, it, expect, beforeAll, afterAll, afterEach, vi } from "vitest";
import { and, eq } from "drizzle-orm";
import { setupDb, newTenant } from "../helpers";
import type { DB } from "../../src/server/db/client";
import * as s from "../../src/server/db/schema";
import { processPending } from "../../src/server/events";
import { registerAllHandlers } from "../../src/server/events/handlers";
import { saveWorkflow, setWorkflowStatus, emitTestEvent, isSafeWebhookUrl } from "../../src/server/workflows/engine";
import { decideApproval, listApprovals } from "../../src/server/domains/closer";
import type { TenantContext } from "../../src/server/tenancy/context";

// Ações sensíveis de automação (webhook / send_message): só executam DEPOIS da aprovação humana,
// e os passos seguintes também esperam a decisão.
let db: DB, close: () => Promise<void>;
beforeAll(async () => { ({ db, close } = await setupDb()); registerAllHandlers(); });
afterAll(async () => { await close(); });
afterEach(() => vi.unstubAllGlobals());

async function webhookFlow(ctx: TenantContext, url: string) {
  const wf = await saveWorkflow(ctx, { name: "Webhook com aprovação", triggerEvent: "lead.created", definition: { entry: "t", nodes: [
    { id: "t", type: "trigger", config: {}, next: "w" },
    { id: "w", type: "action", config: { action: "webhook", url }, next: "a2" },
    { id: "a2", type: "action", config: { action: "create_task", title: "Depois do webhook" }, next: "e" },
    { id: "e", type: "end", config: {} },
  ] } });
  await setWorkflowStatus(ctx, wf.id, "active");
  await emitTestEvent(ctx, "lead.created", { leadId: null });
  await processPending(db);
  const [run] = await db.select().from(s.workflowRuns).where(eq(s.workflowRuns.workflowId, wf.id));
  return run;
}
const tasksAfter = (org: string) => db.select().from(s.tasks).where(and(eq(s.tasks.organizationId, org), eq(s.tasks.title, "Depois do webhook")));

describe("Ações sensíveis de automação", () => {
  it("para na ação sensível, executa o webhook só após aprovação e depois retoma", async () => {
    const fetchMock = vi.fn().mockResolvedValue(new Response("ok", { status: 200 }));
    vi.stubGlobal("fetch", fetchMock);
    const ctx = await newTenant(db, "WhOk");
    const run = await webhookFlow(ctx, "https://example.com/hook");
    expect(run.status).toBe("waiting_approval");
    expect(fetchMock).not.toHaveBeenCalled();
    expect(await tasksAfter(ctx.organizationId)).toHaveLength(0); // passo seguinte não rodou antes da aprovação

    const [ap] = await listApprovals(ctx);
    await decideApproval(ctx, ap.id, true);
    await processPending(db);
    expect(fetchMock).toHaveBeenCalledTimes(1);
    expect(fetchMock.mock.calls[0][0]).toBe("https://example.com/hook");
    const [after] = await db.select().from(s.workflowRuns).where(eq(s.workflowRuns.id, run.id));
    expect(after.status).toBe("completed");
    expect(after.log.some((l) => l.message.includes("Webhook chamado (HTTP 200)"))).toBe(true);
    expect(await tasksAfter(ctx.organizationId)).toHaveLength(1);
  });

  it("rejeição não chama o webhook nem executa os passos seguintes", async () => {
    const fetchMock = vi.fn();
    vi.stubGlobal("fetch", fetchMock);
    const ctx = await newTenant(db, "WhRej");
    const run = await webhookFlow(ctx, "https://example.com/hook");
    const [ap] = await listApprovals(ctx);
    await decideApproval(ctx, ap.id, false);
    await processPending(db);
    expect(fetchMock).not.toHaveBeenCalled();
    const [after] = await db.select().from(s.workflowRuns).where(eq(s.workflowRuns.id, run.id));
    expect(after.log.some((l) => l.status === "rejected")).toBe(true);
    expect(await tasksAfter(ctx.organizationId)).toHaveLength(0);
  });

  it("webhook para endereço interno é recusado mesmo aprovado (SSRF)", async () => {
    const fetchMock = vi.fn();
    vi.stubGlobal("fetch", fetchMock);
    const ctx = await newTenant(db, "WhSsrf");
    const run = await webhookFlow(ctx, "https://127.0.0.1/admin");
    const [ap] = await listApprovals(ctx);
    await decideApproval(ctx, ap.id, true);
    await processPending(db);
    expect(fetchMock).not.toHaveBeenCalled();
    const [after] = await db.select().from(s.workflowRuns).where(eq(s.workflowRuns.id, run.id));
    expect(after.status).toBe("failed");
  });

  it("isSafeWebhookUrl aceita só https público", () => {
    expect(isSafeWebhookUrl("https://hooks.zapier.com/abc")).toBe(true);
    for (const u of ["http://example.com", "https://localhost/x", "https://10.0.0.5", "https://192.168.1.1", "https://172.20.0.1", "https://169.254.169.254/latest", "https://[::1]/", "https://svc.internal", "nao-e-url"]) {
      expect(isSafeWebhookUrl(u)).toBe(false);
    }
  });
});
