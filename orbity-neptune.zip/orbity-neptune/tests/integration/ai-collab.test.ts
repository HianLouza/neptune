import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { and, eq } from "drizzle-orm";
import { setupDb, newTenant } from "../helpers";
import type { DB } from "../../src/server/db/client";
import { aiAgents, aiDrafts, aiDraftVersions, memberships, organizations, roles } from "../../src/server/db/schema";
import { registerUser, contextFor } from "../../src/server/auth/service";
import type { TenantContext } from "../../src/server/tenancy/context";
import { addKnowledge, decideApproval, getConversation, listApprovals, receiveInbound } from "../../src/server/domains/closer";
import { draftOutreach } from "../../src/server/domains/prospect";
import { createLead } from "../../src/server/domains/crm";
import {
  createDraft, discardVersion, draftOriginsForMessages, getDraft, markCopied, regenerate, restoreVersion, saveManualEdit, sendDraft, takeOverManually,
} from "../../src/server/ai/collab";
import { aiSuggestionMetrics } from "../../src/server/ai/collab/metrics";
import { similarity, unsupportedFigures, wordDiff } from "../../src/server/ai/collab/text";

let db: DB, close: () => Promise<void>;
beforeAll(async () => { ({ db, close } = await setupDb()); });
afterAll(async () => { await close(); });

let seq = 0;
async function addUser(owner: TenantContext, roleKey: "manager" | "member") {
  const [org] = await db.select().from(organizations).where(eq(organizations.id, owner.organizationId));
  seq++;
  const { user } = await registerUser(db, { name: `Pessoa ${seq}`, email: `collab-${seq}-${Date.now()}@test.dev`, password: "senhaSegura123", inviteOrgSlug: org.slug });
  const [role] = await db.select().from(roles).where(and(eq(roles.organizationId, org.id), eq(roles.key, roleKey)));
  await db.update(memberships).set({ status: "active", roleId: role.id }).where(and(eq(memberships.userId, user.id), eq(memberships.organizationId, org.id)));
  return (await contextFor(db, user.id, org.id))!;
}

let n = 0;
async function conversation(ctx: TenantContext, body = "Vocês têm teste gratuito?") {
  n++;
  const { conversationId } = await receiveInbound(db, ctx.organizationId, { channel: "webchat", from: { name: `Mariana Lopes ${n}`, email: `m${n}-${Date.now()}@x.dev` }, body });
  return conversationId;
}
async function withKb(name: string) {
  const ctx = await newTenant(db, name);
  await addKnowledge(ctx, { title: "FAQ", content: "Oferecemos teste gratuito de 7 dias para todos os planos. O suporte funciona em horário comercial." });
  return ctx;
}
const current = (v: Awaited<ReturnType<typeof getDraft>>) => v.versions.find((x) => x.id === v.currentVersionId)!;

describe("Colaboração humano × IA — gerar, regenerar, instruir, editar", () => {
  it("primeira sugestão usa o contexto da conversa e a base de conhecimento", async () => {
    const ctx = await withKb("CtxA");
    const conv = await conversation(ctx);
    const v = await createDraft(ctx, { module: "closer", subjectId: conv });
    const c = current(v);
    expect(c.origin).toBe("ai");
    expect(c.simulated).toBe(true); // sem provedor real nos testes → sinalizado como simulado
    expect(c.content).toMatch(/Mariana/); // nome do cliente da conversa
    expect(c.content).toMatch(/teste gratuito de 7 dias/); // informação da base de conhecimento
    expect(c.sources[0].title).toBe("FAQ");
    expect(v.warnings.join(" ")).toMatch(/simulado/);
  });

  it("permite 25 regenerações seguidas, sempre como novas versões", async () => {
    const ctx = await withKb("Ilimitado");
    const v0 = await createDraft(ctx, { module: "closer", subjectId: await conversation(ctx) });
    let v = v0;
    for (let i = 0; i < 25; i++) v = await regenerate(ctx, v0.draft.id, { operation: "regenerate" });
    expect(v.versions).toHaveLength(26);
    expect(v.regenerations).toBe(25);
    expect(new Set(v.versions.map((x) => x.seq)).size).toBe(26);
  });

  it("nova sugestão após descarte é realmente diferente e nunca repete a descartada", async () => {
    const ctx = await withKb("Desc");
    const v0 = await createDraft(ctx, { module: "closer", subjectId: await conversation(ctx) });
    const first = current(v0);
    await discardVersion(ctx, v0.draft.id, { versionId: first.id, reason: "outra_abordagem" });
    const v1 = await regenerate(ctx, v0.draft.id, { operation: "regenerate" });
    const second = current(v1);
    expect(second.id).not.toBe(first.id);
    expect(second.content).not.toBe(first.content);
    expect(similarity(first.content, second.content)).toBeLessThan(0.75);
    expect(v1.versions.find((x) => x.id === first.id)!.rejected).toBe(true);
    expect(v1.draft.status).toBe("open"); // descartar não encerra: o funcionário continua
  });

  it("instruções do funcionário são guardadas e consideradas", async () => {
    const ctx = await withKb("Instr");
    const v0 = await createDraft(ctx, { module: "closer", subjectId: await conversation(ctx) });
    await saveManualEdit(ctx, v0.draft.id, { content: "Olá! O plano custa R$ 199 por mês. Posso ajudar em algo mais?" });
    const v = await regenerate(ctx, v0.draft.id, { operation: "instruct", instruction: "Não mencione preços e seja mais formal" });
    const c = current(v);
    expect(c.instruction).toBe("Não mencione preços e seja mais formal");
    expect(c.content).not.toMatch(/R\$/);
    expect(c.content).toMatch(/Prezado|Atenciosamente/);
    await expect(regenerate(ctx, v0.draft.id, { operation: "instruct" })).rejects.toThrow(/instrução/);
  });

  it("edição manual nunca é sobrescrita por novas gerações", async () => {
    const ctx = await withKb("Manual");
    const v0 = await createDraft(ctx, { module: "closer", subjectId: await conversation(ctx) });
    const mine = "Oi Mariana! Escrevi esta resposta eu mesmo, com o meu jeito.";
    const e = await saveManualEdit(ctx, v0.draft.id, { content: mine });
    const manualId = current(e).id;
    await regenerate(ctx, v0.draft.id, { operation: "persuasive" });
    await regenerate(ctx, v0.draft.id, { operation: "regenerate" });
    const after = await getDraft(ctx, v0.draft.id);
    const kept = after.versions.find((x) => x.id === manualId)!;
    expect(kept.content).toBe(mine);
    expect(kept.origin).toBe("human");
    const [row] = await db.select().from(aiDraftVersions).where(eq(aiDraftVersions.id, manualId));
    expect(row.content).toBe(mine);
  });

  it("melhorar trecho selecionado altera só o trecho", async () => {
    const ctx = await withKb("Trecho");
    const v0 = await createDraft(ctx, { module: "closer", subjectId: await conversation(ctx) });
    const text = "Primeira frase fica igual. vc pode testar sem custo pq e simples. Última frase também fica igual.";
    const e = await saveManualEdit(ctx, v0.draft.id, { content: text });
    const base = current(e);
    const start = text.indexOf("vc pode"), end = text.indexOf("simples.") + "simples.".length;
    const v = await regenerate(ctx, v0.draft.id, { operation: "improve_selection", baseVersionId: base.id, selection: { start, end } });
    const out = current(v).content;
    expect(out.startsWith(text.slice(0, start))).toBe(true);
    expect(out.endsWith(text.slice(end))).toBe(true);
    expect(out).toMatch(/[Vv]ocê pode testar/);
    expect(out).toMatch(/porque/);
    await expect(regenerate(ctx, v0.draft.id, { operation: "improve_selection", baseVersionId: base.id, selection: { start: 5, end: 9999 } })).rejects.toThrow(/Seleção/);
  });

  it("recupera versões anteriores e compara versões", async () => {
    const ctx = await withKb("Restore");
    const v0 = await createDraft(ctx, { module: "closer", subjectId: await conversation(ctx) });
    const first = current(v0);
    await regenerate(ctx, v0.draft.id, { operation: "shorten" });
    const r = await restoreVersion(ctx, v0.draft.id, first.id);
    const restored = current(r);
    expect(restored.content).toBe(first.content);
    expect(restored.operation).toBe("restore");
    expect(r.versions).toHaveLength(3);
    const d = wordDiff("Olá Mariana, tudo bem?", "Olá Mariana, tudo ótimo?");
    expect(d.some((p) => p.type === "removed" && p.text.includes("bem?"))).toBe(true);
    expect(d.some((p) => p.type === "added" && p.text.includes("ótimo?"))).toBe(true);
  });
});

describe("Envio, aprovação e permissões", () => {
  it("colaborador: sugestão da IA vai para aprovação; gestor aprova e envia exatamente a versão", async () => {
    const owner = await withKb("Pol");
    const member = await addUser(owner, "member");
    const manager = await addUser(owner, "manager");
    const conv = await conversation(owner);
    const v0 = await createDraft(member, { module: "closer", subjectId: conv });
    expect(v0.policy.mode).toBe("approval");
    const r = await sendDraft(member, v0.draft.id, { versionId: v0.currentVersionId! });
    expect(r.status).toBe("pending_approval");
    let c = await getConversation(owner, conv);
    expect(c.messages.filter((m) => m.direction === "outbound")).toHaveLength(0);
    const [ap] = await listApprovals(manager);
    expect(ap.payload.draftId).toBe(v0.draft.id);
    await decideApproval(manager, ap.id, true);
    c = await getConversation(owner, conv);
    const out = c.messages.filter((m) => m.direction === "outbound");
    expect(out).toHaveLength(1);
    expect(out[0].body).toBe(current(v0).content);
    expect(out[0].status).toBe("simulated"); // sem canal real: nunca "enviada"
    const after = await getDraft(owner, v0.draft.id);
    expect(after.draft.status).toBe("sent");
    const origins = await draftOriginsForMessages(owner, [out[0].id]);
    expect(origins[out[0].id].origin).toBe("ai_unchanged");
  });

  it("gestor envia direto; envio duplicado é recusado", async () => {
    const owner = await withKb("Dup");
    const manager = await addUser(owner, "manager");
    const v0 = await createDraft(manager, { module: "closer", subjectId: await conversation(owner) });
    expect(v0.policy.mode).toBe("send");
    const r = await sendDraft(manager, v0.draft.id, { versionId: v0.currentVersionId! });
    expect(r.status).toBe("sent");
    await expect(sendDraft(manager, v0.draft.id, { versionId: v0.currentVersionId! })).rejects.toThrow(/já foi enviada/);
    await expect(regenerate(manager, v0.draft.id, { operation: "regenerate" })).rejects.toThrow(/já foi enviada/);
  });

  it("colaborador que assume a resposta escreve e envia sem aprovação", async () => {
    const owner = await withKb("Assume");
    const member = await addUser(owner, "member");
    const conv = await conversation(owner);
    const v0 = await createDraft(member, { module: "closer", subjectId: conv });
    const m = await takeOverManually(member, v0.draft.id, {});
    expect(m.draft.status).toBe("manual");
    const e = await saveManualEdit(member, v0.draft.id, { content: "Oi! Aqui é a Ana, do time comercial. Te ligo amanhã cedo para explicar tudo com calma." });
    const r = await sendDraft(member, v0.draft.id, { versionId: e.currentVersionId! });
    expect(r.status).toBe("sent");
    const c = await getConversation(owner, conv);
    const out = c.messages.filter((x) => x.direction === "outbound");
    expect(out[0].author).toBe("user");
    expect((await draftOriginsForMessages(owner, [out[0].id]))[out[0].id].origin).toBe("human");
  });

  it("versão descartada não pode ser enviada", async () => {
    const owner = await withKb("NoSend");
    const v0 = await createDraft(owner, { module: "closer", subjectId: await conversation(owner) });
    await discardVersion(owner, v0.draft.id, { versionId: v0.currentVersionId! });
    await expect(sendDraft(owner, v0.draft.id, { versionId: v0.currentVersionId! })).rejects.toThrow(/descartada/);
  });

  it("isolamento: outra organização não lê, não regenera e não envia o rascunho", async () => {
    const a = await withKb("IsoA"), b = await newTenant(db, "IsoB");
    const v0 = await createDraft(a, { module: "closer", subjectId: await conversation(a) });
    await expect(getDraft(b, v0.draft.id)).rejects.toThrow(/não encontrada/);
    await expect(regenerate(b, v0.draft.id, { operation: "regenerate" })).rejects.toThrow(/não encontrada/);
    await expect(sendDraft(b, v0.draft.id, { versionId: v0.currentVersionId! })).rejects.toThrow(/não encontrada/);
    await expect(createDraft(b, { module: "closer", subjectId: v0.draft.subjectId })).rejects.toThrow(/não encontrada/);
  });

  it("sem créditos: erro claro e nenhuma versão é perdida", async () => {
    const ctx = await withKb("Credito");
    const v0 = await createDraft(ctx, { module: "closer", subjectId: await conversation(ctx) });
    await saveManualEdit(ctx, v0.draft.id, { content: "Meu texto em andamento." });
    await db.update(aiAgents).set({ limits: { maxTokensPerRun: 4000, maxCreditsPerDay: 0 } }).where(and(eq(aiAgents.organizationId, ctx.organizationId), eq(aiAgents.key, "support_chat")));
    await expect(regenerate(ctx, v0.draft.id, { operation: "regenerate" })).rejects.toThrow(/preservadas/);
    const after = await getDraft(ctx, v0.draft.id);
    expect(after.versions).toHaveLength(2);
    expect(after.versions[1].content).toBe("Meu texto em andamento.");
  });
});

describe("Prospect.AI e guardas", () => {
  it("copiloto de abordagem usa o mesmo serviço e nunca envia", async () => {
    const ctx = await newTenant(db, "Prosp");
    const lead = await createLead(ctx, { title: "Construtora Rio", companyName: "Construtora Rio", segment: "Construção" });
    const r = await draftOutreach(ctx, lead.id, "email");
    const [d] = await db.select().from(aiDrafts).where(eq(aiDrafts.id, r.draftId));
    expect(d.module).toBe("prospect");
    const v = await regenerate(ctx, r.draftId, { operation: "tone_formal" });
    expect(v.policy.mode).toBe("copy");
    await expect(sendDraft(ctx, r.draftId, { versionId: v.currentVersionId! })).rejects.toThrow(/Copiar texto/);
    const c = await markCopied(ctx, r.draftId, { versionId: v.currentVersionId! });
    expect(c.draft.status).toBe("copied");
  });

  it("guarda de preços aponta valores sem fonte", () => {
    expect(unsupportedFigures("O plano custa R$ 199 por mês e tem 20% de desconto.", "Teste gratuito de 7 dias.")).toEqual(["R$ 199", "20%"]);
    expect(unsupportedFigures("O teste é de 7 dias.", "Oferecemos teste gratuito de 7 dias.")).toEqual([]);
    expect(unsupportedFigures("Custa R$ 199.", "Plano Growth: R$ 199 por mês.")).toEqual([]);
  });

  it("métricas sobre um conjunto conhecido", async () => {
    const ctx = await withKb("Metr");
    // A: 2 regenerações e envio sem alteração
    const a = await createDraft(ctx, { module: "closer", subjectId: await conversation(ctx) });
    await regenerate(ctx, a.draft.id, { operation: "regenerate" });
    const a2 = await regenerate(ctx, a.draft.id, { operation: "regenerate" });
    await sendDraft(ctx, a.draft.id, { versionId: a2.currentVersionId! });
    // B: edição leve e envio (editada)
    const b = await createDraft(ctx, { module: "closer", subjectId: await conversation(ctx) });
    const be = await saveManualEdit(ctx, b.draft.id, { content: `${current(b).content} Obrigado!` });
    await sendDraft(ctx, b.draft.id, { versionId: be.currentVersionId! });
    // C: descartada com motivo
    const c = await createDraft(ctx, { module: "closer", subjectId: await conversation(ctx) });
    await discardVersion(ctx, c.draft.id, { versionId: c.currentVersionId!, reason: "tom" });

    const m = await aiSuggestionMetrics(ctx, 30);
    expect(m.totals.drafts).toBe(3);
    expect(m.totals.generated).toBe(5);
    expect(m.totals.sent).toBe(2);
    expect(m.totals.discardedVersions).toBe(1);
    expect(m.totals.unchangedPct).toBe(50);
    expect(m.totals.editedPct).toBe(50);
    expect(m.totals.avgRegenerations).toBeCloseTo(2 / 3, 5);
    expect(m.reasons.tom).toBe(1);
    expect(m.byAgent[0].agentKey).toBe("support_chat");
    expect(m.conversion.sample).toBe(2);
    expect(m.conversion.note).toMatch(/não causalidade/);
  });
});
