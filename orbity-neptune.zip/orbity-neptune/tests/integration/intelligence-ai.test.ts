import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { setupDb, newTenant } from "../helpers";
import type { DB } from "../../src/server/db/client";
import { createOpportunity } from "../../src/server/domains/crm";
import { buildReport, reportToCsv } from "../../src/server/domains/reporting";
import { listAgents, updateAgent, getAgent, setExecutionFeedback, addEvalCase, providerStatus } from "../../src/server/ai/agents/admin";
import { runAgent } from "../../src/server/ai/orchestrator";

let db: DB, close: () => Promise<void>;
beforeAll(async () => { ({ db, close } = await setupDb()); });
afterAll(async () => { await close(); });

describe("Relatórios", () => {
  it("gera todos os tipos e exporta CSV", async () => {
    const ctx = await newTenant(db, "Rep");
    await createOpportunity(ctx, { title: "Negócio X", amountCents: 250000 });
    for (const t of ["executive", "funnel", "sellers", "origins", "forecast"] as const) {
      const r = await buildReport(ctx, t, 30);
      expect(r.columns.length).toBeGreaterThan(0);
      expect(reportToCsv(r)).toContain(r.columns[0]);
    }
    const f = await buildReport(ctx, "forecast", 30);
    expect(f.notes.some((n) => n.includes("Amostra"))).toBe(true);
  });
});

describe("Centro de Controle de IA", () => {
  it("lista, atualiza agente, registra feedback e adiciona caso; isolamento entre tenants", async () => {
    const a = await newTenant(db, "AgA"), b = await newTenant(db, "AgB");
    expect((await listAgents(a)).length).toBeGreaterThan(5);
    const u = await updateAgent(a, "executive", { autonomy: "approve", maxCreditsPerDay: 10 });
    expect(u.autonomy).toBe("approve");
    expect(u.limits.maxCreditsPerDay).toBe(10);
    const out = await runAgent(a, { agentKey: "executive", input: "Qual a receita?" });
    await setExecutionFeedback(a, out.executionId, 1);
    await expect(setExecutionFeedback(b, out.executionId, -1)).rejects.toThrow(/não encontrada/);
    await addEvalCase(a, { agentKey: "executive", name: "Teste", input: "Olá", mustInclude: [], mustNotInclude: ["senha"] });
    const d = await getAgent(a, "executive");
    expect(d.executions[0].feedback).toBe(1);
    expect(d.cases).toHaveLength(1);
    expect((await getAgent(b, "executive")).cases).toHaveLength(0);
    expect(providerStatus().find((p) => p.name === "local-heuristic")?.simulated).toBe(true);
    const member = { ...a, permissions: ["ai:use"] };
    await expect(updateAgent(member, "executive", { enabled: false })).rejects.toThrow(/Permissão/);
  });
});
