import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { eq } from "drizzle-orm";
import { setupDb, newTenant } from "../helpers";
import type { DB } from "../../src/server/db/client";
import * as s from "../../src/server/db/schema";
import { createLead, createOpportunity, getDefaultPipeline, upsertContact, upsertCompany } from "../../src/server/domains/crm";
import { saveIcp } from "../../src/server/domains/prospect";
import { exportLeadsCsv, listProspectLeads, scoreOneLead } from "../../src/server/domains/prospect/queries";
import { kanban, listCompanies, listContacts, staleCount, getCompany } from "../../src/server/domains/crm/queries";

let db: DB, close: () => Promise<void>;
beforeAll(async () => { ({ db, close } = await setupDb()); });
afterAll(async () => { await close(); });

describe("Prospect queries", () => {
  it("pontua um lead pelo ICP, filtra quentes e exporta CSV com auditoria e proteção contra fórmula", async () => {
    const ctx = await newTenant(db, "PQ");
    await saveIcp(ctx, { name: "ICP", segments: ["Tecnologia"], regions: ["SP"], minEmployees: 5, maxEmployees: 100 });
    const l = await createLead(ctx, { title: "=HYPERLINK(\"x\")", companyName: "Tech SP", segment: "Tecnologia", region: "SP", employees: 20, contactName: "Ana", contactEmail: "ana@tech.dev", contactPhone: "11999", source: "referral" });
    const r = await scoreOneLead(ctx, l.id);
    expect(r!.score).toBeGreaterThanOrEqual(80);
    expect((await listProspectLeads(ctx, { hot: true })).map((x) => x.id)).toContain(l.id);
    const csv = await exportLeadsCsv(ctx);
    expect(csv).toContain("'=HYPERLINK");
    const logs = await db.select().from(s.auditLogs).where(eq(s.auditLogs.organizationId, ctx.organizationId));
    expect(logs.some((x) => x.action === "data.exported")).toBe(true);
  });

  it("exportação exige permissão export:data", async () => {
    const ctx = await newTenant(db, "PX");
    await expect(exportLeadsCsv({ ...ctx, permissions: ["prospect:read"] })).rejects.toThrow(/export:data/);
  });
});

describe("CRM queries", () => {
  it("kanban filtra paradas e por etapa; listas são isoladas por tenant", async () => {
    const a = await newTenant(db, "KA"), b = await newTenant(db, "KB");
    const o1 = await createOpportunity(a, { title: "Parada", amountCents: 1000 });
    await createOpportunity(a, { title: "Ativa", amountCents: 2000 });
    await db.update(s.opportunities).set({ lastActivityAt: new Date(Date.now() - 10 * 864e5) }).where(eq(s.opportunities.id, o1.id));
    const stale = await kanban(a, { stale: true });
    expect(stale.columns.flatMap((c) => c.items).map((i) => i.title)).toEqual(["Parada"]);
    expect(await staleCount(a)).toBe(1);
    const { stages } = await getDefaultPipeline(a);
    const one = await kanban(a, { stageId: stages[0].id });
    expect(one.columns).toHaveLength(1);
    expect(one.columns[0].count).toBe(2);

    const comp = (await upsertCompany(a, { name: "Empresa Secreta" })).company;
    await upsertContact(a, { name: "Contato A", email: "a@a.dev", companyId: comp.id });
    expect((await listCompanies(b)).some((c) => c.name === "Empresa Secreta")).toBe(false);
    expect((await listContacts(b)).length).toBe(0);
    expect(await getCompany(b, comp.id)).toBeNull();
    const ca = await listCompanies(a);
    expect(ca.find((c) => c.id === comp.id)!.contacts).toBe(1);
  });
});
