import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { and, eq } from "drizzle-orm";
import { setupDb, newTenant } from "../helpers";
import type { DB } from "../../src/server/db/client";
import * as s from "../../src/server/db/schema";
import { proposeAction } from "../../src/server/ai/flavio/actions";
import { previewAction, summarizeChanges, type CurrentValues } from "../../src/server/ai/flavio/preview";

let db: DB, close: () => Promise<void>;
beforeAll(async () => { ({ db, close } = await setupDb()); });
afterAll(async () => { await close(); });

const EMPTY: CurrentValues = { leads: {}, opportunities: {}, users: {} };
const LEAD = "11111111-1111-4111-8111-111111111111";

describe("Resumo antes → depois (função pura)", () => {
  it("alteração com valor atual: campo, atual e proposto", () => {
    const [c] = summarizeChanges({ kind: "update_lead_status", leadId: LEAD, status: "qualified" }, { ...EMPTY, leads: { [LEAD]: { title: "Grupo Alfa", status: "new" } } });
    expect(c).toMatchObject({ kind: "update", entity: "Lead", label: "Grupo Alfa" });
    expect(c.fields).toEqual([{ field: "Status", before: "Novo", after: "Qualificado", comparable: true }]);
  });

  it("alteração sem valor atual: só o proposto e aviso de que não há comparação", () => {
    const [c] = summarizeChanges({ kind: "update_lead_status", leadId: LEAD, status: "qualified" }, EMPTY);
    expect(c.fields[0]).toMatchObject({ before: null, after: "Qualificado", comparable: false });
    expect(c.note).toMatch(/não há comparação/);
  });

  it("valor atual igual ao proposto avisa que nada muda", () => {
    const [c] = summarizeChanges({ kind: "update_lead_status", leadId: LEAD, status: "new" }, { ...EMPTY, leads: { [LEAD]: { title: "X", status: "new" } } });
    expect(c.note).toMatch(/nada muda/);
  });

  it("criação: 'novo registro' com os campos principais", () => {
    const changes = summarizeChanges({ kind: "create_tasks", items: [{ title: "Ligar para o cliente", priority: "high", dueAt: "2026-11-20T13:00:00.000Z", leadId: LEAD }] },
      { ...EMPTY, leads: { [LEAD]: { title: "Grupo Alfa", status: "new" } } }, { timezone: "America/Sao_Paulo" });
    expect(changes).toHaveLength(1);
    const c = changes[0];
    expect(c).toMatchObject({ kind: "create", entity: "Tarefa", label: "Ligar para o cliente" });
    const f = Object.fromEntries(c.fields.map((x) => [x.field, x.after]));
    expect(f).toMatchObject({ "Título": "Ligar para o cliente", "Prioridade": "Alta", "Lead vinculado": "Grupo Alfa", "Responsável": "Sem responsável definido" });
    expect(f["Prazo"]).toMatch(/20\/11\/2026/);
    expect(c.fields.every((x) => x.before === null && !x.comparable)).toBe(true);
  });

  it("decisão, cenário e automação aparecem como novos registros em rascunho", () => {
    const [d] = summarizeChanges({ kind: "register_decision", title: "Rever preço", problem: "Margem caiu", alternatives: [{ name: "Subir 5%", description: "" }] }, EMPTY);
    expect(d).toMatchObject({ kind: "create", entity: "Decisão" });
    const [sc] = summarizeChanges({ kind: "save_scenario", name: "Preço +10%", scenarioKind: "price", variables: { priceChangePct: 10 } }, EMPTY);
    expect(sc.fields.find((x) => x.field === "Preço")?.after).toBe("+10%");
    const [wf] = summarizeChanges({ kind: "draft_automation", templateKey: "nutricao" }, EMPTY);
    expect(wf.fields.find((x) => x.field === "Situação")?.after).toMatch(/Rascunho/);
  });
});

describe("Prévia da proposta assinada (banco real)", () => {
  it("lê o valor atual da organização e NÃO altera nada", async () => {
    const ctx = await newTenant(db, "Prev");
    const [lead] = await db.insert(s.leads).values({ organizationId: ctx.organizationId, title: "Construtora Rio", status: "qualifying" }).returning();
    const p = proposeAction(ctx, { kind: "update_lead_status", leadId: lead.id, status: "qualified" }, { title: "Qualificar lead", summary: "Marcar como qualificado" });
    const prev = await previewAction(ctx, p.token);
    expect(prev.changes[0].fields[0]).toEqual({ field: "Status", before: "Em qualificação", after: "Qualificado", comparable: true });
    const [after] = await db.select().from(s.leads).where(and(eq(s.leads.id, lead.id), eq(s.leads.organizationId, ctx.organizationId)));
    expect(after.status).toBe("qualifying"); // prévia não executa
  });

  it("não expõe dados de outra organização: lead alheio aparece sem valor atual", async () => {
    const a = await newTenant(db, "PrevA"), b = await newTenant(db, "PrevB");
    const [leadA] = await db.insert(s.leads).values({ organizationId: a.organizationId, title: "Segredo da A", status: "new" }).returning();
    const p = proposeAction(b, { kind: "update_lead_status", leadId: leadA.id, status: "qualified" }, { title: "x", summary: "y" });
    const prev = await previewAction(b, p.token);
    expect(prev.changes[0].label).not.toContain("Segredo");
    expect(prev.changes[0].fields[0].comparable).toBe(false);
  });

  it("proposta de outro usuário é recusada", async () => {
    const a = await newTenant(db, "PrevU1"), b = await newTenant(db, "PrevU2");
    const p = proposeAction(a, { kind: "create_tasks", items: [{ title: "Tarefa", priority: "medium" }] }, { title: "x", summary: "y" });
    await expect(previewAction(b, p.token)).rejects.toThrow(/outro usuário|organização/);
  });
});
