import { describe, it, expect, beforeAll, afterAll, afterEach, vi } from "vitest";
import { setupDb, newTenant } from "../helpers";
import type { DB } from "../../src/server/db/client";
import { runAgent } from "../../src/server/ai/orchestrator";
import { anthropicProvider, AIRefusalError } from "../../src/server/ai/providers";

// Simula a API da Anthropic (sem rede, sem custo) para testar o caminho do provedor real.
let db: DB, close: () => Promise<void>;
const oldKey = process.env.ANTHROPIC_API_KEY;
beforeAll(async () => { ({ db, close } = await setupDb()); process.env.ANTHROPIC_API_KEY = "test-key-not-real"; });
afterAll(async () => { process.env.ANTHROPIC_API_KEY = oldKey; await close(); });
afterEach(() => vi.restoreAllMocks());

describe("Provedor de IA real (Anthropic)", () => {
  it("usa o provedor real quando há chave e não marca como simulado", async () => {
    const ctx = await newTenant(db, "IAReal");
    vi.spyOn(anthropicProvider, "complete").mockResolvedValue({ text: "Resposta real", inputTokens: 900, outputTokens: 300, model: "claude-opus-5-5", provider: "anthropic", simulated: false });
    const out = await runAgent(ctx, { agentKey: "executive", input: "Resumo da semana", chargeCredits: false });
    expect(out.provider).toBe("anthropic");
    expect(out.simulated).toBe(false);
    expect(out.status).toBe("success");
  });

  it("recusa do modelo bloqueia e NÃO cai para resposta simulada", async () => {
    const ctx = await newTenant(db, "IARecusa");
    vi.spyOn(anthropicProvider, "complete").mockRejectedValue(new AIRefusalError("recusado"));
    const out = await runAgent(ctx, { agentKey: "executive", input: "Pedido qualquer", chargeCredits: false });
    expect(out.status).toBe("blocked");
    expect(out.simulated).toBe(false);
    expect(out.credits).toBe(0);
  });

  it("falha técnica cai para o modo simulado e avisa", async () => {
    const ctx = await newTenant(db, "IAFalha");
    vi.spyOn(anthropicProvider, "complete").mockRejectedValue(new Error("HTTP 529"));
    const out = await runAgent(ctx, { agentKey: "executive", input: "Pedido qualquer", chargeCredits: false });
    expect(out.simulated).toBe(true);
    expect(out.status).toBe("fallback");
    expect(out.warnings.join(" ")).toMatch(/provedor de IA real falhou/);
  });
});
