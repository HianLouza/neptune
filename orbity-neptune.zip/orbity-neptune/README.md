# ORBITY-NEPTUNE

**INTELLIGENCE. AUTOMATION. GROWTH.** — Ecossistema SaaS B2B de inteligência comercial com IA.

Prospect.AI · Closer.AI · Sales Intelligence · CRM central · Event Engine · Workflow Engine · Centro de controle de IA ·
AI Evaluation Center · Metas e comissões · Billing com créditos · Customer Success · Feature flags · Experimentos · Incidentes · LGPD.

## Rodar localmente (não precisa instalar banco)
```bash
npm install
cp .env.example .env     # gere SESSION_SECRET e ENCRYPTION_KEY
npm run db:seed          # cria o banco local (PGlite) + organização de DEMONSTRAÇÃO
npm run dev              # http://localhost:3000
npm run worker           # opcional: processa a fila de eventos continuamente
npm test                 # 41 testes (unitários + integração com Postgres em memória)
```
Login de desenvolvimento: `admin@orbity.local` com a senha de `DEMO_PASSWORD` (padrão definido em `scripts/seed.ts`).
É também administrador global (Painel global e Customer Success).

## Estrutura
```
src/app/(auth)        login, cadastro, onboarding
src/app/(app)         telas autenticadas (dashboard e módulos)
src/app/api           rotas REST (BFF)
src/server/db         schema Drizzle, cliente (PGlite/Postgres), migrações
src/server/auth       sessões, senhas, TOTP, OAuth
src/server/domains    CRM, Prospect, Closer, Intelligence, Billing, CS, ...
src/server/events     Event Engine (outbox, retry, DLQ)
src/server/workflows  Workflow Engine
src/server/ai         provedores, orquestrador, guardrails, avaliação
tests/                unitários e integração
docs/                 arquitetura, operação, usuários, ADRs, matriz de requisitos
```

## O que é real e o que é simulado
- **Real:** todo o CRM, Prospect, inbox, base de conhecimento, automações, eventos, metas, billing interno, auditoria, LGPD.
- **Simulado (sempre sinalizado na interface):** IA sem chave configurada (provedor `local-heuristic`); envio de mensagens em canais sem integração conectada.
- **Depende de credenciais:** Anthropic/OpenAI, Google/Microsoft OAuth, WhatsApp, Stripe/Mercado Pago/Asaas, CRMs externos.

## Ativar a IA real (Anthropic)
1. Crie uma chave em https://console.anthropic.com (Settings → API Keys).
2. No `.env`, preencha `ANTHROPIC_API_KEY=` com a chave. Opcional: `ANTHROPIC_MODEL` (padrão `claude-opus-5-5`) e
   `ANTHROPIC_EFFORT` (`low`/`medium`/`high`; padrão `medium` — `low` é mais barato e rápido para chat).
3. Reinicie o `npm run dev`. Em **IA e Agentes** o provedor aparece como configurado e as respostas deixam de ter o selo "Simulado".

Comportamento: se a API falhar, o app cai para o modo simulado e avisa; se o modelo recusar um pedido por segurança,
a resposta é bloqueada (não vira simulação). A chave nunca vai para o navegador nem para o repositório (`.env` está no `.gitignore`).

Documentação: [`docs/arquitetura`](docs/arquitetura/README.md) · [`docs/operacao`](docs/operacao/deploy.md) ·
[`docs/usuarios`](docs/usuarios/manual.md) · [`docs/MATRIZ-REQUISITOS.md`](docs/MATRIZ-REQUISITOS.md) · [`docs/v4`](docs/v4/README.md) (Master Prompt 4.0: auditoria, matriz, backlog, roadmap)
