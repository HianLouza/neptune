CREATE TABLE "ai_draft_versions" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"organization_id" uuid NOT NULL,
	"draft_id" uuid NOT NULL,
	"seq" integer NOT NULL,
	"origin" text NOT NULL,
	"operation" text NOT NULL,
	"instruction" text,
	"content" text NOT NULL,
	"based_on_version_id" uuid,
	"execution_id" uuid,
	"simulated" boolean DEFAULT false NOT NULL,
	"provider" text,
	"model" text,
	"sources" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"rejected" boolean DEFAULT false NOT NULL,
	"created_by" uuid NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "ai_drafts" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"organization_id" uuid NOT NULL,
	"module" text NOT NULL,
	"subject_type" text NOT NULL,
	"subject_id" uuid NOT NULL,
	"agent_key" text NOT NULL,
	"channel" text,
	"status" text DEFAULT 'open' NOT NULL,
	"created_by" uuid NOT NULL,
	"sent_version_id" uuid,
	"sent_message_id" uuid,
	"sent_by" uuid,
	"sent_at" timestamp with time zone,
	"discard_reason" text,
	"discard_note" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "flavio_conversations" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"organization_id" uuid NOT NULL,
	"user_id" uuid NOT NULL,
	"title" text NOT NULL,
	"surface" text DEFAULT 'brain' NOT NULL,
	"status" text DEFAULT 'active' NOT NULL,
	"context" jsonb DEFAULT '{}'::jsonb NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "flavio_messages" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"organization_id" uuid NOT NULL,
	"conversation_id" uuid NOT NULL,
	"role" text NOT NULL,
	"content" text NOT NULL,
	"payload" jsonb,
	"execution_id" uuid,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "ai_draft_versions" ADD CONSTRAINT "ai_draft_versions_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "ai_draft_versions" ADD CONSTRAINT "ai_draft_versions_draft_id_ai_drafts_id_fk" FOREIGN KEY ("draft_id") REFERENCES "public"."ai_drafts"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "ai_drafts" ADD CONSTRAINT "ai_drafts_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "flavio_conversations" ADD CONSTRAINT "flavio_conversations_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "flavio_messages" ADD CONSTRAINT "flavio_messages_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "flavio_messages" ADD CONSTRAINT "flavio_messages_conversation_id_flavio_conversations_id_fk" FOREIGN KEY ("conversation_id") REFERENCES "public"."flavio_conversations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE UNIQUE INDEX "ai_draft_version_seq_uq" ON "ai_draft_versions" USING btree ("draft_id","seq");--> statement-breakpoint
CREATE INDEX "ai_draft_subject_idx" ON "ai_drafts" USING btree ("organization_id","module","subject_id");--> statement-breakpoint
CREATE INDEX "ai_draft_status_idx" ON "ai_drafts" USING btree ("organization_id","status");--> statement-breakpoint
CREATE INDEX "flavio_conv_user_idx" ON "flavio_conversations" USING btree ("organization_id","user_id","updated_at");--> statement-breakpoint
CREATE INDEX "flavio_msg_conv_idx" ON "flavio_messages" USING btree ("conversation_id","created_at");