CREATE TABLE "task_alert_events" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"organization_id" uuid NOT NULL,
	"task_id" uuid NOT NULL,
	"alert_id" uuid,
	"type" text NOT NULL,
	"actor_id" text,
	"channel" text,
	"data" jsonb DEFAULT '{}'::jsonb NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "task_alert_responses" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"organization_id" uuid NOT NULL,
	"task_id" uuid NOT NULL,
	"alert_id" uuid,
	"user_id" uuid NOT NULL,
	"kind" text NOT NULL,
	"message" text,
	"progress_pct" integer,
	"evidence_url" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "task_alert_rules" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"organization_id" uuid NOT NULL,
	"name" text NOT NULL,
	"trigger" text NOT NULL,
	"offset_minutes" integer DEFAULT 1440 NOT NULL,
	"stale_after_hours" integer DEFAULT 48 NOT NULL,
	"repeat_every_minutes" integer,
	"max_reminders" integer DEFAULT 3 NOT NULL,
	"allowed_start_hour" integer DEFAULT 8 NOT NULL,
	"allowed_end_hour" integer DEFAULT 18 NOT NULL,
	"priorities" jsonb DEFAULT '["low","medium","high"]'::jsonb NOT NULL,
	"alert_priority" text DEFAULT 'medium' NOT NULL,
	"channels" jsonb DEFAULT '["in_app"]'::jsonb NOT NULL,
	"tone" text,
	"escalation" jsonb DEFAULT '{"enabled":false,"maxAttempts":2,"steps":[]}'::jsonb NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	"created_by" uuid,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "task_alerts" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"organization_id" uuid NOT NULL,
	"task_id" uuid NOT NULL,
	"recipient_id" uuid NOT NULL,
	"sender_id" uuid,
	"kind" text DEFAULT 'manual' NOT NULL,
	"title" text NOT NULL,
	"message" text NOT NULL,
	"original_message" text,
	"message_origin" text DEFAULT 'manual' NOT NULL,
	"priority" text DEFAULT 'medium' NOT NULL,
	"channels" jsonb DEFAULT '["in_app"]'::jsonb NOT NULL,
	"channel_results" jsonb DEFAULT '{}'::jsonb NOT NULL,
	"status" text DEFAULT 'draft' NOT NULL,
	"scheduled_at" timestamp with time zone,
	"sent_at" timestamp with time zone,
	"delivered_at" timestamp with time zone,
	"read_at" timestamp with time zone,
	"responded_at" timestamp with time zone,
	"canceled_at" timestamp with time zone,
	"failure_reason" text,
	"task_due_at_snapshot" timestamp with time zone,
	"rule_id" uuid,
	"parent_alert_id" uuid,
	"escalation_level" integer DEFAULT 0 NOT NULL,
	"idempotency_key" text,
	"flavio_execution_id" uuid,
	"simulated" boolean DEFAULT false NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "task_extension_requests" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"organization_id" uuid NOT NULL,
	"task_id" uuid NOT NULL,
	"alert_id" uuid,
	"requester_id" uuid NOT NULL,
	"current_due_at" timestamp with time zone,
	"requested_due_at" timestamp with time zone NOT NULL,
	"justification" text NOT NULL,
	"blockers" text,
	"impact" text,
	"status" text DEFAULT 'pending' NOT NULL,
	"recommendation" jsonb,
	"decided_by" uuid,
	"decided_at" timestamp with time zone,
	"decided_due_at" timestamp with time zone,
	"decision_note" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "notifications" ADD COLUMN "alert_id" uuid;--> statement-breakpoint
ALTER TABLE "notifications" ADD COLUMN "priority" text;--> statement-breakpoint
ALTER TABLE "tasks" ADD COLUMN "blocked_reason" text;--> statement-breakpoint
ALTER TABLE "tasks" ADD COLUMN "progress_pct" integer;--> statement-breakpoint
ALTER TABLE "tasks" ADD COLUMN "goal_id" uuid;--> statement-breakpoint
ALTER TABLE "tasks" ADD COLUMN "updated_at" timestamp with time zone DEFAULT now() NOT NULL;--> statement-breakpoint
ALTER TABLE "task_alert_events" ADD CONSTRAINT "task_alert_events_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "task_alert_events" ADD CONSTRAINT "task_alert_events_task_id_tasks_id_fk" FOREIGN KEY ("task_id") REFERENCES "public"."tasks"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "task_alert_responses" ADD CONSTRAINT "task_alert_responses_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "task_alert_responses" ADD CONSTRAINT "task_alert_responses_task_id_tasks_id_fk" FOREIGN KEY ("task_id") REFERENCES "public"."tasks"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "task_alert_rules" ADD CONSTRAINT "task_alert_rules_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "task_alerts" ADD CONSTRAINT "task_alerts_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "task_alerts" ADD CONSTRAINT "task_alerts_task_id_tasks_id_fk" FOREIGN KEY ("task_id") REFERENCES "public"."tasks"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "task_alerts" ADD CONSTRAINT "task_alerts_recipient_id_users_id_fk" FOREIGN KEY ("recipient_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "task_extension_requests" ADD CONSTRAINT "task_extension_requests_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "task_extension_requests" ADD CONSTRAINT "task_extension_requests_task_id_tasks_id_fk" FOREIGN KEY ("task_id") REFERENCES "public"."tasks"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "task_alert_ev_task_idx" ON "task_alert_events" USING btree ("organization_id","task_id","created_at");--> statement-breakpoint
CREATE INDEX "task_alert_resp_task_idx" ON "task_alert_responses" USING btree ("organization_id","task_id","created_at");--> statement-breakpoint
CREATE INDEX "task_rule_org_idx" ON "task_alert_rules" USING btree ("organization_id","active");--> statement-breakpoint
CREATE UNIQUE INDEX "task_alert_idem_uq" ON "task_alerts" USING btree ("organization_id","idempotency_key");--> statement-breakpoint
CREATE INDEX "task_alert_task_idx" ON "task_alerts" USING btree ("organization_id","task_id");--> statement-breakpoint
CREATE INDEX "task_alert_recipient_idx" ON "task_alerts" USING btree ("organization_id","recipient_id","status");--> statement-breakpoint
CREATE INDEX "task_alert_due_idx" ON "task_alerts" USING btree ("status","scheduled_at");--> statement-breakpoint
CREATE INDEX "task_ext_org_idx" ON "task_extension_requests" USING btree ("organization_id","status");--> statement-breakpoint
CREATE INDEX "tasks_org_assignee_idx" ON "tasks" USING btree ("organization_id","assignee_id","status");