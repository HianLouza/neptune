/**
 * DECISION ENGINE — registro de decisões empresariais com alternativas, aprovação e monitoramento.
 *
 * Fluxo: draft → pending_approval → approved | rejected → monitoring → closed
 *  - Aprovação exige `approvals:decide` e SEGREGAÇÃO DE FUNÇÕES: quem criou não aprova.
 *  - Toda transição é auditada; aprovação publica o evento "decision.approved" (pode disparar automações).
 *  - Decisão criada a partir de um insight copia a evidência dele (Evidence Engine).
 */
import { and, desc, eq, inArray, sql } from "drizzle-orm";
import { z } from "zod";
import { decisions, notifications, scenarios } from "../db/schema";
import { requirePerm, type TenantContext } from "../tenancy/context";
import { audit } from "../audit";
import { publish, EVENT_TYPES } from "../events";
import { HttpError } from "../http";
import { getInsight } from "./insights";

export type DecisionRow = typeof decisions.$inferSelect;

const alternative = z.object({
  name: z.string().trim().min(2).max(120),
  description: z.string().trim().max(1000).default(""),
  estimatedImpact: z.string().trim().max(500).default(""),
  risks: z.string().trim().max(500).default(""),
});

export const createDecisionInput = z.object({
  title: z.string().trim().min(3).max(200),
  problem: z.string().trim().min(3).max(2000),
  alternatives: z.array(alternative).max(10).default([]),
  insightId: z.string().uuid().optional(),
  scenarioId: z.string().uuid().optional(),
  reviewAt: z.coerce.date().optional(),
});

const uuid = z.string().uuid();

async function load(ctx: TenantContext, id: string) {
  if (!uuid.safeParse(id).success) throw new HttpError(404, "Decisão não encontrada.");
  const [d] = await ctx.db.select().from(decisions).where(and(eq(decisions.id, id), eq(decisions.organizationId, ctx.organizationId)));
  if (!d) throw new HttpError(404, "Decisão não encontrada.");
  return d;
}

export async function createDecision(ctx: TenantContext, raw: z.input<typeof createDecisionInput>) {
  requirePerm(ctx, "intelligence:read");
  const input = createDecisionInput.parse(raw);
  let evidence = null;
  if (input.insightId) evidence = (await getInsight(ctx, input.insightId)).evidence; // valida tenant + permissão de domínio
  if (input.scenarioId) {
    const [s] = await ctx.db.select({ id: scenarios.id }).from(scenarios).where(and(eq(scenarios.id, input.scenarioId), eq(scenarios.organizationId, ctx.organizationId)));
    if (!s) throw new HttpError(404, "Cenário não encontrado.");
  }
  const [d] = await ctx.db.insert(decisions).values({
    organizationId: ctx.organizationId, title: input.title, problem: input.problem, alternatives: input.alternatives,
    insightId: input.insightId ?? null, scenarioId: input.scenarioId ?? null, evidence, reviewAt: input.reviewAt ?? null, createdBy: ctx.userId,
  }).returning();
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "decision.created", resource: "decision", resourceId: d.id, metadata: { insightId: input.insightId, scenarioId: input.scenarioId }, ip: ctx.ip });
  return d;
}

export const transitionInput = z.discriminatedUnion("action", [
  z.object({ action: z.literal("edit"), alternatives: z.array(alternative).max(10).optional(), chosenAlternative: z.string().trim().max(120).optional(), rationale: z.string().trim().max(2000).optional(), reviewAt: z.coerce.date().optional() }),
  z.object({ action: z.literal("submit") }),
  z.object({ action: z.literal("approve"), note: z.string().trim().max(1000).optional() }),
  z.object({ action: z.literal("reject"), note: z.string().trim().min(3, "Informe o motivo da rejeição.").max(1000) }),
  z.object({ action: z.literal("monitor"), reviewAt: z.coerce.date() }),
  z.object({ action: z.literal("close"), result: z.string().trim().min(3, "Descreva o resultado observado.").max(2000) }),
]);

export async function transitionDecision(ctx: TenantContext, id: string, raw: z.input<typeof transitionInput>) {
  requirePerm(ctx, "intelligence:read");
  const input = transitionInput.parse(raw);
  const d = await load(ctx, id);
  const set: Partial<typeof decisions.$inferInsert> = {};
  const expect = (...st: string[]) => { if (!st.includes(d.status)) throw new HttpError(409, `Ação "${input.action}" não permitida com a decisão em "${d.status}".`); };

  switch (input.action) {
    case "edit":
      expect("draft");
      if (input.alternatives) set.alternatives = input.alternatives;
      if (input.chosenAlternative !== undefined) {
        const alts = input.alternatives ?? d.alternatives;
        if (input.chosenAlternative && !alts.some((a) => a.name === input.chosenAlternative)) throw new HttpError(400, "A alternativa escolhida não está na lista.");
        set.chosenAlternative = input.chosenAlternative || null;
      }
      if (input.rationale !== undefined) set.rationale = input.rationale;
      if (input.reviewAt) set.reviewAt = input.reviewAt;
      break;
    case "submit":
      expect("draft");
      if (d.alternatives.length < 1) throw new HttpError(400, "Inclua ao menos uma alternativa antes de enviar.");
      if (!d.chosenAlternative || !d.rationale) throw new HttpError(400, "Escolha uma alternativa e registre a justificativa antes de enviar para aprovação.");
      set.status = "pending_approval";
      break;
    case "approve":
    case "reject":
      expect("pending_approval");
      requirePerm(ctx, "approvals:decide");
      if (d.createdBy === ctx.userId) throw new HttpError(403, "Segregação de funções: quem criou a decisão não pode aprová-la nem rejeitá-la.");
      set.status = input.action === "approve" ? (d.reviewAt ? "monitoring" : "approved") : "rejected";
      set.approvedBy = ctx.userId;
      set.approvedAt = new Date();
      if (input.action === "reject") set.result = `Rejeitada: ${input.note}`;
      break;
    case "monitor":
      expect("approved");
      set.status = "monitoring";
      set.reviewAt = input.reviewAt;
      break;
    case "close":
      expect("approved", "monitoring");
      set.status = "closed";
      set.result = input.result;
      break;
  }

  const updated = await ctx.db.transaction(async (tx) => {
    const [u] = await tx.update(decisions).set(set).where(and(eq(decisions.id, d.id), eq(decisions.organizationId, ctx.organizationId))).returning();
    if (input.action === "approve") {
      await publish(tx, ctx.organizationId, EVENT_TYPES.DECISION_APPROVED, { decisionId: d.id, chosenAlternative: d.chosenAlternative, by: ctx.userId });
    }
    if (input.action === "submit") {
      await tx.insert(notifications).values({ organizationId: ctx.organizationId, title: "Decisão aguardando aprovação", body: d.title, href: "/command-center#decisoes" });
    }
    if (input.action === "approve" || input.action === "reject") {
      await tx.insert(notifications).values({ organizationId: ctx.organizationId, userId: d.createdBy, title: input.action === "approve" ? "Sua decisão foi aprovada" : "Sua decisão foi rejeitada", body: d.title, href: "/command-center#decisoes" });
    }
    return u;
  });
  await audit(ctx.db, {
    organizationId: ctx.organizationId, actorId: ctx.userId, action: `decision.${input.action}`, resource: "decision", resourceId: d.id,
    metadata: { from: d.status, to: updated.status, note: "note" in input ? input.note : undefined }, ip: ctx.ip,
  });
  return updated;
}

export async function listDecisions(ctx: TenantContext, opts: { status?: string[]; limit?: number } = {}) {
  requirePerm(ctx, "intelligence:read");
  const conds = [eq(decisions.organizationId, ctx.organizationId)];
  if (opts.status?.length) conds.push(inArray(decisions.status, opts.status));
  return ctx.db.select().from(decisions).where(and(...conds))
    .orderBy(sql`case ${decisions.status} when 'pending_approval' then 0 when 'draft' then 1 when 'monitoring' then 2 when 'approved' then 3 else 4 end`, desc(decisions.createdAt))
    .limit(opts.limit ?? 50);
}

export async function getDecision(ctx: TenantContext, id: string) {
  requirePerm(ctx, "intelligence:read");
  return load(ctx, id);
}
