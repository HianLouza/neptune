/**
 * EXECUTIVE BRIEFING (Business Brain §7.4) — relatório diário/semanal/mensal/trimestral gerado a partir de dados.
 * Responde às 6 perguntas do Command Center. Tudo é calculado; nada é narrado sem fonte.
 */
import { and, desc, eq } from "drizzle-orm";
import { z } from "zod";
import { briefings } from "../db/schema";
import { requirePerm, can, type TenantContext } from "../tenancy/context";
import { audit } from "../audit";
import { dashboardKpis, revenueForecast } from "../domains/intelligence";
import { financialSnapshot } from "../domains/finance/snapshot";
import { fmtMoney } from "./evidence";
import { listInsights, scanInsights } from "./insights";
import { listDecisions } from "./decisions";

export const BRIEFING_PERIODS = { daily: 1, weekly: 7, monthly: 30, quarterly: 90 } as const;
export type BriefingPeriod = keyof typeof BRIEFING_PERIODS;
export const PERIOD_LABEL: Record<BriefingPeriod, string> = { daily: "Diário", weekly: "Semanal", monthly: "Mensal", quarterly: "Trimestral" };

export type BriefingContent = {
  acontecendo: string[];
  mudou: string[];
  atencao: string[];
  oportunidades: string[];
  decisoes: string[];
  melhorar: string[];
  fontes: string[];
  financeStatus: "ok" | "sem_dados" | "sem_permissao";
};

const signed = (v: number | null, suffix = "%") => (v == null ? "sem base de comparação" : `${v >= 0 ? "+" : ""}${v}${suffix}`);

export async function generateBriefing(ctx: TenantContext, period: BriefingPeriod) {
  requirePerm(ctx, "intelligence:read");
  z.enum(["daily", "weekly", "monthly", "quarterly"]).parse(period);
  const days = BRIEFING_PERIODS[period];
  const m = (c: number) => fmtMoney(c, ctx.locale, ctx.currency);
  await scanInsights(ctx);
  const [k, fc, ins, dec] = await Promise.all([
    dashboardKpis(ctx, days), revenueForecast(ctx), listInsights(ctx, { status: ["open", "accepted", "modified"], limit: 50 }),
    listDecisions(ctx, { status: ["pending_approval", "draft", "monitoring"] }),
  ]);
  const financeAllowed = can(ctx, "finance:read");
  const fin = financeAllowed ? await financialSnapshot(ctx, days) : null;
  const financeStatus: BriefingContent["financeStatus"] = !financeAllowed ? "sem_permissao" : fin?.hasData ? "ok" : "sem_dados";

  const c: BriefingContent = { acontecendo: [], mudou: [], atencao: [], oportunidades: [], decisoes: [], melhorar: [], fontes: [], financeStatus };
  c.acontecendo.push(`Receita de vendas: ${m(k.current.revenueCents)} em ${k.current.won} negócios ganhos.`);
  c.acontecendo.push(`${k.current.leads} leads e ${k.current.opportunities} oportunidades criadas.`);
  c.acontecendo.push(`Pipeline aberto: ${m(fc.pipelineTotalCents)} em ${fc.openDeals} negócios (previsão base ${m(fc.scenarios.base)}).`);
  if (fin?.hasData) c.acontecendo.push(`Caixa: ${m(fin.revenueCents)} recebidos e ${m(fin.expensesCents)} pagos (resultado ${m(fin.resultCents)}).`);

  c.mudou.push(`Receita ${signed(k.delta.revenue)} · vendas ${signed(k.delta.won)} · leads ${signed(k.delta.leads)}.`);
  if (k.delta.conversionPp != null) c.mudou.push(`Conversão ${signed(k.delta.conversionPp, " p.p.")} (${k.current.conversionRate}%).`);
  if (fin?.hasData && fin.previous.expensesCents > 0) {
    const g = Math.round(((fin.expensesCents - fin.previous.expensesCents) / fin.previous.expensesCents) * 1000) / 10;
    c.mudou.push(`Despesas pagas ${signed(g)} vs. período anterior.`);
  }

  for (const i of ins.filter((x) => x.priority === "high").slice(0, 6)) c.atencao.push(i.title);
  if (!c.atencao.length) c.atencao.push("Nenhum alerta de alta prioridade aberto.");

  for (const i of ins.filter((x) => ["sales", "prospect"].includes(x.domain) && x.priority !== "high").slice(0, 3)) c.oportunidades.push(`${i.title} — ${i.recommendedAction ?? ""}`.trim());
  if (fc.scenarios.base > 0) c.oportunidades.push(`Pipeline ponderado de ${m(fc.scenarios.base)} disponível para fechamento.`);

  const pending = dec.filter((d) => d.status === "pending_approval");
  for (const d of pending) c.decisoes.push(`Aguardando aprovação: ${d.title}`);
  const toDecide = ins.filter((i) => i.status === "open" && i.priority === "high").length;
  if (toDecide) c.decisoes.push(`${toDecide} recomendação(ões) de alta prioridade aguardam aceite ou rejeição.`);
  if (!c.decisoes.length) c.decisoes.push("Nenhuma decisão pendente.");

  for (const i of ins.filter((x) => x.recommendedAction).slice(0, 4)) c.melhorar.push(i.recommendedAction!);
  if (financeStatus === "sem_dados") c.melhorar.push("Registrar receitas e despesas no Financeiro para habilitar margem, caixa e inadimplência.");

  c.fontes = ["CRM · leads e oportunidades", "Sales Intelligence · previsão", "Intelligence Layer · insights", "Decision Engine · decisões", ...(fin?.hasData ? ["Financeiro · lançamentos"] : [])];

  const now = new Date();
  const [row] = await ctx.db.insert(briefings).values({
    organizationId: ctx.organizationId, period, periodStart: new Date(now.getTime() - days * 864e5), periodEnd: now, content: c, generatedBy: ctx.roleKey === "system" ? null : ctx.userId,
  }).returning();
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.roleKey === "system" ? "system" : ctx.userId, action: "briefing.generated", resource: "briefing", resourceId: row.id, metadata: { period } });
  return row;
}

export async function listBriefings(ctx: TenantContext, limit = 10) {
  requirePerm(ctx, "intelligence:read");
  return ctx.db.select().from(briefings).where(eq(briefings.organizationId, ctx.organizationId)).orderBy(desc(briefings.createdAt)).limit(limit);
}

export async function latestBriefing(ctx: TenantContext, period?: BriefingPeriod) {
  requirePerm(ctx, "intelligence:read");
  const conds = [eq(briefings.organizationId, ctx.organizationId)];
  if (period) conds.push(eq(briefings.period, period));
  const [row] = await ctx.db.select().from(briefings).where(and(...conds)).orderBy(desc(briefings.createdAt)).limit(1);
  return row ?? null;
}
