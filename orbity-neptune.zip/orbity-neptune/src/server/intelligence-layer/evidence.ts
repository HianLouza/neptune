/**
 * EVIDENCE ENGINE — formato único de evidência para insights, decisões, cenários e briefings.
 *
 * Regras (Master Prompt 4.0 §6.4):
 *  - Toda análise relevante informa fonte, período, métrica, premissas, cálculos, confiança, dados ausentes e limitações.
 *  - A confiança é calculada a partir do tamanho da amostra e dos dados ausentes (nunca "inventada").
 *  - Fatos, inferências, estimativas e recomendações são distinguidos pelo campo `nature` de quem usa a evidência.
 */
import type { Evidence } from "../db/schema";

export type { Evidence };
export type EvidenceFact = Evidence["facts"][number];

/** Confiança 0..1: amostras pequenas e dados ausentes reduzem a confiança de forma explícita e auditável. */
export function confidenceFrom(sampleSize: number, missingCount = 0, minSample = 30): number {
  if (sampleSize <= 0) return 0;
  const sample = Math.min(1, Math.sqrt(sampleSize / minSample));
  const penalty = Math.min(0.6, missingCount * 0.15);
  return Math.max(0, Math.round((sample * (1 - penalty)) * 100) / 100);
}

export function confidenceLabel(c: number): "alta" | "média" | "baixa" | "insuficiente" {
  if (c >= 0.75) return "alta";
  if (c >= 0.5) return "média";
  if (c > 0) return "baixa";
  return "insuficiente";
}

export function buildEvidence(e: Partial<Evidence> & { facts: EvidenceFact[] }): Evidence {
  return {
    facts: e.facts,
    assumptions: e.assumptions ?? [],
    calculations: e.calculations ?? [],
    confidence: Math.max(0, Math.min(1, e.confidence ?? 0)),
    missingData: e.missingData ?? [],
    limitations: e.limitations ?? [],
  };
}

/** Garante que nenhuma evidência seja salva sem ao menos um fato com fonte. */
export function assertEvidence(e: Evidence) {
  if (!e.facts.length) throw Object.assign(new Error("Evidência sem fatos: análise não pode ser registrada."), { status: 422 });
  for (const f of e.facts) if (!f.source) throw Object.assign(new Error(`Fato "${f.label}" sem fonte.`), { status: 422 });
}

export const fmtMoney = (cents: number, locale: string, currency: string) =>
  (cents / 100).toLocaleString(locale, { style: "currency", currency, maximumFractionDigits: 0 });

export const fmtPct = (v: number, locale = "pt-BR", digits = 1) =>
  `${v.toLocaleString(locale, { maximumFractionDigits: digits, minimumFractionDigits: 0 })}%`;
