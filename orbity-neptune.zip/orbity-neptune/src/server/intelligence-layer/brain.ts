/**
 * ORBITY BUSINESS BRAIN — perguntas executivas em linguagem natural.
 *
 * - A pergunta é mapeada para uma ANÁLISE DETERMINÍSTICA (intenção por palavras-chave); nenhum SQL é gerado por IA.
 * - Toda resposta tem as 10 partes do Master Prompt §7.3 e separa fatos, inferências, estimativas e recomendações.
 * - Dados ausentes (ex.: sem lançamentos financeiros, produtos sem vínculo) são declarados e reduzem a confiança.
 * - Narração opcional por LLM: só reescreve o resumo executivo a partir dos fatos calculados, quando há um provedor
 *   de IA real configurado. Falhou? Volta para o texto determinístico. Os fatos nunca vêm do modelo.
 */
import { and, count, desc, eq, gte, inArray, isNotNull, lt, max, sql } from "drizzle-orm";
import { activities, companies, contacts, conversations, financeCategories, financeEntries, opportunities, products } from "../db/schema";
import type { Evidence } from "../db/schema";
import { requirePerm, can, type TenantContext } from "../tenancy/context";
import { audit } from "../audit";
import { dashboardKpis, funnelAnalysis, sellerPerformance, revenueForecast } from "../domains/intelligence";
import { financialSnapshot, type FinancialSnapshot } from "../domains/finance/snapshot";
import { providerChain } from "../ai/providers";
import { runAgent } from "../ai/orchestrator";
import { buildEvidence, confidenceFrom, fmtMoney } from "./evidence";

export type Nature = "fato" | "inferência" | "estimativa" | "recomendação";
export type Item = { text: string; nature: Nature };

export type BrainAnswer = {
  question: string;
  intent: string | null;
  supported: boolean;
  narration: "ai" | "deterministic";
  resumoExecutivo: string;
  diagnostico: Item[];
  dadosUtilizados: { fonte: string; descricao: string; periodo?: string }[];
  evidencias: Evidence;
  causasPossiveis: Item[];
  impactoFinanceiro: Item[];
  alternativas: Item[];
  recomendacoes: Item[];
  planoDeAcao: { passo: string; prazo: string }[];
  indicadores: string[];
};

export const SUPPORTED_QUESTIONS = [
  "Por que minha receita caiu?",
  "Quais produtos são mais rentáveis?",
  "Quais clientes representam maior risco?",
  "Onde estamos perdendo oportunidades?",
  "Qual equipe apresenta melhor desempenho?",
  "Quais despesas cresceram?",
  "Posso contratar mais funcionários?",
  "Qual produto devo priorizar?",
  "Quais clientes possuem potencial de expansão?",
  "Qual decisão pode melhorar meu fluxo de caixa?",
];

const DAY = 864e5;
const f = (text: string): Item => ({ text, nature: "fato" });
const inf = (text: string): Item => ({ text, nature: "inferência" });
const est = (text: string): Item => ({ text, nature: "estimativa" });
const rec = (text: string): Item => ({ text, nature: "recomendação" });

export type Draft = Omit<BrainAnswer, "question" | "intent" | "supported" | "narration">;

const norm = (s: string) => s.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "");

const INTENTS: { key: string; test: RegExp }[] = [
  { key: "hiring", test: /contrat|funcionari|admitir|vaga/ },
  { key: "cashflow", test: /fluxo de caixa|caixa/ },
  { key: "expenses", test: /despesa|custo|gasto/ },
  { key: "product_priority", test: /produto.*prioriz|prioriz.*produto/ },
  { key: "product_profitability", test: /produto|rentav|margem por/ },
  { key: "customers_risk", test: /(cliente|conta).*(risco|cancel|churn|perder)/ },
  { key: "expansion", test: /expans|upsell|cross|potencial/ },
  { key: "lost_opportunities", test: /perd|motivo/ },
  { key: "best_team", test: /equipe|vendedor|time|desempenho|ranking/ },
  { key: "revenue_drop", test: /receita|faturamento|vendas? (cai|caiu)|caiu/ },
];

export function detectIntent(question: string) {
  const q = norm(question);
  return INTENTS.find((i) => i.test.test(q))?.key ?? null;
}

const noFinance = (ctx: TenantContext, snap: FinancialSnapshot | null) =>
  !can(ctx, "finance:read") ? "Você não tem permissão para ver dados financeiros (finance:read)." : !snap?.hasData ? "Não há lançamentos financeiros registrados no módulo Financeiro." : null;

/* ------------------------------------------------------------------ análises */

async function revenueDrop(ctx: TenantContext): Promise<Draft> {
  const k = await dashboardKpis(ctx, 30);
  const funnel = await funnelAnalysis(ctx);
  const sellers = await sellerPerformance(ctx, 30);
  const m = (c: number) => fmtMoney(c, ctx.locale, ctx.currency);
  const d = k.delta.revenue;
  const fell = d != null && d < 0;
  const causes: Item[] = [];
  if (k.delta.leads != null && k.delta.leads < 0) causes.push(inf(`Menos leads entrando: ${k.delta.leads}% vs. período anterior (${k.current.leads} contra ${k.previous.leads}).`));
  if (k.delta.conversionPp != null && k.delta.conversionPp < 0) causes.push(inf(`Conversão menor: ${k.delta.conversionPp} p.p. (${k.current.conversionRate}% contra ${k.previous.conversionRate}%).`));
  if (k.delta.won != null && k.delta.won < 0) causes.push(inf(`Menos negócios fechados: ${k.current.won} contra ${k.previous.won}.`));
  const ticketCur = k.current.won ? k.current.revenueCents / k.current.won : 0, ticketPrev = k.previous.won ? k.previous.revenueCents / k.previous.won : 0;
  if (ticketPrev && ticketCur < ticketPrev * 0.9) causes.push(inf(`Ticket médio menor: ${m(ticketCur)} contra ${m(ticketPrev)}.`));
  const open = funnel.filter((s) => s.kind === "open");
  const biggest = [...open].sort((a, b) => b.total - a.total)[0];
  if (biggest?.total) causes.push(inf(`Maior volume parado está em "${biggest.name}" (${biggest.n} oportunidades, ${m(biggest.total)}).`));
  if (!causes.length && fell) causes.push(inf("Nenhuma das causas monitoradas (volume, conversão, ticket) explica sozinha a queda; verifique sazonalidade e negócios grandes atípicos."));

  return {
    resumoExecutivo: d == null ? "Não há receita no período anterior para comparar." : fell
      ? `A receita de vendas caiu ${Math.abs(d)}% nos últimos 30 dias (${m(k.current.revenueCents)} contra ${m(k.previous.revenueCents)}).`
      : `A receita de vendas não caiu: variação de +${d}% nos últimos 30 dias (${m(k.current.revenueCents)}).`,
    diagnostico: [
      f(`Receita ganha: ${m(k.current.revenueCents)} (atual) e ${m(k.previous.revenueCents)} (anterior).`),
      f(`Vendas: ${k.current.won} e ${k.previous.won}. Leads: ${k.current.leads} e ${k.previous.leads}.`),
      f(`Conversão: ${k.current.conversionRate ?? "—"}% e ${k.previous.conversionRate ?? "—"}%.`),
    ],
    dadosUtilizados: [
      { fonte: "CRM · oportunidades ganhas/perdidas", descricao: "Receita, vendas e conversão", periodo: "últimos 30 dias vs. 30 anteriores" },
      { fonte: "CRM · leads", descricao: "Volume de entrada" },
      { fonte: "CRM · funil", descricao: "Posição atual por etapa" },
    ],
    evidencias: buildEvidence({
      facts: [
        { label: "Receita atual", value: m(k.current.revenueCents), source: "CRM · oportunidades ganhas", period: "últimos 30 dias" },
        { label: "Receita anterior", value: m(k.previous.revenueCents), source: "CRM · oportunidades ganhas", period: "30 dias anteriores" },
      ],
      calculations: ["Variação = (atual − anterior) ÷ anterior.", "Ticket médio = receita ÷ vendas."],
      confidence: confidenceFrom(k.current.won + k.previous.won, 0, 20),
      limitations: ["Receita comercial do CRM (negócios ganhos), não recebimentos."],
    }),
    causasPossiveis: causes,
    impactoFinanceiro: d != null ? [f(`Diferença de receita: ${m(k.current.revenueCents - k.previous.revenueCents)} em 30 dias.`)] : [],
    alternativas: [rec("Recuperar volume: ativar campanhas/prospecção para o ICP."), rec("Recuperar conversão: revisar qualificação e motivos de perda."), rec("Destravar o funil: follow-up nas etapas com mais valor parado.")],
    recomendacoes: fell ? [rec(causes[0] ? `Atacar primeiro: ${causes[0].text}` : "Investigar negócios grandes do período anterior que não se repetiram.")] : [rec("Manter o ritmo e acompanhar a conversão semanalmente.")],
    planoDeAcao: [{ passo: "Revisar oportunidades paradas da etapa com mais valor", prazo: "7 dias" }, { passo: "Analisar os 10 últimos motivos de perda com o time", prazo: "7 dias" }],
    indicadores: ["Receita ganha (30 dias)", "Taxa de conversão", "Leads gerados", "Ticket médio"],
  };
}

async function productProfitability(ctx: TenantContext, prioritize = false): Promise<Draft> {
  const snap = can(ctx, "finance:read") ? await financialSnapshot(ctx, 90) : null;
  const missing = noFinance(ctx, snap);
  const prods = await ctx.db.select({ id: products.id, name: products.name, price: products.priceCents }).from(products).where(and(eq(products.organizationId, ctx.organizationId), eq(products.active, true)));
  let rows: { name: string; rev: number; cost: number }[] = [];
  if (!missing) {
    const since = new Date(Date.now() - 90 * DAY);
    const r = await ctx.db.select({
      productId: financeEntries.productId,
      rev: sql<number>`coalesce(sum(case when ${financeEntries.kind}='receivable' then ${financeEntries.amountCents} else 0 end),0)::bigint`,
      cost: sql<number>`coalesce(sum(case when ${financeEntries.kind}='payable' then ${financeEntries.amountCents} else 0 end),0)::bigint`,
    }).from(financeEntries).where(and(eq(financeEntries.organizationId, ctx.organizationId), eq(financeEntries.status, "paid"), isNotNull(financeEntries.productId), gte(financeEntries.paidAt, since)))
      .groupBy(financeEntries.productId);
    rows = r.map((x) => ({ name: prods.find((p) => p.id === x.productId)?.name ?? "Produto removido", rev: Number(x.rev), cost: Number(x.cost) }));
  }
  const m = (c: number) => fmtMoney(c, ctx.locale, ctx.currency);
  const ranked = rows.map((r) => ({ ...r, result: r.rev - r.cost, margin: r.rev ? Math.round(((r.rev - r.cost) / r.rev) * 1000) / 10 : null })).sort((a, b) => b.result - a.result);
  const missingData = [missing, !missing && !ranked.length ? "Nenhum lançamento financeiro está vinculado a produtos (campo Produto nos lançamentos)." : null, "Oportunidades do CRM não têm vínculo com produtos nesta versão."].filter(Boolean) as string[];
  const top = ranked[0];
  return {
    resumoExecutivo: top
      ? prioritize
        ? `Pelo resultado dos últimos 90 dias, "${top.name}" é o candidato a prioridade: ${m(top.result)} de resultado${top.margin != null ? ` e margem de ${top.margin}%` : ""}.`
        : `"${top.name}" é o produto mais rentável nos últimos 90 dias: ${m(top.result)} de resultado${top.margin != null ? ` (margem ${top.margin}%)` : ""}.`
      : `Não é possível calcular a rentabilidade por produto: ${missingData[0]}`,
    diagnostico: ranked.length ? ranked.slice(0, 5).map((r) => f(`${r.name}: receita ${m(r.rev)}, custos ${m(r.cost)}, resultado ${m(r.result)}${r.margin != null ? `, margem ${r.margin}%` : ""}.`)) : [f(`${prods.length} produtos ativos cadastrados, sem dados de receita e custo vinculados.`)],
    dadosUtilizados: [{ fonte: "Financeiro · lançamentos pagos com produto", descricao: "Receitas e custos por produto", periodo: "últimos 90 dias" }, { fonte: "CRM · produtos", descricao: "Catálogo ativo" }],
    evidencias: buildEvidence({
      facts: ranked.length ? ranked.slice(0, 5).map((r) => ({ label: r.name, value: m(r.result), source: "Financeiro · lançamentos por produto", period: "últimos 90 dias" })) : [{ label: "Produtos ativos", value: String(prods.length), source: "CRM · produtos" }],
      calculations: ["Resultado = recebimentos − pagamentos vinculados ao produto.", "Margem = resultado ÷ recebimentos."],
      confidence: ranked.length ? confidenceFrom(ranked.length * 10, missingData.length - 1) : 0,
      missingData,
      limitations: ["Custos indiretos não rateados por produto não entram no cálculo."],
    }),
    causasPossiveis: [],
    impactoFinanceiro: top ? [f(`Resultado do produto líder: ${m(top.result)} em 90 dias.`)] : [],
    alternativas: ranked.length > 1 ? [rec(`Concentrar esforço comercial em "${ranked[0].name}".`), rec(`Rever preço ou custo de "${ranked[ranked.length - 1].name}", o de menor resultado.`)] : [],
    recomendacoes: ranked.length ? [rec(prioritize ? `Priorizar "${top!.name}" nas campanhas e metas do próximo período.` : `Usar "${top!.name}" como referência de margem para os demais produtos.`)] : [rec("Vincular os lançamentos financeiros aos produtos para habilitar esta análise.")],
    planoDeAcao: ranked.length ? [{ passo: "Validar custos diretos de cada produto com o financeiro", prazo: "15 dias" }] : [{ passo: "Cadastrar produtos e vincular lançamentos no Financeiro", prazo: "7 dias" }],
    indicadores: ["Resultado por produto", "Margem por produto"],
  };
}

async function clientCompanies(ctx: TenantContext) {
  return ctx.db.select({ companyId: opportunities.companyId, name: companies.name, won: sql<number>`count(*) filter (where ${opportunities.status}='won')::int`, open: sql<number>`count(*) filter (where ${opportunities.status}='open')::int`, revenue: sql<number>`coalesce(sum(${opportunities.amountCents}) filter (where ${opportunities.status}='won'),0)::bigint`, lastOpp: max(opportunities.lastActivityAt) })
    .from(opportunities).innerJoin(companies, eq(companies.id, opportunities.companyId))
    .where(and(eq(opportunities.organizationId, ctx.organizationId), isNotNull(opportunities.companyId)))
    .groupBy(opportunities.companyId, companies.name)
    .having(sql`count(*) filter (where ${opportunities.status}='won') > 0`);
}

async function customersRisk(ctx: TenantContext): Promise<Draft> {
  const clients = await clientCompanies(ctx);
  const ids = clients.map((c) => c.companyId!).filter(Boolean);
  const m = (c: number) => fmtMoney(c, ctx.locale, ctx.currency);
  const lastAct = ids.length ? await ctx.db.select({ companyId: activities.companyId, last: max(activities.occurredAt) }).from(activities).where(and(eq(activities.organizationId, ctx.organizationId), inArray(activities.companyId, ids))).groupBy(activities.companyId) : [];
  const lost = ids.length ? await ctx.db.select({ companyId: opportunities.companyId, n: count() }).from(opportunities).where(and(eq(opportunities.organizationId, ctx.organizationId), inArray(opportunities.companyId, ids), eq(opportunities.status, "lost"), gte(opportunities.closedAt, new Date(Date.now() - 90 * DAY)))).groupBy(opportunities.companyId) : [];
  const financeOk = can(ctx, "finance:read");
  const overdue = financeOk && ids.length ? await ctx.db.select({ companyId: financeEntries.companyId, v: sql<number>`sum(${financeEntries.amountCents})::bigint` }).from(financeEntries).where(and(eq(financeEntries.organizationId, ctx.organizationId), inArray(financeEntries.companyId, ids), eq(financeEntries.kind, "receivable"), eq(financeEntries.status, "open"), lt(financeEntries.dueDate, new Date()))).groupBy(financeEntries.companyId) : [];
  const now = Date.now();
  const scored = clients.map((c) => {
    const la = lastAct.find((a) => a.companyId === c.companyId)?.last;
    const last = Math.max(la ? new Date(la).getTime() : 0, c.lastOpp ? new Date(c.lastOpp).getTime() : 0);
    const daysSilent = last ? Math.floor((now - last) / DAY) : null;
    const signals: string[] = [];
    if (daysSilent == null || daysSilent > 60) signals.push(daysSilent == null ? "sem atividades registradas" : `${daysSilent} dias sem contato`);
    const l = Number(lost.find((x) => x.companyId === c.companyId)?.n ?? 0);
    if (l) signals.push(`${l} oportunidade(s) perdida(s) em 90 dias`);
    const ov = Number(overdue.find((x) => x.companyId === c.companyId)?.v ?? 0);
    if (ov) signals.push(`${m(ov)} em atraso`);
    return { ...c, revenue: Number(c.revenue), signals };
  }).filter((c) => c.signals.length).sort((a, b) => b.signals.length - a.signals.length || b.revenue - a.revenue);
  const missingData = [
    "Health Score de clientes finais e dados de uso do produto do cliente não estão disponíveis nesta versão.",
    ...(financeOk ? [] : ["Sem permissão financeira: atrasos de pagamento não foram considerados."]),
  ];
  return {
    resumoExecutivo: clients.length ? (scored.length ? `${scored.length} de ${clients.length} clientes têm sinais de risco. O maior é ${scored[0].name} (${scored[0].signals.join(", ")}).` : `Nenhum dos ${clients.length} clientes apresenta os sinais de risco monitorados.`) : "Ainda não há clientes (empresas com negócio ganho) para avaliar.",
    diagnostico: scored.slice(0, 8).map((c) => f(`${c.name}: ${c.signals.join("; ")} · receita histórica ${m(c.revenue)}.`)),
    dadosUtilizados: [{ fonte: "CRM · oportunidades e empresas", descricao: "Clientes = empresas com ao menos um negócio ganho" }, { fonte: "CRM · atividades", descricao: "Último contato" }, ...(financeOk ? [{ fonte: "Financeiro · contas a receber", descricao: "Títulos vencidos por cliente" }] : [])],
    evidencias: buildEvidence({
      facts: [{ label: "Clientes avaliados", value: String(clients.length), source: "CRM · oportunidades ganhas" }, { label: "Clientes com sinais de risco", value: String(scored.length), source: "CRM + Financeiro" }],
      assumptions: ["Mais de 60 dias sem contato é tratado como sinal de risco."],
      calculations: ["Sinais: silêncio > 60 dias, perda recente (90 dias), títulos vencidos."],
      confidence: confidenceFrom(clients.length, missingData.length),
      missingData,
      limitations: ["Sinais heurísticos; não é um modelo preditivo de churn treinado."],
    }),
    causasPossiveis: scored.length ? [inf("Falta de acompanhamento pós-venda é o sinal mais frequente quando há silêncio prolongado.")] : [],
    impactoFinanceiro: scored.length ? [f(`Receita histórica dos clientes em risco: ${m(scored.reduce((a, c) => a + c.revenue, 0))}.`)] : [],
    alternativas: [rec("Contato de sucesso do cliente para os clientes silenciosos."), rec("Negociar títulos vencidos antes de nova venda.")],
    recomendacoes: scored.length ? [rec(`Começar por ${scored.slice(0, 3).map((c) => c.name).join(", ")}.`)] : [rec("Manter cadência de contato trimestral com todos os clientes.")],
    planoDeAcao: scored.length ? [{ passo: "Criar tarefas de contato para os 3 clientes de maior risco", prazo: "3 dias" }] : [],
    indicadores: ["Clientes com sinais de risco", "Dias desde o último contato"],
  };
}

async function lostOpportunities(ctx: TenantContext): Promise<Draft> {
  const since = new Date(Date.now() - 90 * DAY);
  const rows = await ctx.db.select({ reason: opportunities.lostReason, n: count(), v: sql<number>`coalesce(sum(${opportunities.amountCents}),0)::bigint` }).from(opportunities)
    .where(and(eq(opportunities.organizationId, ctx.organizationId), eq(opportunities.status, "lost"), gte(opportunities.closedAt, since))).groupBy(opportunities.lostReason).orderBy(desc(count()));
  const total = rows.reduce((a, r) => a + Number(r.n), 0);
  const m = (c: number) => fmtMoney(c, ctx.locale, ctx.currency);
  const funnel = (await funnelAnalysis(ctx)).filter((s) => s.kind === "open");
  let worst: { from: string; to: string; pass: number } | null = null;
  for (let i = 1; i < funnel.length; i++) if (funnel[i - 1].n >= 10) { const pass = Math.round((funnel[i].n / funnel[i - 1].n) * 100); if (!worst || pass < worst.pass) worst = { from: funnel[i - 1].name, to: funnel[i].name, pass }; }
  return {
    resumoExecutivo: total ? `Nos últimos 90 dias foram perdidas ${total} oportunidades. Principal motivo: "${rows[0].reason ?? "sem motivo"}" (${rows[0].n}).${worst ? ` O funil afunila mais entre "${worst.from}" e "${worst.to}" (${worst.pass}%).` : ""}` : "Nenhuma oportunidade perdida nos últimos 90 dias.",
    diagnostico: rows.slice(0, 6).map((r) => f(`${r.reason ?? "Sem motivo informado"}: ${r.n} oportunidades, ${m(Number(r.v))}.`)),
    dadosUtilizados: [{ fonte: "CRM · oportunidades perdidas", descricao: "Motivos e valores", periodo: "últimos 90 dias" }, { fonte: "CRM · funil", descricao: "Passagem entre etapas" }],
    evidencias: buildEvidence({
      facts: [{ label: "Oportunidades perdidas", value: String(total), source: "CRM · oportunidades", period: "últimos 90 dias" }, ...(worst ? [{ label: `Passagem ${worst.from} → ${worst.to}`, value: `${worst.pass}%`, source: "CRM · funil" }] : [])],
      calculations: ["Agrupamento por motivo de perda informado na mudança de etapa."],
      confidence: confidenceFrom(total),
      missingData: rows.some((r) => !r.reason) ? ["Parte das perdas não tem motivo informado."] : [],
    }),
    causasPossiveis: total ? [inf(`O motivo "${rows[0].reason ?? "sem motivo"}" concentra ${Math.round((Number(rows[0].n) / total) * 100)}% das perdas.`)] : [],
    impactoFinanceiro: total ? [f(`Valor perdido em 90 dias: ${m(rows.reduce((a, r) => a + Number(r.v), 0))}.`)] : [],
    alternativas: [rec("Ajustar a proposta de valor para o principal motivo de perda."), rec("Reforçar a qualificação antes da etapa de proposta.")],
    recomendacoes: total ? [rec(`Criar um playbook de objeção para "${rows[0].reason ?? "sem motivo"}".`)] : [],
    planoDeAcao: total ? [{ passo: "Revisar 10 perdas recentes com o time comercial", prazo: "7 dias" }] : [],
    indicadores: ["Perdas por motivo", "Passagem entre etapas"],
  };
}

async function bestTeam(ctx: TenantContext): Promise<Draft> {
  const s = await sellerPerformance(ctx, 30);
  const m = (c: number) => fmtMoney(c, ctx.locale, ctx.currency);
  const top = s[0];
  return {
    resumoExecutivo: top ? `${top.name} lidera os últimos 30 dias com ${m(top.revenue)} em ${top.won} vendas${top.winRate != null ? ` (conversão ${top.winRate}%)` : ""}.` : "Não há vendas atribuídas a vendedores nos últimos 30 dias.",
    diagnostico: s.slice(0, 8).map((x) => f(`${x.name}: ${m(x.revenue)}, ${x.won} ganhas, ${x.lost} perdidas, ${x.open} abertas, conversão ${x.winRate ?? "—"}%.`)),
    dadosUtilizados: [{ fonte: "CRM · oportunidades por responsável", descricao: "Receita, vendas e conversão", periodo: "últimos 30 dias" }],
    evidencias: buildEvidence({
      facts: s.slice(0, 5).map((x) => ({ label: x.name, value: m(x.revenue), source: "CRM · oportunidades ganhas", period: "últimos 30 dias" })),
      calculations: ["Conversão por vendedor = ganhas ÷ (ganhas + perdidas)."],
      confidence: confidenceFrom(s.reduce((a, x) => a + x.won + x.lost, 0)),
      missingData: ["Times (equipes) ainda não são usados na atribuição de oportunidades: a análise é por vendedor."],
      limitations: ["Não considera carteira recebida nem território de cada vendedor."],
    }),
    causasPossiveis: [],
    impactoFinanceiro: top ? [f(`Receita do líder: ${m(top.revenue)}.`)] : [],
    alternativas: [rec("Replicar as práticas do líder em sessões de coaching."), rec("Redistribuir oportunidades de quem tem muitos negócios abertos.")],
    recomendacoes: top ? [rec(`Documentar o processo de ${top.name} como playbook do time.`)] : [],
    planoDeAcao: top ? [{ passo: "Sessão de troca de práticas com o time", prazo: "14 dias" }] : [],
    indicadores: ["Receita por vendedor", "Conversão por vendedor"],
  };
}

async function expensesGrowth(ctx: TenantContext): Promise<Draft> {
  const snap = can(ctx, "finance:read") ? await financialSnapshot(ctx, 30) : null;
  const missing = noFinance(ctx, snap);
  if (missing) return missingDraft(missing, "Despesas por categoria");
  const m = (c: number) => fmtMoney(c, ctx.locale, ctx.currency);
  const now = Date.now(), s = new Date(now - 30 * DAY), ps = new Date(now - 60 * DAY);
  const rows = await ctx.db.select({
    name: sql<string>`coalesce(${financeCategories.name}, 'Sem categoria')`,
    cur: sql<number>`coalesce(sum(${financeEntries.amountCents}) filter (where ${financeEntries.paidAt} >= ${s}),0)::bigint`,
    prev: sql<number>`coalesce(sum(${financeEntries.amountCents}) filter (where ${financeEntries.paidAt} >= ${ps} and ${financeEntries.paidAt} < ${s}),0)::bigint`,
  }).from(financeEntries).leftJoin(financeCategories, eq(financeCategories.id, financeEntries.categoryId))
    .where(and(eq(financeEntries.organizationId, ctx.organizationId), eq(financeEntries.kind, "payable"), eq(financeEntries.status, "paid"), gte(financeEntries.paidAt, ps)))
    .groupBy(sql`1`);
  const growth = rows.map((r) => ({ name: r.name, cur: Number(r.cur), prev: Number(r.prev), diff: Number(r.cur) - Number(r.prev) })).sort((a, b) => b.diff - a.diff);
  const up = growth.filter((g) => g.diff > 0);
  return {
    resumoExecutivo: up.length ? `As despesas pagas somaram ${m(snap!.expensesCents)} em 30 dias. A categoria que mais cresceu foi "${up[0].name}" (+${m(up[0].diff)}).` : `Nenhuma categoria de despesa cresceu em relação aos 30 dias anteriores (total ${m(snap!.expensesCents)}).`,
    diagnostico: growth.slice(0, 8).map((g) => f(`${g.name}: ${m(g.cur)} (antes ${m(g.prev)}, ${g.diff >= 0 ? "+" : ""}${m(g.diff)}).`)),
    dadosUtilizados: [{ fonte: "Financeiro · contas a pagar pagas", descricao: "Despesas por categoria", periodo: "últimos 30 dias vs. 30 anteriores" }],
    evidencias: buildEvidence({
      facts: [{ label: "Despesas (atual)", value: m(snap!.expensesCents), source: "Financeiro · contas a pagar", period: "últimos 30 dias" }, { label: "Despesas (anterior)", value: m(snap!.previous.expensesCents), source: "Financeiro · contas a pagar", period: "30 dias anteriores" }],
      calculations: ["Diferença por categoria = pago no período atual − pago no período anterior (regime de caixa)."],
      confidence: confidenceFrom(snap!.entriesInPeriod, 0, 20),
      limitations: ["Pagamentos anuais ou antecipados distorcem a comparação mensal."],
    }),
    causasPossiveis: up.length ? [inf(`O aumento está concentrado em "${up[0].name}".`)] : [],
    impactoFinanceiro: [f(`Variação total: ${m(snap!.expensesCents - snap!.previous.expensesCents)}.`)],
    alternativas: up.length ? [rec(`Renegociar contratos de "${up[0].name}".`), rec("Definir orçamento mensal por categoria.")] : [],
    recomendacoes: up.length ? [rec(`Revisar os lançamentos de "${up[0].name}" do período.`)] : [rec("Manter o orçamento atual.")],
    planoDeAcao: up.length ? [{ passo: `Auditar os pagamentos de "${up[0].name}"`, prazo: "7 dias" }] : [],
    indicadores: ["Despesas por categoria", "Despesas pagas (30 dias)"],
  };
}

function parseHiring(q: string) {
  const n = Number(norm(q).match(/(\d+)\s*(funcionari|pessoa|vendedor|colaborador|contrata)/)?.[1] ?? 1);
  const salary = q.match(/R\$\s*([\d.]+(?:,\d{1,2})?)/i)?.[1];
  const salaryCents = salary ? Math.round(Number(salary.replace(/\./g, "").replace(",", ".")) * 100) : null;
  return { n: Math.max(1, Math.min(100, n)), salaryCents };
}

/** Premissa ajustável: custo total ≈ salário × 1,7 (encargos e benefícios típicos CLT). É estimativa, não cálculo trabalhista. */
export const PAYROLL_MULTIPLIER = 1.7;

async function hiring(ctx: TenantContext, question: string): Promise<Draft> {
  const snap = can(ctx, "finance:read") ? await financialSnapshot(ctx, 90) : null;
  const missing = noFinance(ctx, snap);
  if (missing) return missingDraft(missing, "Capacidade de contratação");
  const m = (c: number) => fmtMoney(c, ctx.locale, ctx.currency);
  const { n, salaryCents } = parseHiring(question);
  const monthlyResult = Math.round(snap!.resultCents / 3);
  const monthlyCost = salaryCents ? Math.round(salaryCents * PAYROLL_MULTIPLIER * n) : null;
  const after = monthlyCost != null ? monthlyResult - monthlyCost : null;
  const ok = after != null && after > 0 && snap!.next30.netCents - (monthlyCost ?? 0) >= 0;
  return {
    resumoExecutivo: monthlyCost == null
      ? `O resultado de caixa médio é ${m(monthlyResult)}/mês (últimos 90 dias). Informe o salário (ex.: "posso contratar 3 funcionários de R$ 4.000?") para eu calcular o impacto.`
      : ok ? `Pelos números atuais, sim: ${n} contratação(ões) custariam cerca de ${m(monthlyCost)}/mês e o resultado médio cairia de ${m(monthlyResult)} para ${m(after!)}/mês.`
        : `Com cautela: ${n} contratação(ões) custariam cerca de ${m(monthlyCost)}/mês, levando o resultado médio a ${m(after!)}/mês${snap!.next30.netCents - monthlyCost < 0 ? " e o caixa projetado dos próximos 30 dias ficaria negativo" : ""}.`,
    diagnostico: [f(`Resultado de caixa em 90 dias: ${m(snap!.resultCents)} (média ${m(monthlyResult)}/mês).`), f(`Saldo projetado nos próximos 30 dias: ${m(snap!.next30.netCents)}.`)],
    dadosUtilizados: [{ fonte: "Financeiro · recebimentos e pagamentos", descricao: "Resultado de caixa", periodo: "últimos 90 dias" }, { fonte: "Financeiro · títulos em aberto", descricao: "Projeção de 30 dias" }],
    evidencias: buildEvidence({
      facts: [{ label: "Resultado médio mensal", value: m(monthlyResult), source: "Financeiro", period: "últimos 90 dias" }, ...(monthlyCost != null ? [{ label: "Custo mensal estimado", value: m(monthlyCost), source: "Pergunta do usuário + premissa de encargos" }] : [])],
      assumptions: [`Custo total por pessoa ≈ salário × ${PAYROLL_MULTIPLIER} (encargos e benefícios; ajuste conforme sua realidade).`, "Resultado dos últimos 90 dias se repete nos próximos meses."],
      calculations: ["Resultado médio = (recebimentos − pagamentos em 90 dias) ÷ 3.", ...(monthlyCost != null ? [`Custo = ${n} × salário × ${PAYROLL_MULTIPLIER}.`] : [])],
      confidence: confidenceFrom(snap!.entriesInPeriod, salaryCents ? 0 : 1, 20) * 0.8,
      missingData: salaryCents ? ["Saldo bancário atual"] : ["Salário das contratações", "Saldo bancário atual"],
      limitations: ["Não substitui análise contábil/trabalhista nem considera ganho de receita gerado pelas novas pessoas."],
    }),
    causasPossiveis: [],
    impactoFinanceiro: monthlyCost != null ? [est(`Impacto estimado: −${m(monthlyCost)}/mês no resultado.`)] : [],
    alternativas: [rec("Contratar em etapas (uma pessoa por vez) e medir o retorno."), rec("Avaliar terceirização ou agentes de IA para tarefas repetitivas antes de contratar.")],
    recomendacoes: monthlyCost == null ? [rec("Informe o salário previsto para obter a recomendação.")] : ok ? [rec("Contratar, mantendo reserva para 3 meses de custo das novas vagas.")] : [rec("Aguardar melhora do caixa ou contratar menos pessoas agora.")],
    planoDeAcao: [{ passo: "Simular o cenário no Simulador Estratégico (tipo: contratação)", prazo: "hoje" }],
    indicadores: ["Resultado de caixa mensal", "Saldo projetado 30 dias"],
  };
}

async function expansion(ctx: TenantContext): Promise<Draft> {
  const clients = await clientCompanies(ctx);
  const ids = clients.map((c) => c.companyId!).filter(Boolean);
  const recentConv = ids.length ? await ctx.db.select({ companyId: contacts.companyId, n: count() }).from(conversations).innerJoin(contacts, eq(contacts.id, conversations.contactId))
    .where(and(eq(conversations.organizationId, ctx.organizationId), inArray(contacts.companyId, ids), gte(conversations.lastMessageAt, new Date(Date.now() - 30 * DAY)))).groupBy(contacts.companyId) : [];
  const m = (c: number) => fmtMoney(c, ctx.locale, ctx.currency);
  const list = clients.map((c) => {
    const signals: string[] = [];
    if (c.won >= 2) signals.push(`${c.won} compras anteriores`);
    if (c.open > 0) signals.push(`${c.open} oportunidade(s) aberta(s)`);
    const conv = Number(recentConv.find((x) => x.companyId === c.companyId)?.n ?? 0);
    if (conv) signals.push(`${conv} conversa(s) nos últimos 30 dias`);
    return { name: c.name, revenue: Number(c.revenue), signals };
  }).filter((c) => c.signals.length).sort((a, b) => b.signals.length - a.signals.length || b.revenue - a.revenue);
  return {
    resumoExecutivo: list.length ? `${list.length} clientes mostram sinais de expansão. Destaque: ${list[0].name} (${list[0].signals.join(", ")}).` : clients.length ? "Nenhum cliente mostra sinais de expansão monitorados no momento." : "Ainda não há clientes (empresas com negócio ganho) para avaliar.",
    diagnostico: list.slice(0, 8).map((c) => f(`${c.name}: ${c.signals.join("; ")} · receita histórica ${m(c.revenue)}.`)),
    dadosUtilizados: [{ fonte: "CRM · oportunidades", descricao: "Compras anteriores e oportunidades abertas" }, { fonte: "Closer.AI · conversas", descricao: "Engajamento recente", periodo: "últimos 30 dias" }],
    evidencias: buildEvidence({
      facts: [{ label: "Clientes avaliados", value: String(clients.length), source: "CRM · oportunidades ganhas" }, { label: "Com sinais de expansão", value: String(list.length), source: "CRM + Closer.AI" }],
      calculations: ["Sinais: ≥ 2 compras, oportunidade aberta, conversa nos últimos 30 dias."],
      confidence: confidenceFrom(clients.length, 1),
      missingData: ["Uso do produto pelo cliente e vínculo de produtos às oportunidades (necessários para cross-sell por produto)."],
      limitations: ["Sinais de engajamento, não modelo preditivo de propensão."],
    }),
    causasPossiveis: [],
    impactoFinanceiro: list.length ? [f(`Receita histórica dos clientes com sinais: ${m(list.reduce((a, c) => a + c.revenue, 0))}.`)] : [],
    alternativas: [rec("Oferta complementar para clientes recorrentes."), rec("Revisão de conta (QBR) com os clientes engajados.")],
    recomendacoes: list.length ? [rec(`Abrir oportunidades de expansão para ${list.slice(0, 3).map((c) => c.name).join(", ")}.`)] : [],
    planoDeAcao: list.length ? [{ passo: "Preparar proposta complementar para os 3 principais", prazo: "14 dias" }] : [],
    indicadores: ["Receita de expansão", "Clientes com mais de uma compra"],
  };
}

async function cashflow(ctx: TenantContext): Promise<Draft> {
  const snap = can(ctx, "finance:read") ? await financialSnapshot(ctx, 30) : null;
  const missing = noFinance(ctx, snap);
  if (missing) return missingDraft(missing, "Fluxo de caixa");
  const s = snap!;
  const m = (c: number) => fmtMoney(c, ctx.locale, ctx.currency);
  const fc = await revenueForecast(ctx);
  const options: Item[] = [];
  if (s.overdueReceivableCents) options.push(rec(`Cobrar os ${s.overdueReceivableCount} títulos vencidos (${m(s.overdueReceivableCents)}): é o efeito mais rápido no caixa.`));
  if (s.next30.netCents < 0) options.push(rec(`Renegociar vencimentos de fornecedores: faltam ${m(-s.next30.netCents)} nos próximos 30 dias.`));
  options.push(rec("Oferecer desconto para pagamento antecipado de recebíveis de maior valor."));
  if (fc.scenarios.base) options.push(rec(`Acelerar o fechamento do pipeline ponderado (${m(fc.scenarios.base)}) com condições de pagamento à vista.`));
  return {
    resumoExecutivo: `Saldo projetado para 30 dias: ${m(s.next30.netCents)}. ${s.overdueReceivableCents ? `A decisão de maior efeito imediato é cobrar ${m(s.overdueReceivableCents)} já vencidos.` : "Não há recebíveis vencidos; o foco é manter prazos de pagamento alinhados às entradas."}`,
    diagnostico: [f(`Entradas previstas: ${m(s.next30.inflowCents)}. Saídas previstas: ${m(s.next30.outflowCents)}.`), f(`Recebíveis vencidos: ${m(s.overdueReceivableCents)}. Pagáveis vencidos: ${m(s.overduePayableCents)}.`)],
    dadosUtilizados: [{ fonte: "Financeiro · títulos em aberto", descricao: "Entradas e saídas previstas", periodo: "próximos 30 dias" }, { fonte: "CRM · pipeline ponderado", descricao: "Receita potencial" }],
    evidencias: buildEvidence({
      facts: [{ label: "Saldo projetado 30 dias", value: m(s.next30.netCents), source: "Financeiro · títulos em aberto" }, { label: "Recebíveis vencidos", value: m(s.overdueReceivableCents), source: "Financeiro · contas a receber" }],
      assumptions: ["Títulos pagos/recebidos no vencimento."],
      calculations: ["Saldo projetado = entradas − saídas com vencimento em 30 dias."],
      confidence: 0.6,
      missingData: ["Saldo bancário atual (sem integração bancária)"],
      limitations: ["Projeção gerencial; não substitui conciliação bancária."],
    }),
    causasPossiveis: s.next30.netCents < 0 ? [inf("Saídas concentradas antes das entradas previstas.")] : [],
    impactoFinanceiro: s.overdueReceivableCents ? [est(`Cobrar 50% dos vencidos melhoraria o caixa em cerca de ${m(Math.round(s.overdueReceivableCents / 2))}.`)] : [],
    alternativas: options.slice(1),
    recomendacoes: options.slice(0, 1),
    planoDeAcao: [{ passo: "Disparar cobrança dos títulos vencidos", prazo: "2 dias" }, { passo: "Revisar calendário de pagamentos da quinzena", prazo: "5 dias" }],
    indicadores: ["Saldo projetado 30 dias", "Recebíveis vencidos"],
  };
}

function missingDraft(reason: string, topic: string): Draft {
  return {
    resumoExecutivo: `Não consigo responder com segurança: ${reason}`,
    diagnostico: [f(reason)],
    dadosUtilizados: [],
    evidencias: buildEvidence({ facts: [], confidence: 0, missingData: [reason], limitations: [`${topic} depende de dados financeiros registrados.`] }),
    causasPossiveis: [], impactoFinanceiro: [], alternativas: [],
    recomendacoes: [rec("Registre receitas e despesas no módulo Financeiro (ou conecte um meio de pagamento) para habilitar esta análise.")],
    planoDeAcao: [{ passo: "Lançar contas a pagar e a receber do mês no Financeiro", prazo: "7 dias" }],
    indicadores: [],
  };
}

/**
 * Análises determinísticas reutilizadas como FERRAMENTAS pelo Flávio (src/server/ai/flavio/tools.ts).
 * Única implementação: o Business Brain e o Flávio usam as mesmas funções.
 */
export const BRAIN_ANALYSES = {
  revenueDrop, productProfitability, customersRisk, lostOpportunities, bestTeam, expensesGrowth, hiring, expansion, cashflow,
};

/* ------------------------------------------------------------------ entrada */

function hasRealProvider() {
  return providerChain().some((p) => p.name !== "local-heuristic");
}

export async function askBrain(ctx: TenantContext, rawQuestion: string, opts: { narrate?: boolean } = {}): Promise<BrainAnswer> {
  requirePerm(ctx, "intelligence:read");
  const question = String(rawQuestion ?? "").trim().slice(0, 500);
  const intent = question.length >= 3 ? detectIntent(question) : null;
  let draft: Draft;
  switch (intent) {
    case "revenue_drop": draft = await revenueDrop(ctx); break;
    case "product_profitability": draft = await productProfitability(ctx); break;
    case "product_priority": draft = await productProfitability(ctx, true); break;
    case "customers_risk": draft = await customersRisk(ctx); break;
    case "lost_opportunities": draft = await lostOpportunities(ctx); break;
    case "best_team": draft = await bestTeam(ctx); break;
    case "expenses": draft = await expensesGrowth(ctx); break;
    case "hiring": draft = await hiring(ctx, question); break;
    case "expansion": draft = await expansion(ctx); break;
    case "cashflow": draft = await cashflow(ctx); break;
    default: {
      const answer: BrainAnswer = {
        question, intent: null, supported: false, narration: "deterministic",
        resumoExecutivo: "Ainda não sei responder essa pergunta com dados verificáveis. Tente uma das perguntas suportadas.",
        diagnostico: [], dadosUtilizados: [],
        evidencias: buildEvidence({ facts: [], confidence: 0, limitations: ["Pergunta fora do catálogo de análises do Business Brain."] }),
        causasPossiveis: [], impactoFinanceiro: [], alternativas: [],
        recomendacoes: SUPPORTED_QUESTIONS.map((q) => rec(q)), planoDeAcao: [], indicadores: [],
      };
      return answer;
    }
  }

  let narration: "ai" | "deterministic" = "deterministic";
  if (opts.narrate !== false && hasRealProvider() && draft.evidencias.facts.length) {
    try {
      const out = await runAgent(ctx, {
        agentKey: "executive",
        input: `Reescreva em até 3 frases, em português e sem acrescentar números ou fatos novos, o resumo executivo para a pergunta: "${question}".`,
        context: JSON.stringify({ resumo: draft.resumoExecutivo, diagnostico: draft.diagnostico.map((d) => d.text), recomendacoes: draft.recomendacoes.map((r) => r.text) }),
      });
      if (out.status !== "blocked" && out.status !== "error" && !out.simulated && out.text.trim()) { draft.resumoExecutivo = out.text.trim(); narration = "ai"; }
    } catch { /* volta para o texto determinístico */ }
  }

  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "brain.asked", resource: "business_brain", metadata: { intent, narration } });
  return { question, intent, supported: true, narration, ...draft };
}
