/** Widgets do Command Center que o usuário pode ocultar/exibir (preferência por usuário). */
import { eq } from "drizzle-orm";
import { userPreferences } from "../db/schema";
import type { TenantContext } from "../tenancy/context";

export const COMMAND_CENTER_WIDGETS = [
  { key: "briefing", label: "Resumo executivo" },
  { key: "kpis", label: "Indicadores" },
  { key: "questions", label: "As 6 perguntas" },
  { key: "insights", label: "Insights e recomendações" },
  { key: "decisions", label: "Decisões" },
  { key: "brain", label: "Business Brain" },
  { key: "rules", label: "Precisão das regras" },
] as const;
export type WidgetKey = (typeof COMMAND_CENTER_WIDGETS)[number]["key"];

export async function hiddenWidgets(ctx: TenantContext): Promise<string[]> {
  const [p] = await ctx.db.select({ ai: userPreferences.aiPersonalization }).from(userPreferences).where(eq(userPreferences.userId, ctx.userId));
  const cc = (p?.ai as { commandCenter?: { hidden?: unknown } } | undefined)?.commandCenter;
  return Array.isArray(cc?.hidden) ? (cc!.hidden as unknown[]).filter((x): x is string => typeof x === "string") : [];
}
