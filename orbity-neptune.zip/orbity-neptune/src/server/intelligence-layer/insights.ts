/**
 * ORBITY INTELLIGENCE LAYER — Insight Engine + Outcome Engine.
 *
 * - Insights são gerados por REGRAS DETERMINÍSTICAS sobre dados reais (CRM, Closer, Prospect, Financeiro, IA).
 *   Nenhum número é inventado: sem dados suficientes, a regra simplesmente não dispara.
 * - Cada insight traz evidência (fonte, período, premissas, cálculos, confiança, dados ausentes, limitações).
 * - `scanInsights` faz upsert por `dedupeKey`: nunca duplica um insight aberto/aceito e expira os que deixaram de valer.
 * - Outcome Engine: decisão humana (aceitar/rejeitar/alterar/cancelar), execução e medição do resultado,
 *   recalculando o MESMO indicador da regra e comparando com a linha de base.
 * - Ciclo de aprendizado (feedback): se uma regra tem ≥ 5 decisões e ≥ 70% de rejeição, seus novos insights
 *   entram com prioridade um nível abaixo (e a evidência registra o motivo). Ver `ruleStats`.
 */
import { and, count, desc, eq, gte, inArray, isNull, lt, sql } from "drizzle-orm";
import { z } from "zod";
import { aiExecutions, conversations, goals, insights, leads, notifications, opportunities } from "../db/schema";
import type { Evidence } from "../db/schema";
import { requirePerm, can, type TenantContext } from "../tenancy/context";
import { audit } from "../audit";
import { publish, EVENT_TYPES } from "../events";
import { HttpError } from "../http";
import { dashboardKpis, funnelAnalysis, mainGoalProgress, periodFromDays } from "../domains/intelligence";
import { slaBreaches } from "../domains/closer";
import { financialSnapshot, type FinancialSnapshot } from "../domains/finance/snapshot";
import { buildEvidence, confidenceFrom, fmtMoney } from "./evidence";
import { deliverDigests, recipientsFor } from "../ai/flavio/alerts";

export type InsightRow = typeof insights.$inferSelect;
type Priority = "high" | "medium" | "low";
type Indicator = NonNullable<InsightRow["indicator"]>;

export type InsightCandidate = {
  ruleKey: string;
  dedupeKey: string;
  domain: string;
  nature: "fact" | "inference" | "estimate" | "recommendation";
  title: string;
  summary: string;
  priority: Priority;
  evidence: Evidence;
  recommendedAction: string;
  indicator: Indicator;
  link: string;
};

/** Medida atual do indicador de uma regra (usada para disparar e para medir resultado). */
type Measure = { value: number | null; sampleSize: number };

type RuleEnv = { ctx: TenantContext; finance: FinancialSnapshot | null };

type Rule = {
  key: string;
  label: string;
  domain: string;
  needsFinance?: boolean;
  evaluate: (env: RuleEnv) => Promise<InsightCandidate[]>;
  /** Recalcula o indicador para o Outcome Engine. `dedupeKey` permite regras parametrizadas (ex.: etapa do funil). */
  measure: (env: RuleEnv, dedupeKey: string) => Promise<Measure>;
};

const DAY = 864e5;
const brl = (ctx: TenantContext, cents: number) => fmtMoney(cents, ctx.locale, ctx.currency);
const periodLabel = (days: number) => `últimos ${days} dias`;

/* ------------------------------------------------------------------ medidas reutilizáveis */

async function staleOpportunities(ctx: TenantContext) {
  const [r] = await ctx.db.select({ n: count(), v: sql<number>`coalesce(sum(${opportunities.amountCents}),0)::bigint` }).from(opportunities)
    .where(and(eq(opportunities.organizationId, ctx.organizationId), eq(opportunities.status, "open"), lt(opportunities.lastActivityAt, new Date(Date.now() - 5 * DAY))));
  const [all] = await ctx.db.select({ n: count() }).from(opportunities).where(and(eq(opportunities.organizationId, ctx.organizationId), eq(opportunities.status, "open")));
  return { n: Number(r.n), valueCents: Number(r.v), open: Number(all.n) };
}

async function unscoredLeads(ctx: TenantContext) {
  const [r] = await ctx.db.select({ n: count() }).from(leads).where(and(eq(leads.organizationId, ctx.organizationId), isNull(leads.score), sql`${leads.status} not in ('converted','disqualified')`));
  const [all] = await ctx.db.select({ n: count() }).from(leads).where(eq(leads.organizationId, ctx.organizationId));
  return { n: Number(r.n), total: Number(all.n) };
}

async function engagementBacklog(ctx: TenantContext) {
  const breaches = await slaBreaches(ctx.db, ctx.organizationId);
  const [h] = await ctx.db.select({ n: count() }).from(conversations).where(and(eq(conversations.organizationId, ctx.organizationId), eq(conversations.status, "handoff")));
  const [open] = await ctx.db.select({ n: count() }).from(conversations).where(and(eq(conversations.organizationId, ctx.organizationId), sql`${conversations.status} <> 'closed'`));
  return { breaches: breaches.length, handoff: Number(h.n), open: Number(open.n) };
}

async function closedSample(ctx: TenantContext, days: number) {
  const p = periodFromDays(days);
  const q = async (a: Date, b: Date) => {
    const [r] = await ctx.db.select({ n: count() }).from(opportunities).where(and(eq(opportunities.organizationId, ctx.organizationId), sql`${opportunities.status} in ('won','lost')`, gte(opportunities.closedAt, a), lt(opportunities.closedAt, b)));
    return Number(r.n);
  };
  return { current: await q(p.start, p.end), previous: await q(p.prevStart, p.prevEnd) };
}

async function aiQuality(ctx: TenantContext) {
  const since = new Date(Date.now() - 7 * DAY);
  const rows = await ctx.db.select({ status: aiExecutions.status, n: count() }).from(aiExecutions)
    .where(and(eq(aiExecutions.organizationId, ctx.organizationId), gte(aiExecutions.createdAt, since))).groupBy(aiExecutions.status);
  const total = rows.reduce((a, r) => a + Number(r.n), 0);
  const failed = rows.filter((r) => r.status === "error").reduce((a, r) => a + Number(r.n), 0);
  const blocked = rows.filter((r) => r.status === "blocked").reduce((a, r) => a + Number(r.n), 0);
  return { total, failed, blocked, ratePct: total ? Math.round(((failed + blocked) / total) * 1000) / 10 : 0 };
}

function goalPace(goal: { achieved: number; target: number; pct: number }, start: Date, end: Date, now = new Date()) {
  const elapsed = Math.max(0, Math.min(1, (now.getTime() - start.getTime()) / Math.max(1, end.getTime() - start.getTime())));
  return { elapsedPct: Math.round(elapsed * 100), expectedCents: Math.round(goal.target * elapsed) };
}

/* ------------------------------------------------------------------ regras */

const RULES: Rule[] = [
  {
    key: "funnel_bottleneck", label: "Gargalo no funil", domain: "sales",
    async evaluate({ ctx }) {
      const open = (await funnelAnalysis(ctx)).filter((f) => f.kind === "open");
      const out: InsightCandidate[] = [];
      for (let i = 1; i < open.length; i++) {
        const prev = open[i - 1], cur = open[i];
        if (prev.n < 10) continue;
        const pass = Math.round((cur.n / prev.n) * 1000) / 10;
        if (pass >= 35) continue;
        out.push({
          ruleKey: "funnel_bottleneck", dedupeKey: `funnel_bottleneck:${prev.id}:${cur.id}`, domain: "sales", nature: "inference",
          title: `Gargalo entre "${prev.name}" e "${cur.name}"`,
          summary: `Só ${pass}% do volume de "${prev.name}" aparece em "${cur.name}". ${brl(ctx, prev.total)} estão concentrados em "${prev.name}".`,
          priority: "high",
          evidence: buildEvidence({
            facts: [
              { label: `Oportunidades em ${prev.name}`, value: String(prev.n), source: "CRM · funil (posição atual)" },
              { label: `Oportunidades em ${cur.name}`, value: String(cur.n), source: "CRM · funil (posição atual)" },
              { label: `Valor em ${prev.name}`, value: brl(ctx, prev.total), source: "CRM · oportunidades" },
            ],
            calculations: [`Passagem = ${cur.n} ÷ ${prev.n} = ${pass}%`, "Regra dispara quando a passagem entre etapas consecutivas é < 35% e a etapa anterior tem ≥ 10 oportunidades."],
            assumptions: ["A posição atual das etapas representa o fluxo recente (não é uma coorte)."],
            confidence: confidenceFrom(prev.n + cur.n),
            limitations: ["Compara posições atuais, não conversões históricas por coorte."],
          }),
          recommendedAction: `Revisar critérios de avanço de "${prev.name}" e criar cadência de follow-up para as oportunidades paradas nessa etapa.`,
          indicator: { metric: `Passagem ${prev.name} → ${cur.name}`, baseline: pass, unit: "%", direction: "up" },
          link: "/crm",
        });
      }
      return out;
    },
    async measure({ ctx }, dedupeKey) {
      const [, prevId, curId] = dedupeKey.split(":");
      const f = await funnelAnalysis(ctx);
      const prev = f.find((s) => s.id === prevId), cur = f.find((s) => s.id === curId);
      if (!prev || !cur || !prev.n) return { value: null, sampleSize: 0 };
      return { value: Math.round((cur.n / prev.n) * 1000) / 10, sampleSize: prev.n + cur.n };
    },
  },
  {
    key: "stale_opportunities", label: "Oportunidades paradas", domain: "sales",
    async evaluate({ ctx }) {
      const s = await staleOpportunities(ctx);
      if (!s.n) return [];
      return [{
        ruleKey: "stale_opportunities", dedupeKey: "stale_opportunities", domain: "sales", nature: "fact",
        title: `${s.n} oportunidades sem atividade há mais de 5 dias`,
        summary: `${brl(ctx, s.valueCents)} em negócios abertos sem nenhuma atividade registrada há 5+ dias.`,
        priority: s.n >= 5 || s.valueCents >= 10_000_000 ? "high" : "medium",
        evidence: buildEvidence({
          facts: [
            { label: "Oportunidades paradas", value: String(s.n), source: "CRM · oportunidades", period: "última atividade > 5 dias" },
            { label: "Valor parado", value: brl(ctx, s.valueCents), source: "CRM · oportunidades" },
            { label: "Oportunidades abertas", value: String(s.open), source: "CRM · oportunidades" },
          ],
          calculations: ["Filtro: status = aberta e última atividade anterior a hoje − 5 dias."],
          confidence: 0.95,
          limitations: ["Depende do registro de atividades no CRM; contatos feitos fora do sistema não aparecem."],
        }),
        recommendedAction: "Distribuir tarefas de follow-up e ativar a automação de recuperação de oportunidades paradas.",
        indicator: { metric: "Oportunidades paradas > 5 dias", baseline: s.n, unit: "oportunidades", direction: "down" },
        link: "/crm?filtro=paradas",
      }];
    },
    async measure({ ctx }) { const s = await staleOpportunities(ctx); return { value: s.n, sampleSize: s.open }; },
  },
  {
    key: "unscored_leads", label: "Leads sem pontuação", domain: "prospect",
    async evaluate({ ctx }) {
      const u = await unscoredLeads(ctx);
      if (!u.n) return [];
      return [{
        ruleKey: "unscored_leads", dedupeKey: "unscored_leads", domain: "prospect", nature: "fact",
        title: `${u.n} leads ativos sem pontuação`,
        summary: "Sem score, esses leads não entram na priorização do Prospect.AI.",
        priority: u.total && u.n / u.total > 0.3 ? "medium" : "low",
        evidence: buildEvidence({
          facts: [
            { label: "Leads sem score", value: String(u.n), source: "Prospect.AI · leads" },
            { label: "Leads na base", value: String(u.total), source: "Prospect.AI · leads" },
          ],
          calculations: ["Leads com score nulo e status diferente de convertido/desqualificado."],
          confidence: 0.95,
        }),
        recommendedAction: "Revisar o ICP ativo e usar \"Recalcular scores\" no Prospect.AI.",
        indicator: { metric: "Leads sem score", baseline: u.n, unit: "leads", direction: "down" },
        link: "/prospect",
      }];
    },
    async measure({ ctx }) { const u = await unscoredLeads(ctx); return { value: u.n, sampleSize: u.total }; },
  },
  {
    key: "engagement_backlog", label: "Atendimento atrasado", domain: "engagement",
    async evaluate({ ctx }) {
      const e = await engagementBacklog(ctx);
      const n = e.breaches + e.handoff;
      if (!n) return [];
      return [{
        ruleKey: "engagement_backlog", dedupeKey: "engagement_backlog", domain: "engagement", nature: "fact",
        title: `${e.breaches} conversas fora do SLA · ${e.handoff} aguardando humano`,
        summary: "Clientes esperando resposta além do prazo combinado aumentam o risco de perda.",
        priority: "high",
        evidence: buildEvidence({
          facts: [
            { label: "Conversas com SLA vencido", value: String(e.breaches), source: "Closer.AI · conversas" },
            { label: "Conversas aguardando humano", value: String(e.handoff), source: "Closer.AI · conversas" },
            { label: "Conversas abertas", value: String(e.open), source: "Closer.AI · conversas" },
          ],
          calculations: ["SLA vencido: prazo de SLA anterior a agora e conversa não encerrada."],
          confidence: 0.95,
        }),
        recommendedAction: "Atribuir responsáveis às conversas no Closer.AI e revisar a escala de atendimento.",
        indicator: { metric: "Conversas fora do SLA + aguardando humano", baseline: n, unit: "conversas", direction: "down" },
        link: "/closer?filtro=sla",
      }];
    },
    async measure({ ctx }) { const e = await engagementBacklog(ctx); return { value: e.breaches + e.handoff, sampleSize: e.open }; },
  },
  {
    key: "conversion_drop", label: "Queda de conversão", domain: "sales",
    async evaluate({ ctx }) {
      const k = await dashboardKpis(ctx, 30);
      const s = await closedSample(ctx, 30);
      const d = k.delta.conversionPp;
      if (d == null || d > -3 || s.current < 10 || s.previous < 10) return [];
      return [{
        ruleKey: "conversion_drop", dedupeKey: "conversion_drop", domain: "sales", nature: "fact",
        title: `Conversão caiu ${Math.abs(d)} p.p. em 30 dias`,
        summary: `Taxa de conversão (ganhas ÷ fechadas) passou de ${k.previous.conversionRate}% para ${k.current.conversionRate}%.`,
        priority: d <= -8 ? "high" : "medium",
        evidence: buildEvidence({
          facts: [
            { label: "Conversão atual", value: `${k.current.conversionRate}%`, source: "CRM · oportunidades fechadas", period: periodLabel(30) },
            { label: "Conversão anterior", value: `${k.previous.conversionRate}%`, source: "CRM · oportunidades fechadas", period: "30 dias anteriores" },
            { label: "Negócios fechados (atual / anterior)", value: `${s.current} / ${s.previous}`, source: "CRM · oportunidades" },
          ],
          calculations: ["Conversão = ganhas ÷ (ganhas + perdidas) fechadas no período (definição canônica win_rate)."],
          confidence: confidenceFrom(Math.min(s.current, s.previous)),
          limitations: ["Variação pode refletir mix de negócios diferente entre os períodos."],
        }),
        recommendedAction: "Analisar os motivos de perda recentes e revisar a qualificação antes da proposta.",
        indicator: { metric: "Taxa de conversão (30 dias)", baseline: k.current.conversionRate ?? 0, unit: "%", direction: "up" },
        link: "/intelligence",
      }];
    },
    async measure({ ctx }) { const k = await dashboardKpis(ctx, 30); const s = await closedSample(ctx, 30); return { value: k.current.conversionRate, sampleSize: s.current }; },
  },
  {
    key: "revenue_drop", label: "Queda de receita", domain: "sales",
    async evaluate({ ctx }) {
      const k = await dashboardKpis(ctx, 30);
      const d = k.delta.revenue;
      if (d == null || d > -15 || k.previous.revenueCents <= 0) return [];
      return [{
        ruleKey: "revenue_drop", dedupeKey: "revenue_drop", domain: "sales", nature: "fact",
        title: `Receita de vendas caiu ${Math.abs(d)}% em 30 dias`,
        summary: `${brl(ctx, k.current.revenueCents)} nos últimos 30 dias contra ${brl(ctx, k.previous.revenueCents)} no período anterior.`,
        priority: d <= -30 ? "high" : "medium",
        evidence: buildEvidence({
          facts: [
            { label: "Receita ganha (atual)", value: brl(ctx, k.current.revenueCents), source: "CRM · oportunidades ganhas", period: periodLabel(30) },
            { label: "Receita ganha (anterior)", value: brl(ctx, k.previous.revenueCents), source: "CRM · oportunidades ganhas", period: "30 dias anteriores" },
            { label: "Vendas (atual / anterior)", value: `${k.current.won} / ${k.previous.won}`, source: "CRM · oportunidades" },
          ],
          calculations: [`Variação = (${k.current.revenueCents / 100} − ${k.previous.revenueCents / 100}) ÷ ${k.previous.revenueCents / 100} = ${d}%`],
          confidence: confidenceFrom(k.current.won + k.previous.won, 0, 20),
          limitations: ["Receita comercial (negócios ganhos no CRM), não recebimentos financeiros."],
        }),
        recommendedAction: "Perguntar ao Business Brain \"Por que minha receita caiu?\" para ver causas por etapa, volume e vendedor.",
        indicator: { metric: "Receita ganha (30 dias)", baseline: k.current.revenueCents, unit: "centavos", direction: "up" },
        link: "/intelligence",
      }];
    },
    async measure({ ctx }) { const k = await dashboardKpis(ctx, 30); return { value: k.current.revenueCents, sampleSize: k.current.won }; },
  },
  {
    key: "goal_at_risk", label: "Meta em risco", domain: "sales",
    async evaluate({ ctx }) {
      const g = await mainGoalProgress(ctx);
      if (!g) return [];
      const [row] = await ctx.db.select({ start: goals.periodStart, end: goals.periodEnd }).from(goals).where(and(eq(goals.id, g.id), eq(goals.organizationId, ctx.organizationId)));
      if (!row) return [];
      const pace = goalPace(g, row.start, row.end);
      if (pace.elapsedPct < 20 || g.pct >= pace.elapsedPct - 10) return [];
      const gap = pace.expectedCents - g.achieved;
      return [{
        ruleKey: "goal_at_risk", dedupeKey: `goal_at_risk:${g.id}`, domain: "sales", nature: "estimate",
        title: `Meta "${g.name}" abaixo do ritmo`,
        summary: `${g.pct}% atingido com ${pace.elapsedPct}% do período decorrido. Faltam ${brl(ctx, gap)} para voltar ao ritmo linear.`,
        priority: g.pct < pace.elapsedPct - 25 ? "high" : "medium",
        evidence: buildEvidence({
          facts: [
            { label: "Realizado", value: brl(ctx, g.achieved), source: "CRM · oportunidades ganhas no período da meta" },
            { label: "Meta", value: brl(ctx, g.target), source: "Tarefas & Metas" },
            { label: "Período decorrido", value: `${pace.elapsedPct}%`, source: "Calendário da meta" },
          ],
          assumptions: ["Ritmo esperado linear ao longo do período (sem sazonalidade)."],
          calculations: [`Esperado até hoje = meta × ${pace.elapsedPct}% = ${brl(ctx, pace.expectedCents)}`],
          confidence: 0.7,
          limitations: ["Não considera sazonalidade nem negócios grandes previstos para o fim do período."],
        }),
        recommendedAction: "Priorizar oportunidades em Negociação/Fechamento e revisar a previsão no Sales Intelligence.",
        indicator: { metric: `Atingimento da meta "${g.name}"`, baseline: g.pct, unit: "%", direction: "up" },
        link: "/tarefas",
      }];
    },
    async measure({ ctx }) { const g = await mainGoalProgress(ctx); return { value: g?.pct ?? null, sampleSize: g ? 30 : 0 }; },
  },
  {
    key: "finance_overdue_receivables", label: "Inadimplência", domain: "finance", needsFinance: true,
    async evaluate({ ctx, finance: f }) {
      if (!f?.hasData || !f.overdueReceivableCount) return [];
      const share = f.receivableOpenCents ? Math.round((f.overdueReceivableCents / f.receivableOpenCents) * 1000) / 10 : 0;
      return [{
        ruleKey: "finance_overdue_receivables", dedupeKey: "finance_overdue_receivables", domain: "finance", nature: "fact",
        title: `${f.overdueReceivableCount} recebimentos vencidos (${brl(ctx, f.overdueReceivableCents)})`,
        summary: `${share}% do contas a receber em aberto está vencido.`,
        priority: share >= 10 ? "high" : "medium",
        evidence: buildEvidence({
          facts: [
            { label: "Recebíveis vencidos", value: brl(ctx, f.overdueReceivableCents), source: "Financeiro · contas a receber" },
            { label: "Recebíveis em aberto", value: brl(ctx, f.receivableOpenCents), source: "Financeiro · contas a receber" },
          ],
          calculations: [`Inadimplência = vencidos ÷ em aberto = ${share}%`],
          confidence: 0.9,
          limitations: ["Baseado nos lançamentos registrados; pagamentos não conciliados aparecem como vencidos."],
        }),
        recommendedAction: "Iniciar régua de cobrança para os títulos vencidos e revisar condições dos clientes recorrentes.",
        indicator: { metric: "Recebíveis vencidos", baseline: f.overdueReceivableCents, unit: "centavos", direction: "down" },
        link: "/financeiro",
      }];
    },
    async measure({ finance: f }) { return { value: f?.hasData ? f.overdueReceivableCents : null, sampleSize: f?.hasData ? 30 : 0 }; },
  },
  {
    key: "finance_expense_growth", label: "Crescimento de despesas", domain: "finance", needsFinance: true,
    async evaluate({ ctx, finance: f }) {
      if (!f?.hasData || f.previous.expensesCents <= 0) return [];
      const g = Math.round(((f.expensesCents - f.previous.expensesCents) / f.previous.expensesCents) * 1000) / 10;
      if (g < 20) return [];
      return [{
        ruleKey: "finance_expense_growth", dedupeKey: "finance_expense_growth", domain: "finance", nature: "fact",
        title: `Despesas pagas cresceram ${g}% em 30 dias`,
        summary: `${brl(ctx, f.expensesCents)} contra ${brl(ctx, f.previous.expensesCents)} no período anterior.`,
        priority: g >= 40 ? "high" : "medium",
        evidence: buildEvidence({
          facts: [
            { label: "Despesas pagas (atual)", value: brl(ctx, f.expensesCents), source: "Financeiro · contas a pagar", period: periodLabel(30) },
            { label: "Despesas pagas (anterior)", value: brl(ctx, f.previous.expensesCents), source: "Financeiro · contas a pagar", period: "30 dias anteriores" },
          ],
          calculations: [`Crescimento = ${g}%`],
          confidence: confidenceFrom(f.entriesInPeriod, 0, 20),
          limitations: ["Regime de caixa (data de pagamento); despesas anuais pagas no período distorcem a comparação."],
        }),
        recommendedAction: "Perguntar ao Business Brain \"Quais despesas cresceram?\" para ver as categorias responsáveis.",
        indicator: { metric: "Despesas pagas (30 dias)", baseline: f.expensesCents, unit: "centavos", direction: "down" },
        link: "/financeiro",
      }];
    },
    async measure({ finance: f }) { return { value: f?.hasData ? f.expensesCents : null, sampleSize: f?.entriesInPeriod ?? 0 }; },
  },
  {
    key: "finance_margin_drop", label: "Queda de margem", domain: "finance", needsFinance: true,
    async evaluate({ ctx, finance: f }) {
      if (!f?.hasData || f.marginPct == null || f.previous.revenueCents <= 0) return [];
      const prevMargin = Math.round((f.previous.resultCents / f.previous.revenueCents) * 1000) / 10;
      const drop = Math.round((prevMargin - f.marginPct) * 10) / 10;
      if (drop < 5) return [];
      return [{
        ruleKey: "finance_margin_drop", dedupeKey: "finance_margin_drop", domain: "finance", nature: "fact",
        title: `Margem caiu ${drop} p.p.`,
        summary: `Margem de caixa passou de ${prevMargin}% para ${f.marginPct}% em 30 dias.`,
        priority: drop >= 10 ? "high" : "medium",
        evidence: buildEvidence({
          facts: [
            { label: "Margem atual", value: `${f.marginPct}%`, source: "Financeiro · recebimentos e pagamentos", period: periodLabel(30) },
            { label: "Margem anterior", value: `${prevMargin}%`, source: "Financeiro · recebimentos e pagamentos", period: "30 dias anteriores" },
            { label: "Resultado atual", value: brl(ctx, f.resultCents), source: "Financeiro" },
          ],
          calculations: ["Margem = (recebimentos − pagamentos) ÷ recebimentos, regime de caixa."],
          confidence: confidenceFrom(f.entriesInPeriod, 0, 20),
          limitations: ["Margem de caixa gerencial; não substitui a DRE contábil."],
        }),
        recommendedAction: "Comparar despesas por categoria e revisar descontos concedidos no período.",
        indicator: { metric: "Margem de caixa (30 dias)", baseline: f.marginPct, unit: "%", direction: "up" },
        link: "/financeiro",
      }];
    },
    async measure({ finance: f }) { return { value: f?.hasData ? f.marginPct : null, sampleSize: f?.entriesInPeriod ?? 0 }; },
  },
  {
    key: "finance_negative_cash", label: "Caixa projetado negativo", domain: "finance", needsFinance: true,
    async evaluate({ ctx, finance: f }) {
      if (!f?.hasData || f.next30.netCents >= 0) return [];
      return [{
        ruleKey: "finance_negative_cash", dedupeKey: "finance_negative_cash", domain: "finance", nature: "estimate",
        title: `Saldo projetado negativo nos próximos 30 dias (${brl(ctx, f.next30.netCents)})`,
        summary: `Entradas previstas ${brl(ctx, f.next30.inflowCents)} · saídas previstas ${brl(ctx, f.next30.outflowCents)}.`,
        priority: "high",
        evidence: buildEvidence({
          facts: [
            { label: "Entradas previstas (30 dias)", value: brl(ctx, f.next30.inflowCents), source: "Financeiro · contas a receber em aberto" },
            { label: "Saídas previstas (30 dias)", value: brl(ctx, f.next30.outflowCents), source: "Financeiro · contas a pagar em aberto" },
          ],
          assumptions: ["Todos os títulos são pagos/recebidos na data de vencimento.", "Saldo bancário atual não é conhecido (sem integração bancária)."],
          calculations: ["Saldo projetado = entradas − saídas com vencimento nos próximos 30 dias."],
          confidence: 0.6,
          missingData: ["Saldo bancário atual"],
          limitations: ["Não considera vendas ainda não lançadas nem atrasos de clientes."],
        }),
        recommendedAction: "Antecipar cobranças, renegociar vencimentos de fornecedores e evitar novas despesas não essenciais.",
        indicator: { metric: "Saldo projetado 30 dias", baseline: f.next30.netCents, unit: "centavos", direction: "up" },
        link: "/financeiro",
      }];
    },
    async measure({ finance: f }) { return { value: f?.hasData ? f.next30.netCents : null, sampleSize: f?.hasData ? 30 : 0 }; },
  },
  {
    key: "ai_quality", label: "Falhas dos agentes de IA", domain: "ai",
    async evaluate({ ctx }) {
      const q = await aiQuality(ctx);
      if (q.total < 10 || q.ratePct < 20) return [];
      return [{
        ruleKey: "ai_quality", dedupeKey: "ai_quality", domain: "ai", nature: "fact",
        title: `${q.ratePct}% das execuções de IA falharam ou foram bloqueadas`,
        summary: `${q.failed} falhas e ${q.blocked} bloqueios de segurança em ${q.total} execuções nos últimos 7 dias.`,
        priority: q.ratePct >= 40 ? "high" : "medium",
        evidence: buildEvidence({
          facts: [
            { label: "Execuções", value: String(q.total), source: "IA · histórico de execuções", period: periodLabel(7) },
            { label: "Falhas", value: String(q.failed), source: "IA · histórico de execuções" },
            { label: "Bloqueios (guardrails)", value: String(q.blocked), source: "IA · histórico de execuções" },
          ],
          calculations: [`Taxa = (falhas + bloqueios) ÷ execuções = ${q.ratePct}%`],
          confidence: confidenceFrom(q.total),
          limitations: ["Bloqueios podem ser corretos (tentativas de prompt injection) e não indicam defeito do agente."],
        }),
        recommendedAction: "Revisar provedores e limites no AI Control Plane e o histórico de execuções dos agentes afetados.",
        indicator: { metric: "Falhas + bloqueios de IA (7 dias)", baseline: q.ratePct, unit: "%", direction: "down" },
        link: "/agentes",
      }];
    },
    async measure({ ctx }) { const q = await aiQuality(ctx); return { value: q.ratePct, sampleSize: q.total }; },
  },
];

export const INSIGHT_RULES = RULES.map((r) => ({ key: r.key, label: r.label, domain: r.domain, needsFinance: !!r.needsFinance }));

/* ------------------------------------------------------------------ feedback loop */

export type RuleStat = { ruleKey: string; label: string; total: number; accepted: number; modified: number; rejected: number; executed: number; improved: number; worse: number; decided: number; rejectionRate: number | null; precision: number | null; demoted: boolean };

const FEEDBACK_MIN_DECISIONS = 5;
const FEEDBACK_REJECTION_THRESHOLD = 0.7;

export async function ruleStats(ctx: TenantContext): Promise<RuleStat[]> {
  requirePerm(ctx, "intelligence:read");
  const rows = await ctx.db.select({
    ruleKey: insights.ruleKey,
    total: sql<number>`count(*)::int`,
    accepted: sql<number>`count(*) filter (where ${insights.status} = 'accepted')::int`,
    modified: sql<number>`count(*) filter (where ${insights.status} = 'modified')::int`,
    rejected: sql<number>`count(*) filter (where ${insights.status} = 'rejected')::int`,
    executed: sql<number>`count(*) filter (where ${insights.status} = 'executed')::int`,
    improved: sql<number>`count(*) filter (where ${insights.outcome}->>'verdict' = 'improved')::int`,
    worse: sql<number>`count(*) filter (where ${insights.outcome}->>'verdict' = 'worse')::int`,
  }).from(insights).where(eq(insights.organizationId, ctx.organizationId)).groupBy(insights.ruleKey);
  return rows.map((r) => {
    const decided = r.accepted + r.modified + r.rejected + r.executed;
    const rejectionRate = decided ? r.rejected / decided : null;
    const measured = r.improved + r.worse;
    return {
      ...r, label: RULES.find((x) => x.key === r.ruleKey)?.label ?? r.ruleKey, decided,
      rejectionRate: rejectionRate == null ? null : Math.round(rejectionRate * 100) / 100,
      precision: measured ? Math.round((r.improved / measured) * 100) / 100 : null,
      demoted: decided >= FEEDBACK_MIN_DECISIONS && (rejectionRate ?? 0) >= FEEDBACK_REJECTION_THRESHOLD,
    };
  });
}

const lower = (p: Priority): Priority => (p === "high" ? "medium" : "low");

/* ------------------------------------------------------------------ scan */

const ACTIVE_STATUSES = ["open", "accepted", "modified"];
const RESPECT_DAYS = 14; // rejeitado/executado recentemente: não recria o mesmo insight

export async function scanInsights(ctx: TenantContext) {
  requirePerm(ctx, "intelligence:read");
  const financeAllowed = can(ctx, "finance:read");
  const finance = financeAllowed ? await financialSnapshot(ctx, 30) : null;
  const env: RuleEnv = { ctx, finance };
  const stats = new Map((await ruleStats(ctx)).map((s) => [s.ruleKey, s]));
  const evaluated = RULES.filter((r) => !r.needsFinance || financeAllowed);

  const candidates: InsightCandidate[] = [];
  for (const r of evaluated) candidates.push(...(await r.evaluate(env)));

  const existing = await ctx.db.select().from(insights).where(and(
    eq(insights.organizationId, ctx.organizationId), inArray(insights.ruleKey, evaluated.map((r) => r.key)),
  ));
  const now = Date.now();
  const created: InsightRow[] = [];
  let refreshed = 0, expired = 0;

  for (const c of candidates) {
    const same = existing.filter((e) => e.dedupeKey === c.dedupeKey);
    const active = same.find((e) => ACTIVE_STATUSES.includes(e.status));
    if (active) {
      if (active.status === "open") {
        await ctx.db.update(insights).set({ title: c.title, summary: c.summary, evidence: c.evidence, indicator: c.indicator }).where(eq(insights.id, active.id));
        refreshed++;
      }
      continue;
    }
    const recentlyDecided = same.some((e) => ["rejected", "executed"].includes(e.status) && (e.decidedAt ?? e.createdAt).getTime() > now - RESPECT_DAYS * DAY);
    if (recentlyDecided) continue;

    const st = stats.get(c.ruleKey);
    let priority = c.priority;
    let evidence = c.evidence;
    if (st?.demoted) {
      priority = lower(priority);
      evidence = { ...evidence, limitations: [...evidence.limitations, `Prioridade reduzida pelo histórico: ${Math.round((st.rejectionRate ?? 0) * 100)}% das ${st.decided} recomendações desta regra foram rejeitadas.`] };
    }
    const row = await ctx.db.transaction(async (tx) => {
      const [ins] = await tx.insert(insights).values({
        organizationId: ctx.organizationId, ruleKey: c.ruleKey, dedupeKey: c.dedupeKey, domain: c.domain, nature: c.nature,
        title: c.title, summary: c.summary, priority, evidence, recommendedAction: c.recommendedAction, indicator: c.indicator, link: c.link,
      }).returning();
      await publish(tx, ctx.organizationId, EVENT_TYPES.INSIGHT_CREATED, { insightId: ins.id, ruleKey: ins.ruleKey, priority: ins.priority, domain: ins.domain });
      // Notificação POR USUÁRIO, respeitando preferências de alerta (domínio, prioridade mínima, frequência) e permissões.
      const to = await recipientsFor(tx as unknown as TenantContext["db"], ctx.organizationId, { domain: ins.domain, priority });
      if (to.length) await tx.insert(notifications).values(to.map((userId) => ({ organizationId: ctx.organizationId, userId, title: `Atenção: ${ins.title}`, body: ins.recommendedAction ?? ins.summary, href: "/business-brain" })));
      return ins;
    });
    created.push(row);
  }

  const liveKeys = new Set(candidates.map((c) => c.dedupeKey));
  for (const e of existing) {
    if (e.status === "open" && !liveKeys.has(e.dedupeKey)) {
      await ctx.db.update(insights).set({ status: "expired", decisionNote: "Condição deixou de ocorrer na última análise." }).where(eq(insights.id, e.id));
      expired++;
    }
  }

  const digests = await deliverDigests(ctx.db, ctx.organizationId);

  await audit(ctx.db, {
    organizationId: ctx.organizationId, actorId: ctx.roleKey === "system" ? "system" : ctx.userId, action: "insights.scanned", resource: "insight",
    metadata: { created: created.length, refreshed, expired, financeEvaluated: financeAllowed, digests },
  });
  return { created: created.length, refreshed, expired, financeEvaluated: financeAllowed, financeHasData: finance?.hasData ?? false };
}

/* ------------------------------------------------------------------ leitura */

const visibleDomains = (ctx: TenantContext) => (can(ctx, "finance:read") ? null : sql`${insights.domain} <> 'finance'`);

export async function listInsights(ctx: TenantContext, opts: { status?: string[]; limit?: number } = {}) {
  requirePerm(ctx, "intelligence:read");
  const conds = [eq(insights.organizationId, ctx.organizationId)];
  if (opts.status?.length) conds.push(inArray(insights.status, opts.status));
  const vd = visibleDomains(ctx);
  if (vd) conds.push(vd);
  const rows = await ctx.db.select().from(insights).where(and(...conds))
    .orderBy(sql`case ${insights.priority} when 'high' then 0 when 'medium' then 1 else 2 end`, desc(insights.createdAt)).limit(opts.limit ?? 100);
  return rows;
}

export async function getInsight(ctx: TenantContext, id: string) {
  requirePerm(ctx, "intelligence:read");
  if (!z.string().uuid().safeParse(id).success) throw new HttpError(404, "Insight não encontrado.");
  const [row] = await ctx.db.select().from(insights).where(and(eq(insights.id, id), eq(insights.organizationId, ctx.organizationId)));
  if (!row || (row.domain === "finance" && !can(ctx, "finance:read"))) throw new HttpError(404, "Insight não encontrado.");
  return row;
}

/* ------------------------------------------------------------------ Outcome Engine */

export const decideInput = z.object({
  status: z.enum(["accepted", "rejected", "modified", "canceled"]),
  note: z.string().trim().max(1000).optional(),
});

export async function decideInsight(ctx: TenantContext, id: string, raw: z.input<typeof decideInput>) {
  const input = decideInput.parse(raw);
  const ins = await getInsight(ctx, id);
  if (!["open", "accepted", "modified"].includes(ins.status)) throw new HttpError(409, `Insight já está "${ins.status}".`);
  if (input.status === "modified" && !input.note) throw new HttpError(400, "Descreva a alteração feita na recomendação.");
  const [u] = await ctx.db.update(insights).set({ status: input.status, decidedBy: ctx.userId, decidedAt: new Date(), decisionNote: input.note ?? null })
    .where(and(eq(insights.id, ins.id), eq(insights.organizationId, ctx.organizationId))).returning();
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: `insight.${input.status}`, resource: "insight", resourceId: ins.id, metadata: { ruleKey: ins.ruleKey, note: input.note }, ip: ctx.ip });
  return u;
}

export async function markExecuted(ctx: TenantContext, id: string, note?: string) {
  const ins = await getInsight(ctx, id);
  if (!["open", "accepted", "modified"].includes(ins.status)) throw new HttpError(409, `Insight "${ins.status}" não pode ser marcado como executado.`);
  const [u] = await ctx.db.update(insights).set({
    status: "executed", executedAt: new Date(), decidedBy: ins.decidedBy ?? ctx.userId, decidedAt: ins.decidedAt ?? new Date(),
    decisionNote: note ?? ins.decisionNote,
  }).where(and(eq(insights.id, ins.id), eq(insights.organizationId, ctx.organizationId))).returning();
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "insight.executed", resource: "insight", resourceId: ins.id, ip: ctx.ip });
  return u;
}

export const OUTCOME_MIN_DAYS = 7;

/** Tolerância para considerar "sem mudança": 5% da linha de base (mín. 1 unidade para contagens). */
export function verdictFor(direction: "up" | "down", baseline: number, observed: number): "improved" | "no_change" | "worse" {
  const tol = Math.max(Math.abs(baseline) * 0.05, 1e-9);
  const delta = observed - baseline;
  if (Math.abs(delta) <= tol) return "no_change";
  const better = direction === "up" ? delta > 0 : delta < 0;
  return better ? "improved" : "worse";
}

export async function measureOutcome(ctx: TenantContext, id: string) {
  const ins = await getInsight(ctx, id);
  if (ins.status !== "executed" || !ins.executedAt) throw new HttpError(409, "Marque a recomendação como executada antes de medir o resultado.");
  const rule = RULES.find((r) => r.key === ins.ruleKey);
  if (!rule || !ins.indicator) throw new HttpError(422, "Indicador desta recomendação não pode ser recalculado.");
  const finance = rule.needsFinance && can(ctx, "finance:read") ? await financialSnapshot(ctx, 30) : null;
  const m = await rule.measure({ ctx, finance }, ins.dedupeKey);
  const days = (Date.now() - ins.executedAt.getTime()) / DAY;
  let verdict: "improved" | "no_change" | "worse" | "inconclusive";
  let note: string;
  if (m.value == null) { verdict = "inconclusive"; note = "Não há dados para recalcular o indicador."; }
  else if (days < OUTCOME_MIN_DAYS) { verdict = "inconclusive"; note = `Executado há ${Math.floor(days)} dia(s); aguarde pelo menos ${OUTCOME_MIN_DAYS} dias para medir.`; }
  else if (m.sampleSize < 5) { verdict = "inconclusive"; note = `Amostra pequena (${m.sampleSize}) para conclusões.`; }
  else {
    verdict = verdictFor(ins.indicator.direction, ins.indicator.baseline, m.value);
    note = `${ins.indicator.metric}: ${ins.indicator.baseline} → ${m.value} (${ins.indicator.direction === "up" ? "quanto maior, melhor" : "quanto menor, melhor"}). Associação observada, não prova de causalidade.`;
  }
  const outcome = { observed: m.value ?? 0, measuredAt: new Date().toISOString(), verdict, note };
  const [u] = await ctx.db.update(insights).set({ outcome }).where(and(eq(insights.id, ins.id), eq(insights.organizationId, ctx.organizationId))).returning();
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "insight.outcome_measured", resource: "insight", resourceId: ins.id, metadata: { verdict, observed: m.value } });
  return u;
}
