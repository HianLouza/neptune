/**
 * Contexto de SISTEMA para tarefas agendadas (worker) da Intelligence Layer.
 *
 * - Usado apenas por processos internos (scripts/worker.ts), nunca por rotas HTTP.
 * - Opera no tenant informado, com `roleKey = "system"` (auditoria registra o ator "system").
 * - Permissões amplas ("*") porque a varredura precisa avaliar todos os domínios; o resultado fica no tenant.
 * - `userId` é o do administrador mais antigo ativo, para satisfazer chaves de usuário; a auditoria não o usa como ator.
 */
import { and, asc, eq } from "drizzle-orm";
import type { DB } from "../db/client";
import { memberships, organizations, roles } from "../db/schema";
import type { TenantContext } from "../tenancy/context";

export async function systemContextFor(db: DB, organizationId: string): Promise<TenantContext | null> {
  const [row] = await db.select({ userId: memberships.userId, org: organizations })
    .from(memberships).innerJoin(roles, eq(roles.id, memberships.roleId)).innerJoin(organizations, eq(organizations.id, memberships.organizationId))
    .where(and(eq(memberships.organizationId, organizationId), eq(memberships.status, "active"), eq(roles.key, "admin")))
    .orderBy(asc(memberships.createdAt)).limit(1);
  if (!row || row.org.status === "suspended") return null;
  return {
    db, organizationId, userId: row.userId, roleKey: "system", permissions: ["*"], isPlatformAdmin: false,
    locale: row.org.locale, currency: row.org.currency, timezone: row.org.timezone, ip: null,
  };
}

export async function activeOrganizationIds(db: DB) {
  const rows = await db.select({ id: organizations.id, status: organizations.status }).from(organizations);
  return rows.filter((r) => r.status !== "suspended").map((r) => r.id);
}
