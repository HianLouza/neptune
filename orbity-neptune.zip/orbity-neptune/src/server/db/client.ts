/**
 * Cliente de banco.
 *  - DATABASE_URL definido  -> PostgreSQL real (postgres-js). Use em homologação/produção.
 *  - DATABASE_URL vazio     -> PGlite (Postgres em WASM, com pgvector) persistido em PGLITE_DIR. Só desenvolvimento.
 */
import type { PgDatabase, PgQueryResultHKT } from "drizzle-orm/pg-core";
import * as schema from "./schema";

export type DB = PgDatabase<PgQueryResultHKT, typeof schema>;

type Holder = { db?: DB; ready?: Promise<DB>; close?: () => Promise<void> };
const g = globalThis as unknown as { __orbityDb?: Holder };
const holder: Holder = (g.__orbityDb ??= {});

export async function createDb(opts: { url?: string; dataDir?: string; memory?: boolean } = {}): Promise<{ db: DB; close: () => Promise<void> }> {
  const url = opts.url ?? process.env.DATABASE_URL;
  if (url && !opts.memory) {
    const postgres = (await import("postgres")).default;
    const { drizzle } = await import("drizzle-orm/postgres-js");
    const client = postgres(url, { max: 10, prepare: false });
    return { db: drizzle(client, { schema }) as unknown as DB, close: async () => { await client.end(); } };
  }
  const { PGlite } = await import("@electric-sql/pglite");
  const { vector } = await import("@electric-sql/pglite-pgvector");
  const { drizzle } = await import("drizzle-orm/pglite");
  const { projectRoot } = await import("./paths");
  const path = await import("node:path");
  const dataDir = opts.memory ? undefined : path.resolve(projectRoot(), opts.dataDir ?? process.env.PGLITE_DIR ?? "./.data/pglite");
  if (dataDir) (await import("node:fs")).mkdirSync(dataDir, { recursive: true });
  const client = new PGlite({ ...(dataDir ? { dataDir } : {}), extensions: { vector } });
  await client.waitReady;
  return { db: drizzle(client, { schema }) as unknown as DB, close: async () => { await client.close(); } };
}

/** Instância única por processo (sobrevive ao hot-reload do Next em dev). */
export async function getDb(): Promise<DB> {
  if (holder.db) return holder.db;
  holder.ready ??= (async () => {
    const { db, close } = await createDb();
    const { runMigrations } = await import("./migrate");
    await runMigrations(db);
    holder.db = db;
    holder.close = close;
    return db;
  })();
  return holder.ready;
}

export { schema };
