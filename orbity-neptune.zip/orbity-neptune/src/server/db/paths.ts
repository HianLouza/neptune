import fs from "node:fs";
import path from "node:path";

/** Raiz do projeto (funciona mesmo se o processo for iniciado a partir da pasta-pai). */
export function projectRoot() {
  const cwd = process.cwd();
  if (fs.existsSync(path.join(cwd, "drizzle"))) return cwd;
  const nested = path.join(cwd, "orbity-neptune");
  if (fs.existsSync(path.join(nested, "drizzle"))) return nested;
  return cwd;
}
