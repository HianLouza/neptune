/**
 * Dados de referência da plataforma (planos, feature flags, catálogo de métricas, configuração de health score).
 * Preços de planos: NÃO definidos (null = "a definir") até validação comercial (seção 30/32 do master prompt).
 */
import type { DB } from "./client";
import { featureFlags, healthScoreConfig, plans } from "./schema";
import { seedMetricCatalog } from "../domains/data-intelligence";
import { DEFAULT_THRESHOLDS, DEFAULT_WEIGHTS } from "../domains/customer-success";

const ALL = ["prospect", "closer", "intelligence", "crm", "automations", "ai_agents", "ai_eval", "goals", "integrations_advanced", "experiments", "data_export", "sso", "custom_roles"];

export const PLAN_SEED = [
  { key: "starter", name: "Starter", includedCredits: 1000, annualDiscountPct: 15, limits: { users: 3, leads_per_month: 500, messages_per_month: 2000, agents: 3, automations: 3, integrations: 2, storage_mb: 1024 }, features: ["prospect", "closer", "intelligence", "crm", "ai_agents"] },
  { key: "growth", name: "Growth", includedCredits: 5000, annualDiscountPct: 15, limits: { users: 10, leads_per_month: 3000, messages_per_month: 10000, agents: 8, automations: 15, integrations: 6, storage_mb: 5120 }, features: ["prospect", "closer", "intelligence", "crm", "automations", "ai_agents", "goals", "data_export"] },
  { key: "business", name: "Business", includedCredits: 20000, annualDiscountPct: 15, limits: { users: 30, leads_per_month: 15000, messages_per_month: 50000, agents: 15, automations: 60, integrations: 20, storage_mb: 20480 }, features: ALL.filter((f) => f !== "sso") },
  { key: "enterprise", name: "Enterprise", includedCredits: 100000, annualDiscountPct: 20, limits: { users: -1, leads_per_month: -1, messages_per_month: -1, agents: -1, automations: -1, integrations: -1, storage_mb: -1 }, features: ALL },
];

export async function seedCore(db: DB) {
  for (const p of PLAN_SEED) {
    await db.insert(plans).values({ ...p, monthlyPriceCents: null, trialDays: 7 }).onConflictDoUpdate({ target: plans.key, set: { limits: p.limits, features: p.features, includedCredits: p.includedCredits } });
  }
  const flags = [
    { key: "experiments", description: "Experimentation Center para organizações", enabled: true, rolloutPct: 100, plans: ["business", "enterprise"] },
    { key: "ai_voice", description: "Entrada por voz no assistente", enabled: true, rolloutPct: 25, plans: [] },
    { key: "new_dashboard_widgets", description: "Novos widgets do dashboard (rollout gradual)", enabled: true, rolloutPct: 50, plans: [] },
  ];
  for (const f of flags) await db.insert(featureFlags).values(f).onConflictDoNothing();
  await seedMetricCatalog(db);
  const existing = await db.select().from(healthScoreConfig).limit(1);
  if (!existing.length) await db.insert(healthScoreConfig).values({ weights: DEFAULT_WEIGHTS, thresholds: DEFAULT_THRESHOLDS });
}
