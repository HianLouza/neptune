import path from "node:path";
import { sql } from "drizzle-orm";
import type { DB } from "./client";
import { projectRoot } from "./paths";

/** Aplica extensões + migrações SQL versionadas em ./drizzle (geradas pelo drizzle-kit). */
export async function runMigrations(db: DB) {
  await db.execute(sql`CREATE EXTENSION IF NOT EXISTS vector`);
  const folder = path.join(projectRoot(), "drizzle");
  const isPglite = !process.env.DATABASE_URL;
  if (isPglite) {
    const { migrate } = await import("drizzle-orm/pglite/migrator");
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    await migrate(db as any, { migrationsFolder: folder });
  } else {
    const { migrate } = await import("drizzle-orm/postgres-js/migrator");
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    await migrate(db as any, { migrationsFolder: folder });
  }
  await syncSystemRoles(db);
}

/**
 * Cargos de sistema (admin/gestor/colaborador) recebem as permissões novas do catálogo.
 * Só ACRESCENTA: permissões removidas manualmente de cargos personalizados não são tocadas.
 */
export async function syncSystemRoles(db: DB) {
  const { roles } = await import("./schema");
  const { SYSTEM_ROLES } = await import("../permissions");
  const { eq, and } = await import("drizzle-orm");
  const rows = await db.select().from(roles).where(eq(roles.isSystem, true));
  for (const r of rows) {
    const def = SYSTEM_ROLES[r.key as keyof typeof SYSTEM_ROLES];
    if (!def) continue;
    const missing = def.permissions.filter((p) => !r.permissions.includes(p));
    if (missing.length) await db.update(roles).set({ permissions: [...r.permissions, ...missing] }).where(and(eq(roles.id, r.id)));
  }
}
