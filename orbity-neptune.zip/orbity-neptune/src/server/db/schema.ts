/**
 * ORBITY-NEPTUNE — Modelo canônico de dados.
 *
 * Regras:
 *  - Toda tabela de dados de cliente tem `organizationId` (tenant) e é acessada via repositórios
 *    que exigem o contexto de tenant (src/server/tenancy).
 *  - IDs são UUID gerados no banco.
 *  - Dinheiro é armazenado em centavos (integer/bigint) + código de moeda (i18n: nunca fixo em BRL).
 */
import {
  pgTable, uuid, text, timestamp, integer, boolean, jsonb, real, bigint, uniqueIndex, index, vector, primaryKey,
} from "drizzle-orm/pg-core";

const id = () => uuid("id").primaryKey().defaultRandom();
const createdAt = () => timestamp("created_at", { withTimezone: true }).notNull().defaultNow();
const updatedAt = () => timestamp("updated_at", { withTimezone: true }).notNull().defaultNow();
const orgId = () => uuid("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" });

/* ============================== IDENTITY / ORGANIZATION ============================== */

export const organizations = pgTable("organizations", {
  id: id(),
  name: text("name").notNull(),
  slug: text("slug").notNull(),
  segment: text("segment"),
  size: text("size"), // "2-10", "11-30", ...
  locale: text("locale").notNull().default("pt-BR"),
  currency: text("currency").notNull().default("BRL"),
  timezone: text("timezone").notNull().default("America/Sao_Paulo"),
  isDemo: boolean("is_demo").notNull().default(false), // dados de demonstração nunca misturados com produção
  onboardingCompleted: boolean("onboarding_completed").notNull().default(false),
  settings: jsonb("settings").$type<Record<string, unknown>>().notNull().default({}),
  status: text("status").notNull().default("active"), // active | suspended
  createdAt: createdAt(),
  updatedAt: updatedAt(),
}, (t) => [uniqueIndex("org_slug_uq").on(t.slug)]);

export const users = pgTable("users", {
  id: id(),
  email: text("email").notNull(),
  name: text("name").notNull(),
  passwordHash: text("password_hash"),
  avatarUrl: text("avatar_url"),
  jobTitle: text("job_title"),
  locale: text("locale").notNull().default("pt-BR"),
  timezone: text("timezone"),
  totpSecret: text("totp_secret"),
  totpEnabled: boolean("totp_enabled").notNull().default(false),
  isPlatformAdmin: boolean("is_platform_admin").notNull().default(false), // admin global ORBITY-NEPTUNE
  emailVerifiedAt: timestamp("email_verified_at", { withTimezone: true }),
  lastLoginAt: timestamp("last_login_at", { withTimezone: true }),
  createdAt: createdAt(),
  updatedAt: updatedAt(),
}, (t) => [uniqueIndex("user_email_uq").on(t.email)]);

export const authAccounts = pgTable("auth_accounts", {
  id: id(),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  provider: text("provider").notNull(), // google | microsoft
  providerAccountId: text("provider_account_id").notNull(),
  createdAt: createdAt(),
}, (t) => [uniqueIndex("auth_provider_uq").on(t.provider, t.providerAccountId)]);

export const sessions = pgTable("sessions", {
  id: id(),
  tokenHash: text("token_hash").notNull(),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: "set null" }),
  twoFactorPending: boolean("two_factor_pending").notNull().default(false),
  userAgent: text("user_agent"),
  ip: text("ip"),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  revokedAt: timestamp("revoked_at", { withTimezone: true }),
  createdAt: createdAt(),
}, (t) => [uniqueIndex("session_token_uq").on(t.tokenHash)]);

/* Cargos: admin | manager | member + permissões customizadas por organização */
export const roles = pgTable("roles", {
  id: id(),
  organizationId: orgId(),
  key: text("key").notNull(),
  name: text("name").notNull(),
  permissions: jsonb("permissions").$type<string[]>().notNull().default([]),
  isSystem: boolean("is_system").notNull().default(false),
  createdAt: createdAt(),
}, (t) => [uniqueIndex("role_org_key_uq").on(t.organizationId, t.key)]);

export const memberships = pgTable("memberships", {
  id: id(),
  organizationId: orgId(),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  roleId: uuid("role_id").notNull().references(() => roles.id),
  status: text("status").notNull().default("active"), // pending (aguardando aprovação) | active | disabled
  createdAt: createdAt(),
}, (t) => [uniqueIndex("membership_uq").on(t.organizationId, t.userId)]);

export const teams = pgTable("teams", {
  id: id(),
  organizationId: orgId(),
  name: text("name").notNull(),
  createdAt: createdAt(),
});

export const teamMembers = pgTable("team_members", {
  teamId: uuid("team_id").notNull().references(() => teams.id, { onDelete: "cascade" }),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
}, (t) => [primaryKey({ columns: [t.teamId, t.userId] })]);

export const userPreferences = pgTable("user_preferences", {
  userId: uuid("user_id").primaryKey().references(() => users.id, { onDelete: "cascade" }),
  theme: text("theme").notNull().default("dark"),
  lastRoute: text("last_route"),
  favorites: jsonb("favorites").$type<string[]>().notNull().default([]),
  aiPersonalization: jsonb("ai_personalization").$type<Record<string, unknown>>().notNull().default({}),
  updatedAt: updatedAt(),
});

/* ============================== CRM CENTRAL ============================== */

export const companies = pgTable("companies", {
  id: id(),
  organizationId: orgId(),
  name: text("name").notNull(),
  normalizedName: text("normalized_name").notNull(), // deduplicação
  domain: text("domain"),
  taxId: text("tax_id"), // CNPJ
  segment: text("segment"),
  region: text("region"),
  size: text("size"),
  employees: integer("employees"),
  technologies: jsonb("technologies").$type<string[]>().notNull().default([]),
  ownerId: uuid("owner_id").references(() => users.id, { onDelete: "set null" }),
  source: text("source"), // proveniência (linhagem)
  createdAt: createdAt(),
  updatedAt: updatedAt(),
}, (t) => [index("company_org_idx").on(t.organizationId), index("company_dedupe_idx").on(t.organizationId, t.normalizedName)]);

export const contacts = pgTable("contacts", {
  id: id(),
  organizationId: orgId(),
  companyId: uuid("company_id").references(() => companies.id, { onDelete: "set null" }),
  name: text("name").notNull(),
  email: text("email"),
  phone: text("phone"),
  jobTitle: text("job_title"),
  consentStatus: text("consent_status").notNull().default("unknown"), // LGPD: granted | denied | unknown
  legalBasis: text("legal_basis"), // LGPD: base legal do tratamento
  source: text("source"),
  createdAt: createdAt(),
  updatedAt: updatedAt(),
}, (t) => [index("contact_org_idx").on(t.organizationId), index("contact_email_idx").on(t.organizationId, t.email)]);

export const leads = pgTable("leads", {
  id: id(),
  organizationId: orgId(),
  companyId: uuid("company_id").references(() => companies.id, { onDelete: "set null" }),
  contactId: uuid("contact_id").references(() => contacts.id, { onDelete: "set null" }),
  title: text("title").notNull(),
  status: text("status").notNull().default("new"), // new | qualifying | qualified | disqualified | converted
  source: text("source").notNull().default("manual"), // prospect_ai | website | whatsapp | referral | import | manual | other
  score: integer("score"),
  scoreExplanation: jsonb("score_explanation").$type<{ factors: { name: string; weight: number; value: number; reason: string }[]; confidence: number; model: string }>(),
  ownerId: uuid("owner_id").references(() => users.id, { onDelete: "set null" }),
  campaignId: uuid("campaign_id"),
  createdAt: createdAt(),
  updatedAt: updatedAt(),
}, (t) => [index("lead_org_idx").on(t.organizationId, t.createdAt)]);

export const pipelines = pgTable("pipelines", {
  id: id(),
  organizationId: orgId(),
  name: text("name").notNull(),
  isDefault: boolean("is_default").notNull().default(false),
  createdAt: createdAt(),
});

export const pipelineStages = pgTable("pipeline_stages", {
  id: id(),
  organizationId: orgId(),
  pipelineId: uuid("pipeline_id").notNull().references(() => pipelines.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  position: integer("position").notNull(),
  probability: integer("probability").notNull().default(10),
  color: text("color").notNull().default("violet"),
  kind: text("kind").notNull().default("open"), // open | won | lost
});

export const opportunities = pgTable("opportunities", {
  id: id(),
  organizationId: orgId(),
  pipelineId: uuid("pipeline_id").notNull().references(() => pipelines.id),
  stageId: uuid("stage_id").notNull().references(() => pipelineStages.id),
  companyId: uuid("company_id").references(() => companies.id, { onDelete: "set null" }),
  contactId: uuid("contact_id").references(() => contacts.id, { onDelete: "set null" }),
  leadId: uuid("lead_id").references(() => leads.id, { onDelete: "set null" }),
  title: text("title").notNull(),
  amountCents: bigint("amount_cents", { mode: "number" }).notNull().default(0),
  currency: text("currency").notNull().default("BRL"),
  status: text("status").notNull().default("open"), // open | won | lost
  lostReason: text("lost_reason"),
  source: text("source"),
  ownerId: uuid("owner_id").references(() => users.id, { onDelete: "set null" }),
  expectedCloseDate: timestamp("expected_close_date", { withTimezone: true }),
  closedAt: timestamp("closed_at", { withTimezone: true }),
  lastActivityAt: timestamp("last_activity_at", { withTimezone: true }).notNull().defaultNow(),
  createdAt: createdAt(),
  updatedAt: updatedAt(),
}, (t) => [index("opp_org_idx").on(t.organizationId, t.status)]);

export const opportunityHistory = pgTable("opportunity_history", {
  id: id(),
  organizationId: orgId(),
  opportunityId: uuid("opportunity_id").notNull().references(() => opportunities.id, { onDelete: "cascade" }),
  fromStageId: uuid("from_stage_id"),
  toStageId: uuid("to_stage_id"),
  changedBy: uuid("changed_by"),
  createdAt: createdAt(),
});

export const products = pgTable("products", {
  id: id(),
  organizationId: orgId(),
  name: text("name").notNull(),
  kind: text("kind").notNull().default("product"), // product | service
  description: text("description"),
  priceCents: bigint("price_cents", { mode: "number" }).notNull().default(0),
  currency: text("currency").notNull().default("BRL"),
  active: boolean("active").notNull().default(true),
  createdAt: createdAt(),
});

export const campaigns = pgTable("campaigns", {
  id: id(),
  organizationId: orgId(),
  name: text("name").notNull(),
  channel: text("channel"),
  status: text("status").notNull().default("active"),
  startsAt: timestamp("starts_at", { withTimezone: true }),
  endsAt: timestamp("ends_at", { withTimezone: true }),
  createdAt: createdAt(),
});

export const activities = pgTable("activities", {
  id: id(),
  organizationId: orgId(),
  type: text("type").notNull(), // call | email | meeting | note | whatsapp | follow_up | stage_change
  subject: text("subject").notNull(),
  body: text("body"),
  userId: uuid("user_id").references(() => users.id, { onDelete: "set null" }),
  companyId: uuid("company_id"),
  contactId: uuid("contact_id"),
  leadId: uuid("lead_id"),
  opportunityId: uuid("opportunity_id"),
  occurredAt: timestamp("occurred_at", { withTimezone: true }).notNull().defaultNow(),
  createdAt: createdAt(),
}, (t) => [index("activity_org_idx").on(t.organizationId, t.occurredAt)]);

export const tasks = pgTable("tasks", {
  id: id(),
  organizationId: orgId(),
  title: text("title").notNull(),
  description: text("description"),
  status: text("status").notNull().default("open"), // open | done | canceled
  priority: text("priority").notNull().default("medium"),
  assigneeId: uuid("assignee_id").references(() => users.id, { onDelete: "set null" }),
  opportunityId: uuid("opportunity_id"),
  leadId: uuid("lead_id"),
  dueAt: timestamp("due_at", { withTimezone: true }),
  completedAt: timestamp("completed_at", { withTimezone: true }),
  // Task Intelligence: bloqueio justificado (suspende escalonamento), andamento informado e última atualização real.
  blockedReason: text("blocked_reason"),
  progressPct: integer("progress_pct"),
  goalId: uuid("goal_id"),
  updatedAt: updatedAt(),
  createdAt: createdAt(),
}, (t) => [index("tasks_org_assignee_idx").on(t.organizationId, t.assigneeId, t.status)]);

export const meetings = pgTable("meetings", {
  id: id(),
  organizationId: orgId(),
  title: text("title").notNull(),
  startsAt: timestamp("starts_at", { withTimezone: true }).notNull(),
  endsAt: timestamp("ends_at", { withTimezone: true }),
  userId: uuid("user_id"),
  contactId: uuid("contact_id"),
  opportunityId: uuid("opportunity_id"),
  status: text("status").notNull().default("scheduled"),
  createdAt: createdAt(),
});

export const proposals = pgTable("proposals", {
  id: id(),
  organizationId: orgId(),
  opportunityId: uuid("opportunity_id").notNull().references(() => opportunities.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  amountCents: bigint("amount_cents", { mode: "number" }).notNull(),
  status: text("status").notNull().default("draft"), // draft | sent | accepted | rejected
  sentAt: timestamp("sent_at", { withTimezone: true }),
  createdAt: createdAt(),
});

/* ============================== PROSPECT.AI ============================== */

export const icpProfiles = pgTable("icp_profiles", {
  id: id(),
  organizationId: orgId(),
  name: text("name").notNull(),
  criteria: jsonb("criteria").$type<{
    segments: string[]; regions: string[]; sizes: string[]; minEmployees?: number; maxEmployees?: number;
    technologies: string[]; needs: string[]; weights?: Record<string, number>;
  }>().notNull(),
  active: boolean("active").notNull().default(true),
  createdAt: createdAt(),
});

export const cadences = pgTable("cadences", {
  id: id(),
  organizationId: orgId(),
  name: text("name").notNull(),
  steps: jsonb("steps").$type<{ day: number; channel: string; template: string }[]>().notNull().default([]),
  active: boolean("active").notNull().default(true),
  createdAt: createdAt(),
});

/* ============================== CLOSER.AI ============================== */

export const conversations = pgTable("conversations", {
  id: id(),
  organizationId: orgId(),
  channel: text("channel").notNull(), // whatsapp | email | webchat | instagram
  contactId: uuid("contact_id").references(() => contacts.id, { onDelete: "set null" }),
  leadId: uuid("lead_id"),
  subject: text("subject"),
  status: text("status").notNull().default("open"), // open | waiting | handoff | closed
  assigneeId: uuid("assignee_id"),
  aiEnabled: boolean("ai_enabled").notNull().default(true),
  intent: text("intent"),
  summary: text("summary"),
  slaDueAt: timestamp("sla_due_at", { withTimezone: true }),
  lastMessageAt: timestamp("last_message_at", { withTimezone: true }).notNull().defaultNow(),
  createdAt: createdAt(),
}, (t) => [index("conv_org_idx").on(t.organizationId, t.lastMessageAt)]);

export const messages = pgTable("messages", {
  id: id(),
  organizationId: orgId(),
  conversationId: uuid("conversation_id").notNull().references(() => conversations.id, { onDelete: "cascade" }),
  direction: text("direction").notNull(), // inbound | outbound
  author: text("author").notNull(), // contact | user | ai
  body: text("body").notNull(),
  status: text("status").notNull().default("sent"), // pending_approval | sent | delivered | failed | simulated
  externalId: text("external_id"),
  createdAt: createdAt(),
});

export const knowledgeDocuments = pgTable("knowledge_documents", {
  id: id(),
  organizationId: orgId(),
  title: text("title").notNull(),
  kind: text("kind").notNull().default("text"), // text | faq | pricing | policy | catalog
  content: text("content").notNull(),
  createdAt: createdAt(),
});

export const knowledgeChunks = pgTable("knowledge_chunks", {
  id: id(),
  organizationId: orgId(),
  documentId: uuid("document_id").notNull().references(() => knowledgeDocuments.id, { onDelete: "cascade" }),
  content: text("content").notNull(),
  embedding: vector("embedding", { dimensions: 256 }),
});

/* ============================== EVENT ENGINE ============================== */

/** Transactional outbox: eventos gravados na mesma transação da mudança de domínio. */
export const events = pgTable("events", {
  id: id(),
  organizationId: uuid("organization_id"),
  type: text("type").notNull(),
  version: integer("version").notNull().default(1),
  payload: jsonb("payload").$type<Record<string, unknown>>().notNull(),
  idempotencyKey: text("idempotency_key"),
  correlationId: text("correlation_id"),
  causationId: text("causation_id"),
  status: text("status").notNull().default("pending"), // pending | processing | done | failed | dead
  attempts: integer("attempts").notNull().default(0),
  maxAttempts: integer("max_attempts").notNull().default(5),
  nextAttemptAt: timestamp("next_attempt_at", { withTimezone: true }).notNull().defaultNow(),
  lastError: text("last_error"),
  processedAt: timestamp("processed_at", { withTimezone: true }),
  createdAt: createdAt(),
}, (t) => [uniqueIndex("event_idem_uq").on(t.idempotencyKey), index("event_status_idx").on(t.status, t.nextAttemptAt)]);

export const eventHandlerRuns = pgTable("event_handler_runs", {
  id: id(),
  eventId: uuid("event_id").notNull().references(() => events.id, { onDelete: "cascade" }),
  handler: text("handler").notNull(),
  status: text("status").notNull(), // done | failed
  error: text("error"),
  createdAt: createdAt(),
}, (t) => [uniqueIndex("handler_once_uq").on(t.eventId, t.handler, t.status)]);

/* ============================== WORKFLOW ENGINE ============================== */

export type WorkflowNode = {
  id: string;
  type: "trigger" | "condition" | "action" | "wait" | "approval" | "end";
  config: Record<string, unknown>;
  next?: string | null;
  nextFalse?: string | null; // ramificação para condições
};

export const workflows = pgTable("workflows", {
  id: id(),
  organizationId: orgId(),
  name: text("name").notNull(),
  description: text("description"),
  triggerEvent: text("trigger_event").notNull(),
  status: text("status").notNull().default("draft"), // draft | active | paused
  currentVersion: integer("current_version").notNull().default(1),
  createdBy: uuid("created_by"),
  createdAt: createdAt(),
  updatedAt: updatedAt(),
});

export const workflowVersions = pgTable("workflow_versions", {
  id: id(),
  organizationId: orgId(),
  workflowId: uuid("workflow_id").notNull().references(() => workflows.id, { onDelete: "cascade" }),
  version: integer("version").notNull(),
  definition: jsonb("definition").$type<{ nodes: WorkflowNode[]; entry: string }>().notNull(),
  createdAt: createdAt(),
}, (t) => [uniqueIndex("wf_version_uq").on(t.workflowId, t.version)]);

export const workflowRuns = pgTable("workflow_runs", {
  id: id(),
  organizationId: orgId(),
  workflowId: uuid("workflow_id").notNull().references(() => workflows.id, { onDelete: "cascade" }),
  version: integer("version").notNull(),
  eventId: uuid("event_id"),
  status: text("status").notNull().default("running"), // running | waiting_approval | completed | failed | simulated
  depth: integer("depth").notNull().default(0), // proteção contra loops
  log: jsonb("log").$type<{ node: string; status: string; message: string; at: string }[]>().notNull().default([]),
  error: text("error"),
  createdAt: createdAt(),
  finishedAt: timestamp("finished_at", { withTimezone: true }),
}, (t) => [uniqueIndex("wf_run_once_uq").on(t.workflowId, t.eventId)]);

export const approvalRequests = pgTable("approval_requests", {
  id: id(),
  organizationId: orgId(),
  kind: text("kind").notNull(), // ai_message | workflow_step | discount | export
  title: text("title").notNull(),
  payload: jsonb("payload").$type<Record<string, unknown>>().notNull(),
  status: text("status").notNull().default("pending"), // pending | approved | rejected
  requestedBy: text("requested_by").notNull(), // user id ou "ai:<agent>"
  decidedBy: uuid("decided_by"),
  decidedAt: timestamp("decided_at", { withTimezone: true }),
  createdAt: createdAt(),
});

/* ============================== IA ============================== */

export const aiAgents = pgTable("ai_agents", {
  id: id(),
  organizationId: orgId(),
  key: text("key").notNull(), // prospecting | research | scoring | outreach | support_chat | qualification | follow_up | intelligence | reporting | automation | support | executive
  name: text("name").notNull(),
  objective: text("objective").notNull(),
  model: text("model").notNull().default("auto"),
  autonomy: text("autonomy").notNull().default("suggest"), // suggest | approve | autonomous (ações sensíveis sempre exigem aprovação)
  // AI Control Plane (v4): 1 observe · 2 analyze · 3 prepare · 4 approve_execute · 5 controlled_autonomous
  autonomyLevel: integer("autonomy_level").notNull().default(2),
  status: text("status").notNull().default("active"), // active | paused | suspended | retired
  domain: text("domain").notNull().default("commercial"),
  ownerUserId: uuid("owner_user_id"),
  monthlyCreditBudget: integer("monthly_credit_budget"), // null = sem orçamento mensal próprio (vale o da organização)
  tools: jsonb("tools").$type<string[]>().notNull().default([]),
  permissions: jsonb("permissions").$type<string[]>().notNull().default([]),
  limits: jsonb("limits").$type<{ maxTokensPerRun: number; maxCreditsPerDay: number }>().notNull().default({ maxTokensPerRun: 4000, maxCreditsPerDay: 500 }),
  activeVersion: integer("active_version").notNull().default(1),
  enabled: boolean("enabled").notNull().default(true),
  createdAt: createdAt(),
}, (t) => [uniqueIndex("agent_org_key_uq").on(t.organizationId, t.key)]);

export const aiPromptVersions = pgTable("ai_prompt_versions", {
  id: id(),
  organizationId: orgId(),
  agentId: uuid("agent_id").notNull().references(() => aiAgents.id, { onDelete: "cascade" }),
  version: integer("version").notNull(),
  systemPrompt: text("system_prompt").notNull(),
  status: text("status").notNull().default("draft"), // draft | approved | retired
  evalScore: real("eval_score"),
  createdAt: createdAt(),
}, (t) => [uniqueIndex("prompt_version_uq").on(t.agentId, t.version)]);

export const aiExecutions = pgTable("ai_executions", {
  id: id(),
  organizationId: orgId(),
  agentKey: text("agent_key").notNull(),
  provider: text("provider").notNull(),
  model: text("model").notNull(),
  promptVersion: integer("prompt_version"),
  input: text("input").notNull(),
  output: text("output"),
  status: text("status").notNull(), // success | error | blocked | fallback
  simulated: boolean("simulated").notNull().default(false),
  inputTokens: integer("input_tokens").notNull().default(0),
  outputTokens: integer("output_tokens").notNull().default(0),
  credits: integer("credits").notNull().default(0),
  latencyMs: integer("latency_ms").notNull().default(0),
  userId: uuid("user_id"),
  feedback: integer("feedback"), // -1 | 1
  createdAt: createdAt(),
}, (t) => [index("ai_exec_org_idx").on(t.organizationId, t.createdAt)]);

export const aiEvalCases = pgTable("ai_eval_cases", {
  id: id(),
  organizationId: orgId(),
  agentKey: text("agent_key").notNull(),
  name: text("name").notNull(),
  input: text("input").notNull(),
  mustInclude: jsonb("must_include").$type<string[]>().notNull().default([]),
  mustNotInclude: jsonb("must_not_include").$type<string[]>().notNull().default([]),
  adversarial: boolean("adversarial").notNull().default(false),
  locale: text("locale").notNull().default("pt-BR"),
  createdAt: createdAt(),
});

export const aiEvalRuns = pgTable("ai_eval_runs", {
  id: id(),
  organizationId: orgId(),
  agentKey: text("agent_key").notNull(),
  promptVersion: integer("prompt_version").notNull(),
  model: text("model").notNull(),
  passed: integer("passed").notNull(),
  total: integer("total").notNull(),
  avgLatencyMs: integer("avg_latency_ms").notNull(),
  results: jsonb("results").$type<{ caseId: string; passed: boolean; reason: string }[]>().notNull(),
  createdAt: createdAt(),
});

/* ============================== BILLING / ENTITLEMENTS ============================== */

export const plans = pgTable("plans", {
  id: id(),
  key: text("key").notNull(), // starter | growth | business | enterprise
  name: text("name").notNull(),
  // Preços ainda NÃO validados comercialmente (seção 30) — campo pode ser nulo = "sob consulta / a definir".
  monthlyPriceCents: bigint("monthly_price_cents", { mode: "number" }),
  annualDiscountPct: integer("annual_discount_pct").notNull().default(0),
  currency: text("currency").notNull().default("BRL"),
  includedCredits: integer("included_credits").notNull().default(0),
  limits: jsonb("limits").$type<Record<string, number>>().notNull(), // users, leads, messages, agents, automations, integrations, storage_mb
  features: jsonb("features").$type<string[]>().notNull(),
  trialDays: integer("trial_days").notNull().default(7),
  active: boolean("active").notNull().default(true),
}, (t) => [uniqueIndex("plan_key_uq").on(t.key)]);

export const subscriptions = pgTable("subscriptions", {
  id: id(),
  organizationId: orgId(),
  planId: uuid("plan_id").notNull().references(() => plans.id),
  status: text("status").notNull().default("trialing"), // trialing | active | past_due | suspended | canceled
  billingCycle: text("billing_cycle").notNull().default("monthly"),
  overageAuthorized: boolean("overage_authorized").notNull().default(false),
  overageCapCents: bigint("overage_cap_cents", { mode: "number" }).notNull().default(0),
  trialEndsAt: timestamp("trial_ends_at", { withTimezone: true }),
  currentPeriodStart: timestamp("current_period_start", { withTimezone: true }).notNull().defaultNow(),
  currentPeriodEnd: timestamp("current_period_end", { withTimezone: true }).notNull(),
  contractExceptions: jsonb("contract_exceptions").$type<Record<string, number>>().notNull().default({}),
  provider: text("provider").notNull().default("manual"), // manual | stripe | mercadopago | asaas
  createdAt: createdAt(),
});

export const creditWallets = pgTable("credit_wallets", {
  id: id(),
  organizationId: orgId(),
  balance: integer("balance").notNull().default(0),
  monthlyAllowance: integer("monthly_allowance").notNull().default(0),
  usedThisPeriod: integer("used_this_period").notNull().default(0),
  updatedAt: updatedAt(),
}, (t) => [uniqueIndex("wallet_org_uq").on(t.organizationId)]);

export const creditTransactions = pgTable("credit_transactions", {
  id: id(),
  organizationId: orgId(),
  amount: integer("amount").notNull(), // positivo = crédito, negativo = consumo
  reason: text("reason").notNull(),
  referenceId: text("reference_id"),
  teamId: uuid("team_id"),
  agentKey: text("agent_key"),
  createdAt: createdAt(),
});

export const usageRecords = pgTable("usage_records", {
  id: id(),
  organizationId: orgId(),
  metric: text("metric").notNull(), // users | leads | messages | tokens | agents | automations | integrations | storage_mb | reports
  quantity: integer("quantity").notNull(),
  periodStart: timestamp("period_start", { withTimezone: true }).notNull(),
  createdAt: createdAt(),
}, (t) => [index("usage_org_metric_idx").on(t.organizationId, t.metric, t.periodStart)]);

export const invoices = pgTable("invoices", {
  id: id(),
  organizationId: orgId(),
  number: text("number").notNull(),
  amountCents: bigint("amount_cents", { mode: "number" }).notNull(),
  currency: text("currency").notNull().default("BRL"),
  status: text("status").notNull().default("open"), // draft | open | paid | void | uncollectible
  lines: jsonb("lines").$type<{ description: string; amountCents: number }[]>().notNull(),
  dueAt: timestamp("due_at", { withTimezone: true }).notNull(),
  paidAt: timestamp("paid_at", { withTimezone: true }),
  createdAt: createdAt(),
});

export const payments = pgTable("payments", {
  id: id(),
  organizationId: orgId(),
  invoiceId: uuid("invoice_id").references(() => invoices.id),
  provider: text("provider").notNull(),
  externalId: text("external_id"),
  amountCents: bigint("amount_cents", { mode: "number" }).notNull(),
  status: text("status").notNull(), // pending | confirmed | failed | refunded
  createdAt: createdAt(),
});

export const coupons = pgTable("coupons", {
  id: id(),
  code: text("code").notNull(),
  percentOff: integer("percent_off").notNull(),
  maxRedemptions: integer("max_redemptions"),
  redemptions: integer("redemptions").notNull().default(0),
  createdBy: uuid("created_by").notNull(), // apenas admins globais
  expiresAt: timestamp("expires_at", { withTimezone: true }),
  createdAt: createdAt(),
}, (t) => [uniqueIndex("coupon_code_uq").on(t.code)]);

export const featureFlags = pgTable("feature_flags", {
  id: id(),
  key: text("key").notNull(),
  description: text("description").notNull(),
  enabled: boolean("enabled").notNull().default(false),
  rolloutPct: integer("rollout_pct").notNull().default(0),
  plans: jsonb("plans").$type<string[]>().notNull().default([]),
  segments: jsonb("segments").$type<string[]>().notNull().default([]),
  createdAt: createdAt(),
}, (t) => [uniqueIndex("flag_key_uq").on(t.key)]);

export const featureFlagOverrides = pgTable("feature_flag_overrides", {
  id: id(),
  flagKey: text("flag_key").notNull(),
  organizationId: uuid("organization_id"),
  userId: uuid("user_id"),
  enabled: boolean("enabled").notNull(),
  createdAt: createdAt(),
});

/* ============================== METAS / COMISSÕES ============================== */

export const goals = pgTable("goals", {
  id: id(),
  organizationId: orgId(),
  name: text("name").notNull(),
  metric: text("metric").notNull(), // revenue | deals_won | leads | meetings
  scope: text("scope").notNull().default("organization"), // organization | team | user | product | channel
  scopeId: text("scope_id"),
  targetValue: bigint("target_value", { mode: "number" }).notNull(),
  periodStart: timestamp("period_start", { withTimezone: true }).notNull(),
  periodEnd: timestamp("period_end", { withTimezone: true }).notNull(),
  createdAt: createdAt(),
});

export const commissionRules = pgTable("commission_rules", {
  id: id(),
  organizationId: orgId(),
  name: text("name").notNull(),
  version: integer("version").notNull().default(1),
  ratePct: real("rate_pct").notNull(),
  acceleratorPct: real("accelerator_pct").notNull().default(0), // acima de 100% da meta
  active: boolean("active").notNull().default(true),
  createdBy: uuid("created_by"),
  createdAt: createdAt(),
});

/* ============================== DATA INTELLIGENCE ============================== */

export const metricDefinitions = pgTable("metric_definitions", {
  id: id(),
  key: text("key").notNull(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  formula: text("formula").notNull(),
  source: text("source").notNull(),
  dimensions: jsonb("dimensions").$type<string[]>().notNull().default([]),
  periodicity: text("periodicity").notNull().default("daily"),
  version: integer("version").notNull().default(1),
  owner: text("owner").notNull(),
}, (t) => [uniqueIndex("metric_key_uq").on(t.key, t.version)]);

export const dataSources = pgTable("data_sources", {
  id: id(),
  organizationId: orgId(),
  name: text("name").notNull(),
  kind: text("kind").notNull(), // csv | integration | manual | public_api
  classification: text("classification").notNull().default("internal"), // public | internal | confidential | personal
  legalBasis: text("legal_basis"),
  retentionDays: integer("retention_days"),
  recordsImported: integer("records_imported").notNull().default(0),
  createdAt: createdAt(),
});

/* ============================== INTEGRAÇÕES ============================== */

export const integrations = pgTable("integrations", {
  id: id(),
  organizationId: orgId(),
  provider: text("provider").notNull(),
  category: text("category").notNull(),
  status: text("status").notNull().default("disconnected"), // disconnected | connected | error | simulated
  mode: text("mode").notNull().default("real"), // real | simulated  (simulações sempre identificadas)
  encryptedCredentials: text("encrypted_credentials"),
  config: jsonb("config").$type<Record<string, unknown>>().notNull().default({}),
  lastSyncAt: timestamp("last_sync_at", { withTimezone: true }),
  lastError: text("last_error"),
  createdAt: createdAt(),
}, (t) => [uniqueIndex("integration_org_provider_uq").on(t.organizationId, t.provider)]);

export const integrationLogs = pgTable("integration_logs", {
  id: id(),
  organizationId: orgId(),
  integrationId: uuid("integration_id").notNull().references(() => integrations.id, { onDelete: "cascade" }),
  level: text("level").notNull(),
  message: text("message").notNull(),
  createdAt: createdAt(),
});

/* ============================== NOTIFICAÇÕES / AUDITORIA ============================== */

export const notifications = pgTable("notifications", {
  id: id(),
  organizationId: orgId(),
  userId: uuid("user_id"),
  title: text("title").notNull(),
  body: text("body"),
  href: text("href"),
  alertId: uuid("alert_id"), // alerta de tarefa que originou a notificação (leitura da notificação ≠ leitura do alerta)
  priority: text("priority"),
  readAt: timestamp("read_at", { withTimezone: true }),
  createdAt: createdAt(),
});

export const auditLogs = pgTable("audit_logs", {
  id: id(),
  organizationId: uuid("organization_id"),
  actorId: text("actor_id"), // user id, "ai:<agent>" ou "system"
  action: text("action").notNull(),
  resource: text("resource").notNull(),
  resourceId: text("resource_id"),
  metadata: jsonb("metadata").$type<Record<string, unknown>>().notNull().default({}),
  ip: text("ip"),
  createdAt: createdAt(),
}, (t) => [index("audit_org_idx").on(t.organizationId, t.createdAt)]);

/* ============================== CUSTOMER SUCCESS / SUPORTE ============================== */

export const healthScoreConfig = pgTable("health_score_config", {
  id: id(),
  weights: jsonb("weights").$type<Record<string, number>>().notNull(),
  thresholds: jsonb("thresholds").$type<{ healthy: number; attention: number; risk: number }>().notNull(),
  updatedAt: updatedAt(),
});

export const csInteractions = pgTable("cs_interactions", {
  id: id(),
  organizationId: orgId(), // cliente atendido
  type: text("type").notNull(), // call | email | meeting | playbook | task
  note: text("note").notNull(),
  status: text("status").notNull().default("open"),
  authorId: uuid("author_id"),
  createdAt: createdAt(),
});

export const supportTickets = pgTable("support_tickets", {
  id: id(),
  organizationId: orgId(),
  subject: text("subject").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull().default("geral"),
  priority: text("priority").notNull().default("medium"), // low | medium | high | urgent
  status: text("status").notNull().default("open"), // open | in_progress | escalated | resolved
  requesterId: uuid("requester_id"),
  slaDueAt: timestamp("sla_due_at", { withTimezone: true }).notNull(),
  satisfaction: integer("satisfaction"),
  createdAt: createdAt(),
  resolvedAt: timestamp("resolved_at", { withTimezone: true }),
});

/* ============================== EXPERIMENTOS / INCIDENTES ============================== */

export const experiments = pgTable("experiments", {
  id: id(),
  key: text("key").notNull(),
  hypothesis: text("hypothesis").notNull(),
  objective: text("objective").notNull(),
  audience: text("audience").notNull(),
  variants: jsonb("variants").$type<{ key: string; weight: number; exposures: number; conversions: number }[]>().notNull(),
  primaryMetric: text("primary_metric").notNull(),
  secondaryMetrics: jsonb("secondary_metrics").$type<string[]>().notNull().default([]),
  owner: text("owner").notNull(),
  status: text("status").notNull().default("draft"), // draft | running | stopped | concluded
  conclusion: text("conclusion"),
  startsAt: timestamp("starts_at", { withTimezone: true }),
  endsAt: timestamp("ends_at", { withTimezone: true }),
  createdAt: createdAt(),
}, (t) => [uniqueIndex("experiment_key_uq").on(t.key)]);

export const incidents = pgTable("incidents", {
  id: id(),
  title: text("title").notNull(),
  category: text("category").notNull(), // security | availability | database | integrations | ai | billing | queues | performance | ux
  severity: text("severity").notNull(), // sev1 | sev2 | sev3 | sev4
  status: text("status").notNull().default("investigating"), // investigating | identified | monitoring | resolved | postmortem
  ownerId: uuid("owner_id"),
  impact: text("impact"),
  affectedOrganizations: jsonb("affected_organizations").$type<string[]>().notNull().default([]),
  rootCause: text("root_cause"),
  correctiveActions: text("corrective_actions"),
  timeline: jsonb("timeline").$type<{ at: string; by: string; note: string }[]>().notNull().default([]),
  createdAt: createdAt(),
  resolvedAt: timestamp("resolved_at", { withTimezone: true }),
});

/* =====================================================================================
 * MASTER PROMPT 4.0 — CICLO 1
 * Financial Intelligence · Intelligence Layer (Evidence/Decision/Outcome) · Business Brain ·
 * Strategy Simulator · AI Control Plane
 * ===================================================================================== */

/** Tipo de evidência usado por insights, decisões, cenários e briefings (Evidence Engine). */
export type Evidence = {
  facts: { label: string; value: string; source: string; period?: string }[];
  assumptions: string[];
  calculations: string[];
  confidence: number; // 0..1
  missingData: string[];
  limitations: string[];
};

export const financeCategories = pgTable("finance_categories", {
  id: id(),
  organizationId: orgId(),
  name: text("name").notNull(),
  kind: text("kind").notNull(), // revenue | expense
  group: text("group").notNull().default("operacional"), // receita_bruta | deducoes | custo | operacional | pessoal | marketing | financeiro | impostos | outros
  createdAt: createdAt(),
}, (t) => [uniqueIndex("fin_cat_org_name_uq").on(t.organizationId, t.name, t.kind)]);

export const financeEntries = pgTable("finance_entries", {
  id: id(),
  organizationId: orgId(),
  kind: text("kind").notNull(), // receivable | payable
  description: text("description").notNull(),
  categoryId: uuid("category_id").references(() => financeCategories.id, { onDelete: "set null" }),
  costCenter: text("cost_center"),
  amountCents: bigint("amount_cents", { mode: "number" }).notNull(),
  currency: text("currency").notNull().default("BRL"),
  dueDate: timestamp("due_date", { withTimezone: true }).notNull(),
  paidAt: timestamp("paid_at", { withTimezone: true }),
  status: text("status").notNull().default("open"), // open | paid | canceled
  companyId: uuid("company_id").references(() => companies.id, { onDelete: "set null" }),
  productId: uuid("product_id").references(() => products.id, { onDelete: "set null" }),
  opportunityId: uuid("opportunity_id").references(() => opportunities.id, { onDelete: "set null" }),
  source: text("source").notNull().default("manual"), // manual | crm | stripe | mercadopago | asaas | erp
  externalId: text("external_id"),
  createdBy: uuid("created_by"),
  createdAt: createdAt(),
}, (t) => [index("fin_entry_org_due_idx").on(t.organizationId, t.dueDate), index("fin_entry_org_status_idx").on(t.organizationId, t.status)]);

export const financeBudgets = pgTable("finance_budgets", {
  id: id(),
  organizationId: orgId(),
  categoryId: uuid("category_id").notNull().references(() => financeCategories.id, { onDelete: "cascade" }),
  month: text("month").notNull(), // YYYY-MM
  amountCents: bigint("amount_cents", { mode: "number" }).notNull(),
  createdAt: createdAt(),
}, (t) => [uniqueIndex("fin_budget_uq").on(t.organizationId, t.categoryId, t.month)]);

/** Insights da Intelligence Layer: recomendações com evidência e ciclo de vida (Outcome Engine). */
export const insights = pgTable("insights", {
  id: id(),
  organizationId: orgId(),
  ruleKey: text("rule_key").notNull(), // regra determinística que gerou o insight
  dedupeKey: text("dedupe_key").notNull(), // evita duplicar o mesmo insight aberto
  domain: text("domain").notNull(), // sales | prospect | engagement | finance | customer | ai | operations
  nature: text("nature").notNull().default("recommendation"), // fact | inference | estimate | recommendation
  title: text("title").notNull(),
  summary: text("summary").notNull(),
  priority: text("priority").notNull().default("medium"), // high | medium | low
  evidence: jsonb("evidence").$type<Evidence>().notNull(),
  recommendedAction: text("recommended_action"),
  indicator: jsonb("indicator").$type<{ metric: string; baseline: number; target?: number; unit: string; direction: "up" | "down" }>(),
  link: text("link"),
  status: text("status").notNull().default("open"), // open | accepted | modified | rejected | executed | canceled | expired
  decidedBy: uuid("decided_by"),
  decidedAt: timestamp("decided_at", { withTimezone: true }),
  decisionNote: text("decision_note"),
  executedAt: timestamp("executed_at", { withTimezone: true }),
  outcome: jsonb("outcome").$type<{ observed: number; measuredAt: string; verdict: "improved" | "no_change" | "worse" | "inconclusive"; note: string }>(),
  createdAt: createdAt(),
}, (t) => [index("insight_org_status_idx").on(t.organizationId, t.status), index("insight_org_dedupe_idx").on(t.organizationId, t.dedupeKey)]);

/** Decision Engine: registro de decisões com alternativas, aprovação e monitoramento. */
export const decisions = pgTable("decisions", {
  id: id(),
  organizationId: orgId(),
  title: text("title").notNull(),
  problem: text("problem").notNull(),
  alternatives: jsonb("alternatives").$type<{ name: string; description: string; estimatedImpact: string; risks: string }[]>().notNull().default([]),
  chosenAlternative: text("chosen_alternative"),
  rationale: text("rationale"),
  status: text("status").notNull().default("draft"), // draft | pending_approval | approved | rejected | monitoring | closed
  insightId: uuid("insight_id").references(() => insights.id, { onDelete: "set null" }),
  scenarioId: uuid("scenario_id"),
  evidence: jsonb("evidence").$type<Evidence>(),
  reviewAt: timestamp("review_at", { withTimezone: true }),
  result: text("result"),
  createdBy: uuid("created_by").notNull(),
  approvedBy: uuid("approved_by"),
  approvedAt: timestamp("approved_at", { withTimezone: true }),
  createdAt: createdAt(),
}, (t) => [index("decision_org_idx").on(t.organizationId, t.status)]);

/** Strategy Simulator: cenários salvos com premissas, linha de base e resultados. */
export const scenarios = pgTable("scenarios", {
  id: id(),
  organizationId: orgId(),
  name: text("name").notNull(),
  kind: text("kind").notNull(), // price | cost | hiring | volume | conversion | marketing | churn | custom
  baseline: jsonb("baseline").$type<Record<string, number>>().notNull(),
  variables: jsonb("variables").$type<Record<string, number>>().notNull(),
  results: jsonb("results").$type<Record<string, unknown>>().notNull(),
  evidence: jsonb("evidence").$type<Evidence>().notNull(),
  status: text("status").notNull().default("draft"), // draft | submitted | approved | rejected
  createdBy: uuid("created_by").notNull(),
  approvedBy: uuid("approved_by"),
  approvedAt: timestamp("approved_at", { withTimezone: true }),
  createdAt: createdAt(),
}, (t) => [index("scenario_org_idx").on(t.organizationId, t.createdAt)]);

/** Business Brain: briefings executivos gerados a partir de dados (diário/semanal/mensal/trimestral). */
export const briefings = pgTable("briefings", {
  id: id(),
  organizationId: orgId(),
  period: text("period").notNull(), // daily | weekly | monthly | quarterly
  periodStart: timestamp("period_start", { withTimezone: true }).notNull(),
  periodEnd: timestamp("period_end", { withTimezone: true }).notNull(),
  content: jsonb("content").$type<Record<string, unknown>>().notNull(),
  generatedBy: uuid("generated_by"),
  createdAt: createdAt(),
}, (t) => [index("briefing_org_idx").on(t.organizationId, t.period, t.createdAt)]);

/** AI Control Plane: kill switches. organizationId nulo = interrupção global da plataforma. */
export const killSwitches = pgTable("kill_switches", {
  id: id(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: "cascade" }),
  scope: text("scope").notNull(), // all_ai | agent | agent_domain | integration | tool | workflow | action_category
  target: text("target").notNull().default("*"),
  reason: text("reason").notNull(),
  active: boolean("active").notNull().default(true),
  createdBy: uuid("created_by").notNull(),
  releasedBy: uuid("released_by"),
  releasedAt: timestamp("released_at", { withTimezone: true }),
  createdAt: createdAt(),
}, (t) => [index("kill_switch_active_idx").on(t.organizationId, t.active)]);

/** AI Control Plane: orçamentos de IA por organização, agente ou modelo. */
export const aiBudgets = pgTable("ai_budgets", {
  id: id(),
  organizationId: orgId(),
  scope: text("scope").notNull(), // organization | agent | model
  target: text("target").notNull().default("*"),
  monthlyCredits: integer("monthly_credits").notNull(),
  alertPct: integer("alert_pct").notNull().default(80),
  hardStop: boolean("hard_stop").notNull().default(true),
  createdAt: createdAt(),
}, (t) => [uniqueIndex("ai_budget_uq").on(t.organizationId, t.scope, t.target)]);

/* =====================================================================================
 * MASTER PROMPT 4.0 — ADIÇÕES
 * (1) Colaboração humano × IA em sugestões (rascunhos versionados, ilimitados, editáveis)
 * (2) Business Brain via Flávio (investigações persistidas com contexto)
 * ===================================================================================== */

/** Rascunho de resposta/texto sugerido pela IA em qualquer módulo (Closer.AI, Prospect.AI…). */
export const aiDrafts = pgTable("ai_drafts", {
  id: id(),
  organizationId: orgId(),
  module: text("module").notNull(), // closer | prospect | …
  subjectType: text("subject_type").notNull(), // conversation | lead | …
  subjectId: uuid("subject_id").notNull(),
  agentKey: text("agent_key").notNull(),
  channel: text("channel"), // canal alvo quando aplicável (whatsapp, email, linkedin…)
  status: text("status").notNull().default("open"), // open | manual | pending_approval | sent | copied | discarded
  createdBy: uuid("created_by").notNull(),
  sentVersionId: uuid("sent_version_id"),
  sentMessageId: uuid("sent_message_id"),
  sentBy: uuid("sent_by"),
  sentAt: timestamp("sent_at", { withTimezone: true }),
  discardReason: text("discard_reason"), // preferencia_de_abordagem | tom | informacao_incorreta | muito_longa | muito_curta | outro
  discardNote: text("discard_note"),
  createdAt: createdAt(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [index("ai_draft_subject_idx").on(t.organizationId, t.module, t.subjectId), index("ai_draft_status_idx").on(t.organizationId, t.status)]);

/** Versões de um rascunho: sugestões da IA, revisões por instrução e edições manuais. Nunca sobrescritas. */
export const aiDraftVersions = pgTable("ai_draft_versions", {
  id: id(),
  organizationId: orgId(),
  draftId: uuid("draft_id").notNull().references(() => aiDrafts.id, { onDelete: "cascade" }),
  seq: integer("seq").notNull(),
  origin: text("origin").notNull(), // ai | human
  operation: text("operation").notNull(), // initial | regenerate | instruct | tone | shorten | expand | persuasive | negotiate | fix | adapt | custom | improve_selection | spellcheck | manual_edit | restore
  instruction: text("instruction"),
  content: text("content").notNull(),
  basedOnVersionId: uuid("based_on_version_id"),
  executionId: uuid("execution_id"),
  simulated: boolean("simulated").notNull().default(false),
  provider: text("provider"),
  model: text("model"),
  sources: jsonb("sources").$type<{ title: string; similarity?: number }[]>().notNull().default([]),
  rejected: boolean("rejected").notNull().default(false), // a IA não deve repetir abordagens rejeitadas
  createdBy: uuid("created_by").notNull(),
  createdAt: createdAt(),
}, (t) => [uniqueIndex("ai_draft_version_seq_uq").on(t.draftId, t.seq)]);

/** Investigações do Flávio / Business Brain (conversas persistidas com contexto). */
export const flavioConversations = pgTable("flavio_conversations", {
  id: id(),
  organizationId: orgId(),
  userId: uuid("user_id").notNull(),
  title: text("title").notNull(),
  surface: text("surface").notNull().default("brain"), // brain | dock
  status: text("status").notNull().default("active"), // active | archived
  context: jsonb("context").$type<Record<string, unknown>>().notNull().default({}), // tema, período, entidades, última análise
  createdAt: createdAt(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [index("flavio_conv_user_idx").on(t.organizationId, t.userId, t.updatedAt)]);

export const flavioMessages = pgTable("flavio_messages", {
  id: id(),
  organizationId: orgId(),
  conversationId: uuid("conversation_id").notNull().references(() => flavioConversations.id, { onDelete: "cascade" }),
  role: text("role").notNull(), // user | assistant
  content: text("content").notNull(),
  payload: jsonb("payload").$type<Record<string, unknown>>(), // resposta estruturada: seções, evidências, ferramentas, gráficos, ações
  executionId: uuid("execution_id"),
  createdAt: createdAt(),
}, (t) => [index("flavio_msg_conv_idx").on(t.conversationId, t.createdAt)]);

/* ============================== ORBITY TASK INTELLIGENCE (alertas, escalonamento, prorrogação) ============================== */

/** Estados: draft | scheduled | sent | delivered | read | responded | failed | canceled. Envio, entrega e leitura são registrados separadamente. */
export const taskAlerts = pgTable("task_alerts", {
  id: id(),
  organizationId: orgId(),
  taskId: uuid("task_id").notNull().references(() => tasks.id, { onDelete: "cascade" }),
  recipientId: uuid("recipient_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  senderId: uuid("sender_id"), // null = automação/escalonamento
  kind: text("kind").notNull().default("manual"), // manual | automation | escalation
  title: text("title").notNull(),
  message: text("message").notNull(), // mensagem efetivamente enviada
  originalMessage: text("original_message"), // sugestão original do Flávio, quando houver
  messageOrigin: text("message_origin").notNull().default("manual"), // manual | flavio | flavio_edited
  priority: text("priority").notNull().default("medium"), // low | medium | high | urgent
  channels: jsonb("channels").$type<string[]>().notNull().default(["in_app"]),
  channelResults: jsonb("channel_results").$type<Record<string, { status: string; at: string; error?: string }>>().notNull().default({}),
  status: text("status").notNull().default("draft"),
  scheduledAt: timestamp("scheduled_at", { withTimezone: true }),
  sentAt: timestamp("sent_at", { withTimezone: true }),
  deliveredAt: timestamp("delivered_at", { withTimezone: true }),
  readAt: timestamp("read_at", { withTimezone: true }),
  respondedAt: timestamp("responded_at", { withTimezone: true }),
  canceledAt: timestamp("canceled_at", { withTimezone: true }),
  failureReason: text("failure_reason"),
  taskDueAtSnapshot: timestamp("task_due_at_snapshot", { withTimezone: true }),
  ruleId: uuid("rule_id"),
  parentAlertId: uuid("parent_alert_id"),
  escalationLevel: integer("escalation_level").notNull().default(0),
  idempotencyKey: text("idempotency_key"),
  flavioExecutionId: uuid("flavio_execution_id"),
  simulated: boolean("simulated").notNull().default(false),
  createdAt: createdAt(),
  updatedAt: updatedAt(),
}, (t) => [
  uniqueIndex("task_alert_idem_uq").on(t.organizationId, t.idempotencyKey),
  index("task_alert_task_idx").on(t.organizationId, t.taskId),
  index("task_alert_recipient_idx").on(t.organizationId, t.recipientId, t.status),
  index("task_alert_due_idx").on(t.status, t.scheduledAt),
]);

/** Linha do tempo imutável de cada alerta/tarefa (auditoria de produto). */
export const taskAlertEvents = pgTable("task_alert_events", {
  id: id(),
  organizationId: orgId(),
  taskId: uuid("task_id").notNull().references(() => tasks.id, { onDelete: "cascade" }),
  alertId: uuid("alert_id"),
  type: text("type").notNull(), // created | scheduled | sent | delivered | read | failed | canceled | responded | escalated | extension_requested | extension_decided ...
  actorId: text("actor_id"), // user id, "system" ou "ai:<agente>"
  channel: text("channel"),
  data: jsonb("data").$type<Record<string, unknown>>().notNull().default({}),
  createdAt: createdAt(),
}, (t) => [index("task_alert_ev_task_idx").on(t.organizationId, t.taskId, t.createdAt)]);

/** Respostas e atualizações do responsável. kind: ack | working | need_more_time | delay_justification | blocker | help | comment | progress | done */
export const taskAlertResponses = pgTable("task_alert_responses", {
  id: id(),
  organizationId: orgId(),
  taskId: uuid("task_id").notNull().references(() => tasks.id, { onDelete: "cascade" }),
  alertId: uuid("alert_id"),
  userId: uuid("user_id").notNull(),
  kind: text("kind").notNull(),
  message: text("message"),
  progressPct: integer("progress_pct"),
  evidenceUrl: text("evidence_url"),
  createdAt: createdAt(),
}, (t) => [index("task_alert_resp_task_idx").on(t.organizationId, t.taskId, t.createdAt)]);

export const taskExtensionRequests = pgTable("task_extension_requests", {
  id: id(),
  organizationId: orgId(),
  taskId: uuid("task_id").notNull().references(() => tasks.id, { onDelete: "cascade" }),
  alertId: uuid("alert_id"),
  requesterId: uuid("requester_id").notNull(),
  currentDueAt: timestamp("current_due_at", { withTimezone: true }),
  requestedDueAt: timestamp("requested_due_at", { withTimezone: true }).notNull(),
  justification: text("justification").notNull(),
  blockers: text("blockers"),
  impact: text("impact"),
  status: text("status").notNull().default("pending"), // pending | approved | rejected | countered
  recommendation: jsonb("recommendation").$type<Record<string, unknown>>(), // análise do Flávio: recomenda, nunca decide
  decidedBy: uuid("decided_by"),
  decidedAt: timestamp("decided_at", { withTimezone: true }),
  decidedDueAt: timestamp("decided_due_at", { withTimezone: true }),
  decisionNote: text("decision_note"),
  createdAt: createdAt(),
}, (t) => [index("task_ext_org_idx").on(t.organizationId, t.status)]);

/** Regras de automação e escalonamento. trigger: before_due | on_due | overdue | stale | priority_pending */
export const taskAlertRules = pgTable("task_alert_rules", {
  id: id(),
  organizationId: orgId(),
  name: text("name").notNull(),
  trigger: text("trigger").notNull(),
  offsetMinutes: integer("offset_minutes").notNull().default(1440), // antecedência (before_due)
  staleAfterHours: integer("stale_after_hours").notNull().default(48), // stale
  repeatEveryMinutes: integer("repeat_every_minutes"), // null = sem repetição
  maxReminders: integer("max_reminders").notNull().default(3),
  allowedStartHour: integer("allowed_start_hour").notNull().default(8),
  allowedEndHour: integer("allowed_end_hour").notNull().default(18),
  priorities: jsonb("priorities").$type<string[]>().notNull().default(["low", "medium", "high"]), // prioridades da TAREFA abrangidas
  alertPriority: text("alert_priority").notNull().default("medium"),
  channels: jsonb("channels").$type<string[]>().notNull().default(["in_app"]),
  tone: text("tone"), // sobrescreve o tom da organização
  /** Escalonamento: cada degrau notifica outras pessoas se não houver resposta/atualização após N minutos. */
  escalation: jsonb("escalation").$type<{ enabled: boolean; maxAttempts: number; steps: { afterMinutes: number; userIds: string[] }[] }>()
    .notNull().default({ enabled: false, maxAttempts: 2, steps: [] }),
  active: boolean("active").notNull().default(true),
  createdBy: uuid("created_by"),
  createdAt: createdAt(),
  updatedAt: updatedAt(),
}, (t) => [index("task_rule_org_idx").on(t.organizationId, t.active)]);
