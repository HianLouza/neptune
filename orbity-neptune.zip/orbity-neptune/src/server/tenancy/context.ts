import type { DB } from "../db/client";
import { ForbiddenError, hasPermission, type Permission } from "../permissions";

/** Contexto obrigatório para qualquer operação sobre dados de cliente. */
export type TenantContext = {
  db: DB;
  organizationId: string;
  userId: string;
  roleKey: string;
  permissions: string[];
  isPlatformAdmin: boolean;
  locale: string;
  currency: string;
  timezone: string;
  ip?: string | null;
};

export function requirePerm(ctx: TenantContext, perm: Permission) {
  if (!hasPermission(ctx.permissions, perm)) throw new ForbiddenError(perm);
}
export const can = (ctx: TenantContext, perm: Permission) => hasPermission(ctx.permissions, perm);
