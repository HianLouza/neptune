/** Modelos prontos de automação + criação por linguagem natural (gera RASCUNHO, nunca publica). */
import type { Definition } from "./engine";

export type Template = { key: string; name: string; description: string; triggerEvent: string; definition: Definition };

export const TEMPLATES: Template[] = [
  {
    key: "nutricao", name: "Nutrição de leads novos", description: "Ao criar um lead, cria tarefa de primeiro contato e, após 48h, notifica se ainda estiver novo.",
    triggerEvent: "lead.created",
    definition: { entry: "t", nodes: [
      { id: "t", type: "trigger", config: {}, next: "a1" },
      { id: "a1", type: "action", config: { action: "create_task", title: "Primeiro contato com o lead", dueInHours: 4 }, next: "w" },
      { id: "w", type: "wait", config: { hours: 48 }, next: "a2" },
      { id: "a2", type: "action", config: { action: "notify", title: "Lead sem avanço há 48h", body: "Verifique o lead e registre o contato." }, next: "e" },
      { id: "e", type: "end", config: {} },
    ] },
  },
  {
    key: "lead-quente", name: "Alerta de lead quente", description: "Quando um lead é qualificado, notifica a equipe e cria tarefa prioritária.",
    triggerEvent: "lead.qualified",
    definition: { entry: "t", nodes: [
      { id: "t", type: "trigger", config: {}, next: "a1" },
      { id: "a1", type: "action", config: { action: "notify", title: "Lead qualificado!", body: "Novo lead qualificado aguardando contato." }, next: "a2" },
      { id: "a2", type: "action", config: { action: "create_task", title: "Agendar reunião com lead qualificado", dueInHours: 2 }, next: "e" },
      { id: "e", type: "end", config: {} },
    ] },
  },
  {
    key: "grande-negocio", name: "Aprovação de grandes negócios", description: "Oportunidades acima de R$ 100 mil exigem aprovação do gestor e geram tarefa de revisão.",
    triggerEvent: "opportunity.created",
    definition: { entry: "t", nodes: [
      { id: "t", type: "trigger", config: {}, next: "c" },
      { id: "c", type: "condition", config: { field: "payload.amountCents", op: "gte", value: 10000000 }, next: "ap", nextFalse: "e" },
      { id: "ap", type: "approval", config: { title: "Aprovar acompanhamento de negócio estratégico" }, next: "a1" },
      { id: "a1", type: "action", config: { action: "create_task", title: "Revisão estratégica do negócio", dueInHours: 24 }, next: "e" },
      { id: "e", type: "end", config: {} },
    ] },
  },
  {
    key: "perda", name: "Análise de oportunidade perdida", description: "Ao perder uma oportunidade, registra atividade e agenda follow-up em 30 dias.",
    triggerEvent: "opportunity.lost",
    definition: { entry: "t", nodes: [
      { id: "t", type: "trigger", config: {}, next: "a1" },
      { id: "a1", type: "action", config: { action: "log_activity", subject: "Oportunidade perdida — analisar motivo" }, next: "a2" },
      { id: "a2", type: "action", config: { action: "create_task", title: "Follow-up de reativação", dueInHours: 720 }, next: "e" },
      { id: "e", type: "end", config: {} },
    ] },
  },
  {
    key: "boas-vindas", name: "Resposta inicial em conversas", description: "Ao receber conversa, sugere mensagem de boas-vindas (envio exige aprovação).",
    triggerEvent: "conversation.received",
    definition: { entry: "t", nodes: [
      { id: "t", type: "trigger", config: {}, next: "c" },
      { id: "c", type: "condition", config: { field: "payload.intent", op: "eq", value: "pricing" }, next: "a1", nextFalse: "e" },
      { id: "a1", type: "action", config: { action: "send_message", body: "Olá! Recebemos sua solicitação de orçamento e um especialista vai responder em instantes." }, next: "e" },
      { id: "e", type: "end", config: {} },
    ] },
  },
];

/** Linguagem natural → rascunho (regras determinísticas; com IA configurada o agente de automação pode refinar). */
export function draftFromText(text: string): Template | null {
  const t = text.toLowerCase();
  const trigger = /qualificad/.test(t) ? "lead.qualified" : /lead/.test(t) ? "lead.created" : /perd/.test(t) ? "opportunity.lost"
    : /(oportunidade|neg[oó]cio)/.test(t) ? "opportunity.created" : /(conversa|mensagem|whatsapp)/.test(t) ? "conversation.received"
    : /reuni/.test(t) ? "meeting.scheduled" : /proposta/.test(t) ? "proposal.sent" : null;
  if (!trigger) return null;
  const nodes: Definition["nodes"] = [{ id: "t", type: "trigger", config: {}, next: "n1" }];
  let i = 1;
  const pushNode = (n: Omit<Definition["nodes"][number], "id" | "next">) => { nodes.push({ ...n, id: `n${i}`, next: `n${i + 1}` }); i++; };
  const hours = t.match(/(\d+)\s*(h|hora)/);
  const days = t.match(/(\d+)\s*dia/);
  if (/tarefa/.test(t)) pushNode({ type: "action", config: { action: "create_task", title: "Tarefa criada por automação", dueInHours: 24 } });
  if (hours || days) pushNode({ type: "wait", config: { hours: hours ? Number(hours[1]) : Number(days![1]) * 24 } });
  if (/(notifi|avis|alert)/.test(t)) pushNode({ type: "action", config: { action: "notify", title: "Alerta de automação", body: text.slice(0, 140) } });
  if (/(envi|mensagem|whatsapp|e-?mail)/.test(t)) pushNode({ type: "action", config: { action: "send_message", body: "Mensagem configurada pela automação." } });
  if (/aprova/.test(t)) pushNode({ type: "approval", config: { title: "Aprovação solicitada pela automação" } });
  if (nodes.length === 1) pushNode({ type: "action", config: { action: "notify", title: "Automação executada", body: text.slice(0, 140) } });
  nodes.push({ id: `n${i}`, type: "end", config: {} });
  return { key: "nl", name: `Rascunho: ${text.slice(0, 50)}`, description: text.slice(0, 300), triggerEvent: trigger, definition: { entry: "t", nodes } };
}
