/**
 * WORKFLOW ENGINE
 * Definição: grafo de nós { trigger → condition/action/wait/approval → end }.
 * Garantias:
 *  - Uma execução por (workflow, evento) — índice único evita duplicidade.
 *  - Profundidade máxima de encadeamento (eventos gerados por automações carregam _wfDepth) → impede loops infinitos.
 *  - Máximo de passos por execução.
 *  - Ações sensíveis (enviar mensagem externa, webhook) exigem aprovação humana.
 *  - Simulação sem efeitos colaterais.
 */
import { and, desc, eq } from "drizzle-orm";
import type { DB } from "../db/client";
import { approvalRequests, events, notifications, tasks, leads, activities, workflowRuns, workflowVersions, workflows, type WorkflowNode } from "../db/schema";
import { publish, type EventRecord } from "../events";
import { audit } from "../audit";
import { requirePerm, type TenantContext } from "../tenancy/context";
import { HttpError } from "../http";
import { z } from "zod";
import { assertWithinLimit } from "../domains/billing";
import { workflowBlockReason } from "../ai/control-plane";

export const MAX_DEPTH = 3;
export const MAX_STEPS = 50;
export const SENSITIVE_ACTIONS = new Set(["send_message", "webhook"]);
const WAITING_APPROVAL = "Aguardando aprovação humana";

/** Bloqueia destinos internos (SSRF): só https para hosts públicos. Não resolve DNS — limitação documentada. */
export function isSafeWebhookUrl(raw: string): boolean {
  let u: URL;
  try { u = new URL(raw); } catch { return false; }
  if (u.protocol !== "https:") return false;
  const h = u.hostname.toLowerCase().replace(/^\[|\]$/g, "");
  if (h === "localhost" || h.endsWith(".localhost") || h.endsWith(".local") || h.endsWith(".internal") || h === "::1" || h === "0.0.0.0") return false;
  const m = h.match(/^(\d+)\.(\d+)\.(\d+)\.(\d+)$/);
  if (m) {
    const [a, b] = [Number(m[1]), Number(m[2])];
    if (a === 10 || a === 127 || a === 0 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127)) return false;
  }
  if (/^(fc|fd|fe80)/.test(h)) return false;
  return true;
}

/**
 * Executa uma ação sensível JÁ APROVADA por um humano.
 *  - webhook: POST JSON para URL https pública (timeout 10s), resultado registrado no log da execução.
 *  - send_message: o envio real por canal ainda não existe (ver Closer OUTBOUND_SENDERS) — registra atividade
 *    dizendo que a mensagem NÃO foi entregue, em vez de fingir envio.
 * O kill switch é checado de novo no momento da execução.
 */
export async function executeApprovedAction(db: DB, organizationId: string, p: { action: string; config: Record<string, unknown>; event?: Record<string, unknown>; runId?: string }, workflowId: string | null): Promise<{ ok: boolean; message: string }> {
  const blocked = await workflowBlockReason(db, organizationId, workflowId, p.action);
  if (blocked) return { ok: false, message: `Ação interrompida por kill switch. ${blocked}` };
  if (p.action === "webhook") {
    const url = String(p.config.url ?? "");
    if (!isSafeWebhookUrl(url)) return { ok: false, message: "URL de webhook recusada: use https para um endereço público." };
    try {
      const res = await fetch(url, { method: "POST", headers: { "content-type": "application/json", "user-agent": "ORBITY-NEPTUNE-Workflows/1.0" },
        body: JSON.stringify({ source: "orbity-neptune", runId: p.runId, event: p.event ?? {} }), signal: AbortSignal.timeout(10_000), redirect: "manual" });
      return res.ok ? { ok: true, message: `Webhook chamado (HTTP ${res.status})` } : { ok: false, message: `Webhook respondeu HTTP ${res.status}` };
    } catch (err) {
      return { ok: false, message: `Falha ao chamar webhook: ${(err as Error).message.slice(0, 120)}` };
    }
  }
  if (p.action === "send_message") {
    const ev = (p.event ?? {}) as Record<string, string>;
    await db.insert(activities).values({ organizationId, type: "note", subject: "Mensagem de automação aprovada — NÃO entregue",
      body: `Envio real por canal ainda não implementado. Texto aprovado: ${String(p.config.body ?? "").slice(0, 500)}`, leadId: ev.leadId ?? null, opportunityId: ev.opportunityId ?? null });
    return { ok: true, message: "Mensagem aprovada e registrada; não entregue (envio real por canal ainda não implementado)" };
  }
  return { ok: false, message: `Ação sensível desconhecida: ${p.action}` };
}

export const ACTION_CATALOG = [
  { key: "create_task", label: "Criar tarefa", params: ["title", "dueInHours"] },
  { key: "notify", label: "Notificar equipe", params: ["title", "body"] },
  { key: "update_lead_status", label: "Atualizar status do lead", params: ["status"] },
  { key: "log_activity", label: "Registrar atividade", params: ["subject"] },
  { key: "send_message", label: "Enviar mensagem ao contato (requer aprovação)", params: ["body"] },
  { key: "webhook", label: "Chamar webhook (requer aprovação)", params: ["url"] },
];

export type Definition = { nodes: WorkflowNode[]; entry: string };
type LogEntry = { node: string; status: string; message: string; at: string };

export function validateDefinition(def: Definition) {
  const ids = new Set(def.nodes.map((n) => n.id));
  if (!ids.has(def.entry)) throw new HttpError(400, "Nó de entrada inexistente.");
  if (def.nodes.length > 100) throw new HttpError(400, "Workflow excede 100 nós.");
  for (const n of def.nodes) {
    for (const ref of [n.next, n.nextFalse]) if (ref && !ids.has(ref)) throw new HttpError(400, `Nó ${n.id} aponta para nó inexistente ${ref}.`);
    if (n.type === "action" && !ACTION_CATALOG.some((a) => a.key === n.config.action)) throw new HttpError(400, `Ação desconhecida no nó ${n.id}.`);
  }
  // Detecta ciclos no grafo (repetições devem usar o nó "wait" com limite, não ciclos diretos).
  const visiting = new Set<string>(), done = new Set<string>();
  const byId = new Map(def.nodes.map((n) => [n.id, n]));
  const dfs = (id: string) => {
    if (done.has(id)) return;
    if (visiting.has(id)) throw new HttpError(400, `Ciclo detectado no nó ${id}.`);
    visiting.add(id);
    const n = byId.get(id)!;
    for (const nx of [n.next, n.nextFalse]) if (nx) dfs(nx);
    visiting.delete(id); done.add(id);
  };
  dfs(def.entry);
}

function getPath(obj: unknown, path: string): unknown {
  return path.split(".").reduce<unknown>((o, k) => (o && typeof o === "object" ? (o as Record<string, unknown>)[k] : undefined), obj);
}
export function evalCondition(cfg: Record<string, unknown>, data: Record<string, unknown>) {
  const v = getPath(data, String(cfg.field ?? "")), target = cfg.value;
  switch (cfg.op) {
    case "eq": return String(v) === String(target);
    case "neq": return String(v) !== String(target);
    case "gt": return Number(v) > Number(target);
    case "gte": return Number(v) >= Number(target);
    case "lt": return Number(v) < Number(target);
    case "contains": return String(v ?? "").toLowerCase().includes(String(target).toLowerCase());
    case "exists": return v !== undefined && v !== null;
    default: return false;
  }
}

type ExecOptions = { simulate: boolean; organizationId: string; runId?: string; workflowId?: string | null; depth: number; db?: DB; startAt?: string | null };

async function execAction(node: WorkflowNode, data: Record<string, unknown>, o: ExecOptions): Promise<string> {
  const cfg = node.config as Record<string, string | number>;
  const action = String(cfg.action);
  if (o.simulate || !o.db) return SENSITIVE_ACTIONS.has(action) ? `[simulação] ${action} exigiria aprovação humana` : `[simulação] executaria ${action}`;
  const db = o.db, org = o.organizationId;
  const payload = (data.payload ?? {}) as Record<string, string>;
  switch (action) {
    case "create_task": {
      await db.insert(tasks).values({ organizationId: org, title: String(cfg.title ?? "Tarefa de automação"), opportunityId: payload.opportunityId ?? null, leadId: payload.leadId ?? null, dueAt: new Date(Date.now() + Number(cfg.dueInHours ?? 24) * 3600e3) });
      return "Tarefa criada";
    }
    case "notify":
      await db.insert(notifications).values({ organizationId: org, title: String(cfg.title ?? "Automação"), body: String(cfg.body ?? "") });
      return "Notificação criada";
    case "update_lead_status": {
      if (!payload.leadId) return "Sem lead no evento — ignorado";
      await db.update(leads).set({ status: String(cfg.status) }).where(and(eq(leads.id, payload.leadId), eq(leads.organizationId, org)));
      return `Lead atualizado para ${cfg.status}`;
    }
    case "log_activity":
      await db.insert(activities).values({ organizationId: org, type: "note", subject: String(cfg.subject ?? "Automação executada"), leadId: payload.leadId ?? null, opportunityId: payload.opportunityId ?? null });
      return "Atividade registrada";
    default: {
      if (SENSITIVE_ACTIONS.has(action)) {
        // Guarda o que executar e onde retomar: a ação só roda DEPOIS da aprovação (handler workflow-approval-resume).
        await db.insert(approvalRequests).values({ organizationId: org, kind: "workflow_step", title: `Automação: ${ACTION_CATALOG.find((a) => a.key === action)?.label}`, payload: { action, config: cfg, event: payload, runId: o.runId, node: node.id, resumeNode: node.next ?? null, data }, requestedBy: `workflow:${o.runId}` });
        return WAITING_APPROVAL;
      }
      throw new Error(`Ação não suportada: ${action}`);
    }
  }
}

/** Executa (ou simula) a definição a partir do nó de entrada. */
export async function executeDefinition(def: Definition, data: Record<string, unknown>, o: ExecOptions) {
  const byId = new Map(def.nodes.map((n) => [n.id, n]));
  const log: LogEntry[] = [];
  const add = (node: string, status: string, message: string) => log.push({ node, status, message, at: new Date().toISOString() });
  let cur: string | null | undefined = o.startAt ?? def.entry, steps = 0, finalStatus = o.simulate ? "simulated" : "completed";
  while (cur) {
    if (++steps > MAX_STEPS) { add(cur, "error", `Limite de ${MAX_STEPS} passos excedido`); finalStatus = "failed"; break; }
    const node = byId.get(cur);
    if (!node) { add(cur, "error", "Nó inexistente"); finalStatus = "failed"; break; }
    if (node.type === "trigger") { add(node.id, "ok", "Gatilho recebido"); cur = node.next; continue; }
    if (node.type === "end") { add(node.id, "ok", "Fim"); break; }
    if (node.type === "condition") {
      const r = evalCondition(node.config, data);
      add(node.id, "ok", `Condição ${r ? "verdadeira" : "falsa"}`);
      cur = r ? node.next : node.nextFalse; continue;
    }
    if (node.type === "wait") {
      const hours = Number(node.config.hours ?? 0);
      if (!o.simulate && o.db && hours > 0) {
        await o.db.insert(events).values({ organizationId: o.organizationId, type: "workflow.resume", payload: { runId: o.runId, node: node.next, data, _wfDepth: o.depth }, nextAttemptAt: new Date(Date.now() + hours * 3600e3) });
        add(node.id, "waiting", `Aguardando ${hours}h`);
        return { status: "waiting", log };
      }
      add(node.id, "ok", `Espera de ${hours}h${o.simulate ? " (simulada)" : ""}`); cur = node.next; continue;
    }
    if (node.type === "approval") {
      if (!o.simulate && o.db) {
        await o.db.insert(approvalRequests).values({ organizationId: o.organizationId, kind: "workflow_step", title: String(node.config.title ?? "Aprovação de automação"), payload: { runId: o.runId, resumeNode: node.next, data }, requestedBy: `workflow:${o.runId}` });
        add(node.id, "waiting", "Aguardando aprovação humana");
        return { status: "waiting_approval", log };
      }
      add(node.id, "ok", "Aprovação (simulada)"); cur = node.next; continue;
    }
    // AI Control Plane: kill switch por automação ou por categoria de ação interrompe o nó (e a execução).
    if (!o.simulate && o.db) {
      if (o.workflowId === undefined && o.runId) {
        const [r] = await o.db.select({ wf: workflowRuns.workflowId }).from(workflowRuns).where(eq(workflowRuns.id, o.runId));
        o.workflowId = r?.wf ?? null;
      }
      const blocked = await workflowBlockReason(o.db, o.organizationId, o.workflowId ?? null, String(node.config.action));
      if (blocked) {
        add(node.id, "error", `Ação interrompida por kill switch. ${blocked}`);
        finalStatus = "failed"; break;
      }
    }
    try {
      const msg = await execAction(node, data, o);
      add(node.id, msg === WAITING_APPROVAL ? "waiting" : "ok", msg);
      // Ação sensível: a execução PARA aqui; os próximos nós só rodam depois da decisão humana.
      if (msg === WAITING_APPROVAL) return { status: "waiting_approval", log };
    } catch (err) {
      add(node.id, "error", (err as Error).message);
      if (node.config.onError === "continue") { cur = node.next; continue; }
      finalStatus = "failed"; break;
    }
    cur = node.next;
  }
  return { status: finalStatus, log };
}

/** Handler do Event Engine: dispara workflows ativos cujo gatilho corresponde ao evento. */
export async function runWorkflowsForEvent(db: DB, e: EventRecord) {
  if (!e.organizationId) return;
  const depth = Number((e.payload as Record<string, unknown>)._wfDepth ?? 0);
  if (depth >= MAX_DEPTH) return; // proteção contra loops entre automações
  const active = await db.select().from(workflows).where(and(eq(workflows.organizationId, e.organizationId), eq(workflows.status, "active"), eq(workflows.triggerEvent, e.type)));
  for (const wf of active) {
    const [ver] = await db.select().from(workflowVersions).where(and(eq(workflowVersions.workflowId, wf.id), eq(workflowVersions.version, wf.currentVersion)));
    if (!ver) continue;
    const inserted = await db.insert(workflowRuns).values({ organizationId: wf.organizationId, workflowId: wf.id, version: ver.version, eventId: e.id, depth: depth + 1 })
      .onConflictDoNothing().returning();
    if (!inserted.length) continue; // já executado para este evento (idempotência)
    const run = inserted[0];
    const result = await executeDefinition(ver.definition, { type: e.type, payload: e.payload }, { simulate: false, organizationId: wf.organizationId, runId: run.id, workflowId: wf.id, depth: depth + 1, db });
    await db.update(workflowRuns).set({ status: result.status, log: result.log, finishedAt: ["completed", "failed"].includes(result.status) ? new Date() : null, error: result.status === "failed" ? result.log.at(-1)?.message : null }).where(eq(workflowRuns.id, run.id));
    if (result.status === "failed") await db.insert(notifications).values({ organizationId: wf.organizationId, title: `Falha na automação "${wf.name}"`, body: result.log.at(-1)?.message, href: `/automacoes?wf=${wf.id}` });
  }
}

/* ---------------- CRUD / versionamento ---------------- */

const nodeSchema = z.object({
  id: z.string().min(1).max(40), type: z.enum(["trigger", "condition", "action", "wait", "approval", "end"]),
  config: z.record(z.string(), z.unknown()).default({}), next: z.string().nullable().optional(), nextFalse: z.string().nullable().optional(),
});
export const workflowInput = z.object({
  name: z.string().trim().min(2).max(120), description: z.string().max(500).optional(), triggerEvent: z.string().min(3).max(60),
  definition: z.object({ nodes: z.array(nodeSchema).min(2).max(100), entry: z.string() }),
});

export async function saveWorkflow(ctx: TenantContext, raw: z.input<typeof workflowInput>, workflowId?: string) {
  requirePerm(ctx, "automations:write");
  const input = workflowInput.parse(raw);
  validateDefinition(input.definition as Definition);
  if (!workflowId) {
    // Verificação de limite FORA da transação (evita uso de outra conexão dentro do tx).
    const existing = await ctx.db.select({ id: workflows.id }).from(workflows).where(eq(workflows.organizationId, ctx.organizationId));
    await assertWithinLimit(ctx.db, ctx.organizationId, "automations", existing.length);
  }
  return ctx.db.transaction(async (tx) => {
    if (workflowId) {
      const [wf] = await tx.select().from(workflows).where(and(eq(workflows.id, workflowId), eq(workflows.organizationId, ctx.organizationId)));
      if (!wf) throw new HttpError(404, "Automação não encontrada.");
      const version = wf.currentVersion + 1;
      await tx.insert(workflowVersions).values({ organizationId: ctx.organizationId, workflowId, version, definition: input.definition as Definition });
      const [u] = await tx.update(workflows).set({ name: input.name, description: input.description, triggerEvent: input.triggerEvent, currentVersion: version, updatedAt: new Date() }).where(eq(workflows.id, workflowId)).returning();
      return u;
    }
    const [wf] = await tx.insert(workflows).values({ organizationId: ctx.organizationId, name: input.name, description: input.description, triggerEvent: input.triggerEvent, createdBy: ctx.userId }).returning();
    await tx.insert(workflowVersions).values({ organizationId: ctx.organizationId, workflowId: wf.id, version: 1, definition: input.definition as Definition });
    return wf;
  });
}

export async function setWorkflowStatus(ctx: TenantContext, id: string, status: "active" | "paused" | "draft") {
  requirePerm(ctx, status === "active" ? "automations:publish" : "automations:write");
  const [wf] = await ctx.db.update(workflows).set({ status, updatedAt: new Date() }).where(and(eq(workflows.id, id), eq(workflows.organizationId, ctx.organizationId))).returning();
  if (!wf) throw new HttpError(404, "Automação não encontrada.");
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: `workflow.${status}`, resource: "workflow", resourceId: id });
  return wf;
}

export async function simulateWorkflow(ctx: TenantContext, id: string, samplePayload: Record<string, unknown>) {
  requirePerm(ctx, "automations:read");
  const [wf] = await ctx.db.select().from(workflows).where(and(eq(workflows.id, id), eq(workflows.organizationId, ctx.organizationId)));
  if (!wf) throw new HttpError(404, "Automação não encontrada.");
  const [ver] = await ctx.db.select().from(workflowVersions).where(and(eq(workflowVersions.workflowId, id), eq(workflowVersions.version, wf.currentVersion)));
  return executeDefinition(ver.definition, { type: wf.triggerEvent, payload: samplePayload }, { simulate: true, organizationId: ctx.organizationId, depth: 0 });
}

/** Reprocessa uma execução que falhou (cria nova execução manual vinculada ao mesmo evento). */
export async function reprocessRun(ctx: TenantContext, runId: string) {
  requirePerm(ctx, "automations:write");
  const [run] = await ctx.db.select().from(workflowRuns).where(and(eq(workflowRuns.id, runId), eq(workflowRuns.organizationId, ctx.organizationId)));
  if (!run) throw new HttpError(404, "Execução não encontrada.");
  if (run.status !== "failed") throw new HttpError(409, "Somente execuções com falha podem ser reprocessadas.");
  const [ver] = await ctx.db.select().from(workflowVersions).where(and(eq(workflowVersions.workflowId, run.workflowId), eq(workflowVersions.version, run.version)));
  const [ev] = run.eventId ? await ctx.db.select().from(events).where(eq(events.id, run.eventId)) : [];
  const result = await executeDefinition(ver.definition, { type: ev?.type, payload: ev?.payload ?? {} }, { simulate: false, organizationId: ctx.organizationId, runId: run.id, depth: run.depth, db: ctx.db });
  await ctx.db.update(workflowRuns).set({ status: result.status, log: [...run.log, ...result.log], finishedAt: new Date() }).where(eq(workflowRuns.id, run.id));
  return result;
}

export async function listWorkflows(ctx: TenantContext) {
  requirePerm(ctx, "automations:read");
  return ctx.db.select().from(workflows).where(eq(workflows.organizationId, ctx.organizationId)).orderBy(desc(workflows.updatedAt));
}

export async function workflowDetail(ctx: TenantContext, id: string) {
  requirePerm(ctx, "automations:read");
  const [wf] = await ctx.db.select().from(workflows).where(and(eq(workflows.id, id), eq(workflows.organizationId, ctx.organizationId)));
  if (!wf) throw new HttpError(404, "Automação não encontrada.");
  const versions = await ctx.db.select().from(workflowVersions).where(eq(workflowVersions.workflowId, id)).orderBy(desc(workflowVersions.version));
  const runs = await ctx.db.select().from(workflowRuns).where(eq(workflowRuns.workflowId, id)).orderBy(desc(workflowRuns.createdAt)).limit(30);
  return { workflow: wf, versions, runs };
}

/** Permite publicar eventos de teste (ex.: simulação de ponta a ponta). */
export async function emitTestEvent(ctx: TenantContext, type: string, payload: Record<string, unknown>) {
  requirePerm(ctx, "automations:write");
  return publish(ctx.db, ctx.organizationId, type, { ...payload, _test: true });
}
