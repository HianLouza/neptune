import { NextResponse } from "next/server";
import { ZodError } from "zod";
import { headers } from "next/headers";

export class HttpError extends Error {
  constructor(public status: number, message: string) { super(message); }
}

/** Envelope padrão de API com tratamento de erros e logs estruturados (JSON). */
export async function handle<T>(fn: () => Promise<T>, init?: { status?: number }) {
  const started = Date.now();
  try {
    const data = await fn();
    return NextResponse.json({ ok: true, data }, { status: init?.status ?? 200 });
  } catch (err) {
    if (err instanceof ZodError) {
      return NextResponse.json(
        { ok: false, error: "Dados inválidos.", issues: err.issues.map((i) => ({ path: i.path.join("."), message: i.message })) },
        { status: 400 },
      );
    }
    const status = (err as { status?: number }).status ?? 500;
    const message = status === 500 ? "Erro interno. O incidente foi registrado." : (err as Error).message;
    console.error(JSON.stringify({
      level: status >= 500 ? "error" : "warn", at: new Date().toISOString(), status, message: (err as Error).message,
      ms: Date.now() - started, stack: status >= 500 ? (err as Error).stack : undefined,
    }));
    return NextResponse.json({ ok: false, error: message }, { status });
  }
}

/** Proteção CSRF: rotas mutáveis aceitam apenas requisições da mesma origem (complementa cookie SameSite=Lax). */
export async function assertSameOrigin() {
  const h = await headers();
  const origin = h.get("origin");
  const host = h.get("x-forwarded-host") ?? h.get("host");
  if (origin && host && new URL(origin).host !== host) throw new HttpError(403, "Origem não permitida.");
}

export async function readJson(req: Request) {
  try { return await req.json(); } catch { throw new HttpError(400, "JSON inválido."); }
}
