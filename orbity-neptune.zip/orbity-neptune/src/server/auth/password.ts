import bcrypt from "bcryptjs";

export const PASSWORD_RULES = "Mínimo de 10 caracteres, com letras e números.";
export function validatePasswordStrength(pw: string): string | null {
  if (pw.length < 10) return "A senha precisa ter ao menos 10 caracteres.";
  if (!/[a-zA-Z]/.test(pw) || !/\d/.test(pw)) return "A senha precisa conter letras e números.";
  return null;
}
export const hashPassword = (pw: string) => bcrypt.hash(pw, 12);
export const verifyPassword = (pw: string, hash: string) => bcrypt.compare(pw, hash);
