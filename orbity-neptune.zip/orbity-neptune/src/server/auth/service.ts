/** Serviço de identidade (independente do Next — testável). */
import { and, eq, gt, isNull } from "drizzle-orm";
import type { DB } from "../db/client";
import {
  memberships, organizations, roles, sessions, users, pipelines, pipelineStages, creditWallets, subscriptions, plans, aiAgents, aiPromptVersions,
} from "../db/schema";
import { hashPassword, validatePasswordStrength, verifyPassword } from "./password";
import { randomToken, sha256 } from "./crypto";
import { verifyTotp } from "./totp";
import { SYSTEM_ROLES } from "../permissions";
import { audit } from "../audit";
import { AGENT_DOMAINS, DEFAULT_AGENTS, levelFromLegacy } from "../ai/agents/catalog";
import type { TenantContext } from "../tenancy/context";

export const SESSION_TTL_MS = 1000 * 60 * 60 * 24 * 14;

export class AuthError extends Error { status = 401; }

export function slugify(v: string) {
  return v.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "").slice(0, 48) || "org";
}

/** Cria organização com cargos padrão, funil padrão, agentes, carteira e trial de 7 dias. */
export async function provisionOrganization(db: DB, input: { name: string; ownerId: string; segment?: string; size?: string; isDemo?: boolean }) {
  const slug = `${slugify(input.name)}-${randomToken(4).toLowerCase().replace(/[^a-z0-9]/g, "").slice(0, 5)}`;
  return db.transaction(async (tx) => {
    const [org] = await tx.insert(organizations).values({ name: input.name, slug, segment: input.segment, size: input.size, isDemo: !!input.isDemo }).returning();
    const roleRows = await tx.insert(roles).values(
      (Object.keys(SYSTEM_ROLES) as (keyof typeof SYSTEM_ROLES)[]).map((k) => ({
        organizationId: org.id, key: k, name: SYSTEM_ROLES[k].name, permissions: [...SYSTEM_ROLES[k].permissions], isSystem: true,
      })),
    ).returning();
    const adminRole = roleRows.find((r) => r.key === "admin")!;
    await tx.insert(memberships).values({ organizationId: org.id, userId: input.ownerId, roleId: adminRole.id, status: "active" });
    const [pipe] = await tx.insert(pipelines).values({ organizationId: org.id, name: "Funil de Vendas", isDefault: true }).returning();
    const stages = [
      { name: "Novos Leads", probability: 10, color: "violet" }, { name: "Qualificação", probability: 25, color: "blue" },
      { name: "Proposta", probability: 50, color: "amber" }, { name: "Negociação", probability: 70, color: "fuchsia" },
      { name: "Fechamento", probability: 90, color: "emerald" },
    ];
    await tx.insert(pipelineStages).values([
      ...stages.map((s, i) => ({ organizationId: org.id, pipelineId: pipe.id, name: s.name, position: i, probability: s.probability, color: s.color, kind: "open" })),
      { organizationId: org.id, pipelineId: pipe.id, name: "Ganho", position: 5, probability: 100, color: "green", kind: "won" },
      { organizationId: org.id, pipelineId: pipe.id, name: "Perdido", position: 6, probability: 0, color: "red", kind: "lost" },
    ]);
    const [plan] = await tx.select().from(plans).where(eq(plans.key, "growth"));
    if (plan) {
      const now = Date.now();
      await tx.insert(subscriptions).values({
        organizationId: org.id, planId: plan.id, status: "trialing", trialEndsAt: new Date(now + plan.trialDays * 864e5),
        currentPeriodStart: new Date(now), currentPeriodEnd: new Date(now + 30 * 864e5),
      });
      await tx.insert(creditWallets).values({ organizationId: org.id, balance: plan.includedCredits, monthlyAllowance: plan.includedCredits });
    } else {
      await tx.insert(creditWallets).values({ organizationId: org.id, balance: 0 });
    }
    for (const a of DEFAULT_AGENTS) {
      const [agent] = await tx.insert(aiAgents).values({
        organizationId: org.id, key: a.key, name: a.name, objective: a.objective, tools: a.tools, permissions: a.permissions, autonomy: a.autonomy,
        autonomyLevel: levelFromLegacy(a.autonomy), domain: AGENT_DOMAINS[a.key] ?? "commercial",
      }).returning();
      await tx.insert(aiPromptVersions).values({ organizationId: org.id, agentId: agent.id, version: 1, systemPrompt: a.prompt, status: "approved" });
    }
    return org;
  });
}

export async function registerUser(db: DB, input: { name: string; email: string; password: string; organizationName?: string; inviteOrgSlug?: string }) {
  const email = input.email.trim().toLowerCase();
  const pwErr = validatePasswordStrength(input.password);
  if (pwErr) throw Object.assign(new AuthError(pwErr), { status: 400 });
  const [exists] = await db.select({ id: users.id }).from(users).where(eq(users.email, email));
  if (exists) throw Object.assign(new AuthError("Este e-mail já está cadastrado."), { status: 409 });
  const [user] = await db.insert(users).values({ name: input.name.trim(), email, passwordHash: await hashPassword(input.password) }).returning();

  if (input.inviteOrgSlug) {
    // Cadastro individual de colaborador: fica PENDENTE até o administrador aprovar.
    const [org] = await db.select().from(organizations).where(eq(organizations.slug, input.inviteOrgSlug));
    if (!org) throw Object.assign(new AuthError("Organização não encontrada."), { status: 404 });
    const [memberRole] = await db.select().from(roles).where(and(eq(roles.organizationId, org.id), eq(roles.key, "member")));
    await db.insert(memberships).values({ organizationId: org.id, userId: user.id, roleId: memberRole.id, status: "pending" });
    await audit(db, { organizationId: org.id, actorId: user.id, action: "membership.requested", resource: "membership" });
    return { user, organizationId: null as string | null };
  }
  const org = await provisionOrganization(db, { name: input.organizationName?.trim() || `Empresa de ${input.name.split(" ")[0]}`, ownerId: user.id });
  await audit(db, { organizationId: org.id, actorId: user.id, action: "user.registered", resource: "user", resourceId: user.id });
  return { user, organizationId: org.id as string | null };
}

export async function createSession(
  db: DB, userId: string, organizationId: string | null,
  meta: { ip?: string | null; userAgent?: string | null; twoFactorPending?: boolean },
) {
  const token = randomToken();
  await db.insert(sessions).values({
    tokenHash: sha256(token), userId, organizationId, ip: meta.ip ?? null, userAgent: meta.userAgent ?? null,
    twoFactorPending: !!meta.twoFactorPending, expiresAt: new Date(Date.now() + SESSION_TTL_MS),
  });
  return token;
}

// Proteção contra força bruta (por processo). Em produção: rate limit compartilhado no Redis/edge.
const attempts = new Map<string, { n: number; until: number }>();
function checkRate(key: string) {
  const a = attempts.get(key);
  if (a && a.until > Date.now() && a.n >= 8) throw Object.assign(new AuthError("Muitas tentativas. Aguarde 15 minutos."), { status: 429 });
}
function failRate(key: string) {
  const a = attempts.get(key);
  attempts.set(key, { n: a && a.until > Date.now() ? a.n + 1 : 1, until: Date.now() + 15 * 60_000 });
}

export async function login(db: DB, input: { email: string; password: string; ip?: string | null; userAgent?: string | null }) {
  const email = input.email.trim().toLowerCase();
  const rk = `${email}|${input.ip ?? ""}`;
  checkRate(rk);
  const [user] = await db.select().from(users).where(eq(users.email, email));
  if (!user?.passwordHash || !(await verifyPassword(input.password, user.passwordHash))) {
    failRate(rk);
    await audit(db, { actorId: user?.id ?? null, action: "auth.login_failed", resource: "user", metadata: { email }, ip: input.ip });
    throw new AuthError("E-mail ou senha inválidos.");
  }
  attempts.delete(rk);
  const [m] = await db.select().from(memberships).where(and(eq(memberships.userId, user.id), eq(memberships.status, "active"))).limit(1);
  const token = await createSession(db, user.id, m?.organizationId ?? null, { ip: input.ip, userAgent: input.userAgent, twoFactorPending: user.totpEnabled });
  await db.update(users).set({ lastLoginAt: new Date() }).where(eq(users.id, user.id));
  await audit(db, { organizationId: m?.organizationId, actorId: user.id, action: "auth.login", resource: "session", ip: input.ip });
  return { token, requires2fa: user.totpEnabled, hasOrganization: !!m };
}

export async function completeTwoFactor(db: DB, token: string, code: string) {
  const s = await findSession(db, token, { allowPending2fa: true });
  if (!s) throw new AuthError("Sessão inválida.");
  const [user] = await db.select().from(users).where(eq(users.id, s.userId));
  if (!user.totpSecret || !verifyTotp(user.totpSecret, code)) {
    await audit(db, { organizationId: s.organizationId, actorId: user.id, action: "auth.2fa_failed", resource: "session" });
    throw new AuthError("Código inválido.");
  }
  await db.update(sessions).set({ twoFactorPending: false }).where(eq(sessions.id, s.id));
  await audit(db, { organizationId: s.organizationId, actorId: user.id, action: "auth.2fa_verified", resource: "session" });
}

export async function findSession(db: DB, token: string, opts: { allowPending2fa?: boolean } = {}) {
  const [s] = await db.select().from(sessions)
    .where(and(eq(sessions.tokenHash, sha256(token)), isNull(sessions.revokedAt), gt(sessions.expiresAt, new Date())));
  if (!s) return null;
  if (s.twoFactorPending && !opts.allowPending2fa) return null;
  return s;
}

export async function revokeSession(db: DB, token: string) {
  await db.update(sessions).set({ revokedAt: new Date() }).where(eq(sessions.tokenHash, sha256(token)));
}

/** Monta o TenantContext a partir da sessão. Exige membership ATIVA e organização não suspensa. */
export async function contextFromSession(db: DB, token: string, ip?: string | null): Promise<TenantContext | null> {
  const s = await findSession(db, token);
  if (!s || !s.organizationId) return null;
  return contextFor(db, s.userId, s.organizationId, ip);
}

export async function contextFor(db: DB, userId: string, organizationId: string, ip?: string | null): Promise<TenantContext | null> {
  const rows = await db.select({ user: users, org: organizations, role: roles })
    .from(memberships)
    .innerJoin(users, eq(users.id, memberships.userId))
    .innerJoin(organizations, eq(organizations.id, memberships.organizationId))
    .innerJoin(roles, eq(roles.id, memberships.roleId))
    .where(and(eq(memberships.userId, userId), eq(memberships.organizationId, organizationId), eq(memberships.status, "active")));
  const r = rows[0];
  if (!r || r.org.status === "suspended") return null;
  return {
    db, organizationId: r.org.id, userId: r.user.id, roleKey: r.role.key, permissions: r.role.permissions,
    isPlatformAdmin: r.user.isPlatformAdmin, locale: r.user.locale || r.org.locale, currency: r.org.currency,
    timezone: r.user.timezone || r.org.timezone, ip,
  };
}
