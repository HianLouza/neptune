/** Integração do serviço de identidade com Next.js (cookies, headers, redirects). */
import { cookies, headers } from "next/headers";
import { redirect } from "next/navigation";
import { getDb } from "../db/client";
import { contextFromSession } from "./service";
import type { TenantContext } from "../tenancy/context";
import { ForbiddenError, hasPermission, type Permission } from "../permissions";

export const SESSION_COOKIE = "on_session";

export async function setSessionCookie(token: string) {
  (await cookies()).set(SESSION_COOKIE, token, {
    httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", path: "/", maxAge: 60 * 60 * 24 * 14,
  });
}
export async function clearSessionCookie() { (await cookies()).delete(SESSION_COOKIE); }
export async function getSessionToken() { return (await cookies()).get(SESSION_COOKIE)?.value ?? null; }

export async function clientIp() {
  const h = await headers();
  return h.get("x-forwarded-for")?.split(",")[0]?.trim() ?? h.get("x-real-ip") ?? null;
}

export async function getContext(): Promise<TenantContext | null> {
  const token = await getSessionToken();
  if (!token) return null;
  return contextFromSession(await getDb(), token, await clientIp());
}

/** Para páginas: redireciona ao login se não autenticado. */
export async function requirePageContext(perm?: Permission): Promise<TenantContext> {
  const ctx = await getContext();
  if (!ctx) redirect("/login");
  if (perm && !hasPermission(ctx.permissions, perm)) redirect("/dashboard?erro=permissao");
  return ctx;
}

/** Para rotas de API: lança 401/403, tratados por `handle`. */
export async function requireApiContext(perm?: Permission): Promise<TenantContext> {
  const ctx = await getContext();
  if (!ctx) throw Object.assign(new Error("Não autenticado."), { status: 401 });
  if (perm && !hasPermission(ctx.permissions, perm)) throw new ForbiddenError(perm);
  return ctx;
}
