import type { DB } from "../db/client";
import { auditLogs } from "../db/schema";

export type AuditEntry = {
  organizationId?: string | null; actorId?: string | null; action: string; resource: string;
  resourceId?: string | null; metadata?: Record<string, unknown>; ip?: string | null;
};

/** Registro imutável de auditoria: login, permissões, IA, aprovações, cobranças, exclusões, exportações. */
export async function audit(db: DB, e: AuditEntry) {
  await db.insert(auditLogs).values({
    organizationId: e.organizationId ?? null, actorId: e.actorId ?? "system", action: e.action,
    resource: e.resource, resourceId: e.resourceId ?? null, metadata: e.metadata ?? {}, ip: e.ip ?? null,
  });
}
