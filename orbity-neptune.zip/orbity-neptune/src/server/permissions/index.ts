/** Catálogo de permissões: <módulo>:<ação>. Verificação SEMPRE no backend. */
export const PERMISSIONS = [
  "crm:read", "crm:write", "crm:delete",
  "prospect:read", "prospect:write",
  "closer:read", "closer:write",
  "intelligence:read",
  "automations:read", "automations:write", "automations:publish",
  "ai:use", "ai:manage",
  "approvals:decide",
  "goals:read", "goals:manage",
  "integrations:read", "integrations:manage",
  "billing:read", "billing:manage",
  "admin:users", "admin:settings",
  "audit:read",
  "export:data",
  "support:use",
  // Master Prompt 4.0 — ciclo 1
  "finance:read", "finance:write",
  "strategy:read", "strategy:write",
  "ai:govern", // AI Control Plane: kill switch, orçamentos e níveis de autonomia
  // Task Intelligence
  "alerts:send", // gerar/enviar/cancelar alertas de tarefa, decidir prorrogações e ver a Central de Alertas
  "alerts:manage", // regras de automação, escalonamento e tom de comunicação
] as const;
export type Permission = (typeof PERMISSIONS)[number];

export const SYSTEM_ROLES: Record<"admin" | "manager" | "member", { name: string; permissions: Permission[] }> = {
  admin: { name: "Administrador", permissions: [...PERMISSIONS] },
  manager: {
    name: "Gestor",
    permissions: PERMISSIONS.filter((p) => !["billing:manage", "admin:settings", "integrations:manage", "ai:govern"].includes(p)) as Permission[],
  },
  member: {
    name: "Colaborador",
    permissions: ["crm:read", "crm:write", "prospect:read", "prospect:write", "closer:read", "closer:write",
      "intelligence:read", "automations:read", "ai:use", "goals:read", "integrations:read", "support:use"],
  },
};

export class ForbiddenError extends Error {
  status = 403;
  constructor(public permission: string) { super(`Permissão necessária: ${permission}`); }
}

export function hasPermission(granted: readonly string[], needed: Permission) {
  return granted.includes("*") || granted.includes(needed);
}
