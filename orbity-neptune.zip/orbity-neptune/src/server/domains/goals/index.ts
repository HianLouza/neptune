/** METAS E COMISSÕES — metas por escopo/período, comissões versionadas e auditáveis, simulação de atingimento. */
import { and, desc, eq, gte, lt, sql } from "drizzle-orm";
import { z } from "zod";
import { commissionRules, goals, opportunities } from "../../db/schema";
import { requirePerm, type TenantContext } from "../../tenancy/context";
import { audit } from "../../audit";

export const goalInput = z.object({
  name: z.string().trim().min(2).max(120),
  metric: z.enum(["revenue", "deals_won", "leads", "meetings"]),
  scope: z.enum(["organization", "team", "user", "product", "channel"]).default("organization"),
  scopeId: z.string().max(80).optional(),
  targetValue: z.coerce.number().int().positive(),
  periodStart: z.coerce.date(),
  periodEnd: z.coerce.date(),
});

export async function createGoal(ctx: TenantContext, raw: z.input<typeof goalInput>) {
  requirePerm(ctx, "goals:manage");
  const input = goalInput.parse(raw);
  if (input.periodEnd <= input.periodStart) throw Object.assign(new Error("Período inválido."), { status: 400 });
  const [g] = await ctx.db.insert(goals).values({ organizationId: ctx.organizationId, ...input }).returning();
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "goal.created", resource: "goal", resourceId: g.id });
  return g;
}

export async function goalsWithProgress(ctx: TenantContext) {
  requirePerm(ctx, "goals:read");
  const list = await ctx.db.select().from(goals).where(eq(goals.organizationId, ctx.organizationId)).orderBy(desc(goals.periodEnd));
  const out = [];
  for (const g of list) {
    let achieved = 0;
    const conds = [eq(opportunities.organizationId, ctx.organizationId), eq(opportunities.status, "won"), gte(opportunities.closedAt, g.periodStart), lt(opportunities.closedAt, g.periodEnd)];
    if (g.scope === "user" && g.scopeId) conds.push(eq(opportunities.ownerId, g.scopeId));
    if (g.scope === "channel" && g.scopeId) conds.push(eq(opportunities.source, g.scopeId));
    if (g.metric === "revenue" || g.metric === "deals_won") {
      const [r] = await ctx.db.select({ v: g.metric === "revenue" ? sql<number>`coalesce(sum(${opportunities.amountCents}),0)::bigint` : sql<number>`count(*)::int` }).from(opportunities).where(and(...conds));
      achieved = Number(r.v);
    }
    const elapsed = Math.min(1, Math.max(0.01, (Date.now() - g.periodStart.getTime()) / (g.periodEnd.getTime() - g.periodStart.getTime())));
    out.push({ ...g, targetValue: Number(g.targetValue), achieved, pct: Math.round((achieved / Number(g.targetValue)) * 100), projectedPct: Math.round((achieved / elapsed / Number(g.targetValue)) * 100) });
  }
  return out;
}

/** Comissão = base × taxa; acima de 100% da meta aplica acelerador sobre o excedente. */
export function calculateCommission(rule: { ratePct: number; acceleratorPct: number }, achieved: number, target: number) {
  const base = Math.min(achieved, target) * (rule.ratePct / 100);
  const extra = Math.max(0, achieved - target) * ((rule.ratePct + rule.acceleratorPct) / 100);
  return Math.round(base + extra);
}

export async function saveCommissionRule(ctx: TenantContext, raw: { name: string; ratePct: number; acceleratorPct?: number }) {
  requirePerm(ctx, "goals:manage");
  const input = z.object({ name: z.string().min(2).max(120), ratePct: z.number().min(0).max(100), acceleratorPct: z.number().min(0).max(100).default(0) }).parse(raw);
  const prev = await ctx.db.select().from(commissionRules).where(and(eq(commissionRules.organizationId, ctx.organizationId), eq(commissionRules.name, input.name))).orderBy(desc(commissionRules.version));
  await ctx.db.update(commissionRules).set({ active: false }).where(and(eq(commissionRules.organizationId, ctx.organizationId), eq(commissionRules.name, input.name)));
  const [r] = await ctx.db.insert(commissionRules).values({ organizationId: ctx.organizationId, ...input, version: (prev[0]?.version ?? 0) + 1, createdBy: ctx.userId }).returning();
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "commission_rule.saved", resource: "commission_rule", resourceId: r.id, metadata: input });
  return r;
}

export async function listCommissionRules(ctx: TenantContext) {
  requirePerm(ctx, "goals:read");
  return ctx.db.select().from(commissionRules).where(eq(commissionRules.organizationId, ctx.organizationId)).orderBy(desc(commissionRules.createdAt));
}
