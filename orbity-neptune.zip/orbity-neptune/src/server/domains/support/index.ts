/** SUPORTE — chamados com prioridade, SLA, escalonamento e satisfação. */
import { and, desc, eq } from "drizzle-orm";
import { z } from "zod";
import { supportTickets } from "../../db/schema";
import { requirePerm, type TenantContext } from "../../tenancy/context";
import { HttpError } from "../../http";

export const SLA_HOURS: Record<string, number> = { urgent: 4, high: 8, medium: 24, low: 72 };

export const ticketInput = z.object({
  subject: z.string().trim().min(3).max(200), description: z.string().trim().min(5).max(5000),
  category: z.enum(["geral", "billing", "integracoes", "ia", "crm", "acesso", "bug"]).default("geral"),
  priority: z.enum(["low", "medium", "high", "urgent"]).default("medium"),
});

export async function openTicket(ctx: TenantContext, raw: z.input<typeof ticketInput>) {
  requirePerm(ctx, "support:use");
  const input = ticketInput.parse(raw);
  const [t] = await ctx.db.insert(supportTickets).values({ organizationId: ctx.organizationId, ...input, requesterId: ctx.userId, slaDueAt: new Date(Date.now() + SLA_HOURS[input.priority] * 3600e3) }).returning();
  return t;
}

export async function listTickets(ctx: TenantContext) {
  requirePerm(ctx, "support:use");
  return ctx.db.select().from(supportTickets).where(eq(supportTickets.organizationId, ctx.organizationId)).orderBy(desc(supportTickets.createdAt)).limit(100);
}

export async function rateTicket(ctx: TenantContext, id: string, satisfaction: number) {
  requirePerm(ctx, "support:use");
  const s = z.number().int().min(1).max(5).parse(satisfaction);
  const [t] = await ctx.db.update(supportTickets).set({ satisfaction: s }).where(and(eq(supportTickets.id, id), eq(supportTickets.organizationId, ctx.organizationId))).returning();
  if (!t) throw new HttpError(404, "Chamado não encontrado.");
  return t;
}
