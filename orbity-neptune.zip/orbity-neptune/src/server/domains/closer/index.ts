/**
 * CLOSER.AI — caixa de entrada compartilhada, base de conhecimento (RAG com pgvector), respostas de IA com
 * aprovação humana, classificação de intenção, resumo, handoff e alertas de SLA.
 *
 * Envio externo: só é "sent" quando há integração REAL conectada para o canal. Sem integração, a mensagem fica
 * com status "simulated" e a interface sinaliza claramente que NÃO foi entregue ao cliente.
 */
import { and, desc, eq, lt, sql, asc } from "drizzle-orm";
import { z } from "zod";
import { approvalRequests, contacts, conversations, integrations, knowledgeChunks, knowledgeDocuments, messages } from "../../db/schema";
import { integrationBlockReason } from "../../ai/control-plane";
import { requirePerm, type TenantContext } from "../../tenancy/context";
import { publish, EVENT_TYPES } from "../../events";
import { chunkText, embed } from "../../ai/embeddings";
import { runAgent } from "../../ai/orchestrator";
import { audit } from "../../audit";
import { HttpError } from "../../http";
import type { DB } from "../../db/client";
import { recordUsage } from "../billing";
import { createDraft, finalizeDraftApproval, sendDraft } from "../../ai/collab";

export const SLA_MINUTES = 30;
export const CHANNELS = ["whatsapp", "email", "webchat", "instagram"] as const;
const CHANNEL_PROVIDER: Record<string, string> = { whatsapp: "whatsapp", email: "email_smtp", webchat: "webchat", instagram: "instagram" };

/* ---------------- Base de conhecimento ---------------- */

export async function addKnowledge(ctx: TenantContext, raw: { title: string; kind?: string; content: string }) {
  requirePerm(ctx, "closer:write");
  const input = z.object({ title: z.string().min(2).max(200), kind: z.enum(["text", "faq", "pricing", "policy", "catalog"]).default("text"), content: z.string().min(10).max(500_000) }).parse(raw);
  return ctx.db.transaction(async (tx) => {
    const [doc] = await tx.insert(knowledgeDocuments).values({ organizationId: ctx.organizationId, ...input }).returning();
    const chunks = chunkText(input.content);
    if (chunks.length) await tx.insert(knowledgeChunks).values(chunks.map((c) => ({ organizationId: ctx.organizationId, documentId: doc.id, content: c, embedding: embed(`${input.title} ${c}`) })));
    return { ...doc, chunks: chunks.length };
  });
}

export async function searchKnowledge(db: DB, organizationId: string, query: string, k = 4, minSimilarity = 0.12) {
  const v = embed(query);
  const vec = `[${v.join(",")}]`;
  const rows = await db.select({
    content: knowledgeChunks.content, title: knowledgeDocuments.title,
    similarity: sql<number>`1 - (${knowledgeChunks.embedding} <=> ${vec}::vector)`,
  }).from(knowledgeChunks).innerJoin(knowledgeDocuments, eq(knowledgeDocuments.id, knowledgeChunks.documentId))
    .where(eq(knowledgeChunks.organizationId, organizationId)) // isolamento: busca só no tenant
    .orderBy(sql`${knowledgeChunks.embedding} <=> ${vec}::vector`).limit(k);
  return rows.filter((r) => Number(r.similarity) >= minSimilarity);
}

/* ---------------- Classificação de intenção (heurística determinística) ---------------- */

const INTENTS: { key: string; label: string; re: RegExp }[] = [
  { key: "pricing", label: "Preço / orçamento", re: /(pre[cç]o|valor|quanto custa|or[cç]amento|plano|desconto)/i },
  { key: "meeting", label: "Agendar reunião", re: /(reuni[aã]o|agendar|marcar|call|hor[aá]rio|demonstra[cç][aã]o|demo)/i },
  { key: "support", label: "Suporte", re: /(problema|erro|n[aã]o funciona|ajuda|suporte|bug)/i },
  { key: "cancel", label: "Cancelamento", re: /(cancelar|desistir|encerrar contrato)/i },
  { key: "purchase", label: "Intenção de compra", re: /(quero (comprar|contratar|fechar)|vamos fechar|pode mandar o contrato|aceito a proposta)/i },
  { key: "human", label: "Pediu humano", re: /(falar com (um )?(humano|atendente|pessoa|vendedor))/i },
];
export function classifyIntent(text: string) {
  const hit = INTENTS.find((i) => i.re.test(text));
  return hit ? { key: hit.key, label: hit.label } : { key: "general", label: "Dúvida geral" };
}

/* ---------------- Conversas ---------------- */

async function channelIsReal(db: DB, organizationId: string, channel: string) {
  const [i] = await db.select().from(integrations).where(and(eq(integrations.organizationId, organizationId), eq(integrations.provider, CHANNEL_PROVIDER[channel] ?? channel)));
  return !!i && i.status === "connected" && i.mode === "real";
}

/** Mensagem recebida (webhook de canal ou webchat). */
export async function receiveInbound(db: DB, organizationId: string, input: { channel: string; from: { name: string; email?: string; phone?: string }; body: string; externalId?: string; conversationId?: string }) {
  const body = input.body.slice(0, 10_000);
  if (input.externalId) {
    // Idempotência: reentregas do provedor (ex.: WhatsApp) não duplicam a mensagem.
    const [dup] = await db.select({ id: messages.id, conversationId: messages.conversationId }).from(messages)
      .where(and(eq(messages.organizationId, organizationId), eq(messages.externalId, input.externalId))).limit(1);
    if (dup) return { conversationId: dup.conversationId, messageId: dup.id, intent: classifyIntent(body), duplicate: true };
  }
  return db.transaction(async (tx) => {
    let conv;
    if (input.conversationId) {
      [conv] = await tx.select().from(conversations).where(and(eq(conversations.id, input.conversationId), eq(conversations.organizationId, organizationId)));
      if (!conv) throw new HttpError(404, "Conversa não encontrada.");
    } else {
      let contactId: string | null = null;
      const email = input.from.email?.toLowerCase();
      if (email) {
        const [found] = await tx.select({ id: contacts.id }).from(contacts).where(and(eq(contacts.organizationId, organizationId), eq(contacts.email, email))).limit(1);
        contactId = found?.id ?? null;
      }
      if (!contactId) {
        const [c] = await tx.insert(contacts).values({ organizationId, name: input.from.name.slice(0, 200), email: email ?? null, phone: input.from.phone ?? null, source: input.channel, legalBasis: "legitimo_interesse" }).returning();
        contactId = c.id;
      }
      [conv] = await tx.select().from(conversations).where(and(eq(conversations.organizationId, organizationId), eq(conversations.contactId, contactId!), eq(conversations.channel, input.channel), sql`${conversations.status} <> 'closed'`)).limit(1);
      if (!conv) [conv] = await tx.insert(conversations).values({ organizationId, channel: input.channel, contactId, subject: body.slice(0, 80) }).returning();
    }
    const intent = classifyIntent(body);
    const [msg] = await tx.insert(messages).values({ organizationId, conversationId: conv.id, direction: "inbound", author: "contact", body, externalId: input.externalId ?? null, status: "delivered" }).returning();
    await tx.update(conversations).set({
      lastMessageAt: new Date(), intent: intent.label, slaDueAt: new Date(Date.now() + SLA_MINUTES * 60_000),
      status: intent.key === "human" ? "handoff" : conv.status === "closed" ? "open" : conv.status,
    }).where(eq(conversations.id, conv.id));
    await recordUsage(tx, organizationId, "messages", 1);
    await publish(tx, organizationId, EVENT_TYPES.CONVERSATION_RECEIVED, { conversationId: conv.id, messageId: msg.id, channel: input.channel, intent: intent.key }, input.externalId ? { idempotencyKey: `inbound:${input.channel}:${input.externalId}` } : {});
    return { conversationId: conv.id, messageId: msg.id, intent };
  });
}

export async function listConversations(ctx: TenantContext, status?: string) {
  requirePerm(ctx, "closer:read");
  const conds = [eq(conversations.organizationId, ctx.organizationId)];
  if (status) conds.push(eq(conversations.status, status));
  return ctx.db.select({ c: conversations, contactName: contacts.name, contactEmail: contacts.email }).from(conversations)
    .leftJoin(contacts, eq(contacts.id, conversations.contactId)).where(and(...conds)).orderBy(desc(conversations.lastMessageAt)).limit(100);
}

export async function getConversation(ctx: TenantContext, id: string) {
  requirePerm(ctx, "closer:read");
  const [c] = await ctx.db.select({ c: conversations, contactName: contacts.name, contactEmail: contacts.email, contactPhone: contacts.phone })
    .from(conversations).leftJoin(contacts, eq(contacts.id, conversations.contactId))
    .where(and(eq(conversations.id, id), eq(conversations.organizationId, ctx.organizationId)));
  if (!c) throw new HttpError(404, "Conversa não encontrada.");
  const msgs = await ctx.db.select().from(messages).where(eq(messages.conversationId, id)).orderBy(asc(messages.createdAt));
  const channelConnected = await channelIsReal(ctx.db, ctx.organizationId, c.c.channel);
  const outboundImplemented = !!OUTBOUND_SENDERS[c.c.channel];
  // channelReal = envio realmente entrega ao cliente (integração conectada E envio implementado).
  return { ...c, messages: msgs, channelReal: channelConnected && outboundImplemented, channelConnected, outboundImplemented };
}

/** Envio por humano. */
export async function sendReply(ctx: TenantContext, conversationId: string, body: string, author: "user" | "ai" = "user") {
  requirePerm(ctx, "closer:write");
  const text = z.string().trim().min(1).max(5000).parse(body);
  const [conv] = await ctx.db.select().from(conversations).where(and(eq(conversations.id, conversationId), eq(conversations.organizationId, ctx.organizationId)));
  if (!conv) throw new HttpError(404, "Conversa não encontrada.");
  // AI Control Plane: kill switch da integração (qualquer autor) ou da categoria "enviar mensagem" (envios originados pela IA).
  const killed = await integrationBlockReason(ctx.db, ctx.organizationId, CHANNEL_PROVIDER[conv.channel] ?? conv.channel,
    author === "ai" ? [{ scope: "action_category", target: "send_message" }, { scope: "all_ai", target: "*" }] : []);
  if (killed) {
    const [m] = await ctx.db.insert(messages).values({ organizationId: ctx.organizationId, conversationId, direction: "outbound", author, body: text, status: "blocked" }).returning();
    await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "message.blocked_by_kill_switch", resource: "message", resourceId: m.id, metadata: { conversationId, channel: conv.channel, reason: killed } });
    return { message: m, delivered: false, notice: `Mensagem NÃO enviada. ${killed}` };
  }
  // Só é "sent" depois que a chamada ao provedor do canal tiver sucesso. Integração "conectada" sem
  // envio implementado NÃO conta como entregue (honestidade: nunca apresentar simulação como real).
  const connected = await channelIsReal(ctx.db, ctx.organizationId, conv.channel);
  const sender = OUTBOUND_SENDERS[conv.channel];
  let status: "sent" | "failed" | "simulated" = "simulated", externalId: string | null = null, notice: string | null;
  if (connected && sender) {
    try {
      externalId = (await sender({ organizationId: ctx.organizationId, conversationId, body: text })).externalId ?? null;
      status = "sent"; notice = null;
    } catch (err) {
      status = "failed"; notice = `Falha ao enviar pelo canal ${conv.channel}: ${(err as Error).message.slice(0, 160)}. A mensagem NÃO foi entregue.`;
    }
  } else if (connected) {
    notice = `Integração do canal ${conv.channel} conectada, mas o envio real por este canal ainda não foi implementado: a mensagem foi registrada e NÃO foi entregue ao cliente.`;
  } else {
    notice = "Canal sem integração real conectada: a mensagem foi registrada mas NÃO foi entregue ao cliente.";
  }
  const delivered = status === "sent";
  return ctx.db.transaction(async (tx) => {
    const [m] = await tx.insert(messages).values({ organizationId: ctx.organizationId, conversationId, direction: "outbound", author, body: text, status, externalId }).returning();
    await tx.update(conversations).set({ lastMessageAt: new Date(), slaDueAt: null, status: conv.status === "handoff" && author === "user" ? "open" : conv.status }).where(eq(conversations.id, conversationId));
    await recordUsage(tx, ctx.organizationId, "messages", 1);
    await publish(tx, ctx.organizationId, EVENT_TYPES.MESSAGE_REPLIED, { conversationId, messageId: m.id, author, delivered, deliveryNote: notice, outboundImplemented: !!sender });
    return { message: m, delivered, notice };
  });
}

/**
 * Envio real por canal. Cada canal só entra aqui quando a chamada ao provedor estiver implementada e testada.
 * Hoje NENHUM canal tem envio real implementado — todas as respostas ficam "não entregue (simulado)".
 */
type OutboundSender = (m: { organizationId: string; conversationId: string; body: string }) => Promise<{ externalId?: string }>;
export const OUTBOUND_SENDERS: Partial<Record<string, OutboundSender>> = {};

/**
 * Atalho legado (API /suggest e integrações): cria a sugestão pelo serviço de colaboração (rascunho versionado)
 * e a submete à fila de aprovações. A interface usa o fluxo completo de rascunhos (/api/ai-drafts).
 */
export async function suggestAiReply(ctx: TenantContext, conversationId: string) {
  requirePerm(ctx, "closer:write");
  const conv = await getConversation(ctx, conversationId);
  if (!conv.messages.some((m) => m.direction === "inbound")) throw new HttpError(400, "Não há mensagem do cliente para responder.");
  const view = await createDraft(ctx, { module: "closer", subjectId: conversationId });
  const current = view.versions.find((v) => v.id === view.currentVersionId)!;
  const r = await sendDraft(ctx, view.draft.id, { versionId: current.id }, { forceApproval: true });
  if (view.needsHuman) await ctx.db.update(conversations).set({ status: "handoff" }).where(eq(conversations.id, conversationId));
  return {
    approvalId: r.approvalId!, draftId: view.draft.id, suggestion: current.content,
    sources: current.sources.map((s) => ({ title: s.title, similarity: Number(s.similarity ?? 0) })), needsHuman: view.needsHuman,
    ai: { simulated: current.simulated, warnings: view.warnings, status: "success" as const, credits: 0 },
  };
}

/** Decisão humana sobre ações sensíveis da IA. Aprovar uma mensagem efetivamente a envia. */
export async function decideApproval(ctx: TenantContext, approvalId: string, approve: boolean, editedBody?: string) {
  requirePerm(ctx, "approvals:decide");
  const [a] = await ctx.db.select().from(approvalRequests).where(and(eq(approvalRequests.id, approvalId), eq(approvalRequests.organizationId, ctx.organizationId)));
  if (!a) throw new HttpError(404, "Aprovação não encontrada.");
  if (a.status !== "pending") throw new HttpError(409, "Esta aprovação já foi decidida.");
  await ctx.db.update(approvalRequests).set({ status: approve ? "approved" : "rejected", decidedBy: ctx.userId, decidedAt: new Date() }).where(eq(approvalRequests.id, a.id));
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: approve ? "approval.approved" : "approval.rejected", resource: "approval", resourceId: a.id, metadata: { kind: a.kind } });
  await publish(ctx.db, ctx.organizationId, EVENT_TYPES.APPROVAL_DECIDED, { approvalId: a.id, kind: a.kind, approved: approve });
  let result: unknown = null;
  if (a.kind === "ai_message") {
    const p = a.payload as { conversationId: string; body: string; draftId?: string; versionId?: string };
    if (p.draftId && p.versionId) {
      // Pedido vindo de um rascunho versionado: envia EXATAMENTE a versão submetida (ou a edição do aprovador, registrada como nova versão).
      result = await finalizeDraftApproval(ctx, { draftId: p.draftId, versionId: p.versionId, conversationId: p.conversationId }, approve, editedBody);
    } else if (approve) {
      result = await sendReply(ctx, p.conversationId, editedBody?.trim() || p.body, "ai");
    }
  }
  return { status: approve ? "approved" : "rejected", result };
}

export async function listApprovals(ctx: TenantContext, status = "pending") {
  requirePerm(ctx, "closer:read");
  return ctx.db.select().from(approvalRequests).where(and(eq(approvalRequests.organizationId, ctx.organizationId), eq(approvalRequests.status, status))).orderBy(desc(approvalRequests.createdAt)).limit(50);
}

export async function summarizeConversation(ctx: TenantContext, conversationId: string) {
  const conv = await getConversation(ctx, conversationId);
  const transcript = conv.messages.map((m) => `${m.direction === "inbound" ? "Cliente" : "Equipe"}: ${m.body}`).join("\n");
  const out = await runAgent(ctx, { agentKey: "qualification", input: "Resuma a conversa em até 5 tópicos e indique próximos passos.", context: transcript });
  await ctx.db.update(conversations).set({ summary: out.text }).where(eq(conversations.id, conversationId));
  return out;
}

export async function setConversationStatus(ctx: TenantContext, id: string, patch: { status?: "open" | "waiting" | "handoff" | "closed"; aiEnabled?: boolean }) {
  requirePerm(ctx, "closer:write");
  const [c] = await ctx.db.update(conversations).set(patch).where(and(eq(conversations.id, id), eq(conversations.organizationId, ctx.organizationId))).returning();
  if (!c) throw new HttpError(404, "Conversa não encontrada.");
  return c;
}

/** Conversas com SLA estourado (cliente aguardando resposta). */
export async function slaBreaches(db: DB, organizationId: string) {
  return db.select().from(conversations).where(and(eq(conversations.organizationId, organizationId), lt(conversations.slaDueAt, new Date()), sql`${conversations.status} <> 'closed'`));
}

export async function listKnowledge(ctx: TenantContext) {
  requirePerm(ctx, "closer:read");
  return ctx.db.select({ id: knowledgeDocuments.id, title: knowledgeDocuments.title, kind: knowledgeDocuments.kind, createdAt: knowledgeDocuments.createdAt, size: sql<number>`length(${knowledgeDocuments.content})` })
    .from(knowledgeDocuments).where(eq(knowledgeDocuments.organizationId, ctx.organizationId)).orderBy(desc(knowledgeDocuments.createdAt));
}
