/**
 * CENTRAL DE INTEGRAÇÕES — catálogo, credenciais criptografadas por organização, logs e status.
 * Status "connected" só é atribuído após validação real da credencial. Integrações sem conector implementado
 * ou sem credencial aparecem como "Requer credenciais" — nunca como conectadas.
 */
import { and, desc, eq } from "drizzle-orm";
import { integrationLogs, integrations } from "../../db/schema";
import { requirePerm, type TenantContext } from "../../tenancy/context";
import { encrypt } from "../../auth/crypto";
import { audit } from "../../audit";
import { HttpError } from "../../http";

export type CatalogItem = { provider: string; name: string; category: string; auth: "oauth" | "api_key" | "webhook" | "builtin"; validator?: (creds: Record<string, string>) => Promise<void>; fields?: string[] };

async function check(url: string, init: RequestInit) {
  const r = await fetch(url, { ...init, signal: AbortSignal.timeout(10_000) });
  if (!r.ok) throw new Error(`Credencial rejeitada pelo provedor (HTTP ${r.status}).`);
}

export const CATALOG: CatalogItem[] = [
  { provider: "whatsapp", name: "WhatsApp Business Platform (oficial)", category: "Comunicação", auth: "api_key", fields: ["phoneNumberId", "accessToken"],
    validator: (c) => check(`https://graph.facebook.com/v21.0/${encodeURIComponent(c.phoneNumberId)}`, { headers: { authorization: `Bearer ${c.accessToken}` } }) },
  { provider: "email_smtp", name: "E-mail (SMTP)", category: "Comunicação", auth: "api_key", fields: ["smtpUrl"] },
  { provider: "webchat", name: "Webchat ORBITY", category: "Comunicação", auth: "builtin" },
  { provider: "instagram", name: "Instagram Direct", category: "Comunicação", auth: "oauth" },
  { provider: "hubspot", name: "HubSpot", category: "CRM", auth: "api_key", fields: ["accessToken"],
    validator: (c) => check("https://api.hubapi.com/crm/v3/objects/contacts?limit=1", { headers: { authorization: `Bearer ${c.accessToken}` } }) },
  { provider: "pipedrive", name: "Pipedrive", category: "CRM", auth: "api_key", fields: ["apiToken"],
    validator: (c) => check(`https://api.pipedrive.com/v1/users/me?api_token=${encodeURIComponent(c.apiToken)}`, {}) },
  { provider: "rdstation", name: "RD Station", category: "CRM", auth: "oauth" },
  { provider: "google_workspace", name: "Google Workspace (Gmail, Drive, Calendar)", category: "Produtividade", auth: "oauth" },
  { provider: "microsoft_365", name: "Microsoft 365 (Outlook, OneDrive, Teams)", category: "Produtividade", auth: "oauth" },
  { provider: "zapier", name: "Zapier", category: "Produtividade", auth: "webhook" },
  { provider: "make", name: "Make", category: "Produtividade", auth: "webhook" },
  { provider: "n8n", name: "n8n", category: "Produtividade", auth: "webhook" },
  { provider: "google_sheets", name: "Google Sheets", category: "Dados", auth: "oauth" },
  { provider: "csv", name: "Importação CSV", category: "Dados", auth: "builtin" },
  { provider: "rest_webhook", name: "API REST / Webhooks", category: "Dados", auth: "webhook" },
  { provider: "stripe", name: "Stripe", category: "Pagamentos", auth: "api_key", fields: ["secretKey"],
    validator: (c) => check("https://api.stripe.com/v1/balance", { headers: { authorization: `Bearer ${c.secretKey}` } }) },
  { provider: "mercadopago", name: "Mercado Pago", category: "Pagamentos", auth: "api_key", fields: ["accessToken"],
    validator: (c) => check("https://api.mercadopago.com/users/me", { headers: { authorization: `Bearer ${c.accessToken}` } }) },
  { provider: "asaas", name: "Asaas", category: "Pagamentos", auth: "api_key", fields: ["apiKey"],
    validator: (c) => check("https://api.asaas.com/v3/myAccount", { headers: { access_token: c.apiKey } }) },
];

export async function listIntegrations(ctx: TenantContext) {
  requirePerm(ctx, "integrations:read");
  const rows = await ctx.db.select().from(integrations).where(eq(integrations.organizationId, ctx.organizationId));
  return CATALOG.map((c) => {
    const r = rows.find((x) => x.provider === c.provider);
    const status = c.auth === "builtin" ? "connected" : r?.status ?? "disconnected";
    return {
      provider: c.provider, name: c.name, category: c.category, auth: c.auth, fields: c.fields ?? [],
      status, mode: r?.mode ?? (c.auth === "builtin" ? "real" : "real"), lastSyncAt: r?.lastSyncAt ?? null, lastError: r?.lastError ?? null,
      connectable: !!c.validator, note: c.auth === "oauth" ? "Requer configuração do app OAuth (credenciais do provedor)." : c.auth === "webhook" ? "Use a URL de webhook da organização." : !c.validator && c.auth === "api_key" ? "Credencial armazenada; validação manual." : null,
    };
  });
}

export async function connectIntegration(ctx: TenantContext, provider: string, creds: Record<string, string>) {
  requirePerm(ctx, "integrations:manage");
  const item = CATALOG.find((c) => c.provider === provider);
  if (!item) throw new HttpError(404, "Integração desconhecida.");
  for (const f of item.fields ?? []) if (!creds[f]?.trim()) throw new HttpError(400, `Campo obrigatório: ${f}`);
  let status = "connected", lastError: string | null = null;
  if (item.validator) {
    try { await item.validator(creds); } catch (err) { status = "error"; lastError = (err as Error).message; }
  } else if (item.auth !== "api_key") {
    throw new HttpError(409, "Esta integração requer fluxo OAuth com credenciais de aplicativo configuradas pelo administrador da plataforma.");
  }
  // Identificadores NÃO secretos ficam em config (roteamento de webhooks sem descriptografar credenciais).
  const config: Record<string, unknown> = provider === "whatsapp" ? { phoneNumberId: creds.phoneNumberId } : {};
  const values = { organizationId: ctx.organizationId, provider, category: item.category, status, mode: "real", config, encryptedCredentials: encrypt(JSON.stringify(creds)), lastError, lastSyncAt: status === "connected" ? new Date() : null };
  const [row] = await ctx.db.insert(integrations).values(values).onConflictDoUpdate({ target: [integrations.organizationId, integrations.provider], set: values }).returning();
  await ctx.db.insert(integrationLogs).values({ organizationId: ctx.organizationId, integrationId: row.id, level: status === "connected" ? "info" : "error", message: status === "connected" ? "Credencial validada e conectada." : `Falha na validação: ${lastError}` });
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: `integration.${status}`, resource: "integration", resourceId: row.id, metadata: { provider } });
  return { status, lastError };
}

export async function disconnectIntegration(ctx: TenantContext, provider: string) {
  requirePerm(ctx, "integrations:manage");
  const [row] = await ctx.db.update(integrations).set({ status: "disconnected", encryptedCredentials: null }).where(and(eq(integrations.organizationId, ctx.organizationId), eq(integrations.provider, provider))).returning();
  if (row) await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "integration.disconnected", resource: "integration", resourceId: row.id });
  return { ok: true };
}

export async function integrationLogsFor(ctx: TenantContext) {
  requirePerm(ctx, "integrations:read");
  return ctx.db.select().from(integrationLogs).where(eq(integrationLogs.organizationId, ctx.organizationId)).orderBy(desc(integrationLogs.createdAt)).limit(50);
}
