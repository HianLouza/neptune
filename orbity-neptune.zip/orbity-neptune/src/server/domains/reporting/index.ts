/** RELATÓRIOS GERENCIAIS — montados a partir das métricas canônicas do Sales Intelligence. */
import { z } from "zod";
import { requirePerm, type TenantContext } from "../../tenancy/context";
import { dashboardKpis, funnelAnalysis, leadOrigins, recommendations, revenueForecast, sellerPerformance } from "../intelligence";
import { money } from "../../../lib/format";

export const REPORT_TYPES = {
  executive: "Executivo",
  funnel: "Funil",
  sellers: "Vendedores",
  origins: "Origem de leads",
  forecast: "Previsão",
} as const;
export type ReportType = keyof typeof REPORT_TYPES;
export const reportQuery = z.object({
  type: z.enum(["executive", "funnel", "sellers", "origins", "forecast"]).default("executive"),
  days: z.coerce.number().int().refine((d) => [7, 30, 90, 180, 365].includes(d), "Período inválido").default(30),
});

export type Report = { type: ReportType; title: string; days: number; generatedAt: string; columns: string[]; rows: (string | number)[][]; notes: string[]; context: string };

export async function buildReport(ctx: TenantContext, type: ReportType, days: number): Promise<Report> {
  requirePerm(ctx, "intelligence:read");
  const o = { locale: ctx.locale, currency: ctx.currency };
  const base = { type, title: `Relatório ${REPORT_TYPES[type]} — últimos ${days} dias`, days, generatedAt: new Date().toISOString() };
  const fmtPct = (v: number | null) => (v == null ? "n/d" : `${v}%`);

  if (type === "executive") {
    const k = await dashboardKpis(ctx, days);
    const recs = await recommendations(ctx);
    const rows: (string | number)[][] = [
      ["Leads gerados", k.current.leads, k.previous.leads, fmtPct(k.delta.leads)],
      ["Oportunidades criadas", k.current.opportunities, k.previous.opportunities, fmtPct(k.delta.opportunities)],
      ["Vendas realizadas", k.current.won, k.previous.won, fmtPct(k.delta.won)],
      ["Receita", money(k.current.revenueCents, o), money(k.previous.revenueCents, o), fmtPct(k.delta.revenue)],
      ["Taxa de conversão", fmtPct(k.current.conversionRate), fmtPct(k.previous.conversionRate), k.delta.conversionPp == null ? "n/d" : `${k.delta.conversionPp} p.p.`],
    ];
    const notes = recs.map((r) => `[${r.priority}] ${r.problem}: ${r.evidence} → ${r.action}`);
    return { ...base, columns: ["Indicador", "Período atual", "Período anterior", "Variação"], rows, notes, context: toContext(["Indicador", "Atual", "Anterior", "Variação"], rows, notes) };
  }
  if (type === "funnel") {
    const f = await funnelAnalysis(ctx);
    const open = f.filter((s) => s.kind === "open");
    const rows = f.map((s) => {
      const i = open.findIndex((x) => x.id === s.id);
      const conv = i > 0 && open[i - 1].n ? `${Math.round((s.n / open[i - 1].n) * 100)}%` : "—";
      return [s.name, s.kind === "open" ? "Aberta" : s.kind === "won" ? "Ganho" : "Perdido", s.n, money(s.total, o), conv];
    });
    return { ...base, title: "Relatório de Funil (posição atual)", columns: ["Etapa", "Tipo", "Oportunidades", "Valor", "Passagem da etapa anterior"], rows, notes: ["Funil reflete a posição atual das oportunidades (não depende do período)."], context: toContext(["Etapa", "Tipo", "Qtd", "Valor", "Passagem"], rows, []) };
  }
  if (type === "sellers") {
    const s = await sellerPerformance(ctx, days);
    const rows = s.map((r, i) => [i + 1, r.name, r.won, r.lost, r.open, money(r.revenue, o), r.winRate == null ? "n/d" : `${r.winRate}%`]);
    const notes = s.filter((r) => r.won + r.lost < 5).length ? ["Vendedores com menos de 5 negócios fechados têm taxa de conversão pouco confiável."] : [];
    return { ...base, columns: ["#", "Vendedor", "Ganhas", "Perdidas", "Abertas", "Receita", "Conversão"], rows, notes, context: toContext(["#", "Vendedor", "Ganhas", "Perdidas", "Abertas", "Receita", "Conversão"], rows, notes) };
  }
  if (type === "origins") {
    const og = await leadOrigins(ctx, days);
    const rows = og.buckets.map((b) => [b.label, b.count, `${b.pct}%`]);
    return { ...base, columns: ["Origem", "Leads", "Participação"], rows, notes: [`Total de leads no período: ${og.total}.`], context: toContext(["Origem", "Leads", "%"], rows, []) };
  }
  const fc = await revenueForecast(ctx);
  const rows = [
    ["Pessimista", money(fc.scenarios.pessimistic, o)],
    ["Base", money(fc.scenarios.base, o)],
    ["Otimista", money(fc.scenarios.optimistic, o)],
    ["Pipeline aberto (total)", money(fc.pipelineTotalCents, o)],
    ["Negócios abertos", fc.openDeals],
    ["Taxa de ganho histórica (90d)", fc.historicalWinRate == null ? "n/d" : `${Math.round(fc.historicalWinRate * 1000) / 10}%`],
  ];
  const notes = [...fc.assumptions, ...fc.limitations];
  return { ...base, title: "Relatório de Previsão de Receita", columns: ["Cenário / Indicador", "Valor"], rows, notes, context: toContext(["Cenário", "Valor"], rows, notes) };
}

function toContext(cols: string[], rows: (string | number)[][], notes: string[]) {
  return [cols.join(" | "), ...rows.map((r) => r.join(" | ")), ...(notes.length ? ["Observações:", ...notes] : [])].join("\n");
}

export function reportToCsv(r: Report) {
  const esc = (v: string | number) => {
    const s = String(v);
    return /[";\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const lines = [r.columns.map(esc).join(";"), ...r.rows.map((row) => row.map(esc).join(";"))];
  if (r.notes.length) lines.push("", ...r.notes.map((n) => esc(n)));
  return "﻿" + lines.join("\r\n");
}
