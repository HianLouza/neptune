/**
 * BILLING / CRÉDITOS / ENTITLEMENTS
 * - Planos definem features e limites; exceções contratuais sobrescrevem limites por organização.
 * - Carteira unificada de créditos de IA. Consumo acima do saldo só é permitido com excedente AUTORIZADO
 *   (contrato) e até o teto definido. Nunca cobrar sem autorização (regra 7).
 * - Preços finais NÃO são inventados: planos sem preço exibem "a definir".
 */
import { and, desc, eq, gte, sql } from "drizzle-orm";
import type { DB } from "../../db/client";
import { creditTransactions, creditWallets, invoices, plans, subscriptions, usageRecords, featureFlags, featureFlagOverrides, organizations, memberships } from "../../db/schema";
import { publish, EVENT_TYPES } from "../../events";
import { audit } from "../../audit";
import type { TenantContext } from "../../tenancy/context";

/** Preço unitário de excedente por crédito (centavos). Parâmetro configurável — hipótese a validar comercialmente. */
export const OVERAGE_CENTS_PER_CREDIT = Number(process.env.OVERAGE_CENTS_PER_CREDIT ?? 2);

export class PaymentRequiredError extends Error { status = 402; }
export class LimitError extends Error { status = 403; }

export async function getSubscription(db: DB, organizationId: string) {
  const [row] = await db.select({ sub: subscriptions, plan: plans }).from(subscriptions)
    .innerJoin(plans, eq(plans.id, subscriptions.planId))
    .where(eq(subscriptions.organizationId, organizationId)).orderBy(desc(subscriptions.createdAt)).limit(1);
  return row ?? null;
}

export async function getWallet(db: DB, organizationId: string) {
  const [w] = await db.select().from(creditWallets).where(eq(creditWallets.organizationId, organizationId));
  return w ?? null;
}

/** Entitlement: a organização tem acesso à feature? (plano + flags + overrides) */
export async function hasFeature(db: DB, organizationId: string, feature: string, userId?: string) {
  const s = await getSubscription(db, organizationId);
  const planHas = !!s && ["trialing", "active", "past_due"].includes(s.sub.status) && s.plan.features.includes(feature);
  const [flag] = await db.select().from(featureFlags).where(eq(featureFlags.key, feature));
  if (!flag) return planHas;
  const overrides = await db.select().from(featureFlagOverrides).where(eq(featureFlagOverrides.flagKey, feature));
  const userOv = userId && overrides.find((o) => o.userId === userId);
  if (userOv) return userOv.enabled;
  const orgOv = overrides.find((o) => o.organizationId === organizationId);
  if (orgOv) return orgOv.enabled;
  if (!flag.enabled) return false;
  if (flag.plans.length && s && !flag.plans.includes(s.plan.key)) return false;
  if (flag.segments.length) {
    const [org] = await db.select({ segment: organizations.segment }).from(organizations).where(eq(organizations.id, organizationId));
    if (!org?.segment || !flag.segments.includes(org.segment)) return false;
  }
  // Rollout gradual determinístico por organização.
  const bucket = [...organizationId].reduce((a, c) => (a * 31 + c.charCodeAt(0)) % 100, 7);
  return bucket < flag.rolloutPct || flag.rolloutPct >= 100 || planHas;
}

export async function getLimit(db: DB, organizationId: string, metric: string): Promise<number | null> {
  const s = await getSubscription(db, organizationId);
  if (!s) return 0;
  const exc = s.sub.contractExceptions?.[metric];
  if (typeof exc === "number") return exc;
  const l = s.plan.limits[metric];
  return typeof l === "number" ? (l < 0 ? null : l) : null; // -1 = ilimitado
}

/** Verifica limite de quantidade antes de criar recursos (ex.: leads/mês, usuários, automações). */
export async function assertWithinLimit(db: DB, organizationId: string, metric: string, currentCount: number) {
  const limit = await getLimit(db, organizationId, metric);
  if (limit !== null && currentCount >= limit) {
    await publish(db, organizationId, EVENT_TYPES.LIMIT_REACHED, { metric, limit }, { idempotencyKey: `limit:${organizationId}:${metric}:${new Date().toISOString().slice(0, 10)}` });
    throw new LimitError(`Limite do plano atingido para "${metric}" (${limit}). Faça upgrade ou contrate um add-on.`);
  }
}

export async function recordUsage(db: Pick<DB, "insert">, organizationId: string, metric: string, quantity: number) {
  const now = new Date();
  await db.insert(usageRecords).values({ organizationId, metric, quantity, periodStart: new Date(now.getFullYear(), now.getMonth(), 1) });
}

export async function usageThisPeriod(db: DB, organizationId: string, metric: string) {
  const now = new Date();
  const [r] = await db.select({ total: sql<number>`coalesce(sum(${usageRecords.quantity}), 0)::int` }).from(usageRecords)
    .where(and(eq(usageRecords.organizationId, organizationId), eq(usageRecords.metric, metric), gte(usageRecords.periodStart, new Date(now.getFullYear(), now.getMonth(), 1))));
  return Number(r?.total ?? 0);
}

/**
 * Consome créditos de IA de forma atômica.
 * - Saldo suficiente: debita.
 * - Saldo insuficiente: só prossegue se excedente autorizado e dentro do teto; o valor fica registrado para a fatura.
 */
export async function consumeCredits(db: DB, organizationId: string, amount: number, reason: string, meta: { referenceId?: string; agentKey?: string; teamId?: string } = {}) {
  if (amount <= 0) return { overageCredits: 0 };
  const s = await getSubscription(db, organizationId);
  if (s && ["suspended", "canceled"].includes(s.sub.status)) throw new PaymentRequiredError("Assinatura suspensa. Regularize o pagamento para usar a IA.");
  return db.transaction(async (tx) => {
    const [w] = await tx.select().from(creditWallets).where(eq(creditWallets.organizationId, organizationId)).for("update");
    if (!w) throw new PaymentRequiredError("Carteira de créditos não encontrada.");
    let overageCredits = 0;
    if (w.balance < amount) {
      overageCredits = amount - Math.max(0, w.balance);
      const authorized = s?.sub.overageAuthorized ?? false;
      const capCredits = s ? Math.floor(Number(s.sub.overageCapCents) / OVERAGE_CENTS_PER_CREDIT) : 0;
      const [used] = await tx.select({ total: sql<number>`coalesce(sum(-${creditTransactions.amount}), 0)::int` }).from(creditTransactions)
        .where(and(eq(creditTransactions.organizationId, organizationId), eq(creditTransactions.reason, "overage"), gte(creditTransactions.createdAt, s?.sub.currentPeriodStart ?? new Date(0))));
      if (!authorized || Number(used?.total ?? 0) + overageCredits > capCredits) {
        await publish(tx, organizationId, EVENT_TYPES.LIMIT_REACHED, { metric: "ai_credits", balance: w.balance }, { idempotencyKey: `limit:${organizationId}:credits:${new Date().toISOString().slice(0, 13)}` });
        throw new PaymentRequiredError("Créditos de IA insuficientes. Compre créditos ou autorize excedentes no Billing.");
      }
    }
    const debit = amount - overageCredits;
    await tx.update(creditWallets).set({ balance: w.balance - debit, usedThisPeriod: w.usedThisPeriod + amount, updatedAt: new Date() }).where(eq(creditWallets.id, w.id));
    if (debit > 0) await tx.insert(creditTransactions).values({ organizationId, amount: -debit, reason, referenceId: meta.referenceId, agentKey: meta.agentKey, teamId: meta.teamId });
    if (overageCredits > 0) await tx.insert(creditTransactions).values({ organizationId, amount: -overageCredits, reason: "overage", referenceId: meta.referenceId, agentKey: meta.agentKey });
    await recordUsage(tx, organizationId, "ai_credits", amount);
    await publish(tx, organizationId, EVENT_TYPES.CREDIT_CONSUMED, { amount, reason, overageCredits, agentKey: meta.agentKey ?? null });
    return { overageCredits };
  });
}

/** Créditos usados hoje por um agente (limites por agente). */
export async function agentCreditsToday(db: DB, organizationId: string, agentKey: string) {
  const start = new Date(); start.setHours(0, 0, 0, 0);
  const [r] = await db.select({ total: sql<number>`coalesce(sum(-${creditTransactions.amount}), 0)::int` }).from(creditTransactions)
    .where(and(eq(creditTransactions.organizationId, organizationId), eq(creditTransactions.agentKey, agentKey), gte(creditTransactions.createdAt, start)));
  return Number(r?.total ?? 0);
}

/** Previsão de gastos (simulador): projeção linear do consumo do período. */
export async function forecastSpend(db: DB, organizationId: string) {
  const s = await getSubscription(db, organizationId);
  const w = await getWallet(db, organizationId);
  if (!s || !w) return null;
  const start = s.sub.currentPeriodStart.getTime(), end = s.sub.currentPeriodEnd.getTime();
  const elapsed = Math.max(1, (Date.now() - start) / 864e5), total = Math.max(1, (end - start) / 864e5);
  const projectedUse = Math.round((w.usedThisPeriod / elapsed) * total);
  const projectedOverage = Math.max(0, projectedUse - w.monthlyAllowance - Math.max(0, w.balance - (w.monthlyAllowance - w.usedThisPeriod)));
  return {
    usedThisPeriod: w.usedThisPeriod, balance: w.balance, allowance: w.monthlyAllowance, projectedUse,
    projectedOverageCredits: projectedOverage, projectedOverageCents: projectedOverage * OVERAGE_CENTS_PER_CREDIT,
    overageAuthorized: s.sub.overageAuthorized, overageCapCents: Number(s.sub.overageCapCents),
    assumptions: ["Projeção linear do consumo médio diário do período atual.", `Preço de excedente: ${OVERAGE_CENTS_PER_CREDIT} centavos/crédito (parâmetro a validar).`],
  };
}

export async function setOverageAuthorization(ctx: TenantContext, authorized: boolean, capCents: number) {
  const s = await getSubscription(ctx.db, ctx.organizationId);
  if (!s) throw new LimitError("Sem assinatura.");
  await ctx.db.update(subscriptions).set({ overageAuthorized: authorized, overageCapCents: Math.max(0, Math.round(capCents)) }).where(eq(subscriptions.id, s.sub.id));
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "billing.overage_authorization", resource: "subscription", resourceId: s.sub.id, metadata: { authorized, capCents } });
}

export async function changePlan(ctx: TenantContext, planKey: string) {
  const [plan] = await ctx.db.select().from(plans).where(and(eq(plans.key, planKey), eq(plans.active, true)));
  if (!plan) throw new LimitError("Plano inválido.");
  const s = await getSubscription(ctx.db, ctx.organizationId);
  if (!s) throw new LimitError("Sem assinatura.");
  // Downgrade: o uso atual precisa caber nos limites do novo plano.
  const userLimit = plan.limits.users;
  if (typeof userLimit === "number" && userLimit >= 0) {
    const [m] = await ctx.db.select({ n: sql<number>`count(*)::int` }).from(memberships)
      .where(and(eq(memberships.organizationId, ctx.organizationId), eq(memberships.status, "active")));
    if (Number(m?.n ?? 0) > userLimit) throw new LimitError(`O plano ${plan.name} permite ${userLimit} usuários; a organização tem ${m.n} ativos. Desative usuários antes do downgrade.`);
  }
  await ctx.db.update(subscriptions).set({ planId: plan.id }).where(eq(subscriptions.id, s.sub.id));
  await ctx.db.update(creditWallets).set({ monthlyAllowance: plan.includedCredits }).where(eq(creditWallets.organizationId, ctx.organizationId));
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "billing.plan_changed", resource: "subscription", metadata: { from: s.plan.key, to: plan.key } });
  return plan;
}

/** Gera fatura do período (assinatura + excedentes registrados). Pagamento real depende do provedor configurado. */
export async function generateInvoice(db: DB, organizationId: string) {
  const s = await getSubscription(db, organizationId);
  if (!s) return null;
  const [ov] = await db.select({ total: sql<number>`coalesce(sum(-${creditTransactions.amount}), 0)::int` }).from(creditTransactions)
    .where(and(eq(creditTransactions.organizationId, organizationId), eq(creditTransactions.reason, "overage"), gte(creditTransactions.createdAt, s.sub.currentPeriodStart)));
  const lines: { description: string; amountCents: number }[] = [];
  if (s.plan.monthlyPriceCents != null) lines.push({ description: `Plano ${s.plan.name} (${s.sub.billingCycle === "annual" ? "anual" : "mensal"})`, amountCents: Number(s.plan.monthlyPriceCents) });
  const overageCredits = Number(ov?.total ?? 0);
  if (overageCredits > 0) lines.push({ description: `Excedente autorizado: ${overageCredits} créditos de IA`, amountCents: overageCredits * OVERAGE_CENTS_PER_CREDIT });
  const amount = lines.reduce((a, l) => a + l.amountCents, 0);
  const [count] = await db.select({ n: sql<number>`count(*)::int` }).from(invoices).where(eq(invoices.organizationId, organizationId));
  const [inv] = await db.insert(invoices).values({
    organizationId, number: `ON-${new Date().getFullYear()}-${String(Number(count?.n ?? 0) + 1).padStart(5, "0")}`, amountCents: amount,
    currency: s.plan.currency, status: amount > 0 ? "open" : "draft", lines, dueAt: new Date(Date.now() + 7 * 864e5),
  }).returning();
  await audit(db, { organizationId, actorId: "system", action: "billing.invoice_generated", resource: "invoice", resourceId: inv.id, metadata: { amount } });
  return inv;
}
