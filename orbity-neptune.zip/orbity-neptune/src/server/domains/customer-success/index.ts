/**
 * CUSTOMER SUCCESS (administração ORBITY-NEPTUNE) — Customer Health Score transparente e configurável.
 * Cada sinal vira um valor 0..1; score = soma ponderada × 100. Classificação por limiares configuráveis.
 */
import { and, count, eq, gte, sql, desc } from "drizzle-orm";
import type { DB } from "../../db/client";
import { aiExecutions, csInteractions, healthScoreConfig, integrations, memberships, organizations, sessions, subscriptions, supportTickets, workflows, opportunities, plans } from "../../db/schema";

export const DEFAULT_WEIGHTS = { access: 0.2, activeUsers: 0.15, featureAdoption: 0.2, integrations: 0.1, results: 0.15, tickets: 0.1, billing: 0.1 };
export const DEFAULT_THRESHOLDS = { healthy: 75, attention: 55, risk: 35 };

export async function getHealthConfig(db: DB) {
  const [c] = await db.select().from(healthScoreConfig).limit(1);
  return c ?? { weights: DEFAULT_WEIGHTS, thresholds: DEFAULT_THRESHOLDS };
}

export function classify(score: number, t = DEFAULT_THRESHOLDS) {
  return score >= t.healthy ? "Saudável" : score >= t.attention ? "Atenção" : score >= t.risk ? "Risco" : "Crítico";
}

export async function computeHealth(db: DB, organizationId: string) {
  const cfg = await getHealthConfig(db);
  const since = new Date(Date.now() - 30 * 864e5);
  const [members] = await db.select({ n: count() }).from(memberships).where(and(eq(memberships.organizationId, organizationId), eq(memberships.status, "active")));
  const [active] = await db.select({ n: sql<number>`count(distinct ${sessions.userId})::int` }).from(sessions).where(and(eq(sessions.organizationId, organizationId), gte(sessions.createdAt, since)));
  const [logins] = await db.select({ n: count() }).from(sessions).where(and(eq(sessions.organizationId, organizationId), gte(sessions.createdAt, since)));
  const [ai] = await db.select({ n: count() }).from(aiExecutions).where(and(eq(aiExecutions.organizationId, organizationId), gte(aiExecutions.createdAt, since)));
  const [wf] = await db.select({ n: count() }).from(workflows).where(and(eq(workflows.organizationId, organizationId), eq(workflows.status, "active")));
  const [integ] = await db.select({ n: count() }).from(integrations).where(and(eq(integrations.organizationId, organizationId), eq(integrations.status, "connected")));
  const [won] = await db.select({ n: count() }).from(opportunities).where(and(eq(opportunities.organizationId, organizationId), eq(opportunities.status, "won"), gte(opportunities.closedAt, since)));
  const [tk] = await db.select({ n: count() }).from(supportTickets).where(and(eq(supportTickets.organizationId, organizationId), gte(supportTickets.createdAt, since), sql`${supportTickets.priority} in ('high','urgent')`));
  const [sub] = await db.select({ status: subscriptions.status }).from(subscriptions).where(eq(subscriptions.organizationId, organizationId)).orderBy(desc(subscriptions.createdAt)).limit(1);
  const m = Math.max(1, Number(members.n));
  const signals = {
    access: Math.min(1, Number(logins.n) / (m * 8)),
    activeUsers: Math.min(1, Number(active.n) / m),
    featureAdoption: (Number(ai.n) > 0 ? 0.5 : 0) + (Number(wf.n) > 0 ? 0.5 : 0),
    integrations: Math.min(1, Number(integ.n) / 2),
    results: Math.min(1, Number(won.n) / 5),
    tickets: Math.max(0, 1 - Number(tk.n) / 3),
    billing: sub?.status === "active" ? 1 : sub?.status === "trialing" ? 0.7 : sub?.status === "past_due" ? 0.2 : 0,
  };
  const w = cfg.weights as Record<string, number>;
  const totalW = Object.values(w).reduce((a, b) => a + b, 0) || 1;
  const score = Math.round((Object.entries(signals).reduce((a, [k, v]) => a + v * (w[k] ?? 0), 0) / totalW) * 100);
  const status = classify(score, cfg.thresholds as typeof DEFAULT_THRESHOLDS);
  const recommendations: string[] = [];
  if (signals.activeUsers < 0.5) recommendations.push("Baixa utilização: agendar treinamento com a equipe do cliente.");
  if (signals.integrations === 0) recommendations.push("Nenhuma integração ativa: apoiar conexão de WhatsApp/e-mail.");
  if (signals.featureAdoption < 1) recommendations.push("Adoção parcial: apresentar automações e agentes de IA.");
  if (signals.billing < 0.5) recommendations.push("Pendência financeira: acionar time financeiro (comunicação externa requer aprovação).");
  return { organizationId, score, status, signals, weights: w, recommendations };
}

export async function healthOverview(db: DB) {
  const orgs = await db.select({ id: organizations.id, name: organizations.name, segment: organizations.segment, isDemo: organizations.isDemo, plan: plans.name, subStatus: subscriptions.status, periodEnd: subscriptions.currentPeriodEnd })
    .from(organizations).leftJoin(subscriptions, eq(subscriptions.organizationId, organizations.id)).leftJoin(plans, eq(plans.id, subscriptions.planId));
  const rows = [];
  for (const o of orgs) rows.push({ ...o, health: await computeHealth(db, o.id) });
  return rows;
}

export async function logInteraction(db: DB, organizationId: string, authorId: string, type: string, note: string) {
  const [r] = await db.insert(csInteractions).values({ organizationId, authorId, type, note }).returning();
  return r;
}
