/**
 * SERVIÇO CENTRAL DE MÉTRICAS — fonte única dos números de cards, gráficos, tabelas, relatórios e do Flávio.
 *
 * Princípios:
 *  - Toda consulta filtra por `organization_id` do TenantContext e exige permissão no backend.
 *  - Cada número sai acompanhado da definição (fórmula, fonte, campo de data), do período e dos filtros aplicados.
 *  - Nada é estimado ou preenchido: período sem registros retorna zero; métrica não aplicável retorna null com o motivo.
 *  - Datas em UTC (mesma convenção do Sales Intelligence).
 */
import { and, asc, count, desc, eq, gte, inArray, isNull, lt, sql, type SQL } from "drizzle-orm";
import { z } from "zod";
import { campaigns, companies, leads, memberships, opportunities, pipelineStages, teamMembers, teams, users } from "../../db/schema";
import { can, requirePerm, type TenantContext } from "../../tenancy/context";
import { ForbiddenError } from "../../permissions";
import {
  DIMENSIONS, DIMENSION_LABELS, SOURCE_KEYS, SOURCE_LABELS, describeFilters, metricFiltersSchema, resolvePeriod,
  type Dimension, type MetricFilters, type ResolvedPeriod,
} from "../../../lib/metrics-filters";

export { metricFiltersSchema };
export type { MetricFilters, Dimension };

/* ------------------------------------------------------------------ definições auditáveis */

export const METRIC_DEFINITIONS = {
  leads: { label: "Leads gerados", formula: "COUNT(leads) com created_at no período", source: "leads", dateField: "leads.created_at", dimensions: ["seller", "team", "campaign", "source"] },
  opportunities: { label: "Oportunidades criadas", formula: "COUNT(opportunities) com created_at no período", source: "opportunities", dateField: "opportunities.created_at", dimensions: ["seller", "team", "campaign", "source", "stage"] },
  won: { label: "Vendas realizadas", formula: "COUNT(opportunities) com status = 'won' e closed_at no período", source: "opportunities", dateField: "opportunities.closed_at", dimensions: ["seller", "team", "campaign", "source", "stage"] },
  lost: { label: "Oportunidades perdidas", formula: "COUNT(opportunities) com status = 'lost' e closed_at no período", source: "opportunities", dateField: "opportunities.closed_at", dimensions: ["seller", "team", "campaign", "source", "stage"] },
  revenue: { label: "Receita", formula: "SUM(opportunities.amount_cents) com status = 'won' e closed_at no período", source: "opportunities", dateField: "opportunities.closed_at", dimensions: ["seller", "team", "campaign", "source", "stage"] },
  conversion: { label: "Taxa de conversão", formula: "ganhas / (ganhas + perdidas), fechadas no período (definição canônica win_rate)", source: "opportunities", dateField: "opportunities.closed_at", dimensions: ["seller", "team", "campaign", "source", "stage"] },
  avg_ticket: { label: "Ticket médio", formula: "receita / vendas realizadas no período", source: "opportunities", dateField: "opportunities.closed_at", dimensions: ["seller", "team", "campaign", "source", "stage"] },
  open_pipeline: { label: "Pipeline aberto", formula: "SUM(opportunities.amount_cents) com status = 'open' (posição atual, independe do período)", source: "opportunities", dateField: "—", dimensions: ["seller", "team", "campaign", "source", "stage"] },
} as const;
export type MetricKey = keyof typeof METRIC_DEFINITIONS;

export const DIMENSION_NOTES: Record<Dimension, string> = {
  seller: "Responsável do registro (owner_id).",
  team: "Equipe do responsável (team_members). Na segmentação, quem está em mais de uma equipe entra na primeira em ordem alfabética; o filtro por equipe inclui todos os membros dela.",
  campaign: "Campanha do lead (leads.campaign_id). Oportunidades herdam a campanha do lead de origem.",
  source: "Origem do lead (leads.source). Oportunidades usam a própria origem e, se vazia, a do lead de origem.",
  stage: "Etapa atual da oportunidade. Não se aplica a leads.",
};

/* ------------------------------------------------------------------ filtros → SQL */

export function parseMetricFilters(raw: unknown): MetricFilters {
  return metricFiltersSchema.parse(raw ?? {});
}

/** Origem efetiva da oportunidade. */
const oppSource = sql<string>`coalesce(${opportunities.source}, ${leads.source}, 'other')`;

function teamUsers(ctx: TenantContext, teamId: string) {
  return sql`(select tm.user_id from ${teamMembers} tm inner join ${teams} t on t.id = tm.team_id where t.id = ${teamId} and t.organization_id = ${ctx.organizationId})`;
}

function leadFilterConds(ctx: TenantContext, f: MetricFilters): SQL[] {
  const c: SQL[] = [eq(leads.organizationId, ctx.organizationId)];
  if (f.seller) c.push(eq(leads.ownerId, f.seller));
  if (f.team) c.push(sql`${leads.ownerId} in ${teamUsers(ctx, f.team)}`);
  if (f.campaign === "none") c.push(isNull(leads.campaignId));
  else if (f.campaign) c.push(eq(leads.campaignId, f.campaign));
  if (f.source) c.push(eq(leads.source, f.source));
  return c;
}

/** Condições sobre opportunities (a consulta precisa de LEFT JOIN leads ON leads.id = opportunities.lead_id). */
function oppFilterConds(ctx: TenantContext, f: MetricFilters): SQL[] {
  const c: SQL[] = [eq(opportunities.organizationId, ctx.organizationId)];
  if (f.seller) c.push(eq(opportunities.ownerId, f.seller));
  if (f.team) c.push(sql`${opportunities.ownerId} in ${teamUsers(ctx, f.team)}`);
  if (f.campaign === "none") c.push(isNull(leads.campaignId));
  else if (f.campaign) c.push(eq(leads.campaignId, f.campaign));
  if (f.source) c.push(sql`${oppSource} = ${f.source}`);
  if (f.stage) c.push(eq(opportunities.stageId, f.stage));
  return c;
}

/** Leads não têm etapa: com filtro de etapa ativo, métricas de lead não se aplicam. */
const leadsApplicable = (f: MetricFilters) => !f.stage;

/* ------------------------------------------------------------------ KPIs */

export type KpiSet = {
  leads: number | null; opportunities: number; won: number; lost: number; revenueCents: number;
  conversionRate: number | null; avgTicketCents: number | null;
};
type Range = { start: Date; end: Date };

export async function computeKpis(ctx: TenantContext, f: MetricFilters, r: Range): Promise<KpiSet> {
  requirePerm(ctx, "intelligence:read");
  const db = ctx.db;
  const leadQ = leadsApplicable(f)
    ? db.select({ n: count() }).from(leads).where(and(...leadFilterConds(ctx, f), gte(leads.createdAt, r.start), lt(leads.createdAt, r.end)))
    : Promise.resolve(null);
  const oppQ = db.select({ n: count() }).from(opportunities).leftJoin(leads, eq(leads.id, opportunities.leadId))
    .where(and(...oppFilterConds(ctx, f), gte(opportunities.createdAt, r.start), lt(opportunities.createdAt, r.end)));
  const closedQ = db.select({
    won: sql<number>`count(*) filter (where ${opportunities.status} = 'won')::int`,
    lost: sql<number>`count(*) filter (where ${opportunities.status} = 'lost')::int`,
    revenue: sql<number>`coalesce(sum(${opportunities.amountCents}) filter (where ${opportunities.status} = 'won'),0)::bigint`,
  }).from(opportunities).leftJoin(leads, eq(leads.id, opportunities.leadId))
    .where(and(...oppFilterConds(ctx, f), sql`${opportunities.status} in ('won','lost')`, gte(opportunities.closedAt, r.start), lt(opportunities.closedAt, r.end)));
  const [l, [o], [c]] = await Promise.all([leadQ, oppQ, closedQ]);
  const won = Number(c.won), lost = Number(c.lost), revenue = Number(c.revenue);
  return {
    leads: l ? Number(l[0].n) : null,
    opportunities: Number(o.n), won, lost, revenueCents: revenue,
    conversionRate: won + lost ? Math.round((won / (won + lost)) * 1000) / 10 : null,
    avgTicketCents: won ? Math.round(revenue / won) : null,
  };
}

/** Variação percentual com 1 casa (mesma regra do dashboard original). null = sem base de comparação. */
export const pctDelta = (cur: number | null, prev: number | null) => {
  if (cur == null || prev == null) return null;
  return prev === 0 ? (cur > 0 ? null : 0) : Math.round(((cur - prev) / prev) * 1000) / 10;
};

export type MetricsMeta = {
  period: { start: string; end: string; label: string; days: number; custom: boolean };
  comparison: { start: string; end: string; label: string } | null;
  filters: MetricFilters; filtersApplied: string[]; generatedAt: string; timezone: "UTC";
  notApplicable: string[];
};

async function filterNames(ctx: TenantContext, f: MetricFilters) {
  const names: Partial<Record<Dimension, Record<string, string>>> = {};
  if (f.seller) { const [u] = await ctx.db.select({ name: users.name }).from(users).innerJoin(memberships, and(eq(memberships.userId, users.id), eq(memberships.organizationId, ctx.organizationId))).where(eq(users.id, f.seller)); if (u) names.seller = { [f.seller]: u.name }; }
  if (f.team) { const [t] = await ctx.db.select({ name: teams.name }).from(teams).where(and(eq(teams.id, f.team), eq(teams.organizationId, ctx.organizationId))); if (t) names.team = { [f.team]: t.name }; }
  if (f.campaign && f.campaign !== "none") { const [c] = await ctx.db.select({ name: campaigns.name }).from(campaigns).where(and(eq(campaigns.id, f.campaign), eq(campaigns.organizationId, ctx.organizationId))); if (c) names.campaign = { [f.campaign]: c.name }; }
  if (f.stage) { const [s] = await ctx.db.select({ name: pipelineStages.name }).from(pipelineStages).where(and(eq(pipelineStages.id, f.stage), eq(pipelineStages.organizationId, ctx.organizationId))); if (s) names.stage = { [f.stage]: s.name }; }
  return names;
}

export async function buildMeta(ctx: TenantContext, f: MetricFilters, p: ResolvedPeriod): Promise<MetricsMeta> {
  return {
    period: { start: p.start.toISOString(), end: p.end.toISOString(), label: p.label, days: p.days, custom: p.custom },
    comparison: p.prevStart && p.prevEnd ? { start: p.prevStart.toISOString(), end: p.prevEnd.toISOString(), label: p.compareLabel! } : null,
    filters: f, filtersApplied: describeFilters(f, await filterNames(ctx, f)), generatedAt: new Date().toISOString(), timezone: "UTC",
    notApplicable: leadsApplicable(f) ? [] : ["Leads: o filtro de etapa não se aplica a leads (leads não têm etapa)."],
  };
}

export async function metricsOverview(ctx: TenantContext, raw: unknown, now = new Date()) {
  const f = parseMetricFilters(raw);
  const p = resolvePeriod(f, now);
  const [current, previous, meta, pipeline] = await Promise.all([
    computeKpis(ctx, f, p),
    p.prevStart && p.prevEnd ? computeKpis(ctx, f, { start: p.prevStart, end: p.prevEnd }) : Promise.resolve(null),
    buildMeta(ctx, f, p),
    openPipeline(ctx, f),
  ]);
  const delta = previous ? {
    leads: pctDelta(current.leads, previous.leads), opportunities: pctDelta(current.opportunities, previous.opportunities),
    won: pctDelta(current.won, previous.won), revenue: pctDelta(current.revenueCents, previous.revenueCents),
    avgTicket: pctDelta(current.avgTicketCents, previous.avgTicketCents),
    conversionPp: current.conversionRate != null && previous.conversionRate != null ? Math.round((current.conversionRate - previous.conversionRate) * 10) / 10 : null,
  } : null;
  return { meta, current, previous, delta, pipeline, definitions: METRIC_DEFINITIONS };
}

export async function openPipeline(ctx: TenantContext, f: MetricFilters) {
  requirePerm(ctx, "intelligence:read");
  const [r] = await ctx.db.select({ n: count(), v: sql<number>`coalesce(sum(${opportunities.amountCents}),0)::bigint` })
    .from(opportunities).leftJoin(leads, eq(leads.id, opportunities.leadId))
    .where(and(...oppFilterConds(ctx, f), eq(opportunities.status, "open")));
  return { openDeals: Number(r.n), valueCents: Number(r.v) };
}

/* ------------------------------------------------------------------ séries */

export type SeriesPoint = {
  index: number; start: string; end: string;
  leads: number | null; opportunities: number; won: number; revenueCents: number;
  prev: { start: string; end: string; leads: number | null; opportunities: number; won: number; revenueCents: number } | null;
};

async function bucketed(ctx: TenantContext, f: MetricFilters, r: Range, sizeSec: number) {
  const b = (col: unknown) => sql<number>`floor(extract(epoch from (${col} - ${r.start.toISOString()}::timestamptz)) / ${sizeSec})::int`;
  const db = ctx.db;
  const [l, o, w] = await Promise.all([
    leadsApplicable(f)
      ? db.select({ b: b(leads.createdAt), n: count() }).from(leads).where(and(...leadFilterConds(ctx, f), gte(leads.createdAt, r.start), lt(leads.createdAt, r.end))).groupBy(sql`1`)
      : Promise.resolve(null),
    db.select({ b: b(opportunities.createdAt), n: count() }).from(opportunities).leftJoin(leads, eq(leads.id, opportunities.leadId))
      .where(and(...oppFilterConds(ctx, f), gte(opportunities.createdAt, r.start), lt(opportunities.createdAt, r.end))).groupBy(sql`1`),
    db.select({ b: b(opportunities.closedAt), n: count(), v: sql<number>`coalesce(sum(${opportunities.amountCents}),0)::bigint` }).from(opportunities).leftJoin(leads, eq(leads.id, opportunities.leadId))
      .where(and(...oppFilterConds(ctx, f), eq(opportunities.status, "won"), gte(opportunities.closedAt, r.start), lt(opportunities.closedAt, r.end))).groupBy(sql`1`),
  ]);
  return {
    leads: l ? new Map(l.map((x) => [Number(x.b), Number(x.n)])) : null,
    opps: new Map(o.map((x) => [Number(x.b), Number(x.n)])),
    won: new Map(w.map((x) => [Number(x.b), { n: Number(x.n), v: Number(x.v) }])),
  };
}

export async function metricsSeries(ctx: TenantContext, raw: unknown, now = new Date()) {
  requirePerm(ctx, "intelligence:read");
  const f = parseMetricFilters(raw);
  const p = resolvePeriod(f, now);
  const lenMs = p.end.getTime() - p.start.getTime();
  const bucketDays = p.days > 92 ? 7 : 1;
  const sizeMs = bucketDays * 864e5;
  const n = Math.max(1, Math.ceil(lenMs / sizeMs));
  const [cur, prev] = await Promise.all([
    bucketed(ctx, f, p, sizeMs / 1000),
    p.prevStart && p.prevEnd ? bucketed(ctx, f, { start: p.prevStart, end: p.prevEnd }, sizeMs / 1000) : Promise.resolve(null),
  ]);
  const points: SeriesPoint[] = [];
  for (let i = 0; i < n; i++) {
    const s = new Date(p.start.getTime() + i * sizeMs), e = new Date(Math.min(p.end.getTime(), s.getTime() + sizeMs));
    const ps = p.prevStart ? new Date(p.prevStart.getTime() + i * sizeMs) : null;
    points.push({
      index: i, start: s.toISOString(), end: e.toISOString(),
      leads: cur.leads ? cur.leads.get(i) ?? 0 : null, opportunities: cur.opps.get(i) ?? 0, won: cur.won.get(i)?.n ?? 0, revenueCents: cur.won.get(i)?.v ?? 0,
      prev: prev && ps ? {
        start: ps.toISOString(), end: new Date(Math.min(p.prevEnd!.getTime(), ps.getTime() + sizeMs)).toISOString(),
        leads: prev.leads ? prev.leads.get(i) ?? 0 : null, opportunities: prev.opps.get(i) ?? 0, won: prev.won.get(i)?.n ?? 0, revenueCents: prev.won.get(i)?.v ?? 0,
      } : null,
    });
  }
  return { bucketDays, points };
}

/* ------------------------------------------------------------------ segmentação */

export type BreakdownRow = {
  key: string; label: string; leads: number | null; opportunities: number; won: number; lost: number; revenueCents: number;
  conversionRate: number | null; prevRevenueCents: number | null; prevWon: number | null; revenueSharePct: number;
};

const NONE = "__none__";

function keyExprs(ctx: TenantContext, d: Dimension) {
  switch (d) {
    case "seller": return { lead: sql<string | null>`${leads.ownerId}::text`, opp: sql<string | null>`${opportunities.ownerId}::text` };
    case "campaign": return { lead: sql<string | null>`${leads.campaignId}::text`, opp: sql<string | null>`${leads.campaignId}::text` };
    case "source": return { lead: sql<string | null>`${leads.source}`, opp: sql<string | null>`${oppSource}` };
    case "stage": return { lead: null, opp: sql<string | null>`${opportunities.stageId}::text` };
    case "team": return {
      lead: sql<string | null>`(select tm.team_id::text from ${teamMembers} tm inner join ${teams} t on t.id = tm.team_id where tm.user_id = ${leads.ownerId} and t.organization_id = ${ctx.organizationId} order by t.name limit 1)`,
      opp: sql<string | null>`(select tm.team_id::text from ${teamMembers} tm inner join ${teams} t on t.id = tm.team_id where tm.user_id = ${opportunities.ownerId} and t.organization_id = ${ctx.organizationId} order by t.name limit 1)`,
    };
  }
}

async function dimensionLabels(ctx: TenantContext, d: Dimension, keys: string[]): Promise<Record<string, string>> {
  const ids = keys.filter((k) => k !== NONE && /^[0-9a-f-]{36}$/i.test(k));
  const none: Record<Dimension, string> = { seller: "Sem responsável", team: "Sem equipe", campaign: "Sem campanha", source: "Sem origem", stage: "Sem etapa" };
  const out: Record<string, string> = { [NONE]: none[d] };
  if (d === "source") { for (const k of keys) if (k !== NONE) out[k] = SOURCE_LABELS[k] ?? k; return out; }
  if (!ids.length) return out;
  const org = ctx.organizationId;
  const rows: { id: string; name: string }[] =
    d === "seller" ? await ctx.db.select({ id: users.id, name: users.name }).from(users).innerJoin(memberships, and(eq(memberships.userId, users.id), eq(memberships.organizationId, org))).where(inArray(users.id, ids))
    : d === "team" ? await ctx.db.select({ id: teams.id, name: teams.name }).from(teams).where(and(eq(teams.organizationId, org), inArray(teams.id, ids)))
    : d === "campaign" ? await ctx.db.select({ id: campaigns.id, name: campaigns.name }).from(campaigns).where(and(eq(campaigns.organizationId, org), inArray(campaigns.id, ids)))
    : await ctx.db.select({ id: pipelineStages.id, name: pipelineStages.name }).from(pipelineStages).where(and(eq(pipelineStages.organizationId, org), inArray(pipelineStages.id, ids)));
  for (const r of rows) out[r.id] = r.name;
  for (const k of ids) out[k] ??= "Registro sem nome";
  return out;
}

async function grouped(ctx: TenantContext, f: MetricFilters, d: Dimension, r: Range) {
  const k = keyExprs(ctx, d);
  const db = ctx.db;
  const [l, o, c] = await Promise.all([
    k.lead && leadsApplicable(f)
      ? db.select({ k: k.lead, n: count() }).from(leads).where(and(...leadFilterConds(ctx, f), gte(leads.createdAt, r.start), lt(leads.createdAt, r.end))).groupBy(sql`1`)
      : Promise.resolve(null),
    db.select({ k: k.opp, n: count() }).from(opportunities).leftJoin(leads, eq(leads.id, opportunities.leadId))
      .where(and(...oppFilterConds(ctx, f), gte(opportunities.createdAt, r.start), lt(opportunities.createdAt, r.end))).groupBy(sql`1`),
    db.select({
      k: k.opp,
      won: sql<number>`count(*) filter (where ${opportunities.status} = 'won')::int`,
      lost: sql<number>`count(*) filter (where ${opportunities.status} = 'lost')::int`,
      v: sql<number>`coalesce(sum(${opportunities.amountCents}) filter (where ${opportunities.status} = 'won'),0)::bigint`,
    }).from(opportunities).leftJoin(leads, eq(leads.id, opportunities.leadId))
      .where(and(...oppFilterConds(ctx, f), sql`${opportunities.status} in ('won','lost')`, gte(opportunities.closedAt, r.start), lt(opportunities.closedAt, r.end))).groupBy(sql`1`),
  ]);
  const key = (x: string | null) => x ?? NONE;
  return {
    leads: l ? new Map(l.map((x) => [key(x.k), Number(x.n)])) : null,
    opps: new Map(o.map((x) => [key(x.k), Number(x.n)])),
    closed: new Map(c.map((x) => [key(x.k), { won: Number(x.won), lost: Number(x.lost), v: Number(x.v) }])),
  };
}

export async function metricsBreakdown(ctx: TenantContext, raw: unknown, dimension: Dimension, now = new Date()) {
  requirePerm(ctx, "intelligence:read");
  if (!DIMENSIONS.includes(dimension)) throw Object.assign(new Error("Dimensão inválida."), { status: 400 });
  const f = parseMetricFilters(raw);
  const p = resolvePeriod(f, now);
  const [cur, prev] = await Promise.all([
    grouped(ctx, f, dimension, p),
    p.prevStart && p.prevEnd ? grouped(ctx, f, dimension, { start: p.prevStart, end: p.prevEnd }) : Promise.resolve(null),
  ]);
  const keys = new Set<string>([...(cur.leads?.keys() ?? []), ...cur.opps.keys(), ...cur.closed.keys()]);
  if (dimension === "source") for (const s of SOURCE_KEYS) if (cur.leads?.has(s) || cur.opps.has(s) || cur.closed.has(s)) keys.add(s);
  const labels = await dimensionLabels(ctx, dimension, [...keys]);
  const totalRevenue = [...cur.closed.values()].reduce((a, x) => a + x.v, 0);
  const rows: BreakdownRow[] = [...keys].map((k) => {
    const c = cur.closed.get(k) ?? { won: 0, lost: 0, v: 0 };
    const pc = prev ? prev.closed.get(k) ?? { won: 0, lost: 0, v: 0 } : null;
    return {
      key: k, label: labels[k] ?? k,
      leads: cur.leads ? cur.leads.get(k) ?? 0 : null, opportunities: cur.opps.get(k) ?? 0, won: c.won, lost: c.lost, revenueCents: c.v,
      conversionRate: c.won + c.lost ? Math.round((c.won / (c.won + c.lost)) * 1000) / 10 : null,
      prevRevenueCents: pc ? pc.v : null, prevWon: pc ? pc.won : null,
      revenueSharePct: totalRevenue ? Math.round((c.v / totalRevenue) * 1000) / 10 : 0,
    };
  }).sort((a, b) => b.revenueCents - a.revenueCents || b.opportunities - a.opportunities || (b.leads ?? 0) - (a.leads ?? 0));
  return { dimension, label: DIMENSION_LABELS[dimension], note: DIMENSION_NOTES[dimension], rows, totalRevenueCents: totalRevenue };
}

/* ------------------------------------------------------------------ drill-down até registros */

export const DRILL_METRICS = ["leads", "opportunities", "won", "lost", "closed", "revenue", "open_pipeline"] as const;
export type DrillMetric = (typeof DRILL_METRICS)[number];

export const drilldownSchema = z.object({
  metric: z.enum(DRILL_METRICS),
  /** Recorte opcional de um ponto do gráfico (dentro do período). */
  pointStart: z.string().datetime().optional(),
  pointEnd: z.string().datetime().optional(),
  /** "previous" abre os registros do período de comparação. */
  window: z.enum(["current", "previous"]).default("current"),
  limit: z.coerce.number().int().min(1).max(500).default(100),
  offset: z.coerce.number().int().min(0).max(100000).default(0),
});
export type DrilldownRequest = z.input<typeof drilldownSchema>;

export type DrillRow = {
  id: string; entity: "lead" | "opportunity"; title: string; companyName: string | null; ownerName: string | null;
  status: string; stageName: string | null; source: string | null; campaignName: string | null; score: number | null;
  amountCents: number | null; createdAt: string; closedAt: string | null; lastActivityAt: string | null; href: string;
};

/** Leads exigem crm:read ou prospect:read; oportunidades exigem crm:read. Sempre além de intelligence:read. */
export function assertDrillPermission(ctx: TenantContext, metric: DrillMetric) {
  requirePerm(ctx, "intelligence:read");
  if (metric === "leads") { if (!can(ctx, "crm:read") && !can(ctx, "prospect:read")) throw new ForbiddenError("crm:read"); return; }
  requirePerm(ctx, "crm:read");
}

export async function metricsDrilldown(ctx: TenantContext, rawFilters: unknown, rawReq: DrilldownRequest, now = new Date()) {
  const req = drilldownSchema.parse(rawReq);
  assertDrillPermission(ctx, req.metric);
  const f = parseMetricFilters(rawFilters);
  const p = resolvePeriod(f, now);
  let range: Range = req.window === "previous" && p.prevStart && p.prevEnd ? { start: p.prevStart, end: p.prevEnd } : { start: p.start, end: p.end };
  if (req.window === "previous" && !(p.prevStart && p.prevEnd)) throw Object.assign(new Error("Comparação desativada: não há período anterior."), { status: 400 });
  if (req.pointStart && req.pointEnd) {
    // O recorte nunca sai do período resolvido (evita usar o drill-down para ler fora do filtro).
    const s = Math.max(range.start.getTime(), Date.parse(req.pointStart)), e = Math.min(range.end.getTime(), Date.parse(req.pointEnd));
    if (e <= s) throw Object.assign(new Error("Recorte fora do período selecionado."), { status: 400 });
    range = { start: new Date(s), end: new Date(e) };
  }
  const def = METRIC_DEFINITIONS[req.metric === "closed" ? "conversion" : req.metric];
  const base = { metric: req.metric, definition: def, range: { start: range.start.toISOString(), end: range.end.toISOString() }, meta: await buildMeta(ctx, f, p) };

  if (req.metric === "leads") {
    if (!leadsApplicable(f)) return { ...base, entity: "lead" as const, total: 0, totalAmountCents: null, rows: [] as DrillRow[], truncated: false, notApplicable: "O filtro de etapa não se aplica a leads." };
    const where = and(...leadFilterConds(ctx, f), gte(leads.createdAt, range.start), lt(leads.createdAt, range.end));
    const [[t], rows] = await Promise.all([
      ctx.db.select({ n: count() }).from(leads).where(where),
      ctx.db.select({
        id: leads.id, title: leads.title, status: leads.status, source: leads.source, score: leads.score, createdAt: leads.createdAt,
        companyName: companies.name, ownerName: users.name, campaignName: campaigns.name,
      }).from(leads).leftJoin(companies, eq(companies.id, leads.companyId)).leftJoin(users, eq(users.id, leads.ownerId))
        .leftJoin(campaigns, and(eq(campaigns.id, leads.campaignId), eq(campaigns.organizationId, ctx.organizationId)))
        .where(where).orderBy(desc(leads.createdAt), asc(leads.id)).limit(req.limit).offset(req.offset),
    ]);
    const total = Number(t.n);
    return {
      ...base, entity: "lead" as const, total, totalAmountCents: null, truncated: req.offset + rows.length < total,
      rows: rows.map((r): DrillRow => ({
        id: r.id, entity: "lead", title: r.title, companyName: r.companyName, ownerName: r.ownerName, status: r.status, stageName: null,
        source: SOURCE_LABELS[r.source] ?? r.source, campaignName: r.campaignName, score: r.score, amountCents: null,
        createdAt: r.createdAt.toISOString(), closedAt: null, lastActivityAt: null, href: `/prospect?lead=${r.id}`,
      })),
    };
  }

  const conds = oppFilterConds(ctx, f);
  if (req.metric === "opportunities") conds.push(gte(opportunities.createdAt, range.start), lt(opportunities.createdAt, range.end));
  else if (req.metric === "open_pipeline") conds.push(eq(opportunities.status, "open"));
  else {
    const status = req.metric === "lost" ? sql`${opportunities.status} = 'lost'` : req.metric === "closed" ? sql`${opportunities.status} in ('won','lost')` : sql`${opportunities.status} = 'won'`;
    conds.push(status, gte(opportunities.closedAt, range.start), lt(opportunities.closedAt, range.end));
  }
  const where = and(...conds);
  const [[t], rows] = await Promise.all([
    ctx.db.select({ n: count(), v: sql<number>`coalesce(sum(${opportunities.amountCents}),0)::bigint` }).from(opportunities).leftJoin(leads, eq(leads.id, opportunities.leadId)).where(where),
    ctx.db.select({
      id: opportunities.id, title: opportunities.title, status: opportunities.status, amountCents: opportunities.amountCents,
      createdAt: opportunities.createdAt, closedAt: opportunities.closedAt, lastActivityAt: opportunities.lastActivityAt, source: oppSource,
      companyName: companies.name, ownerName: users.name, stageName: pipelineStages.name, campaignName: campaigns.name,
    }).from(opportunities).leftJoin(leads, eq(leads.id, opportunities.leadId))
      .leftJoin(companies, eq(companies.id, opportunities.companyId)).leftJoin(users, eq(users.id, opportunities.ownerId))
      .leftJoin(pipelineStages, eq(pipelineStages.id, opportunities.stageId))
      .leftJoin(campaigns, and(eq(campaigns.id, leads.campaignId), eq(campaigns.organizationId, ctx.organizationId)))
      .where(where).orderBy(desc(opportunities.amountCents), asc(opportunities.id)).limit(req.limit).offset(req.offset),
  ]);
  const total = Number(t.n);
  return {
    ...base, entity: "opportunity" as const, total, totalAmountCents: Number(t.v), truncated: req.offset + rows.length < total,
    rows: rows.map((r): DrillRow => ({
      id: r.id, entity: "opportunity", title: r.title, companyName: r.companyName, ownerName: r.ownerName, status: r.status, stageName: r.stageName,
      source: SOURCE_LABELS[r.source] ?? r.source, campaignName: r.campaignName, score: null, amountCents: Number(r.amountCents),
      createdAt: r.createdAt.toISOString(), closedAt: r.closedAt?.toISOString() ?? null, lastActivityAt: r.lastActivityAt?.toISOString() ?? null,
      href: `/crm/oportunidade/${r.id}`,
    })),
  };
}

/* ------------------------------------------------------------------ opções de filtro */

export async function filterOptions(ctx: TenantContext) {
  requirePerm(ctx, "intelligence:read");
  const org = ctx.organizationId;
  const [sellers, teamRows, campaignRows, stageRows] = await Promise.all([
    ctx.db.select({ id: users.id, name: users.name }).from(memberships).innerJoin(users, eq(users.id, memberships.userId))
      .where(and(eq(memberships.organizationId, org), eq(memberships.status, "active"))).orderBy(asc(users.name)),
    ctx.db.select({ id: teams.id, name: teams.name }).from(teams).where(eq(teams.organizationId, org)).orderBy(asc(teams.name)),
    ctx.db.select({ id: campaigns.id, name: campaigns.name }).from(campaigns).where(eq(campaigns.organizationId, org)).orderBy(asc(campaigns.name)),
    ctx.db.select({ id: pipelineStages.id, name: pipelineStages.name, position: pipelineStages.position, kind: pipelineStages.kind }).from(pipelineStages)
      .where(eq(pipelineStages.organizationId, org)).orderBy(asc(pipelineStages.position)),
  ]);
  return {
    sellers, teams: teamRows, campaigns: campaignRows, stages: stageRows,
    sources: SOURCE_KEYS.map((k) => ({ id: k, name: SOURCE_LABELS[k] })),
  };
}

/* ------------------------------------------------------------------ pacote do dashboard */

export async function dashboardBundle(ctx: TenantContext, raw: unknown, now = new Date()) {
  const f = parseMetricFilters(raw);
  const [overview, series, source, seller, stage, team, campaign, options] = await Promise.all([
    metricsOverview(ctx, f, now), metricsSeries(ctx, f, now),
    metricsBreakdown(ctx, f, "source", now), metricsBreakdown(ctx, f, "seller", now), metricsBreakdown(ctx, f, "stage", now),
    metricsBreakdown(ctx, f, "team", now), metricsBreakdown(ctx, f, "campaign", now), filterOptions(ctx),
  ]);
  return { ...overview, series, breakdowns: { source, seller, stage, team, campaign }, options };
}
export type DashboardBundle = Awaited<ReturnType<typeof dashboardBundle>>;

/* ------------------------------------------------------------------ CSV */

/** Neutraliza fórmulas (CSV injection) e escapa separador/aspas. */
export function csvCell(v: unknown) {
  let s = v == null ? "" : String(v);
  if (/^[=+\-@\t\r]/.test(s)) s = "'" + s;
  return /[";\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}
export function toCsv(columns: string[], rows: unknown[][], meta: MetricsMeta, notes: string[] = []) {
  const lines = [columns.map(csvCell).join(";"), ...rows.map((r) => r.map(csvCell).join(";"))];
  lines.push("", csvCell(`Período: ${meta.period.label} (${meta.period.start} a ${meta.period.end}, UTC)`));
  if (meta.comparison) lines.push(csvCell(`Comparação: ${meta.comparison.label}`));
  lines.push(csvCell(`Filtros: ${meta.filtersApplied.join(", ") || "nenhum"}`), csvCell(`Gerado em: ${meta.generatedAt}`), ...notes.map(csvCell));
  return "﻿" + lines.join("\r\n");
}
