/** Exportação CSV do resultado filtrado do serviço de métricas (mesmos números da tela). */
import { requirePerm, type TenantContext } from "../../tenancy/context";
import { DIMENSIONS, resolvePeriod, type Dimension, type MetricFilters } from "../../../lib/metrics-filters";
import { METRIC_DEFINITIONS, buildMeta, metricsBreakdown, metricsDrilldown, metricsOverview, metricsSeries, toCsv } from "./index";
import { drillRequestFromUrl } from "./http";

const money = (c: number | null) => (c == null ? "" : (c / 100).toFixed(2).replace(".", ","));
const pctTxt = (v: number | null | undefined) => (v == null ? "n/d" : String(v).replace(".", ","));

export type CsvKind = "resumo" | "serie" | "segmentacao" | "registros";

export async function buildMetricsCsv(ctx: TenantContext, f: MetricFilters, sp: URLSearchParams): Promise<{ kind: CsvKind; name: string; csv: string }> {
  const kind = (sp.get("tipo") ?? "resumo") as CsvKind;
  const meta = await buildMeta(ctx, f, resolvePeriod(f));

  if (kind === "resumo") {
    const o = await metricsOverview(ctx, f);
    const p = o.previous;
    const row = (k: keyof typeof METRIC_DEFINITIONS, cur: string, prev: string, delta: string) => [METRIC_DEFINITIONS[k].label, cur, prev, delta, METRIC_DEFINITIONS[k].formula];
    const csv = toCsv(["Indicador", "Período atual", "Comparação", "Variação (%)", "Definição"], [
      row("leads", o.current.leads == null ? "n/a" : String(o.current.leads), p ? (p.leads == null ? "n/a" : String(p.leads)) : "", pctTxt(o.delta?.leads)),
      row("opportunities", String(o.current.opportunities), p ? String(p.opportunities) : "", pctTxt(o.delta?.opportunities)),
      row("won", String(o.current.won), p ? String(p.won) : "", pctTxt(o.delta?.won)),
      row("revenue", money(o.current.revenueCents), p ? money(p.revenueCents) : "", pctTxt(o.delta?.revenue)),
      row("conversion", pctTxt(o.current.conversionRate), p ? pctTxt(p.conversionRate) : "", o.delta?.conversionPp == null ? "n/d" : `${pctTxt(o.delta.conversionPp)} p.p.`),
      row("avg_ticket", money(o.current.avgTicketCents), p ? money(p.avgTicketCents) : "", pctTxt(o.delta?.avgTicket)),
      row("open_pipeline", money(o.pipeline.valueCents), "", ""),
    ], o.meta, ["Valores monetários na moeda da organização, com 2 casas decimais."]);
    return { kind, name: "resumo", csv };
  }
  if (kind === "serie") {
    const s = await metricsSeries(ctx, f);
    const csv = toCsv(["Início", "Fim", "Leads", "Oportunidades", "Vendas", "Receita", "Leads (comparação)", "Vendas (comparação)", "Receita (comparação)"],
      s.points.map((x) => [x.start, x.end, x.leads ?? "n/a", x.opportunities, x.won, money(x.revenueCents), x.prev ? x.prev.leads ?? "n/a" : "", x.prev?.won ?? "", x.prev ? money(x.prev.revenueCents) : ""]),
      meta, [`Agrupamento: ${s.bucketDays === 1 ? "diário" : "semanal"} (UTC).`]);
    return { kind, name: "serie", csv };
  }
  if (kind === "segmentacao") {
    const d = (sp.get("dimensao") ?? "") as Dimension;
    if (!DIMENSIONS.includes(d)) throw Object.assign(new Error("Dimensão inválida."), { status: 400 });
    const b = await metricsBreakdown(ctx, f, d);
    const csv = toCsv([b.label, "Leads", "Oportunidades", "Vendas", "Perdidas", "Receita", "Conversão (%)", "Participação na receita (%)", "Receita (comparação)"],
      b.rows.map((r) => [r.label, r.leads ?? "n/a", r.opportunities, r.won, r.lost, money(r.revenueCents), pctTxt(r.conversionRate), pctTxt(r.revenueSharePct), r.prevRevenueCents == null ? "" : money(r.prevRevenueCents)]),
      meta, [b.note]);
    return { kind, name: `segmentacao-${d}`, csv };
  }
  if (kind === "registros") {
    requirePerm(ctx, "export:data");
    const r = await metricsDrilldown(ctx, f, { ...drillRequestFromUrl(sp), limit: 500, offset: 0 });
    const csv = toCsv(["Tipo", "Título", "Empresa", "Responsável", "Situação", "Etapa", "Origem", "Campanha", "Score", "Valor", "Criado em", "Fechado em", "Link"],
      r.rows.map((x) => [x.entity === "lead" ? "Lead" : "Oportunidade", x.title, x.companyName ?? "", x.ownerName ?? "", x.status, x.stageName ?? "", x.source ?? "", x.campaignName ?? "", x.score ?? "", money(x.amountCents), x.createdAt, x.closedAt ?? "", x.href]),
      meta, [`Indicador: ${r.definition.label} — ${r.definition.formula}`, `Total de registros: ${r.total}${r.truncated ? " (exportados os primeiros 500)" : ""}`]);
    return { kind, name: `registros-${r.metric}`, csv };
  }
  throw Object.assign(new Error("Tipo de exportação inválido."), { status: 400 });
}
