/** Leitura ESTRITA dos filtros vindos da URL de uma rota de API (erro 400 com o motivo, em vez de ignorar). */
import { URL_KEYS, metricFiltersSchema, type MetricFilters } from "../../../lib/metrics-filters";

export function strictFiltersFromUrl(sp: URLSearchParams): MetricFilters {
  const raw: Record<string, string> = {};
  for (const [k, urlKey] of Object.entries(URL_KEYS)) {
    const v = sp.get(urlKey);
    if (v != null && v !== "") raw[k] = v;
  }
  return metricFiltersSchema.parse(raw);
}

/** Parâmetros do drill-down vindos da URL (nomes em português). */
export function drillRequestFromUrl(sp: URLSearchParams) {
  return {
    metric: (sp.get("metrica") ?? "") as "leads",
    pointStart: sp.get("inicio") ?? undefined,
    pointEnd: sp.get("fim") ?? undefined,
    window: (sp.get("janela") ?? undefined) as "current" | undefined,
    limit: sp.get("limite") ?? undefined,
    offset: sp.get("deslocamento") ?? undefined,
  } as unknown as import("./index").DrilldownRequest;
}
