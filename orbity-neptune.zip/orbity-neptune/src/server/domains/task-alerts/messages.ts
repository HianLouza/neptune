/**
 * Mensagens de alerta: geração pelo Flávio (via orquestrador, com governança) e compositor determinístico.
 *
 *  - O Flávio SÓ gera texto. Quem envia é o gestor, depois de revisar (createAlert). Nada é enviado por aqui.
 *  - Sem provedor de IA real configurado, o texto vem do compositor local e é marcado como SIMULADO.
 *  - Contexto enviado ao modelo é montado no backend, só com dados da própria organização, e tratado como dado não confiável.
 */
import { and, count, desc, eq } from "drizzle-orm";
import { z } from "zod";
import { taskAlertResponses, taskAlerts, tasks, users } from "../../db/schema";
import { requirePerm, type TenantContext } from "../../tenancy/context";
import { runAgent } from "../../ai/orchestrator";
import { FLAVIO } from "../../ai/flavio/identity";
import { unsupportedFigures } from "../../ai/collab/text";
import { HttpError } from "../../http";
import { loadTask } from "./core";
import {
  MESSAGE_KINDS, MESSAGE_KIND_LABEL, TONES, TONE_LABEL, resolveTone, type MessageKind, type Tone,
} from "./shared";

export type MessageFacts = {
  taskTitle: string; description: string | null; priority: string; status: string; dueAt: Date | null; overdueHours: number | null;
  assignee: string | null; progressPct: number | null; blockedReason: string | null; alertsBefore: number; lastResponses: string[];
  assigneeOpenTasks: number; assigneeOverdue: number; senderName: string | null;
};

const fmtDate = (d: Date | null, tz: string) => (d ? d.toLocaleString("pt-BR", { timeZone: tz, dateStyle: "short", timeStyle: "short" }) : "sem prazo definido");

/** Contexto factual da tarefa (histórico de atualizações, situação, carga do responsável). */
export async function messageFacts(ctx: TenantContext, taskId: string): Promise<MessageFacts> {
  const t = await loadTask(ctx.db, ctx.organizationId, taskId);
  const [assignee] = t.assigneeId ? await ctx.db.select({ name: users.name }).from(users).where(eq(users.id, t.assigneeId)) : [];
  const [sender] = await ctx.db.select({ name: users.name }).from(users).where(eq(users.id, ctx.userId));
  const [prev] = await ctx.db.select({ n: count() }).from(taskAlerts).where(and(eq(taskAlerts.organizationId, ctx.organizationId), eq(taskAlerts.taskId, t.id)));
  const resp = await ctx.db.select({ kind: taskAlertResponses.kind, message: taskAlertResponses.message }).from(taskAlertResponses)
    .where(and(eq(taskAlertResponses.organizationId, ctx.organizationId), eq(taskAlertResponses.taskId, t.id))).orderBy(desc(taskAlertResponses.createdAt)).limit(3);
  let open = 0, overdue = 0;
  if (t.assigneeId) {
    const rows = await ctx.db.select({ dueAt: tasks.dueAt }).from(tasks).where(and(eq(tasks.organizationId, ctx.organizationId), eq(tasks.assigneeId, t.assigneeId), eq(tasks.status, "open")));
    open = rows.length; overdue = rows.filter((r) => r.dueAt && r.dueAt.getTime() < Date.now()).length;
  }
  const now = Date.now();
  return {
    taskTitle: t.title, description: t.description, priority: t.priority, status: t.status, dueAt: t.dueAt, assignee: assignee?.name ?? null,
    overdueHours: t.dueAt && t.dueAt.getTime() < now ? Math.round((now - t.dueAt.getTime()) / 3600_000) : null,
    progressPct: t.progressPct, blockedReason: t.blockedReason, alertsBefore: Number(prev.n), lastResponses: resp.map((r) => `${r.kind}${r.message ? `: ${r.message}` : ""}`),
    assigneeOpenTasks: open, assigneeOverdue: overdue, senderName: sender?.name ?? null,
  };
}

const first = (n: string | null) => (n ? n.split(" ")[0] : "tudo bem");

/**
 * Compositor local (sem IA). Determinístico: o mesmo pedido gera o mesmo texto; `variant` alterna a redação para "nova versão".
 * Só usa dados do contexto. Não inventa números nem promessas.
 */
export function composeAlert(kind: MessageKind, tone: Tone, f: MessageFacts, tz: string, variant = 0, customTone?: string): { title: string; message: string } {
  const who = first(f.assignee);
  const due = fmtDate(f.dueAt, tz);
  const late = f.overdueHours != null ? (f.overdueHours >= 48 ? `${Math.round(f.overdueHours / 24)} dias` : `${f.overdueHours} h`) : null;
  const sig = f.senderName ? `\n\n${f.senderName}` : "";
  const open = {
    formal: `Prezado(a) ${who},`, direct: `${who},`, cordial: `Olá, ${who}! Tudo bem?`, motivational: `${who}, estamos juntos nessa!`, custom: `Olá, ${who},`,
  }[tone];
  const t = `"${f.taskTitle}"`;
  const body: Record<MessageKind, string[]> = {
    friendly_reminder: [`Passando para lembrar da tarefa ${t}, com prazo em ${due}.`, `Um lembrete sobre a tarefa ${t}: o prazo é ${due}.`],
    overdue_notice: [`A tarefa ${t} está atrasada${late ? ` há ${late}` : ""} (prazo era ${due}). Pode me atualizar sobre a situação e o novo prazo previsto?`, `Notei que ${t} passou do prazo (${due})${late ? `, há ${late}` : ""}. Preciso entender o andamento e o que está impedindo a conclusão.`],
    professional_chase: [`Preciso da conclusão de ${t}, prazo ${due}. Por favor, confirme hoje quando será entregue.`, `Solicito a atualização de ${t} (prazo ${due}) e a data prevista de entrega.`],
    high_priority: [`${t} é prioridade alta e o prazo é ${due}. Por favor, trate com prioridade e me avise de qualquer impedimento.`, `Atenção: ${t} está entre as prioridades da equipe (prazo ${due}). Conte comigo para destravar o que for preciso.`],
    goal_missed: [`${t} está ligada a uma meta que ainda não foi atingida. Vamos alinhar o que falta para recuperar o ritmo?`, `A meta relacionada a ${t} está abaixo do esperado. Podemos ver juntos o próximo passo?`],
    guidance: [`Para concluir ${t}: confirme o que falta, registre o andamento na tarefa e me avise se precisar de apoio.${f.description ? ` Contexto: ${f.description}` : ""}`, `Sugestão para fechar ${t}: liste o que ainda falta, defina o próximo passo e atualize a tarefa. Posso ajudar a remover bloqueios.`],
    status_request: [`Pode atualizar o andamento de ${t}${f.progressPct != null ? ` (último registro: ${f.progressPct}%)` : ""}? O prazo é ${due}.`, `Gostaria de uma atualização sobre ${t}. Em que ponto está e há algum impedimento?`],
    deadline_change: [`O prazo de ${t} foi alterado. Novo prazo: ${due}. Em caso de dúvida, me avise.`, `Comunico a mudança de prazo de ${t}. A data vigente agora é ${due}.`],
  };
  const options = body[kind];
  const text = options[variant % options.length];
  const close = {
    formal: "Agradeço a atenção.", direct: "Aguardo retorno.", cordial: "Obrigado pela parceria!", motivational: "Você consegue, e eu estou aqui para ajudar.", custom: customTone ? `(${customTone.slice(0, 80)})` : "Obrigado.",
  }[tone];
  const titles: Record<MessageKind, string> = {
    friendly_reminder: `Lembrete: ${f.taskTitle}`, overdue_notice: `Tarefa atrasada: ${f.taskTitle}`, professional_chase: `Atualização necessária: ${f.taskTitle}`, high_priority: `Prioridade alta: ${f.taskTitle}`,
    goal_missed: `Meta em atenção: ${f.taskTitle}`, guidance: `Como concluir: ${f.taskTitle}`, status_request: `Pedido de atualização: ${f.taskTitle}`, deadline_change: `Prazo alterado: ${f.taskTitle}`,
  };
  return { title: titles[kind].slice(0, 140), message: `${open}\n\n${text}\n\n${close}${sig}` };
}

export const generateInput = z.object({
  taskId: z.string().uuid(),
  kind: z.enum(MESSAGE_KINDS).default("friendly_reminder"),
  tone: z.enum(TONES).optional(),
  instruction: z.string().trim().max(600).optional(), // orientação do gestor
  variant: z.coerce.number().int().min(0).max(1000).default(0),
  previous: z.array(z.string().max(2000)).max(10).optional(), // versões já geradas (para o Flávio variar)
});

export type GeneratedMessage = {
  title: string; message: string; simulated: boolean; executionId: string | null; provider: string; model: string; credits: number;
  kind: MessageKind; tone: Tone; warnings: string[]; basedOn: string[];
};

/** "Gerar mensagem com Flávio". Quantas versões o gestor quiser, enquanto houver créditos e limites (o orquestrador aplica). */
export async function generateAlertMessage(ctx: TenantContext, raw: z.input<typeof generateInput>): Promise<GeneratedMessage> {
  requirePerm(ctx, "alerts:send");
  requirePerm(ctx, "ai:use");
  const input = generateInput.parse(raw);
  const f = await messageFacts(ctx, input.taskId);
  const t = await loadTask(ctx.db, ctx.organizationId, input.taskId);
  const resolved = await resolveTone(ctx.db, ctx.organizationId, t.assigneeId, { kind: input.kind });
  const tone = input.tone ?? resolved.tone;
  const basedOn = [
    `Tarefa: ${f.taskTitle} (prioridade ${f.priority}, ${f.status === "open" ? "aberta" : f.status})`, `Prazo: ${fmtDate(f.dueAt, ctx.timezone)}`,
    ...(f.overdueHours != null ? [`Atrasada há ${f.overdueHours} h`] : []), `Alertas anteriores nesta tarefa: ${f.alertsBefore}`,
    ...(f.lastResponses.length ? [`Últimas atualizações do responsável: ${f.lastResponses.length}`] : []),
    `Carga do responsável: ${f.assigneeOpenTasks} abertas, ${f.assigneeOverdue} atrasadas`, `Tom: ${TONE_LABEL[tone]}`, ...(input.instruction ? ["Orientação do gestor"] : []),
  ];
  const context = [
    `TAREFA: ${f.taskTitle}`, f.description ? `DESCRIÇÃO: ${f.description}` : "", `PRIORIDADE: ${f.priority}`, `SITUAÇÃO: ${f.status}${f.blockedReason ? ` (bloqueada: ${f.blockedReason})` : ""}`,
    `PRAZO: ${fmtDate(f.dueAt, ctx.timezone)}${f.overdueHours != null ? ` (atrasada há ${f.overdueHours} h)` : ""}`, `ANDAMENTO INFORMADO: ${f.progressPct ?? "não informado"}`,
    `RESPONSÁVEL: ${f.assignee ?? "não definido"} — ${f.assigneeOpenTasks} tarefas abertas, ${f.assigneeOverdue} atrasadas`, `ALERTAS ANTERIORES NA TAREFA: ${f.alertsBefore}`,
    f.lastResponses.length ? `ÚLTIMAS ATUALIZAÇÕES: ${f.lastResponses.join(" | ")}` : "", `REMETENTE: ${f.senderName ?? "gestor"}`,
  ].filter(Boolean).join("\n");
  const prompt = [
    `Escreva um alerta para o responsável pela tarefa. Tipo: ${MESSAGE_KIND_LABEL[input.kind]}. Tom: ${TONE_LABEL[tone]}${tone === "custom" && resolved.customTone ? ` (${resolved.customTone})` : ""}.`,
    input.instruction ? `Orientação do gestor: ${input.instruction}` : "",
    input.previous?.length ? `Já existem estas versões; escreva uma redação DIFERENTE:\n${input.previous.slice(-3).map((p, i) => `${i + 1}) ${p}`).join("\n")}` : "",
    `Regras: use SOMENTE os fatos do contexto, sem inventar números, datas, nomes ou promessas; seja claro, respeitoso e profissional; no máximo 120 palavras; sem emojis; não faça julgamentos sobre a pessoa; não ameace.`,
    `Responda exatamente no formato:\nTITULO: <até 80 caracteres>\nMENSAGEM: <texto>`,
  ].filter(Boolean).join("\n");

  const r = await runAgent(ctx, { agentKey: FLAVIO.agentKey, input: prompt, context, persona: `Você é o ${FLAVIO.name}. Você apenas SUGERE o texto; o gestor revisa e decide o envio.` });
  if (r.status === "blocked") throw new HttpError(409, r.warnings[0] ?? r.text);
  const warnings = [...r.warnings];
  let title = "", message = "", simulated = r.simulated;
  const parsed = r.status === "error" ? null : /TITULO:\s*(.+?)\s*\n+\s*MENSAGEM:\s*([\s\S]+)/i.exec(r.text);
  if (!r.simulated && parsed) {
    title = parsed[1].trim().slice(0, 140); message = parsed[2].trim();
    const figs = unsupportedFigures(message, context);
    if (figs.length) warnings.push(`Revise: a mensagem cita valores que não estão no contexto da tarefa (${figs.join(", ")}).`);
  } else {
    const c = composeAlert(input.kind, tone, f, ctx.timezone, input.variant, resolved.customTone);
    title = c.title; message = c.message; simulated = true;
    if (!r.simulated) warnings.push("Não foi possível usar a resposta da IA; texto montado pelo modelo local.");
  }
  if (input.instruction && simulated) warnings.push("Modo simulado: a orientação do gestor não altera o texto local. Edite manualmente ou configure a IA real.");
  return { title, message, simulated, executionId: r.executionId, provider: r.provider, model: r.model, credits: r.credits, kind: input.kind, tone, warnings, basedOn };
}

/** Texto automático das regras (sem custo de IA): usa o compositor local com o tom resolvido. Não é rotulado como "Flávio". */
export async function autoMessage(ctx: TenantContext, taskId: string, kind: MessageKind, ruleTone?: string | null) {
  const f = await messageFacts(ctx, taskId);
  const t = await loadTask(ctx.db, ctx.organizationId, taskId);
  const r = await resolveTone(ctx.db, ctx.organizationId, t.assigneeId, { ruleTone, kind });
  return composeAlert(kind, r.tone, { ...f, senderName: null }, ctx.timezone, 0, r.customTone);
}

