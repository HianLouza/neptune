/**
 * ORBITY TASK INTELLIGENCE — núcleo: criação, entrega, agendamento, cancelamento, leitura, resposta e histórico de alertas.
 *
 * Garantias:
 *  - Idempotência: (organização, idempotencyKey) é único; clique duplo/retentativa nunca gera segundo alerta.
 *  - Entrega atômica: a transição draft/scheduled → enviado ocorre sob lock de linha; dois workers não entregam o mesmo alerta.
 *  - Nada é "enviado/entregue/lido" sem que isso tenha acontecido (ver shared.ts).
 *  - Isolamento: toda consulta filtra por organização; o destinatário precisa ser membro ativo da mesma organização.
 */
import { and, desc, eq, gte, inArray, lte, sql } from "drizzle-orm";
import { z } from "zod";
import type { DB } from "../../db/client";
import { taskAlertEvents, taskAlertResponses, taskAlerts, taskExtensionRequests, tasks, teamMembers, users } from "../../db/schema";
import { can, requirePerm, type TenantContext } from "../../tenancy/context";
import { audit } from "../../audit";
import { HttpError } from "../../http";
import {
  CHANNELS, PRIORITIES, RESPONSE_KINDS, STATUSES, channelAvailability, EXTERNAL_SENDERS, isActiveMember, logEvent, notifyUser, sha1,
  type AlertChannel, type ExternalChannel,
} from "./shared";

export type AlertRow = typeof taskAlerts.$inferSelect;

const channelsSchema = z.array(z.enum(CHANNELS)).min(1, "Escolha ao menos um canal.").max(4).transform((a) => [...new Set(a)]);

export const createAlertInput = z.object({
  taskId: z.string().uuid(),
  recipientId: z.string().uuid().optional(), // padrão: responsável pela tarefa; o gestor pode alterar
  title: z.string().trim().min(2, "Informe o título.").max(140),
  message: z.string().trim().min(2, "Escreva a mensagem.").max(2000),
  priority: z.enum(PRIORITIES).default("medium"),
  channels: channelsSchema.default(["in_app"]),
  sendMode: z.enum(["now", "schedule", "draft"]).default("now"),
  scheduledAt: z.coerce.date().optional(),
  originalMessage: z.string().max(2000).nullish(), // sugestão do Flávio antes da edição
  flavioExecutionId: z.string().uuid().nullish(),
  simulated: z.boolean().optional(),
  ruleId: z.string().uuid().nullish(), // regra de escalonamento a seguir se não houver resposta
  idempotencyKey: z.string().trim().min(8).max(100).optional(),
});

/** Verifica os canais pedidos contra a disponibilidade real. Canal indisponível bloqueia o envio com o motivo. */
async function assertChannelsAvailable(db: DB, organizationId: string, channels: string[]) {
  const avail = await channelAvailability(db, organizationId);
  const bad = channels.filter((c) => !avail[c as AlertChannel]?.available);
  if (bad.length) throw new HttpError(409, `Canal indisponível: ${bad.map((c) => `${c} (${avail[c as AlertChannel]?.reason ?? "desconhecido"})`).join("; ")}`);
}

export async function loadTask(db: DB, organizationId: string, taskId: string) {
  const [t] = await db.select().from(tasks).where(and(eq(tasks.id, taskId), eq(tasks.organizationId, organizationId)));
  if (!t) throw new HttpError(404, "Tarefa não encontrada.");
  return t;
}

type InsertValues = typeof taskAlerts.$inferInsert;

/** Insere respeitando a idempotência. Devolve duplicate=true se a chave já existia. */
export async function insertAlert(db: DB, v: InsertValues): Promise<{ alert: AlertRow; duplicate: boolean }> {
  const rows = await db.insert(taskAlerts).values(v).onConflictDoNothing({ target: [taskAlerts.organizationId, taskAlerts.idempotencyKey] }).returning();
  if (rows[0]) {
    await logEvent(db, { organizationId: v.organizationId, taskId: v.taskId, alertId: rows[0].id, type: "created", actorId: v.senderId ?? "system",
      data: { kind: v.kind ?? "manual", priority: v.priority, channels: v.channels, messageOrigin: v.messageOrigin ?? "manual", status: v.status } });
    return { alert: rows[0], duplicate: false };
  }
  const [existing] = await db.select().from(taskAlerts).where(and(eq(taskAlerts.organizationId, v.organizationId), eq(taskAlerts.idempotencyKey, v.idempotencyKey!)));
  return { alert: existing, duplicate: true };
}

/** Cria (e, se pedido, envia ou agenda) um alerta individual para o responsável da tarefa. */
export async function createAlert(ctx: TenantContext, raw: z.input<typeof createAlertInput>) {
  requirePerm(ctx, "alerts:send");
  const input = createAlertInput.parse(raw);
  const task = await loadTask(ctx.db, ctx.organizationId, input.taskId);
  const recipientId = input.recipientId ?? task.assigneeId;
  if (!recipientId) throw new HttpError(400, "A tarefa não tem responsável. Escolha o destinatário do alerta.");
  if (!(await isActiveMember(ctx.db, ctx.organizationId, recipientId))) throw new HttpError(400, "O destinatário não é um membro ativo desta organização.");
  if (input.sendMode === "schedule") {
    if (!input.scheduledAt) throw new HttpError(400, "Informe a data e o horário do agendamento.");
    if (input.scheduledAt.getTime() < Date.now() - 60_000) throw new HttpError(400, "O horário agendado já passou. Escolha um horário futuro ou envie agora.");
  }
  if (input.sendMode !== "draft") await assertChannelsAvailable(ctx.db, ctx.organizationId, input.channels);

  const key = input.idempotencyKey ?? `manual:${ctx.userId}:${task.id}:${recipientId}:${await sha1(input.message)}:${Math.floor(Date.now() / 120_000)}`;
  const origin = !input.originalMessage ? "manual" : input.originalMessage.trim() === input.message ? "flavio" : "flavio_edited";
  const { alert, duplicate } = await insertAlert(ctx.db, {
    organizationId: ctx.organizationId, taskId: task.id, recipientId, senderId: ctx.userId, kind: "manual", title: input.title, message: input.message,
    originalMessage: input.originalMessage ?? null, messageOrigin: origin, priority: input.priority, channels: input.channels,
    status: input.sendMode === "schedule" ? "scheduled" : "draft", scheduledAt: input.sendMode === "schedule" ? input.scheduledAt : null,
    taskDueAtSnapshot: task.dueAt, ruleId: input.ruleId ?? null, idempotencyKey: key, flavioExecutionId: input.flavioExecutionId ?? null, simulated: input.simulated ?? false,
  });
  if (duplicate) return { alert, duplicate: true, notice: "Este alerta já havia sido criado (envio duplicado ignorado)." };

  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "task_alert.created", resource: "task_alert", resourceId: alert.id,
    metadata: { taskId: task.id, recipientId, priority: input.priority, channels: input.channels, sendMode: input.sendMode, messageOrigin: origin } });
  if (input.sendMode === "schedule") {
    await logEvent(ctx.db, { organizationId: ctx.organizationId, taskId: task.id, alertId: alert.id, type: "scheduled", actorId: ctx.userId, data: { scheduledAt: input.scheduledAt!.toISOString() } });
    return { alert, duplicate: false, notice: `Alerta AGENDADO para ${input.scheduledAt!.toLocaleString("pt-BR", { timeZone: ctx.timezone })}. Ainda não foi enviado.` };
  }
  if (input.sendMode === "draft") return { alert, duplicate: false, notice: "Rascunho salvo. Nada foi enviado." };
  const delivered = await deliverAlert(ctx.db, ctx.organizationId, alert.id, ctx.userId);
  return { alert: delivered.alert, duplicate: false, notice: deliveryNotice(delivered.alert) };
}

export function deliveryNotice(a: Pick<AlertRow, "status" | "failureReason">) {
  if (a.status === "delivered") return "Alerta ENTREGUE na Central de Notificações do destinatário. A leitura só será registrada quando ele abrir.";
  if (a.status === "sent") return "Alerta ENVIADO. A confirmação de entrega não está disponível para este canal.";
  if (a.status === "failed") return `Falha no envio: ${a.failureReason ?? "motivo não informado"}. O alerta NÃO foi entregue.`;
  if (a.status === "canceled") return `Alerta cancelado: ${a.failureReason ?? "tarefa não está mais aberta"}.`;
  return "Alerta registrado.";
}

/**
 * Entrega um alerta (draft/scheduled). Seguro para concorrência: lock de linha + checagem de estado.
 * Tarefas já concluídas/canceladas cancelam o alerta em vez de notificar.
 */
export async function deliverAlert(db: DB, organizationId: string, alertId: string, actorId: string): Promise<{ alert: AlertRow; skipped: boolean }> {
  return db.transaction(async (txRaw) => {
    const tx = txRaw as unknown as DB;
    const [a] = await tx.select().from(taskAlerts).where(and(eq(taskAlerts.id, alertId), eq(taskAlerts.organizationId, organizationId))).for("update");
    if (!a) throw new HttpError(404, "Alerta não encontrado.");
    if (a.status !== "draft" && a.status !== "scheduled") return { alert: a, skipped: true };
    const [t] = await tx.select().from(tasks).where(eq(tasks.id, a.taskId));
    const now = new Date();
    if (!t || t.status !== "open") {
      const reason = "A tarefa já foi concluída ou cancelada.";
      const [c] = await tx.update(taskAlerts).set({ status: "canceled", canceledAt: now, failureReason: reason, updatedAt: now }).where(eq(taskAlerts.id, a.id)).returning();
      await logEvent(tx, { organizationId, taskId: a.taskId, alertId: a.id, type: "canceled", actorId, data: { reason } });
      return { alert: c, skipped: true };
    }
    const avail = await channelAvailability(tx, organizationId);
    const results: AlertRow["channelResults"] = {};
    for (const ch of a.channels as AlertChannel[]) {
      const at = new Date().toISOString();
      if (ch === "in_app") {
        await notifyUser(tx, { organizationId, userId: a.recipientId, title: a.title, body: a.message, href: `/alertas?alerta=${a.id}`, alertId: a.id, priority: a.priority });
        results.in_app = { status: "delivered", at }; // gravado na Central de Notificações do destinatário
        continue;
      }
      const sender = EXTERNAL_SENDERS[ch as ExternalChannel];
      if (!sender || !avail[ch].available) { results[ch] = { status: "failed", at, error: avail[ch].reason ?? "Canal indisponível." }; continue; }
      try {
        const r = await sender({ organizationId, recipientId: a.recipientId, title: a.title, body: a.message, alertId: a.id });
        results[ch] = { status: r.delivered ? "delivered" : "sent", at };
      } catch (err) { results[ch] = { status: "failed", at, error: (err as Error).message.slice(0, 200) }; }
    }
    const vals = Object.values(results);
    const delivered = vals.some((r) => r.status === "delivered");
    const sent = delivered || vals.some((r) => r.status === "sent");
    const status = delivered ? "delivered" : sent ? "sent" : "failed";
    const failureReason = vals.filter((r) => r.status === "failed").map((r) => r.error).filter(Boolean).join("; ") || null;
    const [u] = await tx.update(taskAlerts).set({
      status, channelResults: results, sentAt: sent ? now : null, deliveredAt: delivered ? now : null, failureReason: status === "failed" ? failureReason : null, updatedAt: now,
    }).where(eq(taskAlerts.id, a.id)).returning();
    for (const [ch, r] of Object.entries(results)) {
      await logEvent(tx, { organizationId, taskId: a.taskId, alertId: a.id, type: r.status === "failed" ? "failed" : r.status === "delivered" ? "delivered" : "sent", actorId, channel: ch, data: r.error ? { error: r.error } : {} });
    }
    return { alert: u, skipped: false };
  });
}

/** Envia agora um rascunho ou antecipa um agendado. */
export async function sendAlertNow(ctx: TenantContext, alertId: string) {
  requirePerm(ctx, "alerts:send");
  const a = await getAlertRow(ctx, alertId);
  if (a.status !== "draft" && a.status !== "scheduled") throw new HttpError(409, "Só é possível enviar rascunhos ou alertas agendados.");
  await assertChannelsAvailable(ctx.db, ctx.organizationId, a.channels);
  const r = await deliverAlert(ctx.db, ctx.organizationId, alertId, ctx.userId);
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "task_alert.sent", resource: "task_alert", resourceId: alertId, metadata: { status: r.alert.status } });
  return { alert: r.alert, notice: deliveryNotice(r.alert) };
}

export async function cancelAlert(ctx: TenantContext, alertId: string, reason?: string) {
  requirePerm(ctx, "alerts:send");
  const a = await getAlertRow(ctx, alertId);
  if (a.status !== "draft" && a.status !== "scheduled") throw new HttpError(409, "Só é possível cancelar rascunhos ou alertas ainda não enviados. Um alerta enviado não pode ser desfeito.");
  const now = new Date();
  const [c] = await ctx.db.update(taskAlerts).set({ status: "canceled", canceledAt: now, failureReason: reason?.slice(0, 300) ?? "Cancelado pelo gestor.", updatedAt: now })
    .where(and(eq(taskAlerts.id, alertId), inArray(taskAlerts.status, ["draft", "scheduled"]))).returning();
  if (!c) throw new HttpError(409, "O alerta mudou de estado e não pode mais ser cancelado.");
  await logEvent(ctx.db, { organizationId: ctx.organizationId, taskId: a.taskId, alertId, type: "canceled", actorId: ctx.userId, data: { reason: reason ?? null } });
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "task_alert.canceled", resource: "task_alert", resourceId: alertId, metadata: { reason: reason ?? null } });
  return c;
}

/* ------------------------------------------------------------------ leitura / resposta do colaborador */

async function getAlertRow(ctx: TenantContext, alertId: string) {
  const [a] = await ctx.db.select().from(taskAlerts).where(and(eq(taskAlerts.id, alertId), eq(taskAlerts.organizationId, ctx.organizationId)));
  if (!a) throw new HttpError(404, "Alerta não encontrado.");
  return a;
}

/** Quem pode ver o alerta: o destinatário ou quem gerencia alertas. */
function assertCanView(ctx: TenantContext, a: Pick<AlertRow, "recipientId">) {
  if (a.recipientId !== ctx.userId && !can(ctx, "alerts:send")) throw new HttpError(403, "Você não tem acesso a este alerta.");
}

/** O destinatário abriu o alerta: ÚNICO momento em que "lido" é registrado. */
export async function markAlertRead(ctx: TenantContext, alertId: string) {
  const a = await getAlertRow(ctx, alertId);
  if (a.recipientId !== ctx.userId) throw new HttpError(403, "Só o destinatário registra a leitura do alerta.");
  if (a.readAt || !["sent", "delivered"].includes(a.status)) return a;
  const now = new Date();
  const [u] = await ctx.db.update(taskAlerts).set({ status: "read", readAt: now, updatedAt: now })
    .where(and(eq(taskAlerts.id, alertId), inArray(taskAlerts.status, ["sent", "delivered"]))).returning();
  if (u) await logEvent(ctx.db, { organizationId: ctx.organizationId, taskId: a.taskId, alertId, type: "read", actorId: ctx.userId });
  return u ?? a;
}

export const respondInput = z.object({
  alertId: z.string().uuid().optional(),
  taskId: z.string().uuid().optional(),
  kind: z.enum(RESPONSE_KINDS),
  message: z.string().trim().max(2000).optional(),
  progressPct: z.coerce.number().int().min(0).max(100).optional(),
  evidenceUrl: z.string().trim().url().max(500).optional(),
});

/** Resposta/atualização do responsável (ou do destinatário de um escalonamento). */
export async function respondToAlert(ctx: TenantContext, raw: z.input<typeof respondInput>) {
  const input = respondInput.parse(raw);
  const alert = input.alertId ? await getAlertRow(ctx, input.alertId) : null;
  const taskId = alert?.taskId ?? input.taskId;
  if (!taskId) throw new HttpError(400, "Informe o alerta ou a tarefa.");
  const task = await loadTask(ctx.db, ctx.organizationId, taskId);
  const isAssignee = task.assigneeId === ctx.userId;
  const isRecipient = alert?.recipientId === ctx.userId;
  const isManager = can(ctx, "alerts:send");
  if (!isAssignee && !isRecipient && !(isManager && input.kind === "comment")) throw new HttpError(403, "Você só pode responder alertas e tarefas pelos quais é responsável.");
  if (["blocker", "delay_justification", "help", "comment"].includes(input.kind) && !input.message) throw new HttpError(400, "Escreva uma mensagem para este tipo de resposta.");
  if (input.kind === "need_more_time") throw new HttpError(400, "Para pedir mais prazo, use a solicitação de prorrogação (informa a nova data e a justificativa).");
  if (input.kind === "progress" && input.progressPct == null) throw new HttpError(400, "Informe o percentual de andamento.");
  if (input.kind === "done") requirePerm(ctx, "crm:write");

  const now = new Date();
  const result = await ctx.db.transaction(async (txRaw) => {
    const tx = txRaw as unknown as DB;
    const [resp] = await tx.insert(taskAlertResponses).values({
      organizationId: ctx.organizationId, taskId, alertId: alert?.id ?? null, userId: ctx.userId, kind: input.kind, message: input.message ?? null,
      progressPct: input.progressPct ?? null, evidenceUrl: input.evidenceUrl ?? null,
    }).returning();
    // Efeitos sobre a tarefa (toda atualização do responsável zera o "sem atualização").
    const patch: Partial<typeof tasks.$inferInsert> = { updatedAt: now };
    if (input.kind === "working") { patch.blockedReason = null; }
    if (input.kind === "progress") { patch.progressPct = input.progressPct; patch.blockedReason = null; }
    if (input.kind === "blocker") patch.blockedReason = input.message;
    if (input.kind === "done") { patch.status = "done"; patch.completedAt = now; patch.progressPct = 100; patch.blockedReason = null; }
    if (isAssignee || input.kind !== "comment") await tx.update(tasks).set(patch).where(eq(tasks.id, taskId));
    if (alert && isRecipient) {
      const upd: Partial<typeof taskAlerts.$inferInsert> = { updatedAt: now };
      if (!alert.readAt) { upd.readAt = now; }
      if (input.kind !== "comment" || isRecipient) { upd.respondedAt = now; upd.status = "responded"; }
      if (!["canceled", "failed", "draft", "scheduled"].includes(alert.status)) await tx.update(taskAlerts).set(upd).where(eq(taskAlerts.id, alert.id));
      if (!alert.readAt && ["sent", "delivered"].includes(alert.status)) await logEvent(tx, { organizationId: ctx.organizationId, taskId, alertId: alert.id, type: "read", actorId: ctx.userId });
    }
    await logEvent(tx, { organizationId: ctx.organizationId, taskId, alertId: alert?.id ?? null, type: "responded", actorId: ctx.userId,
      data: { kind: input.kind, message: input.message ?? null, progressPct: input.progressPct ?? null, evidenceUrl: input.evidenceUrl ?? null } });
    return resp;
  });
  // Avisa quem enviou o alerta (ou os gestores) — sem expor dados a quem não deve ver.
  const notifyIds = alert?.senderId ? [alert.senderId] : [];
  for (const uid of notifyIds.filter((u) => u !== ctx.userId)) {
    await notifyUser(ctx.db, { organizationId: ctx.organizationId, userId: uid, title: `Resposta ao alerta: ${task.title}`, body: `${ctx.userId === task.assigneeId ? "O responsável" : "O destinatário"} registrou: ${input.kind}${input.message ? ` — ${input.message}` : ""}`,
      href: `/alertas?alerta=${alert!.id}`, alertId: alert!.id });
  }
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: `task_alert.response.${input.kind}`, resource: "task", resourceId: taskId, metadata: { alertId: alert?.id ?? null } });
  return result;
}

/* ------------------------------------------------------------------ consultas */

export const filtersSchema = z.object({
  recipientId: z.string().uuid().optional(),
  teamId: z.string().uuid().optional(),
  priority: z.enum(PRIORITIES).optional(),
  status: z.enum(STATUSES).optional(),
  taskId: z.string().uuid().optional(),
  channel: z.enum(CHANNELS).optional(),
  kind: z.enum(["manual", "automation", "escalation"]).optional(),
  from: z.coerce.date().optional(),
  to: z.coerce.date().optional(),
  limit: z.coerce.number().int().min(1).max(500).default(200),
});
export type AlertFilters = z.input<typeof filtersSchema>;

const recipientU = users;

/** Central do gestor: alertas da organização com filtros. Quem não gerencia alertas vê apenas os seus. */
export async function listAlerts(ctx: TenantContext, raw: AlertFilters = {}) {
  const f = filtersSchema.parse(raw);
  const manager = can(ctx, "alerts:send");
  const conds = [eq(taskAlerts.organizationId, ctx.organizationId)];
  if (!manager) conds.push(eq(taskAlerts.recipientId, ctx.userId));
  if (f.recipientId && manager) conds.push(eq(taskAlerts.recipientId, f.recipientId));
  if (f.priority) conds.push(eq(taskAlerts.priority, f.priority));
  if (f.status) conds.push(eq(taskAlerts.status, f.status));
  if (f.taskId) conds.push(eq(taskAlerts.taskId, f.taskId));
  if (f.kind) conds.push(eq(taskAlerts.kind, f.kind));
  if (f.channel) conds.push(sql`${taskAlerts.channels} @> ${JSON.stringify([f.channel])}::jsonb`);
  if (f.from) conds.push(gte(taskAlerts.createdAt, f.from));
  if (f.to) conds.push(lte(taskAlerts.createdAt, f.to));
  if (f.teamId && manager) conds.push(sql`${taskAlerts.recipientId} in (select user_id from ${teamMembers} where team_id = ${f.teamId})`);
  const rows = await ctx.db.select({ a: taskAlerts, taskTitle: tasks.title, taskStatus: tasks.status, taskDueAt: tasks.dueAt, recipient: recipientU.name })
    .from(taskAlerts).innerJoin(tasks, eq(tasks.id, taskAlerts.taskId)).innerJoin(recipientU, eq(recipientU.id, taskAlerts.recipientId))
    .where(and(...conds)).orderBy(desc(taskAlerts.createdAt)).limit(f.limit);
  return rows;
}

/** Alertas recebidos pelo usuário logado (experiência do colaborador). */
export async function listMyAlerts(ctx: TenantContext) {
  return ctx.db.select({ a: taskAlerts, taskTitle: tasks.title, taskStatus: tasks.status, taskDueAt: tasks.dueAt, taskProgress: tasks.progressPct, taskBlocked: tasks.blockedReason })
    .from(taskAlerts).innerJoin(tasks, eq(tasks.id, taskAlerts.taskId))
    .where(and(eq(taskAlerts.organizationId, ctx.organizationId), eq(taskAlerts.recipientId, ctx.userId), inArray(taskAlerts.status, ["sent", "delivered", "read", "responded"])))
    .orderBy(desc(taskAlerts.createdAt)).limit(100);
}

/** Histórico completo de uma tarefa: alertas, respostas, prorrogações e linha do tempo. */
export async function taskHistory(ctx: TenantContext, taskId: string) {
  const task = await loadTask(ctx.db, ctx.organizationId, taskId);
  const manager = can(ctx, "alerts:send");
  if (!manager && task.assigneeId !== ctx.userId) throw new HttpError(403, "Você não tem acesso ao histórico desta tarefa.");
  const scope = manager ? undefined : eq(taskAlerts.recipientId, ctx.userId);
  const [alertRows, events, responses, extensions] = await Promise.all([
    ctx.db.select().from(taskAlerts).where(and(eq(taskAlerts.organizationId, ctx.organizationId), eq(taskAlerts.taskId, taskId), ...(scope ? [scope] : []))).orderBy(desc(taskAlerts.createdAt)),
    ctx.db.select().from(taskAlertEvents).where(and(eq(taskAlertEvents.organizationId, ctx.organizationId), eq(taskAlertEvents.taskId, taskId))).orderBy(desc(taskAlertEvents.createdAt)).limit(300),
    ctx.db.select().from(taskAlertResponses).where(and(eq(taskAlertResponses.organizationId, ctx.organizationId), eq(taskAlertResponses.taskId, taskId))).orderBy(desc(taskAlertResponses.createdAt)),
    ctx.db.select().from(taskExtensionRequests).where(and(eq(taskExtensionRequests.organizationId, ctx.organizationId), eq(taskExtensionRequests.taskId, taskId))).orderBy(desc(taskExtensionRequests.createdAt)),
  ]);
  return { task, alerts: alertRows, events, responses, extensions };
}

/** Detalhe de um alerta (com tarefa e histórico). Abrir como destinatário NÃO marca leitura sozinho (use markAlertRead). */
export async function getAlertDetail(ctx: TenantContext, alertId: string) {
  const a = await getAlertRow(ctx, alertId);
  assertCanView(ctx, a);
  const h = await taskHistory(ctx, a.taskId).catch(async (e) => {
    if ((e as { status?: number }).status !== 403) throw e;
    // destinatário de escalonamento (não é responsável): vê só o próprio alerta e o contexto da tarefa
    return { task: await loadTask(ctx.db, ctx.organizationId, a.taskId), alerts: [a], events: [], responses: [], extensions: [] };
  });
  return { alert: a, ...h };
}
