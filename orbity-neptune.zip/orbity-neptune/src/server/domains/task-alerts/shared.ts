/**
 * ORBITY TASK INTELLIGENCE — tipos, constantes e utilitários compartilhados.
 *
 * Princípios deste módulo:
 *  - Envio, entrega e leitura são estados DIFERENTES e só são gravados quando realmente ocorreram.
 *  - Canal externo (push, e-mail, WhatsApp) só entra em EXTERNAL_SENDERS quando o envio real estiver implementado e testado.
 *    Hoje nenhum está: eles aparecem como indisponíveis e o sistema nunca marca como enviado/entregue.
 *  - Toda mudança relevante vira um evento imutável na linha do tempo da tarefa (task_alert_events) e, quando sensível, na auditoria.
 */
import { and, eq } from "drizzle-orm";
import type { DB } from "../../db/client";
import { integrations, memberships, notifications, organizations, roles, taskAlertEvents, teamMembers } from "../../db/schema";
import { hasPermission } from "../../permissions";

import { CHANNEL_LABEL, PRIORITIES, TONES, type AlertChannel, type AlertPriority, type MessageKind, type Tone } from "../../../lib/task-alerts";
export * from "../../../lib/task-alerts";

/** Intervalo mínimo entre dois alertas automáticos para a mesma tarefa e destinatário (evita excesso e duplicidade). */
export const MIN_GAP_MINUTES = 60;

/* ------------------------------------------------------------------ canais */

export type ExternalChannel = Exclude<AlertChannel, "in_app">;
export type ExternalSender = (m: { organizationId: string; recipientId: string; title: string; body: string; alertId: string }) => Promise<{ externalId?: string; delivered?: boolean }>;
/**
 * Envio real por canal externo. Um canal só deve ser registrado aqui depois que a chamada ao provedor estiver implementada
 * E testada. Vazio de propósito: nenhum canal externo entrega de verdade hoje, então nada é apresentado como enviado.
 */
export const EXTERNAL_SENDERS: Partial<Record<ExternalChannel, ExternalSender>> = {};

const CHANNEL_PROVIDER: Partial<Record<ExternalChannel, string>> = { email: "email_smtp", whatsapp: "whatsapp" };

export type ChannelStatus = { available: boolean; reason: string | null };

/** Disponibilidade REAL de cada canal para a organização (integração conectada + envio implementado). */
export async function channelAvailability(db: DB, organizationId: string): Promise<Record<AlertChannel, ChannelStatus>> {
  const rows = await db.select({ provider: integrations.provider, status: integrations.status, mode: integrations.mode })
    .from(integrations).where(eq(integrations.organizationId, organizationId));
  const out = { in_app: { available: true, reason: null } } as Record<AlertChannel, ChannelStatus>;
  for (const ch of ["push", "email", "whatsapp"] as const) {
    const provider = CHANNEL_PROVIDER[ch];
    if (!EXTERNAL_SENDERS[ch]) {
      out[ch] = { available: false, reason: provider
        ? `Envio real por ${CHANNEL_LABEL[ch]} ainda não foi implementado nesta versão; nenhum alerta seria entregue.`
        : "Push notification ainda não tem provedor de envio implementado." };
      continue;
    }
    const connected = !provider || rows.some((r) => r.provider === provider && r.status === "connected" && r.mode === "real");
    out[ch] = connected ? { available: true, reason: null } : { available: false, reason: `Integração ${provider} não está conectada.` };
  }
  return out;
}

/* ------------------------------------------------------------------ linha do tempo / notificações */

export async function logEvent(db: DB, e: { organizationId: string; taskId: string; alertId?: string | null; type: string; actorId?: string | null; channel?: string | null; data?: Record<string, unknown> }) {
  await db.insert(taskAlertEvents).values({
    organizationId: e.organizationId, taskId: e.taskId, alertId: e.alertId ?? null, type: e.type, actorId: e.actorId ?? "system", channel: e.channel ?? null, data: e.data ?? {},
  });
}

export async function notifyUser(db: DB, n: { organizationId: string; userId: string; title: string; body?: string | null; href?: string | null; alertId?: string | null; priority?: string | null }) {
  await db.insert(notifications).values({
    organizationId: n.organizationId, userId: n.userId, title: n.title, body: n.body?.slice(0, 600) ?? null, href: n.href ?? null, alertId: n.alertId ?? null, priority: n.priority ?? null,
  });
}

/** Usuários ativos da organização com uma permissão (gestores/administradores). */
export async function usersWithPermission(db: DB, organizationId: string, perm: "alerts:send" | "alerts:manage") {
  const rows = await db.select({ userId: memberships.userId, permissions: roles.permissions }).from(memberships)
    .innerJoin(roles, eq(roles.id, memberships.roleId))
    .where(and(eq(memberships.organizationId, organizationId), eq(memberships.status, "active")));
  return rows.filter((r) => hasPermission(r.permissions, perm)).map((r) => r.userId);
}

export async function isActiveMember(db: DB, organizationId: string, userId: string) {
  const [m] = await db.select({ id: memberships.id }).from(memberships)
    .where(and(eq(memberships.organizationId, organizationId), eq(memberships.userId, userId), eq(memberships.status, "active")));
  return !!m;
}

/* ------------------------------------------------------------------ tom de comunicação */

export type ToneSettings = { tone: Tone; customTone?: string; byTeam?: Record<string, Tone>; byKind?: Partial<Record<MessageKind, Tone>> };
export const DEFAULT_TONE: ToneSettings = { tone: "cordial" };

export async function getToneSettings(db: DB, organizationId: string): Promise<ToneSettings> {
  const [o] = await db.select({ s: organizations.settings }).from(organizations).where(eq(organizations.id, organizationId));
  const raw = (o?.s as { taskAlerts?: Partial<ToneSettings> } | undefined)?.taskAlerts;
  return { ...DEFAULT_TONE, ...(raw ?? {}) } as ToneSettings;
}

/** Hierarquia: regra/tipo de alerta > equipe do responsável > organização. */
export async function resolveTone(db: DB, organizationId: string, assigneeId: string | null, opts: { ruleTone?: string | null; kind?: MessageKind } = {}): Promise<{ tone: Tone; customTone?: string }> {
  const s = await getToneSettings(db, organizationId);
  if (opts.ruleTone && (TONES as readonly string[]).includes(opts.ruleTone)) return { tone: opts.ruleTone as Tone, customTone: s.customTone };
  if (opts.kind && s.byKind?.[opts.kind]) return { tone: s.byKind[opts.kind]!, customTone: s.customTone };
  if (assigneeId && s.byTeam) {
    const teams = await db.select({ teamId: teamMembers.teamId }).from(teamMembers).where(eq(teamMembers.userId, assigneeId));
    for (const t of teams) if (s.byTeam[t.teamId]) return { tone: s.byTeam[t.teamId], customTone: s.customTone };
  }
  return { tone: s.tone, customTone: s.customTone };
}

/* ------------------------------------------------------------------ utilidades */

/** Hora cheia (0–23) no fuso da organização. */
export function hourInTz(d: Date, timeZone: string): number {
  const h = Number(new Intl.DateTimeFormat("en-GB", { hour: "2-digit", hour12: false, timeZone }).format(d));
  return h % 24;
}

/** Janela [start, end) em horas locais; aceita janelas que cruzam a meia-noite. */
export function inAllowedWindow(d: Date, timeZone: string, startHour: number, endHour: number) {
  const h = hourInTz(d, timeZone);
  return startHour <= endHour ? h >= startHour && h < endHour : h >= startHour || h < endHour;
}

export function bumpPriority(p: string): AlertPriority {
  const i = PRIORITIES.indexOf(p as AlertPriority);
  return PRIORITIES[Math.min(PRIORITIES.length - 1, Math.max(0, i) + 1)];
}

/** Prioridade da TAREFA (low|medium|high) → prioridade padrão do alerta. */
export function alertPriorityFor(taskPriority: string, overdue: boolean): AlertPriority {
  if (overdue) return taskPriority === "high" ? "urgent" : "high";
  return taskPriority === "high" ? "high" : taskPriority === "low" ? "low" : "medium";
}

export const sha1 = async (s: string) => {
  const buf = await crypto.subtle.digest("SHA-1", new TextEncoder().encode(s));
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
};
