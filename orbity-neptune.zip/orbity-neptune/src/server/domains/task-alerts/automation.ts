/**
 * Automação e escalonamento de alertas (roda no worker a cada minuto e pode ser disparada manualmente por `alerts:manage`).
 *
 * Proteções contra excesso e duplicidade:
 *  - cada alerta automático tem idempotencyKey determinística (regra + tarefa + série + nº do lembrete): reexecutar não duplica;
 *  - respeita horário permitido (no fuso da organização), máximo de lembretes por regra e intervalo mínimo entre lembretes;
 *  - intervalo mínimo global (MIN_GAP_MINUTES) entre alertas da mesma tarefa para o mesmo destinatário;
 *  - nunca age sobre tarefas concluídas, canceladas ou justificadamente bloqueadas;
 *  - escalonamento para quando há resposta ou atualização da tarefa, ou ao atingir o máximo de tentativas.
 */
import { and, asc, eq, inArray, isNotNull, lte, notInArray } from "drizzle-orm";
import type { DB } from "../../db/client";
import { memberships, notifications, organizations, taskAlertRules, taskAlerts, tasks, users } from "../../db/schema";
import { systemContextFor } from "../../intelligence-layer/system-context";
import { goalsWithProgress } from "../goals";
import { audit } from "../../audit";
import { deliverAlert, insertAlert, type AlertRow } from "./core";
import { autoMessage } from "./messages";
import { MIN_GAP_MINUTES, bumpPriority, inAllowedWindow, logEvent, usersWithPermission, type MessageKind } from "./shared";

type Rule = typeof taskAlertRules.$inferSelect;
type TaskRow = typeof tasks.$inferSelect;
const MIN = 60_000, HOUR = 3_600_000, DAY = 86_400_000;

export type AutomationStats = { dispatched: number; created: number; escalated: number; goalNotices: number; skipped: number };

const prefixOf = (key: string | null) => (key ? key.slice(0, key.lastIndexOf(":n")) : "");

export async function runAlertAutomation(db: DB, organizationId: string, now = new Date()): Promise<AutomationStats> {
  const stats: AutomationStats = { dispatched: 0, created: 0, escalated: 0, goalNotices: 0, skipped: 0 };
  const [org] = await db.select().from(organizations).where(eq(organizations.id, organizationId));
  const ctx = org ? await systemContextFor(db, organizationId) : null;
  if (!org || !ctx) return stats;
  const tz = org.timezone;

  // 1) Alertas agendados que venceram.
  const due = await db.select({ id: taskAlerts.id }).from(taskAlerts)
    .where(and(eq(taskAlerts.organizationId, organizationId), eq(taskAlerts.status, "scheduled"), lte(taskAlerts.scheduledAt, now))).orderBy(asc(taskAlerts.scheduledAt)).limit(200);
  for (const d of due) {
    const r = await deliverAlert(db, organizationId, d.id, "system");
    if (!r.skipped) stats.dispatched++; else stats.skipped++;
  }

  const rules = await db.select().from(taskAlertRules).where(and(eq(taskAlertRules.organizationId, organizationId), eq(taskAlertRules.active, true)));
  if (!rules.length) return stats;

  const active = new Set((await db.select({ u: memberships.userId }).from(memberships).where(and(eq(memberships.organizationId, organizationId), eq(memberships.status, "active")))).map((m) => m.u));
  const openTasks = await db.select().from(tasks).where(and(eq(tasks.organizationId, organizationId), eq(tasks.status, "open")));
  const eligible = openTasks.filter((t) => !t.blockedReason); // bloqueio justificado suspende lembretes e escalonamento
  const managers = (await usersWithPermission(db, organizationId, "alerts:send")).filter((u) => active.has(u));

  for (const rule of rules) {
    if (!inAllowedWindow(now, tz, rule.allowedStartHour, rule.allowedEndHour)) { stats.skipped++; continue; }
    const mine = await db.select().from(taskAlerts).where(and(eq(taskAlerts.organizationId, organizationId), eq(taskAlerts.ruleId, rule.id)));
    const reminders = new Map<string, { count: number; last: number }>();
    for (const a of mine.filter((x) => x.kind === "automation")) {
      const p = prefixOf(a.idempotencyKey), g = reminders.get(p) ?? { count: 0, last: 0 };
      g.count++; g.last = Math.max(g.last, (a.sentAt ?? a.createdAt).getTime()); reminders.set(p, g);
    }

    /** Cria e entrega um lembrete automático se as proteções permitirem. */
    const remind = async (t: TaskRow, recipientId: string, series: string, kind: MessageKind) => {
      const prefix = `rule:${rule.id}:${t.id}:${series}`;
      const g = reminders.get(prefix) ?? { count: 0, last: 0 };
      if (g.count >= rule.maxReminders) return;
      if (g.count > 0 && (!rule.repeatEveryMinutes || now.getTime() - g.last < rule.repeatEveryMinutes * MIN)) return;
      // Intervalo mínimo global: qualquer alerta (manual ou automático) já enviado há pouco para este destinatário nesta tarefa.
      const sentTimes = (await db.select({ s: taskAlerts.sentAt }).from(taskAlerts).where(and(eq(taskAlerts.organizationId, organizationId), eq(taskAlerts.taskId, t.id),
        eq(taskAlerts.recipientId, recipientId), isNotNull(taskAlerts.sentAt)))).map((r) => r.s!.getTime());
      if (sentTimes.some((s) => now.getTime() - s < MIN_GAP_MINUTES * MIN)) { stats.skipped++; return; }
      const msg = await autoMessage(ctx, t.id, kind, rule.tone);
      const { alert, duplicate } = await insertAlert(db, {
        organizationId, taskId: t.id, recipientId, senderId: null, kind: "automation", title: msg.title, message: msg.message, messageOrigin: "manual", priority: rule.alertPriority,
        channels: rule.channels, status: "draft", taskDueAtSnapshot: t.dueAt, ruleId: rule.id, idempotencyKey: `${prefix}:n${g.count + 1}`,
      });
      if (duplicate) return;
      await deliverAlert(db, organizationId, alert.id, "system");
      reminders.set(prefix, { count: g.count + 1, last: now.getTime() });
      stats.created++;
    };

    if (rule.trigger === "goal_at_risk") { stats.goalNotices += await goalRiskNotices(db, ctx, rule, managers, now); continue; }

    const scoped = eligible.filter((t) => (rule.priorities as string[]).includes(t.priority));
    for (const t of scoped) {
      const dueMs = t.dueAt?.getTime() ?? null;
      const series = String(dueMs ?? 0);
      switch (rule.trigger) {
        case "before_due":
          if (t.assigneeId && active.has(t.assigneeId) && dueMs && now.getTime() >= dueMs - rule.offsetMinutes * MIN && now.getTime() < dueMs) await remind(t, t.assigneeId, series, t.priority === "high" ? "high_priority" : "friendly_reminder");
          break;
        case "on_due":
          if (t.assigneeId && active.has(t.assigneeId) && dueMs && now.getTime() >= dueMs && now.getTime() - dueMs < DAY) await remind(t, t.assigneeId, series, "status_request");
          break;
        case "overdue":
          if (t.assigneeId && active.has(t.assigneeId) && dueMs && now.getTime() >= dueMs + rule.offsetMinutes * MIN) await remind(t, t.assigneeId, series, "overdue_notice");
          break;
        case "priority_pending":
          if (t.assigneeId && active.has(t.assigneeId) && now.getTime() - t.createdAt.getTime() >= rule.staleAfterHours * HOUR && (t.progressPct ?? 0) === 0) await remind(t, t.assigneeId, `pp${series}`, "high_priority");
          break;
        case "stale":
          if (now.getTime() - t.updatedAt.getTime() >= rule.staleAfterHours * HOUR) for (const m of managers.filter((u) => u !== t.assigneeId)) await remind(t, m, `st${t.updatedAt.getTime()}:${m}`, "status_request");
          break;
      }
    }
  }

  // 2) Escalonamento (só para regras com escalonamento habilitado).
  for (const rule of rules.filter((r) => r.escalation.enabled && inAllowedWindow(now, tz, r.allowedStartHour, r.allowedEndHour))) {
    stats.escalated += await escalate(db, rule, eligible, active, now);
  }
  return stats;
}

/** Notificações (não alertas de tarefa) sobre metas com projeção abaixo do objetivo. Estimativa linear: nunca altera meta nem comissão. */
async function goalRiskNotices(db: DB, ctx: NonNullable<Awaited<ReturnType<typeof systemContextFor>>>, rule: Rule, managers: string[], now: Date) {
  const progress = await goalsWithProgress(ctx);
  let n = 0;
  for (const g of progress) {
    if (g.periodEnd.getTime() < now.getTime() || !(g.metric === "revenue" || g.metric === "deals_won")) continue;
    if (g.projectedPct >= 85 || g.pct >= 100) continue;
    const to = new Set([...(g.scope === "user" && g.scopeId ? [g.scopeId] : []), ...managers]);
    const title = `Meta em risco: ${g.name}`;
    for (const userId of to) {
      const recent = await db.select({ id: notifications.id, createdAt: notifications.createdAt }).from(notifications)
        .where(and(eq(notifications.organizationId, ctx.organizationId), eq(notifications.userId, userId), eq(notifications.title, title)));
      if (recent.some((r) => now.getTime() - r.createdAt.getTime() < 7 * DAY)) continue; // no máximo um aviso por semana
      await db.insert(notifications).values({ organizationId: ctx.organizationId, userId, title, body: `Progresso ${g.pct}%, projeção no ritmo atual ${g.projectedPct}% (estimativa linear, não garantia).`, href: "/tarefas", priority: rule.alertPriority });
      n++;
    }
  }
  if (n) await audit(db, { organizationId: ctx.organizationId, actorId: "system", action: "task_alert.goal_risk_notice", resource: "task_alert_rule", resourceId: rule.id, metadata: { notices: n } });
  return n;
}

async function escalate(db: DB, rule: Rule, eligible: TaskRow[], active: Set<string>, now: Date) {
  const alerts = await db.select().from(taskAlerts).where(and(eq(taskAlerts.organizationId, rule.organizationId), eq(taskAlerts.ruleId, rule.id), isNotNull(taskAlerts.sentAt),
    inArray(taskAlerts.kind, ["manual", "automation", "escalation"]), notInArray(taskAlerts.status, ["canceled", "failed"])));
  const taskById = new Map(eligible.map((t) => [t.id, t]));
  const groups = new Map<string, { roots: AlertRow[]; maxLevel: number }>();
  for (const a of alerts) {
    const k = `${a.taskId}|${a.taskDueAtSnapshot?.getTime() ?? 0}`;
    const g = groups.get(k) ?? { roots: [], maxLevel: 0 };
    if (a.kind === "escalation") g.maxLevel = Math.max(g.maxLevel, a.escalationLevel); else g.roots.push(a);
    groups.set(k, g);
  }
  let n = 0;
  for (const [k, g] of groups) {
    const t = taskById.get(k.split("|")[0]);
    if (!t || !g.roots.length) continue; // tarefa concluída/cancelada/bloqueada: não escala
    if (g.roots.some((a) => a.status === "responded")) continue; // houve resposta: critério de interrupção
    const first = g.roots.reduce((m, a) => (a.sentAt! < m.sentAt! ? a : m));
    if (t.updatedAt.getTime() > first.sentAt!.getTime()) continue; // a tarefa foi atualizada depois do alerta
    const level = g.maxLevel + 1;
    if (level > rule.escalation.maxAttempts || level > rule.escalation.steps.length) continue;
    const step = rule.escalation.steps[level - 1];
    if (now.getTime() < first.sentAt!.getTime() + step.afterMinutes * MIN) continue;
    const exclude = new Set([t.assigneeId, ...g.roots.map((a) => a.recipientId)]);
    const targets = step.userIds.filter((u) => active.has(u) && !exclude.has(u));
    const [assignee] = t.assigneeId ? await db.select({ name: users.name }).from(users).where(eq(users.id, t.assigneeId)) : [];
    for (const userId of targets) {
      const { alert, duplicate } = await insertAlert(db, {
        organizationId: rule.organizationId, taskId: t.id, recipientId: userId, senderId: null, kind: "escalation", escalationLevel: level, parentAlertId: first.id, ruleId: rule.id,
        title: `Escalonamento (nível ${level}): ${t.title}`.slice(0, 140),
        message: `A tarefa "${t.title}"${assignee ? ` (responsável: ${assignee.name})` : ""} recebeu um alerta em ${first.sentAt!.toLocaleString("pt-BR")} e não teve resposta nem atualização desde então.${t.dueAt ? ` Prazo: ${t.dueAt.toLocaleDateString("pt-BR")}.` : ""} Avalie se é preciso apoiar, repriorizar ou reatribuir. Isto não é uma avaliação do responsável: pode haver impedimento não comunicado.`,
        messageOrigin: "manual", priority: bumpPriority(first.priority), channels: rule.channels, status: "draft", taskDueAtSnapshot: t.dueAt,
        idempotencyKey: `esc:${rule.id}:${t.id}:${t.dueAt?.getTime() ?? 0}:L${level}:u${userId}`,
      });
      if (duplicate) continue;
      await deliverAlert(db, rule.organizationId, alert.id, "system");
      await logEvent(db, { organizationId: rule.organizationId, taskId: t.id, alertId: alert.id, type: "escalated", actorId: "system", data: { level, ruleId: rule.id, toUserId: userId, rootAlertId: first.id } });
      await audit(db, { organizationId: rule.organizationId, actorId: "system", action: "task_alert.escalated", resource: "task", resourceId: t.id, metadata: { level, toUserId: userId, ruleId: rule.id } });
      n++;
    }
  }
  return n;
}
