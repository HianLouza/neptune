/**
 * Prorrogação e reagendamento.
 *
 * O Flávio RECOMENDA (análise por regras, com fatos e inferências separados) — nunca aprova. Só um gestor com `alerts:send`
 * aprova, rejeita ou propõe outra data, e ninguém decide a própria solicitação. Toda alteração de prazo gera evento + auditoria.
 */
import { and, count, desc, eq, inArray } from "drizzle-orm";
import { z } from "zod";
import type { DB } from "../../db/client";
import { goals, taskExtensionRequests, tasks, users } from "../../db/schema";
import { can, requirePerm, type TenantContext } from "../../tenancy/context";
import { audit } from "../../audit";
import { HttpError } from "../../http";
import { loadTask } from "./core";
import { logEvent, notifyUser, usersWithPermission } from "./shared";

export type ExtensionRecommendation = {
  decision: "approve" | "reject" | "counter"; suggestedDueAt: string | null; rationale: string; facts: string[]; inferences: string[];
  recommendation: string; disclaimer: string; method: "rules";
};

const DAY = 86_400_000;
const fmt = (d: Date | null, tz: string) => (d ? d.toLocaleDateString("pt-BR", { timeZone: tz }) : "sem prazo");

/** Fatos objetivos + inferências + recomendação. Determinístico e auditável. */
export async function analyzeExtension(db: DB, task: typeof tasks.$inferSelect, requestedDueAt: Date, input: { blockers?: string | null; justification: string }, tz: string): Promise<ExtensionRecommendation> {
  const facts: string[] = [], inferences: string[] = [];
  const baseDue = task.dueAt ?? new Date();
  const extraDays = Math.max(0, Math.round((requestedDueAt.getTime() - baseDue.getTime()) / DAY));
  facts.push(`Prioridade da tarefa: ${task.priority}.`, `Prazo atual: ${fmt(task.dueAt, tz)}; solicitado: ${fmt(requestedDueAt, tz)} (+${extraDays} dia(s)).`);
  if (task.progressPct != null) facts.push(`Andamento informado: ${task.progressPct}%.`);
  if (task.blockedReason) facts.push(`A tarefa está marcada como bloqueada: ${task.blockedReason}.`);
  if (input.blockers) facts.push(`Impedimento informado pelo responsável: ${input.blockers}.`);

  let open = 0, late = 0;
  if (task.assigneeId) {
    const rows = await db.select({ dueAt: tasks.dueAt }).from(tasks).where(and(eq(tasks.organizationId, task.organizationId), eq(tasks.assigneeId, task.assigneeId), eq(tasks.status, "open")));
    open = rows.length; late = rows.filter((r) => r.dueAt && r.dueAt.getTime() < Date.now()).length;
    facts.push(`O responsável tem ${open} tarefa(s) aberta(s), ${late} atrasada(s).`);
  }
  const [prev] = await db.select({ n: count() }).from(taskExtensionRequests).where(and(eq(taskExtensionRequests.organizationId, task.organizationId), eq(taskExtensionRequests.taskId, task.id), eq(taskExtensionRequests.status, "approved")));
  const approvedBefore = Number(prev.n);
  if (approvedBefore) facts.push(`Esta tarefa já teve ${approvedBefore} prorrogação(ões) aprovada(s).`);

  let goalEnd: Date | null = null;
  if (task.goalId) {
    const [g] = await db.select({ name: goals.name, end: goals.periodEnd }).from(goals).where(and(eq(goals.id, task.goalId), eq(goals.organizationId, task.organizationId)));
    if (g) { goalEnd = g.end; facts.push(`Meta relacionada: "${g.name}", encerra em ${fmt(g.end, tz)}.`); }
  }

  const heavy = open >= 8;
  const justified = !!(input.blockers || task.blockedReason);
  if (heavy) inferences.push("Carga elevada do responsável pode estar contribuindo para o atraso (possível causa; não é uma avaliação da pessoa).");
  if (justified) inferences.push("Existe um impedimento declarado, o que torna o pedido mais plausível; vale confirmar se é externo ao responsável.");
  if (approvedBefore >= 2) inferences.push("Prorrogações repetidas sugerem estimativa de prazo subestimada ou dependência não resolvida.");
  if (goalEnd && requestedDueAt > goalEnd) inferences.push("O novo prazo ultrapassa o encerramento da meta relacionada.");

  let decision: ExtensionRecommendation["decision"] = "approve", suggested: Date | null = requestedDueAt, rationale = "";
  if (goalEnd && requestedDueAt > goalEnd) { decision = "counter"; suggested = goalEnd; rationale = "O prazo pedido compromete a meta relacionada; sugere-se limitar à data de encerramento dela."; }
  else if (approvedBefore >= 2 && !justified) { decision = "reject"; suggested = null; rationale = "Já houve prorrogações repetidas sem impedimento declarado; sugere-se uma conversa sobre planejamento antes de novo adiamento."; }
  else if (task.priority === "high" && extraDays > 3 && !justified) { decision = "counter"; suggested = new Date(baseDue.getTime() + 2 * DAY); rationale = "Tarefa de prioridade alta com adiamento longo e sem impedimento declarado; sugere-se prazo intermediário (+2 dias)."; }
  else { rationale = extraDays <= 2 ? "Adiamento curto e de baixo impacto." : justified ? "Há impedimento declarado que justifica o novo prazo." : "Adiamento moderado sem sinais de risco para metas."; }

  const recommendation = decision === "approve" ? `Recomendo APROVAR o novo prazo (${fmt(suggested, tz)}).`
    : decision === "counter" ? `Recomendo PROPOR outra data: ${fmt(suggested, tz)}.` : "Recomendo NÃO APROVAR agora e alinhar o planejamento com o responsável.";
  return { decision, suggestedDueAt: suggested?.toISOString() ?? null, rationale, facts, inferences, recommendation,
    disclaimer: "Recomendação do Flávio baseada em regras e nos dados da tarefa. A decisão é do gestor; nada é aprovado automaticamente.", method: "rules" };
}

export const extensionInput = z.object({
  taskId: z.string().uuid(),
  alertId: z.string().uuid().optional(),
  requestedDueAt: z.coerce.date(),
  justification: z.string().trim().min(5, "Explique o motivo do pedido.").max(2000),
  blockers: z.string().trim().max(1000).optional(),
  impact: z.string().trim().max(1000).optional(),
});

/** O responsável pede um novo prazo. Cria a solicitação com a análise do Flávio e avisa os gestores. */
export async function requestExtension(ctx: TenantContext, raw: z.input<typeof extensionInput>) {
  const input = extensionInput.parse(raw);
  const task = await loadTask(ctx.db, ctx.organizationId, input.taskId);
  if (task.assigneeId !== ctx.userId) throw new HttpError(403, "Só o responsável pela tarefa pode pedir prorrogação.");
  if (task.status !== "open") throw new HttpError(409, "A tarefa não está aberta.");
  if (task.dueAt && input.requestedDueAt.getTime() <= task.dueAt.getTime()) throw new HttpError(400, "O novo prazo deve ser posterior ao prazo atual.");
  if (input.requestedDueAt.getTime() <= Date.now()) throw new HttpError(400, "O novo prazo deve estar no futuro.");
  const [pending] = await ctx.db.select({ id: taskExtensionRequests.id }).from(taskExtensionRequests)
    .where(and(eq(taskExtensionRequests.organizationId, ctx.organizationId), eq(taskExtensionRequests.taskId, task.id), eq(taskExtensionRequests.status, "pending")));
  if (pending) throw new HttpError(409, "Já existe uma solicitação de prorrogação pendente para esta tarefa.");

  const recommendation = await analyzeExtension(ctx.db, task, input.requestedDueAt, input, ctx.timezone);
  const [req] = await ctx.db.insert(taskExtensionRequests).values({
    organizationId: ctx.organizationId, taskId: task.id, alertId: input.alertId ?? null, requesterId: ctx.userId, currentDueAt: task.dueAt,
    requestedDueAt: input.requestedDueAt, justification: input.justification, blockers: input.blockers ?? null, impact: input.impact ?? null, recommendation: recommendation as unknown as Record<string, unknown>,
  }).returning();
  await ctx.db.update(tasks).set({ updatedAt: new Date() }).where(eq(tasks.id, task.id));
  await logEvent(ctx.db, { organizationId: ctx.organizationId, taskId: task.id, alertId: input.alertId ?? null, type: "extension_requested", actorId: ctx.userId,
    data: { requestId: req.id, currentDueAt: task.dueAt?.toISOString() ?? null, requestedDueAt: input.requestedDueAt.toISOString(), justification: input.justification, blockers: input.blockers ?? null, impact: input.impact ?? null } });
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "task_extension.requested", resource: "task", resourceId: task.id, metadata: { requestId: req.id } });
  for (const uid of (await usersWithPermission(ctx.db, ctx.organizationId, "alerts:send")).filter((u) => u !== ctx.userId)) {
    await notifyUser(ctx.db, { organizationId: ctx.organizationId, userId: uid, title: `Pedido de prorrogação: ${task.title}`, body: input.justification, href: "/alertas#prorrogacoes", priority: "medium" });
  }
  return { request: req, recommendation };
}

export const decideInput = z.object({
  decision: z.enum(["approve", "reject", "counter"]),
  counterDueAt: z.coerce.date().optional(),
  note: z.string().trim().max(1000).optional(),
});

/** Decisão do gestor. Aprovar aplica o prazo pedido; propor outra data aplica a data proposta; rejeitar mantém o prazo. */
export async function decideExtension(ctx: TenantContext, requestId: string, raw: z.input<typeof decideInput>) {
  requirePerm(ctx, "alerts:send");
  const input = decideInput.parse(raw);
  const [req] = await ctx.db.select().from(taskExtensionRequests).where(and(eq(taskExtensionRequests.id, requestId), eq(taskExtensionRequests.organizationId, ctx.organizationId)));
  if (!req) throw new HttpError(404, "Solicitação não encontrada.");
  if (req.status !== "pending") throw new HttpError(409, "Esta solicitação já foi decidida.");
  if (req.requesterId === ctx.userId) throw new HttpError(403, "Você não pode decidir a própria solicitação.");
  if (input.decision === "counter" && (!input.counterDueAt || input.counterDueAt.getTime() <= Date.now())) throw new HttpError(400, "Informe uma data futura para a proposta.");
  const task = await loadTask(ctx.db, ctx.organizationId, req.taskId);
  const newDue = input.decision === "approve" ? req.requestedDueAt : input.decision === "counter" ? input.counterDueAt! : null;
  const status = input.decision === "approve" ? "approved" : input.decision === "counter" ? "countered" : "rejected";
  const now = new Date();
  const [u] = await ctx.db.transaction(async (txRaw) => {
    const tx = txRaw as unknown as DB;
    const upd = await tx.update(taskExtensionRequests).set({ status, decidedBy: ctx.userId, decidedAt: now, decidedDueAt: newDue, decisionNote: input.note ?? null })
      .where(and(eq(taskExtensionRequests.id, requestId), eq(taskExtensionRequests.status, "pending"))).returning();
    if (!upd.length) throw new HttpError(409, "Esta solicitação já foi decidida.");
    if (newDue) await tx.update(tasks).set({ dueAt: newDue, updatedAt: now }).where(eq(tasks.id, task.id));
    await logEvent(tx, { organizationId: ctx.organizationId, taskId: task.id, alertId: req.alertId, type: "extension_decided", actorId: ctx.userId,
      data: { requestId, decision: status, previousDueAt: task.dueAt?.toISOString() ?? null, newDueAt: newDue?.toISOString() ?? null, note: input.note ?? null } });
    return upd;
  });
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: `task_extension.${status}`, resource: "task", resourceId: task.id, metadata: { requestId, newDueAt: newDue?.toISOString() ?? null } });
  const label = { approved: "aprovado", rejected: "não aprovado", countered: "ajustado pelo gestor" }[status];
  await notifyUser(ctx.db, { organizationId: ctx.organizationId, userId: req.requesterId, title: `Prazo ${label}: ${task.title}`,
    body: `${newDue ? `Novo prazo: ${newDue.toLocaleDateString("pt-BR", { timeZone: ctx.timezone })}. ` : "O prazo atual foi mantido. "}${input.note ?? ""}`.trim(), href: `/alertas`, priority: "medium" });
  return u;
}

export async function listExtensions(ctx: TenantContext, status?: string) {
  const manager = can(ctx, "alerts:send");
  const conds = [eq(taskExtensionRequests.organizationId, ctx.organizationId)];
  if (!manager) conds.push(eq(taskExtensionRequests.requesterId, ctx.userId));
  if (status) conds.push(inArray(taskExtensionRequests.status, status.split(",")));
  return ctx.db.select({ r: taskExtensionRequests, taskTitle: tasks.title, taskPriority: tasks.priority, requester: users.name })
    .from(taskExtensionRequests).innerJoin(tasks, eq(tasks.id, taskExtensionRequests.taskId)).innerJoin(users, eq(users.id, taskExtensionRequests.requesterId))
    .where(and(...conds)).orderBy(desc(taskExtensionRequests.createdAt)).limit(100);
}
