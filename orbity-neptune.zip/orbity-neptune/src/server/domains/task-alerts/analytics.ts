/**
 * Métricas da Central de Alertas e inteligência de execução (alimenta o Business Brain / Flávio).
 *
 * Regras de honestidade:
 *  - fatos, inferências e recomendações ficam separados;
 *  - correlação ≠ causalidade: nunca afirmamos que um alerta "causou" uma conclusão mais rápida;
 *  - sem rankings nem notas de pessoas; carga de trabalho é mostrada como sinal de planejamento, não de desempenho;
 *  - quantidade de alertas, rapidez de resposta ou tarefas concluídas NÃO são usados como medida isolada de produtividade.
 */
import { and, desc, eq, gte, inArray, sql } from "drizzle-orm";
import { taskAlertResponses, taskAlerts, taskExtensionRequests, tasks, teamMembers, teams, users } from "../../db/schema";
import { requirePerm, type TenantContext } from "../../tenancy/context";

const HOUR = 3_600_000;

/** Contadores da Central de Alertas (todos reais, calculados no banco). */
export async function alertCenterMetrics(ctx: TenantContext) {
  requirePerm(ctx, "alerts:send");
  const org = eq(taskAlerts.organizationId, ctx.organizationId);
  const [a] = await ctx.db.select({
    total: sql<number>`count(*) filter (where ${taskAlerts.sentAt} is not null)::int`,
    pendingRead: sql<number>`count(*) filter (where ${taskAlerts.status} in ('sent','delivered'))::int`,
    scheduled: sql<number>`count(*) filter (where ${taskAlerts.status} = 'scheduled')::int`,
    drafts: sql<number>`count(*) filter (where ${taskAlerts.status} = 'draft')::int`,
    read: sql<number>`count(*) filter (where ${taskAlerts.readAt} is not null)::int`,
    unanswered: sql<number>`count(*) filter (where ${taskAlerts.sentAt} is not null and ${taskAlerts.respondedAt} is null and ${taskAlerts.status} not in ('canceled','failed'))::int`,
    escalated: sql<number>`count(*) filter (where ${taskAlerts.kind} = 'escalation')::int`,
    failed: sql<number>`count(*) filter (where ${taskAlerts.status} = 'failed')::int`,
  }).from(taskAlerts).where(org);
  const now = new Date();
  const [t] = await ctx.db.select({
    overdue: sql<number>`count(*) filter (where ${tasks.dueAt} < ${now.toISOString()}::timestamptz)::int`,
    critical: sql<number>`count(*) filter (where ${tasks.priority} = 'high' and ${tasks.blockedReason} is null and ${tasks.dueAt} < ${new Date(now.getTime() + 48 * HOUR).toISOString()}::timestamptz)::int`,
    unassignedCritical: sql<number>`count(*) filter (where ${tasks.priority} = 'high' and ${tasks.assigneeId} is null)::int`,
    blocked: sql<number>`count(*) filter (where ${tasks.blockedReason} is not null)::int`,
  }).from(tasks).where(and(eq(tasks.organizationId, ctx.organizationId), eq(tasks.status, "open")));
  const [e] = await ctx.db.select({ n: sql<number>`count(*)::int` }).from(taskExtensionRequests).where(and(eq(taskExtensionRequests.organizationId, ctx.organizationId), eq(taskExtensionRequests.status, "pending")));
  return { ...a, overdueTasks: t.overdue, criticalTasks: t.critical, unassignedCritical: t.unassignedCritical, blockedTasks: t.blocked, pendingExtensions: e.n };
}

const median = (xs: number[]) => { if (!xs.length) return null; const s = [...xs].sort((x, y) => x - y); const m = Math.floor(s.length / 2); return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2; };
const avg = (xs: number[]) => (xs.length ? xs.reduce((s, x) => s + x, 0) / xs.length : null);
const round1 = (n: number | null) => (n == null ? null : Math.round(n * 10) / 10);

export type ExecutionIntelligence = Awaited<ReturnType<typeof executionIntelligence>>;

export async function executionIntelligence(ctx: TenantContext, days = 90) {
  requirePerm(ctx, "alerts:send");
  const since = new Date(Date.now() - days * 24 * HOUR);
  const now = Date.now();
  const orgTasks = await ctx.db.select().from(tasks).where(eq(tasks.organizationId, ctx.organizationId));
  const open = orgTasks.filter((t) => t.status === "open");
  const teamRows = await ctx.db.select({ userId: teamMembers.userId, team: teams.name }).from(teamMembers).innerJoin(teams, eq(teams.id, teamMembers.teamId)).where(eq(teams.organizationId, ctx.organizationId));
  const teamOf = (u: string | null) => teamRows.find((r) => r.userId === u)?.team ?? "Sem equipe";
  const names = new Map((await ctx.db.select({ id: users.id, name: users.name }).from(users).where(inArray(users.id, [...new Set(open.map((t) => t.assigneeId).filter(Boolean) as string[])].concat("00000000-0000-0000-0000-000000000000")))).map((u) => [u.id, u.name]));

  // Fatos
  const overdueByTeam: Record<string, number> = {};
  for (const t of open) if (t.dueAt && t.dueAt.getTime() < now) overdueByTeam[teamOf(t.assigneeId)] = (overdueByTeam[teamOf(t.assigneeId)] ?? 0) + 1;
  const alerts = await ctx.db.select().from(taskAlerts).where(and(eq(taskAlerts.organizationId, ctx.organizationId), gte(taskAlerts.createdAt, since)));
  const sent = alerts.filter((a) => a.sentAt);
  const rate = (xs: typeof alerts) => (xs.length ? Math.round((xs.filter((a) => a.respondedAt).length / xs.length) * 100) : null);
  const byKind = (["manual", "automation", "escalation"] as const).map((k) => ({ kind: k, sent: sent.filter((a) => a.kind === k).length, responseRatePct: rate(sent.filter((a) => a.kind === k)) }));
  const byPriority = (["low", "medium", "high", "urgent"] as const).map((p) => ({ priority: p, sent: sent.filter((a) => a.priority === p).length, responseRatePct: rate(sent.filter((a) => a.priority === p)) }));
  const byOrigin = (["manual", "flavio", "flavio_edited"] as const).map((o) => ({ origin: o, sent: sent.filter((a) => a.messageOrigin === o).length, responseRatePct: rate(sent.filter((a) => a.messageOrigin === o)) }));

  const done = orgTasks.filter((t) => t.status === "done" && t.completedAt && t.completedAt >= since);
  const firstSent = new Map<string, number>();
  for (const a of sent) { const cur = firstSent.get(a.taskId); if (cur == null || a.sentAt!.getTime() < cur) firstSent.set(a.taskId, a.sentAt!.getTime()); }
  const afterAlert = done.filter((t) => firstSent.has(t.id) && firstSent.get(t.id)! <= t.completedAt!.getTime()).map((t) => (t.completedAt!.getTime() - firstSent.get(t.id)!) / HOUR);
  const noAlertLife = done.filter((t) => !firstSent.has(t.id)).map((t) => (t.completedAt!.getTime() - t.createdAt.getTime()) / HOUR);

  const resp = await ctx.db.select({ kind: taskAlertResponses.kind, n: sql<number>`count(*)::int` }).from(taskAlertResponses)
    .where(and(eq(taskAlertResponses.organizationId, ctx.organizationId), gte(taskAlertResponses.createdAt, since))).groupBy(taskAlertResponses.kind);
  const ext = await ctx.db.select({ status: taskExtensionRequests.status, n: sql<number>`count(*)::int` }).from(taskExtensionRequests)
    .where(and(eq(taskExtensionRequests.organizationId, ctx.organizationId), gte(taskExtensionRequests.createdAt, since))).groupBy(taskExtensionRequests.status);
  const delayReasons = Object.fromEntries(resp.filter((r) => ["blocker", "delay_justification", "help"].includes(r.kind)).map((r) => [r.kind, r.n]));

  const load = new Map<string, number>();
  for (const t of open) if (t.assigneeId) load.set(t.assigneeId, (load.get(t.assigneeId) ?? 0) + 1);
  const med = median([...load.values()]);
  const heavy = [...load.entries()].filter(([, n]) => med != null && n >= 6 && n >= med * 1.5).sort((a, b) => b[1] - a[1]).slice(0, 5)
    .map(([id, n]) => ({ name: names.get(id) ?? "Responsável", openTasks: n, teamMedian: med, team: teamOf(id) }));
  const unassignedCritical = open.filter((t) => t.priority === "high" && !t.assigneeId).length;
  const blocked = open.filter((t) => t.blockedReason);
  const stale = open.filter((t) => now - t.updatedAt.getTime() > 7 * 24 * HOUR).length;

  const facts = {
    openTasks: open.length, overdueTasks: open.filter((t) => t.dueAt && t.dueAt.getTime() < now).length, overdueByTeam, blockedTasks: blocked.length, tasksWithoutUpdate7d: stale,
    unassignedCriticalTasks: unassignedCritical, alertsSent: sent.length, alertsByKind: byKind, alertsByPriority: byPriority, alertsByMessageOrigin: byOrigin,
    responsesByKind: Object.fromEntries(resp.map((r) => [r.kind, r.n])), delayReasons, extensionRequestsByStatus: Object.fromEntries(ext.map((r) => [r.status, r.n])),
    hoursFromFirstAlertToCompletion: { n: afterAlert.length, average: round1(avg(afterAlert)), median: round1(median(afterAlert)) },
    lifetimeHoursOfTasksCompletedWithoutAlert: { n: noAlertLife.length, average: round1(avg(noAlertLife)), median: round1(median(noAlertLife)) },
    workloadSignals: heavy,
  };

  const inferences: string[] = [];
  const topTeam = Object.entries(overdueByTeam).sort((a, b) => b[1] - a[1])[0];
  if (topTeam && topTeam[1] >= 3) inferences.push(`A equipe "${topTeam[0]}" concentra ${topTeam[1]} tarefas atrasadas. Pode indicar sobrecarga, prazos subestimados ou dependências, mas os dados não distinguem a causa.`);
  if (heavy.length) inferences.push("Há responsáveis com carga bem acima da mediana de tarefas abertas. É um sinal de planejamento (distribuição), não de desempenho individual.");
  if ((ext.find((e) => e.status === "approved")?.n ?? 0) >= 3) inferences.push("Várias prorrogações foram aprovadas no período; possível subestimação sistemática de prazos (hipótese a verificar com os responsáveis).");
  if (afterAlert.length >= 5 && noAlertLife.length >= 5) inferences.push("Comparação entre tarefas com e sem alerta é apenas descritiva: alertas costumam ser enviados a tarefas já atrasadas ou críticas, então a diferença não prova efeito do alerta (correlação, não causalidade).");
  if (!sent.length) inferences.push("Ainda não há alertas enviados no período; não é possível analisar resultados dos alertas.");

  const recommendations: string[] = [];
  if (unassignedCritical) recommendations.push(`Atribuir responsável às ${unassignedCritical} tarefa(s) críticas sem dono.`);
  if (blocked.length) recommendations.push(`Revisar os ${blocked.length} bloqueio(s) declarados: destravar impedimentos costuma ser mais eficaz do que novos lembretes.`);
  if (heavy.length) recommendations.push("Avaliar redistribuição de tarefas entre a equipe antes de cobrar prazos de quem está sobrecarregado.");
  if (stale) recommendations.push(`${stale} tarefa(s) sem atualização há mais de 7 dias: considerar uma regra "tarefa sem atualização" para avisar gestores.`);

  return {
    period: { days, since: since.toISOString() },
    facts, inferences, recommendations,
    estimates: [] as string[],
    caveats: [
      "Quantidade de alertas, rapidez de resposta e tarefas concluídas não medem produtividade isoladamente.",
      "Atrasos ou falta de resposta não são avaliação negativa do colaborador: podem refletir sobrecarga, falta de recursos ou dependências externas.",
      "Correlação entre alerta e conclusão não prova causalidade.",
    ],
  };
}

/** Linha do tempo agregada por tarefa para o Business Brain: tarefas críticas e quem está sem responsável. */
export async function criticalTasks(ctx: TenantContext, limit = 20) {
  requirePerm(ctx, "alerts:send");
  return ctx.db.select({ id: tasks.id, title: tasks.title, dueAt: tasks.dueAt, assignee: users.name, blocked: tasks.blockedReason })
    .from(tasks).leftJoin(users, eq(users.id, tasks.assigneeId))
    .where(and(eq(tasks.organizationId, ctx.organizationId), eq(tasks.status, "open"), eq(tasks.priority, "high"))).orderBy(desc(tasks.dueAt)).limit(limit);
}
