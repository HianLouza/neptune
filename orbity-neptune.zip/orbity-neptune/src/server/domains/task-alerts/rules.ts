/** Regras de automação/escalonamento e configuração do tom de comunicação (somente `alerts:manage`). */
import { and, desc, eq } from "drizzle-orm";
import { z } from "zod";
import { organizations, taskAlertRules } from "../../db/schema";
import { requirePerm, type TenantContext } from "../../tenancy/context";
import { audit } from "../../audit";
import { HttpError } from "../../http";
import { CHANNELS, PRIORITIES, TONES, channelAvailability, getToneSettings, isActiveMember, type AlertChannel } from "./shared";

export const TRIGGERS = ["before_due", "on_due", "overdue", "stale", "priority_pending", "goal_at_risk"] as const;
export const TRIGGER_LABEL: Record<(typeof TRIGGERS)[number], string> = {
  before_due: "Antes do vencimento", on_due: "No vencimento", overdue: "Tarefa atrasada", stale: "Tarefa sem atualização (avisa gestores)",
  priority_pending: "Tarefa prioritária pendente", goal_at_risk: "Meta em risco (avisa gestores)",
};

const escalation = z.object({
  enabled: z.boolean().default(false),
  maxAttempts: z.coerce.number().int().min(1).max(5).default(2),
  steps: z.array(z.object({ afterMinutes: z.coerce.number().int().min(15).max(60 * 24 * 14), userIds: z.array(z.string().uuid()).min(1).max(10) })).max(5).default([]),
}).default({ enabled: false, maxAttempts: 2, steps: [] });

export const ruleInput = z.object({
  name: z.string().trim().min(2).max(100),
  trigger: z.enum(TRIGGERS),
  offsetMinutes: z.coerce.number().int().min(0).max(60 * 24 * 30).default(1440),
  staleAfterHours: z.coerce.number().int().min(1).max(24 * 60).default(48),
  repeatEveryMinutes: z.coerce.number().int().min(60).max(60 * 24 * 14).nullish(),
  maxReminders: z.coerce.number().int().min(1).max(10).default(3),
  allowedStartHour: z.coerce.number().int().min(0).max(23).default(8),
  allowedEndHour: z.coerce.number().int().min(1).max(24).default(18),
  priorities: z.array(z.enum(["low", "medium", "high"])).min(1).default(["low", "medium", "high"]),
  alertPriority: z.enum(PRIORITIES).default("medium"),
  channels: z.array(z.enum(CHANNELS)).min(1).default(["in_app"]),
  tone: z.enum(TONES).nullish(),
  escalation,
  active: z.boolean().default(true),
});

async function validate(ctx: TenantContext, v: z.output<typeof ruleInput>) {
  const avail = await channelAvailability(ctx.db, ctx.organizationId);
  const bad = v.channels.filter((c) => !avail[c as AlertChannel].available);
  if (bad.length) throw new HttpError(409, `Canal indisponível nesta organização: ${bad.join(", ")}. ${avail[bad[0] as AlertChannel].reason ?? ""}`);
  for (const s of v.escalation.steps) for (const u of s.userIds) if (!(await isActiveMember(ctx.db, ctx.organizationId, u))) throw new HttpError(400, "Um dos responsáveis pelo escalonamento não é membro ativo da organização.");
  if (v.escalation.enabled && v.escalation.steps.length === 0) throw new HttpError(400, "Defina ao menos um degrau de escalonamento ou desative o escalonamento.");
}

export async function listRules(ctx: TenantContext) {
  requirePerm(ctx, "alerts:manage");
  return ctx.db.select().from(taskAlertRules).where(eq(taskAlertRules.organizationId, ctx.organizationId)).orderBy(desc(taskAlertRules.createdAt));
}

export async function createRule(ctx: TenantContext, raw: z.input<typeof ruleInput>) {
  requirePerm(ctx, "alerts:manage");
  const v = ruleInput.parse(raw);
  await validate(ctx, v);
  const [r] = await ctx.db.insert(taskAlertRules).values({ ...v, repeatEveryMinutes: v.repeatEveryMinutes ?? null, tone: v.tone ?? null, organizationId: ctx.organizationId, createdBy: ctx.userId }).returning();
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "task_alert_rule.created", resource: "task_alert_rule", resourceId: r.id, metadata: { trigger: v.trigger, escalation: v.escalation.enabled } });
  return r;
}

export async function updateRule(ctx: TenantContext, id: string, raw: Partial<z.input<typeof ruleInput>>) {
  requirePerm(ctx, "alerts:manage");
  const [cur] = await ctx.db.select().from(taskAlertRules).where(and(eq(taskAlertRules.id, id), eq(taskAlertRules.organizationId, ctx.organizationId)));
  if (!cur) throw new HttpError(404, "Regra não encontrada.");
  const v = ruleInput.parse({ ...cur, ...raw });
  await validate(ctx, v);
  const [r] = await ctx.db.update(taskAlertRules).set({ ...v, repeatEveryMinutes: v.repeatEveryMinutes ?? null, tone: v.tone ?? null, updatedAt: new Date() }).where(eq(taskAlertRules.id, id)).returning();
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "task_alert_rule.updated", resource: "task_alert_rule", resourceId: id, metadata: { active: v.active } });
  return r;
}

export async function deleteRule(ctx: TenantContext, id: string) {
  requirePerm(ctx, "alerts:manage");
  const del = await ctx.db.delete(taskAlertRules).where(and(eq(taskAlertRules.id, id), eq(taskAlertRules.organizationId, ctx.organizationId))).returning({ id: taskAlertRules.id });
  if (!del.length) throw new HttpError(404, "Regra não encontrada.");
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "task_alert_rule.deleted", resource: "task_alert_rule", resourceId: id });
  return { ok: true };
}

export const toneInput = z.object({
  tone: z.enum(TONES),
  customTone: z.string().trim().max(300).optional(),
  byTeam: z.record(z.string().uuid(), z.enum(TONES)).optional(),
  byKind: z.record(z.string(), z.enum(TONES)).optional(),
});

export async function getTone(ctx: TenantContext) {
  requirePerm(ctx, "alerts:send");
  return getToneSettings(ctx.db, ctx.organizationId);
}

export async function setTone(ctx: TenantContext, raw: z.input<typeof toneInput>) {
  requirePerm(ctx, "alerts:manage");
  const v = toneInput.parse(raw);
  if (v.tone === "custom" && !v.customTone) throw new HttpError(400, "Descreva o tom personalizado da organização.");
  const [o] = await ctx.db.select({ s: organizations.settings }).from(organizations).where(eq(organizations.id, ctx.organizationId));
  await ctx.db.update(organizations).set({ settings: { ...(o?.s ?? {}), taskAlerts: v } }).where(eq(organizations.id, ctx.organizationId));
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "task_alert.tone_changed", resource: "organization", resourceId: ctx.organizationId, metadata: { tone: v.tone } });
  return v;
}
