/**
 * ORBITY STRATEGY SIMULATOR (Master Prompt 4.0 §11)
 *
 * Simula decisões empresariais sobre uma LINHA DE BASE construída com dados reais da organização:
 *  - CRM: receita ganha, negócios ganhos, ticket médio, conversão lead → venda e leads por mês (últimos 90 dias ÷ 3).
 *  - Financeiro (se houver lançamentos e permissão): receita recebida, despesas, custos variáveis (grupo "custo").
 * Quando um dado não existe (ex.: despesas sem módulo financeiro), o usuário precisa informar — nada é inventado.
 *
 * O modelo é determinístico e explicável (função pura `simulate`): fatores multiplicativos sobre receita e volume,
 * custos variáveis proporcionais ao volume, custos fixos somados. Cada premissa aparece na evidência.
 * Cenários de redução de equipe são APENAS análise: o sistema nunca decide nem executa demissões.
 */
import { and, desc, eq, gte, inArray, sql } from "drizzle-orm";
import { z } from "zod";
import { financeCategories, financeEntries, scenarios, users } from "../../db/schema";
import { can, requirePerm, type TenantContext } from "../../tenancy/context";
import { audit } from "../../audit";
import { HttpError } from "../../http";
import { dashboardKpis } from "../intelligence";
import { financialSnapshot } from "../finance/snapshot";
import { buildEvidence, confidenceFrom, type Evidence } from "../../intelligence-layer/evidence";

export * from "./model";
import { simulate, variablesSchema, type Baseline } from "./model";

/* ------------------------------------------------------------------ linha de base com dados reais */

export async function buildBaseline(ctx: TenantContext): Promise<{ baseline: Baseline; evidence: Evidence; financeConnected: boolean }> {
  requirePerm(ctx, "strategy:read");
  const k = await dashboardKpis(ctx, 90);
  const c = k.current;
  const leadsPerMonth = c.leads / 3, dealsPerMonth = c.won / 3;
  const crmRevenue = c.revenueCents / 3;
  const missingData: string[] = [];
  const facts: Evidence["facts"] = [
    { label: "Receita ganha no CRM (média mensal)", value: (crmRevenue / 100).toFixed(2), source: "CRM · oportunidades ganhas", period: "últimos 90 dias ÷ 3" },
    { label: "Negócios ganhos por mês", value: dealsPerMonth.toFixed(1), source: "CRM · oportunidades ganhas", period: "últimos 90 dias ÷ 3" },
    { label: "Leads por mês", value: leadsPerMonth.toFixed(1), source: "Prospect.AI / CRM · leads criados", period: "últimos 90 dias ÷ 3" },
  ];

  let revenueCents = crmRevenue, revenueSource: Baseline["revenueSource"] = "crm";
  let variableCostsCents: number | null = null, fixedCostsCents: number | null = null, financeConnected = false;
  if (can(ctx, "finance:read")) {
    const snap = await financialSnapshot(ctx, 90);
    if (snap.hasData && snap.entriesInPeriod > 0) {
      financeConnected = true;
      revenueCents = snap.revenueCents / 3; revenueSource = "finance";
      const since = new Date(Date.now() - 90 * 864e5);
      const [vc] = await ctx.db.select({ v: sql<number>`coalesce(sum(${financeEntries.amountCents}),0)::bigint` }).from(financeEntries)
        .innerJoin(financeCategories, eq(financeCategories.id, financeEntries.categoryId))
        .where(and(eq(financeEntries.organizationId, ctx.organizationId), eq(financeEntries.kind, "payable"), eq(financeEntries.status, "paid"),
          eq(financeCategories.group, "custo"), gte(financeEntries.paidAt, since)));
      variableCostsCents = Number(vc.v) / 3;
      fixedCostsCents = Math.max(0, snap.expensesCents / 3 - variableCostsCents);
      facts.push(
        { label: "Receita recebida (média mensal)", value: (revenueCents / 100).toFixed(2), source: "Financeiro · contas a receber pagas", period: "últimos 90 dias ÷ 3" },
        { label: "Custos variáveis (média mensal)", value: (variableCostsCents / 100).toFixed(2), source: "Financeiro · contas pagas do grupo \"custo\"", period: "últimos 90 dias ÷ 3" },
        { label: "Custos fixos (média mensal)", value: (fixedCostsCents / 100).toFixed(2), source: "Financeiro · demais contas pagas", period: "últimos 90 dias ÷ 3" },
      );
    } else missingData.push("Lançamentos financeiros dos últimos 90 dias (despesas e custos): informe-os na simulação.");
  } else missingData.push("Sem permissão de leitura financeira: informe custos fixos e variáveis manualmente.");

  const baseline: Baseline = {
    revenueCents: Math.round(revenueCents), revenueSource,
    leadsPerMonth: Math.round(leadsPerMonth * 10) / 10, dealsPerMonth: Math.round(dealsPerMonth * 10) / 10,
    conversionRate: c.leads ? c.won / c.leads : 0, avgTicketCents: c.won ? Math.round(c.revenueCents / c.won) : 0,
    variableCostsCents: variableCostsCents == null ? null : Math.round(variableCostsCents),
    fixedCostsCents: fixedCostsCents == null ? null : Math.round(fixedCostsCents),
    sampleWon90d: c.won,
  };
  if (c.won < 30) missingData.push(`Amostra pequena: ${c.won} negócios ganhos em 90 dias.`);
  const evidence = buildEvidence({
    facts,
    assumptions: ["Médias mensais dos últimos 90 dias representam um mês típico."],
    calculations: ["Valor mensal = total dos últimos 90 dias ÷ 3", "Conversão = negócios ganhos ÷ leads criados", "Ticket médio = receita ganha ÷ negócios ganhos"],
    confidence: confidenceFrom(c.won, missingData.length),
    missingData,
    limitations: ["Modelo linear e determinístico: não captura reação de concorrentes nem efeitos defasados.", "Não substitui análise contábil ou fiscal."],
  });
  return { baseline, evidence, financeConnected };
}

/* ------------------------------------------------------------------ cenários salvos */

const KINDS = ["price", "cost", "hiring", "volume", "conversion", "marketing", "churn", "reorganization", "custom"] as const;
const saveInput = z.object({
  name: z.string().trim().min(3).max(120),
  kind: z.enum(KINDS).default("custom"),
  variables: variablesSchema,
});

export async function runSimulation(ctx: TenantContext, rawVars: unknown) {
  requirePerm(ctx, "strategy:read");
  const { baseline, evidence, financeConnected } = await buildBaseline(ctx);
  const variables = variablesSchema.parse(rawVars ?? {});
  return { baseline, evidence, financeConnected, variables, result: simulate(baseline, variables) };
}

export async function saveScenario(ctx: TenantContext, raw: unknown) {
  requirePerm(ctx, "strategy:write");
  const input = saveInput.parse(raw);
  const { baseline, evidence } = await buildBaseline(ctx);
  const result = simulate(baseline, input.variables);
  const baseNums = Object.fromEntries(Object.entries(baseline).filter(([, v]) => typeof v === "number")) as Record<string, number>;
  const varNums = Object.fromEntries(Object.entries(input.variables).flatMap(([k, v]) =>
    typeof v === "number" ? [[k, v]] : Array.isArray(v) ? v.map((x, i) => [`${k}_${i + 1}`, x]) : [])) as Record<string, number>;
  const ev = buildEvidence({ ...evidence, assumptions: [...evidence.assumptions, ...result.assumptions] });
  const [row] = await ctx.db.insert(scenarios).values({
    organizationId: ctx.organizationId, name: input.name, kind: input.kind, baseline: baseNums, variables: varNums,
    results: { ...result, revenueSource: baseline.revenueSource }, evidence: ev, createdBy: ctx.userId,
  }).returning();
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "strategy.scenario_saved", resource: "scenario", resourceId: row.id, metadata: { name: input.name, kind: input.kind }, ip: ctx.ip });
  return row;
}

export async function listScenarios(ctx: TenantContext) {
  requirePerm(ctx, "strategy:read");
  const rows = await ctx.db.select().from(scenarios).where(eq(scenarios.organizationId, ctx.organizationId)).orderBy(desc(scenarios.createdAt)).limit(50);
  const ids = [...new Set(rows.flatMap((r) => [r.createdBy, r.approvedBy].filter((x): x is string => !!x)))];
  const people = ids.length ? await ctx.db.select({ id: users.id, name: users.name }).from(users).where(inArray(users.id, ids)) : [];
  const names = new Map(people.map((p) => [p.id, p.name]));
  return rows.map((r) => ({ ...r, createdByName: names.get(r.createdBy) ?? "—", approvedByName: r.approvedBy ? names.get(r.approvedBy) ?? "—" : null }));
}

const transition = z.object({ action: z.enum(["submit", "approve", "reject"]) });

export async function updateScenarioStatus(ctx: TenantContext, id: string, raw: unknown) {
  const { action } = transition.parse(raw);
  const [s] = await ctx.db.select().from(scenarios).where(and(eq(scenarios.id, id), eq(scenarios.organizationId, ctx.organizationId)));
  if (!s) throw new HttpError(404, "Cenário não encontrado.");
  let patch: Partial<typeof scenarios.$inferInsert>;
  if (action === "submit") {
    requirePerm(ctx, "strategy:write");
    if (s.status !== "draft" && s.status !== "rejected") throw new HttpError(409, "Só rascunhos ou cenários rejeitados podem ser enviados para aprovação.");
    patch = { status: "submitted", approvedBy: null, approvedAt: null };
  } else {
    requirePerm(ctx, "approvals:decide");
    if (s.status !== "submitted") throw new HttpError(409, "Este cenário não está aguardando aprovação.");
    if (s.createdBy === ctx.userId) throw new HttpError(403, "Quem criou o cenário não pode aprová-lo (segregação de funções).");
    patch = { status: action === "approve" ? "approved" : "rejected", approvedBy: ctx.userId, approvedAt: new Date() };
  }
  const [u] = await ctx.db.update(scenarios).set(patch).where(eq(scenarios.id, id)).returning();
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: `strategy.scenario_${action}`, resource: "scenario", resourceId: id, metadata: { from: s.status, to: u.status }, ip: ctx.ip });
  return u;
}
