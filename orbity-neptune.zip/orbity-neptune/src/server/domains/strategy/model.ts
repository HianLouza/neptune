/**
 * Modelo PURO do Strategy Simulator (sem acesso a banco): pode rodar no servidor e no navegador.
 * Determinístico e explicável — cada premissa é devolvida em `assumptions`.
 */
import { z } from "zod";

/* ------------------------------------------------------------------ tipos */

export type Baseline = {
  revenueCents: number;
  revenueSource: "finance" | "crm";
  leadsPerMonth: number;
  dealsPerMonth: number;
  conversionRate: number; // negócios ganhos ÷ leads (fração)
  avgTicketCents: number;
  variableCostsCents: number | null;
  fixedCostsCents: number | null;
  sampleWon90d: number;
};

export const variablesSchema = z.object({
  priceChangePct: z.coerce.number().min(-90).max(500).default(0),
  elasticity: z.coerce.number().min(-5).max(0).default(-0.5),
  volumeChangePct: z.coerce.number().min(-100).max(1000).default(0),
  conversionChangePct: z.coerce.number().min(-100).max(1000).default(0),
  variableCostChangePct: z.coerce.number().min(-100).max(1000).default(0),
  fixedCostChangePct: z.coerce.number().min(-100).max(1000).default(0),
  newHires: z.coerce.number().int().min(-1000).max(1000).default(0),
  monthlyCostPerHireCents: z.coerce.number().int().min(0).max(1e10).nullable().default(null),
  marketingSpendCents: z.coerce.number().int().min(0).max(1e12).default(0),
  leadsPerThousand: z.coerce.number().min(0).max(100000).nullable().default(null),
  churnChangePct: z.coerce.number().min(-100).max(100).default(0),
  uncertaintyPct: z.coerce.number().min(0).max(80).default(10),
  seasonality: z.array(z.coerce.number().min(0).max(5)).length(12).nullable().default(null),
  initialCashCents: z.coerce.number().int().min(-1e13).max(1e13).nullable().default(null),
  // Substituições informadas pelo usuário quando a base não tem o dado (ou para testar outra hipótese).
  revenueCentsOverride: z.coerce.number().int().min(0).max(1e13).nullable().default(null),
  variableCostsCentsOverride: z.coerce.number().int().min(0).max(1e13).nullable().default(null),
  fixedCostsCentsOverride: z.coerce.number().int().min(0).max(1e13).nullable().default(null),
});
export type Variables = z.output<typeof variablesSchema>;

export class MissingInputError extends Error {
  status = 422;
  constructor(public fields: string[], message: string) { super(message); }
}

export type MonthSummary = {
  revenueCents: number; variableCostsCents: number; fixedCostsCents: number; resultCents: number;
  marginPct: number | null; contributionMarginPct: number | null; breakEvenRevenueCents: number | null; volumeFactor: number;
};

export type SimulationResult = {
  current: MonthSummary;
  scenarios: { pessimista: MonthSummary; base: MonthSummary; otimista: MonthSummary };
  delta: { revenueCents: number; resultCents: number; marginPp: number | null };
  projection: { month: number; revenueCents: number; resultCents: number; cumulativeCashCents: number }[];
  sensitivity: { variable: string; label: string; change: string; resultDeltaCents: number }[];
  contributions: { variable: string; label: string; resultDeltaCents: number }[];
  assumptions: string[];
  notes: string[];
};

/* ------------------------------------------------------------------ modelo puro */

const round = (v: number) => Math.round(v);
const pp = (v: number) => Math.round(v * 10) / 10;

function resolveInputs(b: Baseline, v: Variables) {
  const missing: string[] = [];
  const R0 = v.revenueCentsOverride ?? b.revenueCents;
  const V0 = v.variableCostsCentsOverride ?? b.variableCostsCents;
  const F0 = v.fixedCostsCentsOverride ?? b.fixedCostsCents;
  if (V0 == null) missing.push("variableCostsCentsOverride");
  if (F0 == null) missing.push("fixedCostsCentsOverride");
  if (v.newHires !== 0 && v.monthlyCostPerHireCents == null) missing.push("monthlyCostPerHireCents");
  if (v.marketingSpendCents > 0 && v.leadsPerThousand == null) missing.push("leadsPerThousand");
  if (missing.length) {
    const labels: Record<string, string> = {
      variableCostsCentsOverride: "custos variáveis mensais", fixedCostsCentsOverride: "custos fixos mensais",
      monthlyCostPerHireCents: "custo mensal por contratação", leadsPerThousand: "leads gerados a cada R$ 1.000 de marketing",
    };
    throw new MissingInputError(missing, `Informe: ${missing.map((m) => labels[m]).join(", ")}. Sem esses dados a simulação não é feita (nada é estimado por conta própria).`);
  }
  return { R0, V0: V0!, F0: F0! };
}

function volumeFactorOf(b: Baseline, v: Variables) {
  const ve = Math.max(0, 1 + (v.elasticity * v.priceChangePct) / 100);
  const vv = Math.max(0, 1 + v.volumeChangePct / 100);
  const vc = Math.max(0, 1 + v.conversionChangePct / 100);
  const extraLeads = v.marketingSpendCents > 0 && v.leadsPerThousand != null ? (v.marketingSpendCents / 100 / 1000) * v.leadsPerThousand : 0;
  const vm = b.leadsPerMonth > 0 ? 1 + extraLeads / b.leadsPerMonth : 1;
  const vch = Math.max(0, 1 - v.churnChangePct / 100);
  return { factor: ve * vv * vc * vm * vch, extraLeads };
}

function summarize(R0: number, V0: number, F0: number, v: Variables, volumeFactor: number, season = 1): MonthSummary {
  const pf = 1 + v.priceChangePct / 100;
  const revenue = R0 * pf * volumeFactor * season;
  const variable = V0 * volumeFactor * season * (1 + v.variableCostChangePct / 100);
  const fixed = F0 * (1 + v.fixedCostChangePct / 100) + v.newHires * (v.monthlyCostPerHireCents ?? 0) + v.marketingSpendCents;
  const result = revenue - variable - fixed;
  const cmRatio = revenue > 0 ? (revenue - variable) / revenue : null;
  return {
    revenueCents: round(revenue), variableCostsCents: round(variable), fixedCostsCents: round(fixed), resultCents: round(result),
    marginPct: revenue > 0 ? pp((result / revenue) * 100) : null,
    contributionMarginPct: cmRatio == null ? null : pp(cmRatio * 100),
    breakEvenRevenueCents: cmRatio && cmRatio > 0 ? round(fixed / cmRatio) : null,
    volumeFactor: Math.round(volumeFactor * 10000) / 10000,
  };
}

const NEUTRAL: Variables = variablesSchema.parse({});

/** Função pura e determinística: mesma base + mesmas variáveis = mesmo resultado. */
export function simulate(b: Baseline, raw: Partial<Variables>): SimulationResult {
  const v = variablesSchema.parse(raw);
  const { R0, V0, F0 } = resolveInputs(b, v);
  const neutral = { ...NEUTRAL, elasticity: v.elasticity };
  const current = summarize(R0, V0, F0, neutral, 1);
  const { factor, extraLeads } = volumeFactorOf(b, v);
  const u = v.uncertaintyPct / 100;
  const base = summarize(R0, V0, F0, v, factor);
  const scenariosOut = { pessimista: summarize(R0, V0, F0, v, factor * (1 - u)), base, otimista: summarize(R0, V0, F0, v, factor * (1 + u)) };

  let cash = v.initialCashCents ?? 0;
  const projection = Array.from({ length: 12 }, (_, i) => {
    const s = summarize(R0, V0, F0, v, factor, v.seasonality?.[i] ?? 1);
    cash += s.resultCents;
    return { month: i + 1, revenueCents: s.revenueCents, resultCents: s.resultCents, cumulativeCashCents: round(cash) };
  });

  const resultWith = (patch: Partial<Variables>) => {
    const vv = { ...neutral, ...patch } as Variables;
    return summarize(R0, V0, F0, vv, volumeFactorOf(b, vv).factor).resultCents;
  };
  const sensitivity = [
    { variable: "priceChangePct", label: "Preço", change: "+10%", resultDeltaCents: resultWith({ priceChangePct: 10 }) - current.resultCents },
    { variable: "volumeChangePct", label: "Volume de vendas", change: "+10%", resultDeltaCents: resultWith({ volumeChangePct: 10 }) - current.resultCents },
    { variable: "conversionChangePct", label: "Conversão", change: "+10%", resultDeltaCents: resultWith({ conversionChangePct: 10 }) - current.resultCents },
    { variable: "variableCostChangePct", label: "Custos variáveis", change: "-10%", resultDeltaCents: resultWith({ variableCostChangePct: -10 }) - current.resultCents },
    { variable: "fixedCostChangePct", label: "Custos fixos", change: "-10%", resultDeltaCents: resultWith({ fixedCostChangePct: -10 }) - current.resultCents },
  ].sort((a, b2) => Math.abs(b2.resultDeltaCents) - Math.abs(a.resultDeltaCents));

  const LABELS: Record<string, string> = {
    priceChangePct: "Preço", volumeChangePct: "Volume", conversionChangePct: "Conversão", variableCostChangePct: "Custos variáveis",
    fixedCostChangePct: "Custos fixos", newHires: "Contratações", marketingSpendCents: "Investimento em marketing", churnChangePct: "Perda de clientes",
  };
  const contributions = Object.keys(LABELS).filter((k) => (v as Record<string, unknown>)[k] !== 0).map((k) => {
    const patch: Partial<Variables> = { [k]: (v as Record<string, unknown>)[k] } as Partial<Variables>;
    if (k === "newHires") patch.monthlyCostPerHireCents = v.monthlyCostPerHireCents;
    if (k === "marketingSpendCents") patch.leadsPerThousand = v.leadsPerThousand;
    return { variable: k, label: LABELS[k], resultDeltaCents: resultWith(patch) - current.resultCents };
  });

  const assumptions = [
    `Elasticidade-preço da demanda de ${v.elasticity} (premissa editável): cada 1% de aumento de preço reduz o volume em ${Math.abs(v.elasticity)}%.`,
    "Custos variáveis acompanham o volume vendido; custos fixos não variam com o volume.",
    `Faixa de incerteza de ±${v.uncertaintyPct}% sobre o volume para os cenários otimista e pessimista (premissa editável).`,
    "Efeitos são combinados de forma multiplicativa e aplicados de imediato, sem tempo de adaptação do mercado.",
    v.churnChangePct ? "Variação de perda de clientes aplicada como perda proporcional de receita e volume." : "",
    v.marketingSpendCents > 0 ? `Marketing: ${v.leadsPerThousand} leads a cada R$ 1.000 (informado), convertidos na taxa atual (${round(extraLeads)} leads extras/mês).` : "",
    v.seasonality ? "Sazonalidade mensal informada aplicada à projeção de 12 meses." : "Sem sazonalidade: os 12 meses usam o mesmo mês típico.",
    v.initialCashCents == null ? "Sem saldo inicial de caixa informado: a projeção mostra a variação acumulada de caixa a partir de zero." : "",
  ].filter(Boolean);

  const notes: string[] = [];
  if (v.newHires < 0) notes.push("Cenário de redução de equipe é apenas análise financeira. O ORBITY-NEPTUNE nunca decide nem executa demissões ou reorganizações.");
  if (v.marketingSpendCents > 0 && b.leadsPerMonth === 0) notes.push("Sem histórico de leads: o efeito do marketing sobre o volume não pôde ser calculado.");

  return {
    current, scenarios: scenariosOut,
    delta: {
      revenueCents: base.revenueCents - current.revenueCents, resultCents: base.resultCents - current.resultCents,
      marginPp: base.marginPct != null && current.marginPct != null ? pp(base.marginPct - current.marginPct) : null,
    },
    projection, sensitivity, contributions, assumptions, notes,
  };
}

