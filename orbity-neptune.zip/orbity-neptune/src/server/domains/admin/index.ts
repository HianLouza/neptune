/** ADMINISTRAÇÃO DA EMPRESA — usuários, cargos, equipes, configurações. Sempre restrito ao tenant do contexto. */
import { and, asc, desc, eq, gt, isNull } from "drizzle-orm";
import { z } from "zod";
import { memberships, organizations, roles, sessions, teamMembers, teams, users } from "../../db/schema";
import { requirePerm, type TenantContext } from "../../tenancy/context";
import { PERMISSIONS } from "../../permissions";
import { audit } from "../../audit";
import { HttpError } from "../../http";

export async function listMembers(ctx: TenantContext) {
  requirePerm(ctx, "admin:users");
  return ctx.db.select({ membershipId: memberships.id, status: memberships.status, userId: users.id, name: users.name, email: users.email, lastLoginAt: users.lastLoginAt, totpEnabled: users.totpEnabled, roleId: roles.id, roleName: roles.name, roleKey: roles.key })
    .from(memberships).innerJoin(users, eq(users.id, memberships.userId)).innerJoin(roles, eq(roles.id, memberships.roleId))
    .where(eq(memberships.organizationId, ctx.organizationId)).orderBy(asc(memberships.status), asc(users.name));
}

export async function updateMembership(ctx: TenantContext, membershipId: string, patch: { status?: "active" | "disabled"; roleId?: string }) {
  requirePerm(ctx, "admin:users");
  const [m] = await ctx.db.select().from(memberships).where(and(eq(memberships.id, membershipId), eq(memberships.organizationId, ctx.organizationId)));
  if (!m) throw new HttpError(404, "Membro não encontrado.");
  if (m.userId === ctx.userId && (patch.status === "disabled" || patch.roleId)) throw new HttpError(409, "Você não pode alterar o próprio acesso.");
  if (patch.roleId) {
    const [r] = await ctx.db.select().from(roles).where(and(eq(roles.id, patch.roleId), eq(roles.organizationId, ctx.organizationId)));
    if (!r) throw new HttpError(400, "Cargo inválido.");
  }
  const [u] = await ctx.db.update(memberships).set(patch).where(eq(memberships.id, m.id)).returning();
  if (patch.status === "disabled") await ctx.db.update(sessions).set({ revokedAt: new Date() }).where(and(eq(sessions.userId, m.userId), eq(sessions.organizationId, ctx.organizationId)));
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: m.status === "pending" && patch.status === "active" ? "membership.approved" : "membership.updated", resource: "membership", resourceId: m.id, metadata: patch });
  return u;
}

export async function listTeams(ctx: TenantContext) {
  requirePerm(ctx, "admin:users");
  const ts = await ctx.db.select().from(teams).where(eq(teams.organizationId, ctx.organizationId)).orderBy(asc(teams.name));
  const out = [];
  for (const t of ts) {
    const ms = await ctx.db.select({ userId: users.id, name: users.name }).from(teamMembers).innerJoin(users, eq(users.id, teamMembers.userId)).where(eq(teamMembers.teamId, t.id));
    out.push({ ...t, members: ms });
  }
  return out;
}

export async function createTeam(ctx: TenantContext, name: string) {
  requirePerm(ctx, "admin:users");
  const n = z.string().trim().min(2).max(80).parse(name);
  const [t] = await ctx.db.insert(teams).values({ organizationId: ctx.organizationId, name: n }).returning();
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "team.created", resource: "team", resourceId: t.id });
  return t;
}

export async function setTeamMember(ctx: TenantContext, teamId: string, userId: string, add: boolean) {
  requirePerm(ctx, "admin:users");
  const [t] = await ctx.db.select().from(teams).where(and(eq(teams.id, teamId), eq(teams.organizationId, ctx.organizationId)));
  if (!t) throw new HttpError(404, "Equipe não encontrada.");
  const [m] = await ctx.db.select().from(memberships).where(and(eq(memberships.userId, userId), eq(memberships.organizationId, ctx.organizationId)));
  if (!m) throw new HttpError(400, "Usuário não pertence à organização.");
  if (add) await ctx.db.insert(teamMembers).values({ teamId, userId }).onConflictDoNothing();
  else await ctx.db.delete(teamMembers).where(and(eq(teamMembers.teamId, teamId), eq(teamMembers.userId, userId)));
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: add ? "team.member_added" : "team.member_removed", resource: "team", resourceId: teamId, metadata: { userId } });
  return { ok: true };
}

export async function listRoles(ctx: TenantContext) {
  requirePerm(ctx, "admin:users");
  return ctx.db.select().from(roles).where(eq(roles.organizationId, ctx.organizationId)).orderBy(desc(roles.isSystem), asc(roles.name));
}

const permEnum = z.enum(PERMISSIONS);
export async function saveRole(ctx: TenantContext, raw: { roleId?: string; name: string; permissions: string[] }) {
  requirePerm(ctx, "admin:settings");
  const input = z.object({ roleId: z.string().uuid().optional(), name: z.string().trim().min(2).max(60), permissions: z.array(permEnum).max(PERMISSIONS.length) }).parse(raw);
  if (input.roleId) {
    const [r] = await ctx.db.select().from(roles).where(and(eq(roles.id, input.roleId), eq(roles.organizationId, ctx.organizationId)));
    if (!r) throw new HttpError(404, "Cargo não encontrado.");
    if (r.isSystem) throw new HttpError(409, "Cargos do sistema não podem ser editados.");
    const [u] = await ctx.db.update(roles).set({ name: input.name, permissions: input.permissions }).where(eq(roles.id, r.id)).returning();
    await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "role.updated", resource: "role", resourceId: r.id, metadata: { permissions: input.permissions } });
    return u;
  }
  const key = `custom-${input.name.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").slice(0, 30)}-${Date.now().toString(36)}`;
  const [r] = await ctx.db.insert(roles).values({ organizationId: ctx.organizationId, key, name: input.name, permissions: input.permissions, isSystem: false }).returning();
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "role.created", resource: "role", resourceId: r.id, metadata: { permissions: input.permissions } });
  return r;
}

export const orgSettingsInput = z.object({
  name: z.string().trim().min(2).max(120),
  locale: z.enum(["pt-BR", "en", "es"]),
  currency: z.enum(["BRL", "USD", "EUR"]),
  timezone: z.string().trim().min(3).max(60).refine((tz) => { try { new Intl.DateTimeFormat("en", { timeZone: tz }); return true; } catch { return false; } }, "Fuso horário inválido"),
});
export async function updateOrgSettings(ctx: TenantContext, raw: z.input<typeof orgSettingsInput>) {
  requirePerm(ctx, "admin:settings");
  const input = orgSettingsInput.parse(raw);
  const [o] = await ctx.db.update(organizations).set({ ...input, updatedAt: new Date() }).where(eq(organizations.id, ctx.organizationId)).returning();
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "organization.settings_updated", resource: "organization", resourceId: o.id, metadata: input });
  return o;
}

/* ---------------- Perfil do usuário ---------------- */

export const profileInput = z.object({
  name: z.string().trim().min(2).max(120),
  jobTitle: z.string().trim().max(120).optional().nullable(),
  locale: z.enum(["pt-BR", "en", "es"]),
  timezone: z.string().trim().max(60).optional().nullable(),
});
export async function updateProfile(ctx: TenantContext, raw: z.input<typeof profileInput>) {
  const input = profileInput.parse(raw);
  if (input.timezone) { try { new Intl.DateTimeFormat("en", { timeZone: input.timezone }); } catch { throw new HttpError(400, "Fuso horário inválido."); } }
  const [u] = await ctx.db.update(users).set({ name: input.name, jobTitle: input.jobTitle || null, locale: input.locale, timezone: input.timezone || null, updatedAt: new Date() }).where(eq(users.id, ctx.userId)).returning();
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "user.profile_updated", resource: "user", resourceId: ctx.userId });
  return { id: u.id, name: u.name };
}

export async function listMySessions(ctx: TenantContext) {
  return ctx.db.select({ id: sessions.id, ip: sessions.ip, userAgent: sessions.userAgent, createdAt: sessions.createdAt, expiresAt: sessions.expiresAt })
    .from(sessions).where(and(eq(sessions.userId, ctx.userId), isNull(sessions.revokedAt), gt(sessions.expiresAt, new Date()))).orderBy(desc(sessions.createdAt)).limit(50);
}

export async function revokeMySession(ctx: TenantContext, sessionId: string) {
  const [s] = await ctx.db.update(sessions).set({ revokedAt: new Date() }).where(and(eq(sessions.id, sessionId), eq(sessions.userId, ctx.userId))).returning();
  if (!s) throw new HttpError(404, "Sessão não encontrada.");
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "session.revoked", resource: "session", resourceId: s.id });
  return { ok: true };
}
