/** Consultas de leitura do CRM (listas, kanban filtrado). Sempre filtradas pelo tenant do contexto. */
import { and, asc, count, desc, eq, ilike, lt, or, sql } from "drizzle-orm";
import { companies, contacts, opportunities, pipelineStages, users } from "../../db/schema";
import { requirePerm, type TenantContext } from "../../tenancy/context";
import { getDefaultPipeline } from "./index";

export const STALE_DAYS = 5;

export async function kanban(ctx: TenantContext, opts: { stageId?: string; stale?: boolean; q?: string; perStage?: number } = {}) {
  requirePerm(ctx, "crm:read");
  const { pipeline, stages } = await getDefaultPipeline(ctx);
  const base = [eq(opportunities.organizationId, ctx.organizationId), eq(opportunities.pipelineId, pipeline.id)];
  if (opts.stale) base.push(eq(opportunities.status, "open"), lt(opportunities.lastActivityAt, new Date(Date.now() - STALE_DAYS * 864e5)));
  if (opts.q) base.push(or(ilike(opportunities.title, `%${opts.q}%`), ilike(companies.name, `%${opts.q}%`))!);
  const visible = stages.filter((s) => s.kind === "open" || opts.stageId === s.id).filter((s) => !opts.stageId || s.id === opts.stageId);
  const columns = [];
  for (const s of visible) {
    const where = and(...base, eq(opportunities.stageId, s.id));
    const [c] = await ctx.db.select({ n: count(), total: sql<number>`coalesce(sum(${opportunities.amountCents}),0)::bigint` })
      .from(opportunities).leftJoin(companies, eq(companies.id, opportunities.companyId)).where(where);
    const items = await ctx.db.select({
      id: opportunities.id, title: opportunities.title, amountCents: opportunities.amountCents, companyName: companies.name,
      lastActivityAt: opportunities.lastActivityAt, ownerName: users.name,
    }).from(opportunities).leftJoin(companies, eq(companies.id, opportunities.companyId)).leftJoin(users, eq(users.id, opportunities.ownerId))
      .where(where).orderBy(desc(opportunities.amountCents)).limit(opts.perStage ?? 25);
    columns.push({ stage: s, count: Number(c?.n ?? 0), totalCents: Number(c?.total ?? 0), items: items.map((i) => ({ ...i, amountCents: Number(i.amountCents) })) });
  }
  return { pipeline, stages, columns };
}

export async function listCompanies(ctx: TenantContext, q?: string, limit = 100) {
  requirePerm(ctx, "crm:read");
  const conds = [eq(companies.organizationId, ctx.organizationId)];
  if (q) conds.push(or(ilike(companies.name, `%${q}%`), ilike(companies.domain, `%${q}%`))!);
  return ctx.db.select({
    id: companies.id, name: companies.name, domain: companies.domain, segment: companies.segment, region: companies.region,
    employees: companies.employees, source: companies.source, createdAt: companies.createdAt,
    // Coluna externa qualificada explicitamente: drizzle renderiza `${companies.id}` sem tabela dentro da subconsulta.
    contacts: sql<number>`(select count(*)::int from contacts c where c.company_id = "companies"."id")`,
    openDeals: sql<number>`(select count(*)::int from opportunities o where o.company_id = "companies"."id" and o.status = 'open')`,
  }).from(companies).where(and(...conds)).orderBy(desc(companies.createdAt)).limit(limit);
}

export async function getCompany(ctx: TenantContext, id: string) {
  requirePerm(ctx, "crm:read");
  const [c] = await ctx.db.select().from(companies).where(and(eq(companies.id, id), eq(companies.organizationId, ctx.organizationId)));
  return c ?? null;
}

export async function listContacts(ctx: TenantContext, q?: string, limit = 100) {
  requirePerm(ctx, "crm:read");
  const conds = [eq(contacts.organizationId, ctx.organizationId)];
  if (q) conds.push(or(ilike(contacts.name, `%${q}%`), ilike(contacts.email, `%${q}%`))!);
  return ctx.db.select({
    id: contacts.id, name: contacts.name, email: contacts.email, phone: contacts.phone, jobTitle: contacts.jobTitle,
    consentStatus: contacts.consentStatus, legalBasis: contacts.legalBasis, companyName: companies.name, companyId: contacts.companyId,
  }).from(contacts).leftJoin(companies, eq(companies.id, contacts.companyId)).where(and(...conds)).orderBy(desc(contacts.createdAt)).limit(limit);
}

export async function getContact(ctx: TenantContext, id: string) {
  requirePerm(ctx, "crm:read");
  const [c] = await ctx.db.select({ c: contacts, companyName: companies.name }).from(contacts).leftJoin(companies, eq(companies.id, contacts.companyId))
    .where(and(eq(contacts.id, id), eq(contacts.organizationId, ctx.organizationId)));
  return c ?? null;
}

export async function listStages(ctx: TenantContext) {
  const { stages } = await getDefaultPipeline(ctx);
  return stages;
}

export async function staleCount(ctx: TenantContext) {
  const [r] = await ctx.db.select({ n: count() }).from(opportunities).where(and(
    eq(opportunities.organizationId, ctx.organizationId), eq(opportunities.status, "open"),
    lt(opportunities.lastActivityAt, new Date(Date.now() - STALE_DAYS * 864e5)),
  ));
  return Number(r?.n ?? 0);
}

export async function orgMembers(ctx: TenantContext) {
  const { memberships } = await import("../../db/schema");
  return ctx.db.select({ id: users.id, name: users.name }).from(memberships).innerJoin(users, eq(users.id, memberships.userId))
    .where(and(eq(memberships.organizationId, ctx.organizationId), eq(memberships.status, "active"))).orderBy(asc(users.name));
}
