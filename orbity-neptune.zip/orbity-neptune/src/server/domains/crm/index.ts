/**
 * CRM CENTRAL — cadastro canônico compartilhado por Prospect.AI, Closer.AI e Sales Intelligence.
 * Todas as consultas filtram por organizationId do contexto (isolamento multi-tenant).
 */
import { and, asc, desc, eq, ilike, or, sql, gte, count } from "drizzle-orm";
import { z } from "zod";
import {
  activities, companies, contacts, leads, opportunities, opportunityHistory, pipelineStages, pipelines, tasks, users, meetings, proposals,
} from "../../db/schema";
import { publish, EVENT_TYPES } from "../../events";
import { audit } from "../../audit";
import { requirePerm, type TenantContext } from "../../tenancy/context";
import { assertWithinLimit, recordUsage, usageThisPeriod } from "../billing";
import { HttpError } from "../../http";

export const normalizeName = (n: string) =>
  n.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase()
    .replace(/\b(ltda|me|eireli|s\.?a\.?|sa|epp|inc|llc)\b/g, "").replace(/[^a-z0-9]/g, "");

/* ---------------- Empresas & contatos (com deduplicação) ---------------- */

export const companyInput = z.object({
  name: z.string().trim().min(2).max(200),
  domain: z.string().trim().max(200).optional().nullable(),
  segment: z.string().trim().max(100).optional().nullable(),
  region: z.string().trim().max(100).optional().nullable(),
  size: z.string().trim().max(40).optional().nullable(),
  employees: z.coerce.number().int().min(0).max(10_000_000).optional().nullable(),
  technologies: z.array(z.string().max(60)).max(50).optional(),
  source: z.string().max(60).optional(),
});

/** Retorna empresa existente (mesmo nome normalizado ou domínio) ou cria uma nova. */
export async function upsertCompany(ctx: TenantContext, raw: z.input<typeof companyInput>) {
  requirePerm(ctx, "crm:write");
  const input = companyInput.parse(raw);
  const norm = normalizeName(input.name);
  const domain = input.domain?.toLowerCase().replace(/^https?:\/\//, "").replace(/^www\./, "").replace(/\/.*$/, "") || null;
  const [existing] = await ctx.db.select().from(companies).where(and(
    eq(companies.organizationId, ctx.organizationId),
    domain ? or(eq(companies.normalizedName, norm), eq(companies.domain, domain)) : eq(companies.normalizedName, norm),
  )).limit(1);
  if (existing) return { company: existing, duplicate: true };
  const [company] = await ctx.db.insert(companies).values({
    organizationId: ctx.organizationId, name: input.name, normalizedName: norm, domain, segment: input.segment ?? null,
    region: input.region ?? null, size: input.size ?? null, employees: input.employees ?? null, technologies: input.technologies ?? [],
    ownerId: ctx.userId, source: input.source ?? "manual",
  }).returning();
  return { company, duplicate: false };
}

export const contactInput = z.object({
  name: z.string().trim().min(2).max(200),
  email: z.string().trim().email().max(200).optional().nullable().or(z.literal("")),
  phone: z.string().trim().max(40).optional().nullable(),
  jobTitle: z.string().trim().max(120).optional().nullable(),
  companyId: z.string().uuid().optional().nullable(),
  legalBasis: z.enum(["consentimento", "legitimo_interesse", "execucao_contrato"]).optional(),
  source: z.string().max(60).optional(),
});

export async function upsertContact(ctx: TenantContext, raw: z.input<typeof contactInput>) {
  requirePerm(ctx, "crm:write");
  const input = contactInput.parse(raw);
  const email = input.email ? input.email.toLowerCase() : null;
  if (email) {
    const [ex] = await ctx.db.select().from(contacts).where(and(eq(contacts.organizationId, ctx.organizationId), eq(contacts.email, email))).limit(1);
    if (ex) return { contact: ex, duplicate: true };
  }
  if (input.companyId) await assertOwned(ctx, companies, input.companyId);
  const [contact] = await ctx.db.insert(contacts).values({
    organizationId: ctx.organizationId, name: input.name, email, phone: input.phone ?? null, jobTitle: input.jobTitle ?? null,
    companyId: input.companyId ?? null, legalBasis: input.legalBasis ?? "legitimo_interesse", source: input.source ?? "manual",
  }).returning();
  return { contact, duplicate: false };
}

/** Garante que um ID referenciado pertence ao tenant (evita IDOR entre organizações). */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export async function assertOwned(ctx: TenantContext, table: any, id: string) {
  const [r] = await ctx.db.select({ id: table.id }).from(table).where(and(eq(table.id, id), eq(table.organizationId, ctx.organizationId))).limit(1);
  if (!r) throw new HttpError(404, "Registro não encontrado.");
}

/* ---------------- Leads ---------------- */

export const leadInput = z.object({
  title: z.string().trim().min(2).max(200),
  companyName: z.string().trim().max(200).optional(),
  contactName: z.string().trim().max(200).optional(),
  contactEmail: z.string().trim().email().optional().or(z.literal("")),
  contactPhone: z.string().trim().max(40).optional(),
  source: z.enum(["prospect_ai", "website", "whatsapp", "referral", "import", "manual", "other"]).default("manual"),
  segment: z.string().max(100).optional(),
  region: z.string().max(100).optional(),
  employees: z.coerce.number().int().optional(),
});

export async function createLead(ctx: TenantContext, raw: z.input<typeof leadInput>) {
  requirePerm(ctx, "crm:write");
  const input = leadInput.parse(raw);
  await assertWithinLimit(ctx.db, ctx.organizationId, "leads_per_month", await usageThisPeriod(ctx.db, ctx.organizationId, "leads"));
  let companyId: string | null = null, contactId: string | null = null;
  if (input.companyName) companyId = (await upsertCompany(ctx, { name: input.companyName, segment: input.segment, region: input.region, employees: input.employees, source: input.source })).company.id;
  if (input.contactName) contactId = (await upsertContact(ctx, { name: input.contactName, email: input.contactEmail, phone: input.contactPhone, companyId, source: input.source })).contact.id;
  const lead = await ctx.db.transaction(async (tx) => {
    const [l] = await tx.insert(leads).values({ organizationId: ctx.organizationId, title: input.title, source: input.source, companyId, contactId, ownerId: ctx.userId }).returning();
    await recordUsage(tx, ctx.organizationId, "leads", 1);
    await publish(tx, ctx.organizationId, EVENT_TYPES.LEAD_CREATED, { leadId: l.id, source: l.source, by: ctx.userId });
    return l;
  });
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "lead.created", resource: "lead", resourceId: lead.id });
  return lead;
}

export async function listLeads(ctx: TenantContext, opts: { q?: string; status?: string; limit?: number } = {}) {
  requirePerm(ctx, "crm:read");
  const conds = [eq(leads.organizationId, ctx.organizationId)];
  if (opts.status) conds.push(eq(leads.status, opts.status));
  if (opts.q) conds.push(or(ilike(leads.title, `%${opts.q}%`), ilike(companies.name, `%${opts.q}%`))!);
  return ctx.db.select({
    id: leads.id, title: leads.title, status: leads.status, source: leads.source, score: leads.score, scoreExplanation: leads.scoreExplanation,
    createdAt: leads.createdAt, companyName: companies.name, companySegment: companies.segment, contactName: contacts.name, contactEmail: contacts.email,
  }).from(leads).leftJoin(companies, eq(companies.id, leads.companyId)).leftJoin(contacts, eq(contacts.id, leads.contactId))
    .where(and(...conds)).orderBy(desc(leads.score), desc(leads.createdAt)).limit(opts.limit ?? 200);
}

export async function updateLeadStatus(ctx: TenantContext, leadId: string, status: "new" | "qualifying" | "qualified" | "disqualified") {
  requirePerm(ctx, "crm:write");
  return ctx.db.transaction(async (tx) => {
    const [l] = await tx.update(leads).set({ status, updatedAt: new Date() }).where(and(eq(leads.id, leadId), eq(leads.organizationId, ctx.organizationId))).returning();
    if (!l) throw new HttpError(404, "Lead não encontrado.");
    if (status === "qualified") await publish(tx, ctx.organizationId, EVENT_TYPES.LEAD_QUALIFIED, { leadId, by: ctx.userId });
    return l;
  });
}

/** Converte lead em oportunidade no funil padrão. */
export async function convertLead(ctx: TenantContext, leadId: string, amountCents: number) {
  requirePerm(ctx, "crm:write");
  const [l] = await ctx.db.select().from(leads).where(and(eq(leads.id, leadId), eq(leads.organizationId, ctx.organizationId)));
  if (!l) throw new HttpError(404, "Lead não encontrado.");
  const opp = await createOpportunity(ctx, { title: l.title, amountCents, companyId: l.companyId, contactId: l.contactId, leadId: l.id, source: l.source });
  await ctx.db.update(leads).set({ status: "converted", updatedAt: new Date() }).where(eq(leads.id, l.id));
  return opp;
}

/* ---------------- Funil & oportunidades ---------------- */

export async function getDefaultPipeline(ctx: TenantContext) {
  const [p] = await ctx.db.select().from(pipelines).where(and(eq(pipelines.organizationId, ctx.organizationId), eq(pipelines.isDefault, true)));
  if (!p) throw new HttpError(404, "Funil padrão não configurado.");
  const stages = await ctx.db.select().from(pipelineStages).where(eq(pipelineStages.pipelineId, p.id)).orderBy(asc(pipelineStages.position));
  return { pipeline: p, stages };
}

export const opportunityInput = z.object({
  title: z.string().trim().min(2).max(200),
  amountCents: z.coerce.number().int().min(0).max(1e13),
  stageId: z.string().uuid().optional(),
  companyId: z.string().uuid().nullable().optional(),
  contactId: z.string().uuid().nullable().optional(),
  leadId: z.string().uuid().nullable().optional(),
  source: z.string().max(60).nullable().optional(),
  expectedCloseDate: z.coerce.date().optional(),
});

export async function createOpportunity(ctx: TenantContext, raw: z.input<typeof opportunityInput>) {
  requirePerm(ctx, "crm:write");
  const input = opportunityInput.parse(raw);
  const { pipeline, stages } = await getDefaultPipeline(ctx);
  const stage = input.stageId ? stages.find((s) => s.id === input.stageId) : stages[0];
  if (!stage) throw new HttpError(400, "Etapa inválida.");
  if (input.companyId) await assertOwned(ctx, companies, input.companyId);
  if (input.contactId) await assertOwned(ctx, contacts, input.contactId);
  return ctx.db.transaction(async (tx) => {
    const [o] = await tx.insert(opportunities).values({
      organizationId: ctx.organizationId, pipelineId: pipeline.id, stageId: stage.id, title: input.title, amountCents: input.amountCents,
      currency: ctx.currency, companyId: input.companyId ?? null, contactId: input.contactId ?? null, leadId: input.leadId ?? null,
      source: input.source ?? null, ownerId: ctx.userId, expectedCloseDate: input.expectedCloseDate ?? null,
    }).returning();
    await publish(tx, ctx.organizationId, EVENT_TYPES.OPPORTUNITY_CREATED, { opportunityId: o.id, amountCents: o.amountCents, by: ctx.userId });
    return o;
  });
}

export async function moveOpportunity(ctx: TenantContext, opportunityId: string, stageId: string, lostReason?: string) {
  requirePerm(ctx, "crm:write");
  const [o] = await ctx.db.select().from(opportunities).where(and(eq(opportunities.id, opportunityId), eq(opportunities.organizationId, ctx.organizationId)));
  if (!o) throw new HttpError(404, "Oportunidade não encontrada.");
  const [stage] = await ctx.db.select().from(pipelineStages).where(and(eq(pipelineStages.id, stageId), eq(pipelineStages.pipelineId, o.pipelineId)));
  if (!stage) throw new HttpError(400, "Etapa inválida para este funil.");
  if (stage.kind === "lost" && !lostReason) throw new HttpError(400, "Informe o motivo da perda.");
  const status = stage.kind === "won" ? "won" : stage.kind === "lost" ? "lost" : "open";
  return ctx.db.transaction(async (tx) => {
    const [u] = await tx.update(opportunities).set({
      stageId, status, lostReason: stage.kind === "lost" ? lostReason : null, closedAt: status === "open" ? null : new Date(),
      lastActivityAt: new Date(), updatedAt: new Date(),
    }).where(eq(opportunities.id, o.id)).returning();
    await tx.insert(opportunityHistory).values({ organizationId: ctx.organizationId, opportunityId: o.id, fromStageId: o.stageId, toStageId: stageId, changedBy: ctx.userId });
    await tx.insert(activities).values({ organizationId: ctx.organizationId, type: "stage_change", subject: `Etapa alterada para ${stage.name}`, userId: ctx.userId, opportunityId: o.id, companyId: o.companyId });
    await publish(tx, ctx.organizationId, EVENT_TYPES.OPPORTUNITY_STAGE_CHANGED, { opportunityId: o.id, from: o.stageId, to: stageId, by: ctx.userId });
    if (status === "won") await publish(tx, ctx.organizationId, EVENT_TYPES.OPPORTUNITY_WON, { opportunityId: o.id, amountCents: o.amountCents });
    if (status === "lost") await publish(tx, ctx.organizationId, EVENT_TYPES.OPPORTUNITY_LOST, { opportunityId: o.id, reason: lostReason });
    return u;
  });
}

/** Board do funil: contagem e top oportunidades por etapa. */
export async function pipelineBoard(ctx: TenantContext, perStage = 3) {
  requirePerm(ctx, "crm:read");
  const { pipeline, stages } = await getDefaultPipeline(ctx);
  const counts = await ctx.db.select({ stageId: opportunities.stageId, n: count(), total: sql<number>`coalesce(sum(${opportunities.amountCents}),0)::bigint` })
    .from(opportunities).where(and(eq(opportunities.organizationId, ctx.organizationId), eq(opportunities.pipelineId, pipeline.id))).groupBy(opportunities.stageId);
  const columns = [];
  for (const s of stages) {
    const items = await ctx.db.select({ id: opportunities.id, title: opportunities.title, amountCents: opportunities.amountCents, companyName: companies.name, lastActivityAt: opportunities.lastActivityAt })
      .from(opportunities).leftJoin(companies, eq(companies.id, opportunities.companyId))
      .where(and(eq(opportunities.organizationId, ctx.organizationId), eq(opportunities.stageId, s.id)))
      .orderBy(desc(opportunities.amountCents)).limit(perStage);
    const c = counts.find((x) => x.stageId === s.id);
    columns.push({ stage: s, count: Number(c?.n ?? 0), totalCents: Number(c?.total ?? 0), items });
  }
  return { pipeline, columns };
}

export async function opportunityDetail(ctx: TenantContext, id: string) {
  requirePerm(ctx, "crm:read");
  const [o] = await ctx.db.select({ opp: opportunities, company: companies, contact: contacts, stage: pipelineStages })
    .from(opportunities).leftJoin(companies, eq(companies.id, opportunities.companyId)).leftJoin(contacts, eq(contacts.id, opportunities.contactId))
    .innerJoin(pipelineStages, eq(pipelineStages.id, opportunities.stageId))
    .where(and(eq(opportunities.id, id), eq(opportunities.organizationId, ctx.organizationId)));
  if (!o) throw new HttpError(404, "Oportunidade não encontrada.");
  const acts = await ctx.db.select({ a: activities, userName: users.name }).from(activities).leftJoin(users, eq(users.id, activities.userId))
    .where(and(eq(activities.organizationId, ctx.organizationId), eq(activities.opportunityId, id))).orderBy(desc(activities.occurredAt)).limit(50);
  const props = await ctx.db.select().from(proposals).where(and(eq(proposals.organizationId, ctx.organizationId), eq(proposals.opportunityId, id)));
  return { ...o, activities: acts, proposals: props };
}

/* ---------------- Atividades, tarefas, reuniões ---------------- */

export const activityInput = z.object({
  type: z.enum(["call", "email", "meeting", "note", "whatsapp", "follow_up"]),
  subject: z.string().trim().min(2).max(200),
  body: z.string().max(5000).optional(),
  opportunityId: z.string().uuid().optional(),
  leadId: z.string().uuid().optional(),
});

export async function logActivity(ctx: TenantContext, raw: z.input<typeof activityInput>) {
  requirePerm(ctx, "crm:write");
  const input = activityInput.parse(raw);
  if (input.opportunityId) await assertOwned(ctx, opportunities, input.opportunityId);
  if (input.leadId) await assertOwned(ctx, leads, input.leadId);
  const [a] = await ctx.db.insert(activities).values({ organizationId: ctx.organizationId, ...input, userId: ctx.userId }).returning();
  if (input.opportunityId) await ctx.db.update(opportunities).set({ lastActivityAt: new Date() }).where(eq(opportunities.id, input.opportunityId));
  return a;
}

export const taskInput = z.object({
  title: z.string().trim().min(2).max(200),
  description: z.string().max(2000).optional(),
  priority: z.enum(["low", "medium", "high"]).default("medium"),
  dueAt: z.coerce.date().optional(),
  assigneeId: z.string().uuid().optional(),
  opportunityId: z.string().uuid().optional(),
});

export async function createTask(ctx: TenantContext, raw: z.input<typeof taskInput>) {
  requirePerm(ctx, "crm:write");
  const input = taskInput.parse(raw);
  const [t] = await ctx.db.insert(tasks).values({ organizationId: ctx.organizationId, ...input, assigneeId: input.assigneeId ?? ctx.userId }).returning();
  return t;
}

export async function setTaskStatus(ctx: TenantContext, id: string, status: "open" | "done" | "canceled") {
  requirePerm(ctx, "crm:write");
  const [t] = await ctx.db.update(tasks).set({ status, completedAt: status === "done" ? new Date() : null, updatedAt: new Date() })
    .where(and(eq(tasks.id, id), eq(tasks.organizationId, ctx.organizationId))).returning();
  if (!t) throw new HttpError(404, "Tarefa não encontrada.");
  return t;
}

export async function listTasks(ctx: TenantContext, onlyMine = false) {
  requirePerm(ctx, "crm:read");
  const conds = [eq(tasks.organizationId, ctx.organizationId)];
  if (onlyMine) conds.push(eq(tasks.assigneeId, ctx.userId));
  return ctx.db.select({ t: tasks, assignee: users.name }).from(tasks).leftJoin(users, eq(users.id, tasks.assigneeId))
    .where(and(...conds)).orderBy(asc(tasks.status), asc(tasks.dueAt)).limit(300);
}

export async function scheduleMeeting(ctx: TenantContext, raw: { title: string; startsAt: string | Date; opportunityId?: string; contactId?: string }) {
  requirePerm(ctx, "crm:write");
  const input = z.object({ title: z.string().min(2).max(200), startsAt: z.coerce.date(), opportunityId: z.string().uuid().optional(), contactId: z.string().uuid().optional() }).parse(raw);
  if (input.opportunityId) await assertOwned(ctx, opportunities, input.opportunityId);
  return ctx.db.transaction(async (tx) => {
    const [m] = await tx.insert(meetings).values({ organizationId: ctx.organizationId, ...input, userId: ctx.userId, endsAt: new Date(input.startsAt.getTime() + 3600e3) }).returning();
    await publish(tx, ctx.organizationId, EVENT_TYPES.MEETING_SCHEDULED, { meetingId: m.id, opportunityId: input.opportunityId ?? null });
    return m;
  });
}

export async function sendProposal(ctx: TenantContext, opportunityId: string, title: string, amountCents: number) {
  requirePerm(ctx, "crm:write");
  await assertOwned(ctx, opportunities, opportunityId);
  return ctx.db.transaction(async (tx) => {
    const [p] = await tx.insert(proposals).values({ organizationId: ctx.organizationId, opportunityId, title, amountCents, status: "sent", sentAt: new Date() }).returning();
    await publish(tx, ctx.organizationId, EVENT_TYPES.PROPOSAL_SENT, { proposalId: p.id, opportunityId, amountCents });
    return p;
  });
}

/** Busca global (command palette). */
export async function globalSearch(ctx: TenantContext, q: string) {
  requirePerm(ctx, "crm:read");
  const term = `%${q.slice(0, 80)}%`;
  const [cs, ls, os, ct] = await Promise.all([
    ctx.db.select({ id: companies.id, label: companies.name }).from(companies).where(and(eq(companies.organizationId, ctx.organizationId), ilike(companies.name, term))).limit(5),
    ctx.db.select({ id: leads.id, label: leads.title }).from(leads).where(and(eq(leads.organizationId, ctx.organizationId), ilike(leads.title, term))).limit(5),
    ctx.db.select({ id: opportunities.id, label: opportunities.title }).from(opportunities).where(and(eq(opportunities.organizationId, ctx.organizationId), ilike(opportunities.title, term))).limit(5),
    ctx.db.select({ id: contacts.id, label: contacts.name }).from(contacts).where(and(eq(contacts.organizationId, ctx.organizationId), ilike(contacts.name, term))).limit(5),
  ]);
  return [
    ...cs.map((r) => ({ ...r, kind: "Empresa", href: `/crm?empresa=${r.id}` })),
    ...ls.map((r) => ({ ...r, kind: "Lead", href: `/prospect?lead=${r.id}` })),
    ...os.map((r) => ({ ...r, kind: "Negócio", href: `/crm/oportunidade/${r.id}` })),
    ...ct.map((r) => ({ ...r, kind: "Contato", href: `/crm?contato=${r.id}` })),
  ];
}

export async function countSince(ctx: TenantContext, since: Date) {
  const [r] = await ctx.db.select({ n: count() }).from(leads).where(and(eq(leads.organizationId, ctx.organizationId), gte(leads.createdAt, since)));
  return Number(r?.n ?? 0);
}
