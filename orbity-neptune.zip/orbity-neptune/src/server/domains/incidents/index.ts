/** INCIDENT MANAGEMENT — severidades, linha do tempo, análise de causa e playbooks. */
import { eq } from "drizzle-orm";
import type { DB } from "../../db/client";
import { incidents } from "../../db/schema";
import { audit } from "../../audit";

export const SEVERITIES = {
  sev1: { label: "SEV1 — Crítico", criteria: "Indisponibilidade total, vazamento de dados ou cobrança indevida em massa.", response: "Resposta imediata (15 min), comunicação a clientes afetados." },
  sev2: { label: "SEV2 — Alto", criteria: "Funcionalidade central degradada para muitas organizações.", response: "Resposta em 1h, atualizações a cada 2h." },
  sev3: { label: "SEV3 — Médio", criteria: "Falha parcial com contorno disponível.", response: "Resposta no mesmo dia útil." },
  sev4: { label: "SEV4 — Baixo", criteria: "Impacto mínimo ou cosmético.", response: "Tratado no backlog." },
} as const;

export const CATEGORIES = { security: "Segurança", availability: "Disponibilidade", database: "Banco de dados", integrations: "Integrações", ai: "IA", billing: "Billing", queues: "Filas", performance: "Desempenho", ux: "Experiência do usuário" } as const;

export const PLAYBOOKS: Record<string, string[]> = {
  security: ["Conter: revogar sessões/credenciais afetadas", "Preservar evidências (logs de auditoria)", "Avaliar dados pessoais envolvidos (LGPD art. 48)", "Notificar ANPD e titulares se houver risco relevante", "Corrigir e registrar pós-incidente"],
  availability: ["Verificar /api/health e status do banco", "Rollback do último deploy se correlacionado", "Ativar página de status", "Comunicar clientes afetados"],
  billing: ["Pausar cobranças automáticas", "Identificar faturas afetadas", "Estornar valores indevidos", "Comunicar clientes"],
  ai: ["Desativar agente afetado no Centro de Controle", "Fazer rollback da versão de prompt", "Revisar execuções no período", "Executar avaliação de regressão"],
};

export async function openIncident(db: DB, by: string, input: { title: string; category: string; severity: string; impact?: string; affectedOrganizations?: string[] }) {
  const [i] = await db.insert(incidents).values({ ...input, affectedOrganizations: input.affectedOrganizations ?? [], ownerId: by, timeline: [{ at: new Date().toISOString(), by, note: "Incidente aberto" }] }).returning();
  await audit(db, { actorId: by, action: "incident.opened", resource: "incident", resourceId: i.id, metadata: { severity: input.severity } });
  return i;
}

export async function updateIncident(db: DB, by: string, id: string, patch: { status?: string; note?: string; rootCause?: string; correctiveActions?: string }) {
  const [i] = await db.select().from(incidents).where(eq(incidents.id, id));
  if (!i) return null;
  const timeline = patch.note || patch.status ? [...i.timeline, { at: new Date().toISOString(), by, note: patch.note ?? `Status → ${patch.status}` }] : i.timeline;
  const [u] = await db.update(incidents).set({
    status: patch.status ?? i.status, rootCause: patch.rootCause ?? i.rootCause, correctiveActions: patch.correctiveActions ?? i.correctiveActions, timeline,
    resolvedAt: patch.status === "resolved" ? new Date() : i.resolvedAt,
  }).where(eq(incidents.id, id)).returning();
  await audit(db, { actorId: by, action: "incident.updated", resource: "incident", resourceId: id, metadata: patch });
  return u;
}
