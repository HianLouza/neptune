/**
 * Resumo financeiro compartilhado (Financial Intelligence 360 → Command Center, Business Brain, Simulador).
 * Fonte: lançamentos em finance_entries (manuais ou de integrações efetivamente conectadas).
 * Sem lançamentos, `hasData` é false e os consumidores devem dizer "sem dados financeiros" — nunca estimar.
 */
import { and, eq, gte, lt, lte, sql } from "drizzle-orm";
import { financeEntries } from "../../db/schema";
import { requirePerm, type TenantContext } from "../../tenancy/context";

export type FinancialSnapshot = {
  hasData: boolean;
  periodDays: number;
  revenueCents: number; // recebimentos (receivables pagos) no período
  expensesCents: number; // pagamentos (payables pagos) no período
  resultCents: number;
  marginPct: number | null; // resultado / receita
  previous: { revenueCents: number; expensesCents: number; resultCents: number };
  receivableOpenCents: number;
  payableOpenCents: number;
  overdueReceivableCents: number;
  overdueReceivableCount: number;
  overduePayableCents: number;
  next30: { inflowCents: number; outflowCents: number; netCents: number };
  entriesInPeriod: number;
};

const sum = (expr: ReturnType<typeof sql>) => sql<number>`coalesce(sum(${expr}),0)::bigint`;

export async function financialSnapshot(ctx: TenantContext, days = 30, now = new Date()): Promise<FinancialSnapshot> {
  requirePerm(ctx, "finance:read");
  const org = ctx.organizationId;
  const start = new Date(now.getTime() - days * 864e5);
  const prevStart = new Date(start.getTime() - days * 864e5);
  const in30 = new Date(now.getTime() + 30 * 864e5);
  const fe = financeEntries;

  const paidBetween = async (a: Date, b: Date) => {
    const [r] = await ctx.db.select({
      rev: sum(sql`case when ${fe.kind} = 'receivable' then ${fe.amountCents} else 0 end`),
      exp: sum(sql`case when ${fe.kind} = 'payable' then ${fe.amountCents} else 0 end`),
      n: sql<number>`count(*)::int`,
    }).from(fe).where(and(eq(fe.organizationId, org), eq(fe.status, "paid"), gte(fe.paidAt, a), lt(fe.paidAt, b)));
    return { rev: Number(r.rev), exp: Number(r.exp), n: Number(r.n) };
  };
  const cur = await paidBetween(start, now);
  const prev = await paidBetween(prevStart, start);

  const [open] = await ctx.db.select({
    recOpen: sum(sql`case when ${fe.kind} = 'receivable' then ${fe.amountCents} else 0 end`),
    payOpen: sum(sql`case when ${fe.kind} = 'payable' then ${fe.amountCents} else 0 end`),
    recOver: sum(sql`case when ${fe.kind} = 'receivable' and ${fe.dueDate} < ${now} then ${fe.amountCents} else 0 end`),
    recOverN: sql<number>`count(*) filter (where ${fe.kind} = 'receivable' and ${fe.dueDate} < ${now})::int`,
    payOver: sum(sql`case when ${fe.kind} = 'payable' and ${fe.dueDate} < ${now} then ${fe.amountCents} else 0 end`),
  }).from(fe).where(and(eq(fe.organizationId, org), eq(fe.status, "open")));

  const [next] = await ctx.db.select({
    inflow: sum(sql`case when ${fe.kind} = 'receivable' then ${fe.amountCents} else 0 end`),
    outflow: sum(sql`case when ${fe.kind} = 'payable' then ${fe.amountCents} else 0 end`),
  }).from(fe).where(and(eq(fe.organizationId, org), eq(fe.status, "open"), gte(fe.dueDate, now), lte(fe.dueDate, in30)));

  const [any] = await ctx.db.select({ n: sql<number>`count(*)::int` }).from(fe).where(eq(fe.organizationId, org));

  return {
    hasData: Number(any.n) > 0,
    periodDays: days,
    revenueCents: cur.rev,
    expensesCents: cur.exp,
    resultCents: cur.rev - cur.exp,
    marginPct: cur.rev > 0 ? Math.round(((cur.rev - cur.exp) / cur.rev) * 1000) / 10 : null,
    previous: { revenueCents: prev.rev, expensesCents: prev.exp, resultCents: prev.rev - prev.exp },
    receivableOpenCents: Number(open.recOpen),
    payableOpenCents: Number(open.payOpen),
    overdueReceivableCents: Number(open.recOver),
    overdueReceivableCount: Number(open.recOverN),
    overduePayableCents: Number(open.payOver),
    next30: { inflowCents: Number(next.inflow), outflowCents: Number(next.outflow), netCents: Number(next.inflow) - Number(next.outflow) },
    entriesInPeriod: cur.n,
  };
}
