/**
 * Dados financeiros de DEMONSTRAÇÃO (somente para organizações is_demo = true).
 * ~6 meses de contas pagas, vencidas e futuras, na escala da receita do CRM de demonstração.
 * Lançamentos gerados aqui usam source = "demo" para nunca se confundirem com dados reais.
 */
import { and, eq } from "drizzle-orm";
import type { DB } from "../../db/client";
import { companies, financeCategories, financeEntries, organizations, products } from "../../db/schema";
import { ensureDefaultCategories } from "./index";

export async function seedDemoFinance(db: DB, organizationId: string, now = new Date()): Promise<{ created: number; skipped?: string }> {
  const [org] = await db.select().from(organizations).where(eq(organizations.id, organizationId));
  if (!org) return { created: 0, skipped: "Organização não encontrada." };
  if (!org.isDemo) return { created: 0, skipped: "Dados de demonstração só podem ser gerados em organizações de demonstração." };
  const [has] = await db.select({ id: financeEntries.id }).from(financeEntries).where(eq(financeEntries.organizationId, organizationId)).limit(1);
  if (has) return { created: 0, skipped: "A organização já possui lançamentos financeiros." };

  await ensureDefaultCategories(db, organizationId);
  const cats = await db.select().from(financeCategories).where(eq(financeCategories.organizationId, organizationId));
  const cat = (name: string) => cats.find((c) => c.name === name)!.id;

  let prods = await db.select().from(products).where(and(eq(products.organizationId, organizationId), eq(products.active, true)));
  if (!prods.length) {
    prods = await db.insert(products).values([
      { organizationId, name: "Licença de software (anual)", kind: "product", priceCents: 4_800_000, currency: org.currency },
      { organizationId, name: "Implantação", kind: "service", priceCents: 1_500_000, currency: org.currency },
      { organizationId, name: "Consultoria comercial", kind: "service", priceCents: 2_200_000, currency: org.currency },
    ]).returning();
  }
  const comps = await db.select({ id: companies.id }).from(companies).where(eq(companies.organizationId, organizationId)).limit(40);

  let seed = 7;
  const rand = () => ((seed = (seed * 1103515245 + 12345) % 2 ** 31) / 2 ** 31);
  const pick = <T,>(a: T[]) => a[Math.floor(rand() * a.length)];
  const rows: (typeof financeEntries.$inferInsert)[] = [];
  const day = 864e5;
  const base = { organizationId, currency: org.currency, source: "demo", createdBy: null as string | null };

  // Meses: -5 .. +1 (o mês seguinte só com contas futuras em aberto)
  for (let mOff = -5; mOff <= 1; mOff++) {
    const first = new Date(now.getFullYear(), now.getMonth() + mOff, 1, 12);
    const daysIn = new Date(first.getFullYear(), first.getMonth() + 1, 0).getDate();
    const at = (d: number) => new Date(first.getFullYear(), first.getMonth(), Math.min(d, daysIn), 12);
    const isPast = (d: Date) => d.getTime() < now.getTime();
    const target = 100_000_000 + Math.round(rand() * 30_000_000); // R$ 1,0–1,3 mi
    let revenue = 0;

    // Recebíveis
    while (revenue < target) {
      const amount = Math.round((2_000_000 + rand() * 4_000_000) / 100) * 100; // R$ 20–60 mil
      const due = at(1 + Math.floor(rand() * daysIn));
      const linked = rand() < 0.72;
      const prod = pick(prods);
      const overdue = isPast(due) && mOff >= -2 && rand() < 0.07;
      const paidAt = isPast(due) && !overdue ? new Date(Math.min(due.getTime() + Math.floor(rand() * 4) * day, now.getTime() - 3600_000)) : null;
      rows.push({
        ...base, kind: "receivable", description: `${prod.kind === "service" ? "Serviço" : "Venda"} — ${prod.name}`,
        categoryId: cat(prod.kind === "service" ? "Prestação de serviços" : rand() < 0.5 ? "Assinaturas" : "Vendas de produtos"),
        amountCents: amount, dueDate: due, paidAt, status: paidAt ? "paid" : "open",
        companyId: linked && comps.length ? pick(comps).id : null, productId: linked ? prod.id : null,
      });
      revenue += amount;
    }

    const payable = (description: string, category: string, cents: number, d: number, extra: Partial<typeof financeEntries.$inferInsert> = {}) => {
      const due = at(d);
      const late = isPast(due) && mOff === 0 && rand() < 0.1;
      rows.push({ ...base, kind: "payable", description, categoryId: cat(category), amountCents: Math.round(cents / 100) * 100, dueDate: due, paidAt: isPast(due) && !late ? due : null, status: isPast(due) && !late ? "paid" : "open", costCenter: extra.costCenter ?? null, ...extra });
    };
    const j = () => 0.92 + rand() * 0.16;
    payable("Folha de pagamento", "Salários e encargos", 30_000_000 * j(), 5, { costCenter: "Comercial" });
    payable("Plano de saúde e vale-refeição", "Benefícios", 4_000_000 * j(), 10, { costCenter: "Pessoas" });
    payable("Aluguel do escritório", "Aluguel e condomínio", 3_000_000, 8, { costCenter: "Administrativo" });
    payable("Ferramentas e licenças de software", "Software e ferramentas", 2_500_000 * j(), 15, { costCenter: "Tecnologia" });
    payable("Mídia paga e eventos", "Marketing e mídia", 7_000_000 * j(), 20, { costCenter: "Marketing" });
    payable("Contabilidade e jurídico", "Serviços de terceiros", 2_500_000 * j(), 12, { costCenter: "Administrativo" });
    payable("Impostos sobre faturamento", "Impostos sobre vendas", revenue * 0.08, 20);
    payable("Comissões de vendas", "Comissões de vendas", revenue * 0.04, 25, { costCenter: "Comercial" });
    payable("Tarifas bancárias", "Tarifas bancárias e juros", 400_000 * j(), 28);
    payable("IRPJ/CSLL (provisão gerencial)", "Impostos sobre o lucro", 2_000_000 * j(), 28);
    // Custo direto por produto (permite análise de margem por produto/cliente)
    for (const p of prods) {
      const share = p.kind === "service" ? 0.16 : 0.1;
      payable(`Custo direto — ${p.name}`, "Custo dos produtos e serviços", (revenue / prods.length) * share * j(), 18, { productId: p.id });
    }
  }

  for (let i = 0; i < rows.length; i += 300) await db.insert(financeEntries).values(rows.slice(i, i + 300));
  return { created: rows.length };
}
