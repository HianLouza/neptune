/**
 * FINANCIAL INTELLIGENCE 360 (núcleo) — Master Prompt 4.0 §10.
 *
 * - Contas a pagar/receber, categorias, centros de custo, orçamentos.
 * - DRE gerencial (regime de CAIXA: só lançamentos pagos), fluxo de caixa projetado, inadimplência,
 *   rentabilidade por cliente/produto, ponto de equilíbrio e assistente financeiro determinístico.
 * - Toda análise devolve cálculos, premissas, fontes e evidência (Evidence Engine).
 *
 * Regras:
 *  - Receita do FINANCEIRO (dinheiro recebido) ≠ receita GANHA no CRM (negócios fechados). Sempre rotuladas separadamente.
 *  - Nada de dados externos apresentados como conectados: integrações de pagamento/banco/ERP são lidas da tabela
 *    `integrations` e mostradas como "não conectado" quando não estiverem.
 *  - A IA/assistente nunca substitui obrigações contábeis, fiscais ou regulatórias.
 */
import { and, asc, desc, eq, gte, inArray, lt, lte, ne, or, sql } from "drizzle-orm";
import { z } from "zod";
import { companies, financeBudgets, financeCategories, financeEntries, integrations, opportunities, products } from "../../db/schema";
import type { DB } from "../../db/client";
import { requirePerm, type TenantContext } from "../../tenancy/context";
import { audit } from "../../audit";
import { HttpError } from "../../http";
import { buildEvidence, confidenceFrom, type Evidence } from "../../intelligence-layer/evidence";

export { financialSnapshot, type FinancialSnapshot } from "./snapshot";

/* ------------------------------------------------------------------ */
/* Categorias                                                          */
/* ------------------------------------------------------------------ */

export const GROUPS = ["receita_bruta", "deducoes", "custo", "pessoal", "marketing", "operacional", "financeiro", "impostos", "outros"] as const;
export type FinanceGroup = (typeof GROUPS)[number];

export const GROUP_LABELS: Record<FinanceGroup, string> = {
  receita_bruta: "Receita bruta", deducoes: "Deduções da receita", custo: "Custos variáveis", pessoal: "Pessoal",
  marketing: "Marketing", operacional: "Operacional", financeiro: "Financeiro", impostos: "Impostos sobre o resultado", outros: "Outras despesas",
};

/** Grupos tratados como despesas FIXAS no DRE e no ponto de equilíbrio (premissa declarada). */
export const FIXED_GROUPS: FinanceGroup[] = ["pessoal", "marketing", "operacional", "outros"];

export const DEFAULT_CATEGORIES: { name: string; kind: "revenue" | "expense"; group: FinanceGroup }[] = [
  { name: "Vendas de produtos", kind: "revenue", group: "receita_bruta" },
  { name: "Prestação de serviços", kind: "revenue", group: "receita_bruta" },
  { name: "Assinaturas", kind: "revenue", group: "receita_bruta" },
  { name: "Rendimentos financeiros", kind: "revenue", group: "financeiro" },
  { name: "Impostos sobre vendas", kind: "expense", group: "deducoes" },
  { name: "Devoluções e descontos", kind: "expense", group: "deducoes" },
  { name: "Custo dos produtos e serviços", kind: "expense", group: "custo" },
  { name: "Comissões de vendas", kind: "expense", group: "custo" },
  { name: "Salários e encargos", kind: "expense", group: "pessoal" },
  { name: "Benefícios", kind: "expense", group: "pessoal" },
  { name: "Marketing e mídia", kind: "expense", group: "marketing" },
  { name: "Aluguel e condomínio", kind: "expense", group: "operacional" },
  { name: "Software e ferramentas", kind: "expense", group: "operacional" },
  { name: "Serviços de terceiros", kind: "expense", group: "operacional" },
  { name: "Tarifas bancárias e juros", kind: "expense", group: "financeiro" },
  { name: "Impostos sobre o lucro", kind: "expense", group: "impostos" },
  { name: "Outras despesas", kind: "expense", group: "outros" },
];

/** Idempotente: cria as categorias padrão que ainda não existem. */
export async function ensureDefaultCategories(db: DB, organizationId: string) {
  const existing = await db.select({ name: financeCategories.name, kind: financeCategories.kind }).from(financeCategories).where(eq(financeCategories.organizationId, organizationId));
  const has = new Set(existing.map((c) => `${c.kind}|${c.name}`));
  const missing = DEFAULT_CATEGORIES.filter((c) => !has.has(`${c.kind}|${c.name}`));
  if (missing.length) await db.insert(financeCategories).values(missing.map((c) => ({ organizationId, ...c }))).onConflictDoNothing();
}

export async function listCategories(ctx: TenantContext) {
  requirePerm(ctx, "finance:read");
  await ensureDefaultCategories(ctx.db, ctx.organizationId);
  return ctx.db.select().from(financeCategories).where(eq(financeCategories.organizationId, ctx.organizationId)).orderBy(asc(financeCategories.kind), asc(financeCategories.name));
}

export const categoryInput = z.object({
  name: z.string().trim().min(2).max(80),
  kind: z.enum(["revenue", "expense"]),
  group: z.enum(GROUPS),
});

export async function createCategory(ctx: TenantContext, raw: unknown) {
  requirePerm(ctx, "finance:write");
  const input = categoryInput.parse(raw);
  if (input.kind === "revenue" && !["receita_bruta", "financeiro"].includes(input.group)) throw new HttpError(400, "Categorias de receita devem ser do grupo Receita bruta ou Financeiro.");
  if (input.kind === "expense" && input.group === "receita_bruta") throw new HttpError(400, "Categorias de despesa não podem ser do grupo Receita bruta.");
  const [dup] = await ctx.db.select({ id: financeCategories.id }).from(financeCategories)
    .where(and(eq(financeCategories.organizationId, ctx.organizationId), eq(financeCategories.name, input.name), eq(financeCategories.kind, input.kind)));
  if (dup) throw new HttpError(409, "Já existe uma categoria com esse nome.");
  const [c] = await ctx.db.insert(financeCategories).values({ organizationId: ctx.organizationId, ...input }).returning();
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "finance.category.created", resource: "finance_category", resourceId: c.id, metadata: input, ip: ctx.ip });
  return c;
}

/* ------------------------------------------------------------------ */
/* Lançamentos                                                         */
/* ------------------------------------------------------------------ */

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function owned(ctx: TenantContext, table: any, id: string, label: string) {
  const [r] = await ctx.db.select({ id: table.id }).from(table).where(and(eq(table.id, id), eq(table.organizationId, ctx.organizationId))).limit(1);
  if (!r) throw new HttpError(404, `${label} não encontrado.`);
}

const optionalUuid = z.string().uuid().optional().or(z.literal("").transform(() => undefined)).nullable();

export const entryInput = z.object({
  kind: z.enum(["receivable", "payable"]),
  description: z.string().trim().min(2).max(200),
  categoryId: optionalUuid,
  costCenter: z.string().trim().max(80).optional().nullable(),
  amountCents: z.coerce.number().int().positive().max(1e13),
  dueDate: z.coerce.date(),
  paidAt: z.coerce.date().optional().nullable(),
  /** Atalho do formulário: "já pago" usa o vencimento (se passado) ou agora como data de pagamento. */
  paid: z.boolean().optional(),
  companyId: optionalUuid,
  productId: optionalUuid,
  opportunityId: optionalUuid,
});

async function validateRefs(ctx: TenantContext, input: { categoryId?: string | null; companyId?: string | null; productId?: string | null; opportunityId?: string | null; kind?: string }) {
  if (input.categoryId) {
    const [c] = await ctx.db.select().from(financeCategories).where(and(eq(financeCategories.id, input.categoryId), eq(financeCategories.organizationId, ctx.organizationId)));
    if (!c) throw new HttpError(404, "Categoria não encontrada.");
    if (input.kind && ((input.kind === "receivable") !== (c.kind === "revenue"))) throw new HttpError(400, "A categoria não combina com o tipo do lançamento (receita x despesa).");
  }
  if (input.companyId) await owned(ctx, companies, input.companyId, "Empresa");
  if (input.productId) await owned(ctx, products, input.productId, "Produto");
  if (input.opportunityId) await owned(ctx, opportunities, input.opportunityId, "Oportunidade");
}

export async function createEntry(ctx: TenantContext, raw: unknown) {
  requirePerm(ctx, "finance:write");
  const input = entryInput.parse(raw);
  await validateRefs(ctx, input);
  if (input.paid && !input.paidAt) input.paidAt = input.dueDate.getTime() <= Date.now() ? input.dueDate : new Date();
  const [e] = await ctx.db.insert(financeEntries).values({
    organizationId: ctx.organizationId, kind: input.kind, description: input.description, categoryId: input.categoryId ?? null,
    costCenter: input.costCenter || null, amountCents: input.amountCents, currency: ctx.currency, dueDate: input.dueDate,
    paidAt: input.paidAt ?? null, status: input.paidAt ? "paid" : "open", companyId: input.companyId ?? null,
    productId: input.productId ?? null, opportunityId: input.opportunityId ?? null, source: "manual", createdBy: ctx.userId,
  }).returning();
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "finance.entry.created", resource: "finance_entry", resourceId: e.id, metadata: { kind: e.kind, amountCents: e.amountCents, status: e.status }, ip: ctx.ip });
  return e;
}

async function getOwnedEntry(ctx: TenantContext, id: string) {
  if (!z.string().uuid().safeParse(id).success) throw new HttpError(404, "Lançamento não encontrado.");
  const [e] = await ctx.db.select().from(financeEntries).where(and(eq(financeEntries.id, id), eq(financeEntries.organizationId, ctx.organizationId)));
  if (!e) throw new HttpError(404, "Lançamento não encontrado.");
  return e;
}

export async function getEntry(ctx: TenantContext, id: string) {
  requirePerm(ctx, "finance:read");
  return getOwnedEntry(ctx, id);
}

export const entryPatch = z.union([
  z.object({ action: z.literal("pay"), paidAt: z.coerce.date().optional() }),
  z.object({ action: z.literal("cancel"), reason: z.string().trim().max(200).optional() }),
  z.object({ action: z.literal("reopen") }),
  z.object({ action: z.literal("update"), data: entryInput.partial().omit({ kind: true, paidAt: true, paid: true }) }),
]);

export async function updateEntry(ctx: TenantContext, id: string, raw: unknown) {
  requirePerm(ctx, "finance:write");
  const patch = entryPatch.parse(raw);
  const e = await getOwnedEntry(ctx, id);
  let values: Partial<typeof financeEntries.$inferInsert>;
  if (patch.action === "pay") {
    if (e.status !== "open") throw new HttpError(409, e.status === "paid" ? "Lançamento já está pago." : "Lançamento cancelado não pode ser pago.");
    values = { status: "paid", paidAt: patch.paidAt ?? new Date() };
  } else if (patch.action === "cancel") {
    if (e.status === "canceled") throw new HttpError(409, "Lançamento já está cancelado.");
    values = { status: "canceled" };
  } else if (patch.action === "reopen") {
    if (e.status === "open") throw new HttpError(409, "Lançamento já está em aberto.");
    values = { status: "open", paidAt: null };
  } else {
    await validateRefs(ctx, { ...patch.data, kind: e.kind });
    values = { ...patch.data };
  }
  const [u] = await ctx.db.update(financeEntries).set(values).where(and(eq(financeEntries.id, e.id), eq(financeEntries.organizationId, ctx.organizationId))).returning();
  const action = patch.action === "pay" ? "paid" : patch.action === "cancel" ? "canceled" : patch.action === "reopen" ? "reopened" : "updated";
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: `finance.entry.${action}`, resource: "finance_entry", resourceId: e.id, metadata: { before: { status: e.status, amountCents: e.amountCents }, after: { status: u.status, amountCents: u.amountCents }, ...(patch.action === "cancel" && patch.reason ? { reason: patch.reason } : {}) }, ip: ctx.ip });
  return u;
}

export const entryFilters = z.object({
  kind: z.enum(["receivable", "payable"]).optional(),
  status: z.enum(["open", "paid", "canceled", "overdue"]).optional(),
  categoryId: z.string().uuid().optional(),
  from: z.coerce.date().optional(),
  to: z.coerce.date().optional(),
  limit: z.coerce.number().int().min(1).max(500).default(200),
});

export async function listEntries(ctx: TenantContext, raw: unknown = {}) {
  requirePerm(ctx, "finance:read");
  const f = entryFilters.parse(raw);
  const conds = [eq(financeEntries.organizationId, ctx.organizationId)];
  if (f.kind) conds.push(eq(financeEntries.kind, f.kind));
  if (f.status === "overdue") conds.push(eq(financeEntries.status, "open"), lt(financeEntries.dueDate, new Date()));
  else if (f.status) conds.push(eq(financeEntries.status, f.status));
  if (f.categoryId) conds.push(eq(financeEntries.categoryId, f.categoryId));
  if (f.from) conds.push(gte(financeEntries.dueDate, f.from));
  if (f.to) conds.push(lte(financeEntries.dueDate, f.to));
  return ctx.db.select({
    id: financeEntries.id, kind: financeEntries.kind, description: financeEntries.description, amountCents: financeEntries.amountCents,
    dueDate: financeEntries.dueDate, paidAt: financeEntries.paidAt, status: financeEntries.status, costCenter: financeEntries.costCenter,
    source: financeEntries.source, categoryId: financeEntries.categoryId, categoryName: financeCategories.name, companyName: companies.name, productName: products.name,
  }).from(financeEntries)
    .leftJoin(financeCategories, eq(financeCategories.id, financeEntries.categoryId))
    .leftJoin(companies, eq(companies.id, financeEntries.companyId))
    .leftJoin(products, eq(products.id, financeEntries.productId))
    .where(and(...conds)).orderBy(desc(financeEntries.dueDate)).limit(f.limit);
}

/* ------------------------------------------------------------------ */
/* Cálculos puros (testáveis sem banco)                                */
/* ------------------------------------------------------------------ */

export type CalcRow = {
  kind: "receivable" | "payable" | string; status: string; amountCents: number; dueDate: Date; paidAt: Date | null;
  group: FinanceGroup | string | null; companyId?: string | null; productId?: string | null;
};

export const monthKey = (d: Date, tz = "UTC") => new Intl.DateTimeFormat("en-CA", { timeZone: tz, year: "numeric", month: "2-digit" }).format(d).slice(0, 7);

export type DreMonth = {
  month: string; receitaBruta: number; deducoes: number; receitaLiquida: number; custosVariaveis: number;
  margemContribuicao: number; margemContribuicaoPct: number | null; despesasFixas: Record<"pessoal" | "marketing" | "operacional" | "outros", number>;
  totalDespesasFixas: number; resultadoOperacional: number; receitasFinanceiras: number; despesasFinanceiras: number;
  impostos: number; resultadoLiquido: number; lancamentos: number;
};

const emptyMonth = (month: string): DreMonth => ({
  month, receitaBruta: 0, deducoes: 0, receitaLiquida: 0, custosVariaveis: 0, margemContribuicao: 0, margemContribuicaoPct: null,
  despesasFixas: { pessoal: 0, marketing: 0, operacional: 0, outros: 0 }, totalDespesasFixas: 0, resultadoOperacional: 0,
  receitasFinanceiras: 0, despesasFinanceiras: 0, impostos: 0, resultadoLiquido: 0, lancamentos: 0,
});

/** DRE gerencial em regime de caixa: considera apenas lançamentos PAGOS, pelo mês do pagamento. */
export function computeDre(rows: CalcRow[], months: string[], tz = "UTC"): DreMonth[] {
  const map = new Map(months.map((m) => [m, emptyMonth(m)]));
  for (const r of rows) {
    if (r.status !== "paid" || !r.paidAt) continue;
    const m = map.get(monthKey(r.paidAt, tz));
    if (!m) continue;
    m.lancamentos++;
    const g = (r.group ?? null) as FinanceGroup | null;
    if (r.kind === "receivable") {
      if (g === "financeiro") m.receitasFinanceiras += r.amountCents;
      else m.receitaBruta += r.amountCents; // sem categoria → receita bruta (premissa)
    } else {
      if (g === "deducoes") m.deducoes += r.amountCents;
      else if (g === "custo") m.custosVariaveis += r.amountCents;
      else if (g === "financeiro") m.despesasFinanceiras += r.amountCents;
      else if (g === "impostos") m.impostos += r.amountCents;
      else if (g === "pessoal" || g === "marketing" || g === "operacional") m.despesasFixas[g] += r.amountCents;
      else m.despesasFixas.outros += r.amountCents; // "outros" e sem categoria
    }
  }
  for (const m of map.values()) {
    m.receitaLiquida = m.receitaBruta - m.deducoes;
    m.margemContribuicao = m.receitaLiquida - m.custosVariaveis;
    m.margemContribuicaoPct = m.receitaLiquida > 0 ? Math.round((m.margemContribuicao / m.receitaLiquida) * 1000) / 10 : null;
    m.totalDespesasFixas = m.despesasFixas.pessoal + m.despesasFixas.marketing + m.despesasFixas.operacional + m.despesasFixas.outros;
    m.resultadoOperacional = m.margemContribuicao - m.totalDespesasFixas;
    m.resultadoLiquido = m.resultadoOperacional + m.receitasFinanceiras - m.despesasFinanceiras - m.impostos;
  }
  return months.map((k) => map.get(k)!);
}

export function lastMonths(n: number, now = new Date(), tz = "UTC"): string[] {
  const cur = monthKey(now, tz);
  let [y, mo] = cur.split("-").map(Number);
  const out: string[] = [];
  for (let i = 0; i < n; i++) {
    out.unshift(`${y}-${String(mo).padStart(2, "0")}`);
    mo--; if (mo === 0) { mo = 12; y--; }
  }
  return out;
}

export type BreakEven = {
  computable: boolean; reason?: string; basisMonths: string[]; avgReceitaBruta: number; avgReceitaLiquida: number;
  avgCustosVariaveis: number; avgDespesasFixas: number; contributionRatio: number | null;
  breakEvenReceitaLiquida: number | null; breakEvenReceitaBruta: number | null; gapReceitaBruta: number | null;
  calculations: string[]; premises: string[];
};

/** Ponto de equilíbrio = despesas fixas médias ÷ índice de margem de contribuição. Base: meses completos com receita. */
export function computeBreakEven(dre: DreMonth[], currentMonth: string, fmt: (c: number) => string): BreakEven {
  const basis = dre.filter((m) => m.month !== currentMonth && m.receitaBruta > 0).slice(-3);
  const premises = [
    "Regime de caixa: só lançamentos pagos entram no cálculo.",
    `Despesas fixas = grupos ${FIXED_GROUPS.map((g) => GROUP_LABELS[g]).join(", ")} (marketing tratado como fixo).`,
    "Deduções e custos variáveis são proporcionais à receita (índice médio dos meses-base).",
    "Resultado financeiro e impostos sobre o resultado não entram no ponto de equilíbrio operacional.",
  ];
  const base: BreakEven = { computable: false, basisMonths: basis.map((m) => m.month), avgReceitaBruta: 0, avgReceitaLiquida: 0, avgCustosVariaveis: 0, avgDespesasFixas: 0, contributionRatio: null, breakEvenReceitaLiquida: null, breakEvenReceitaBruta: null, gapReceitaBruta: null, calculations: [], premises };
  if (!basis.length) return { ...base, reason: "Não há nenhum mês completo com receita paga registrada." };
  const n = basis.length;
  const avg = (f: (m: DreMonth) => number) => Math.round(basis.reduce((s, m) => s + f(m), 0) / n);
  const rb = avg((m) => m.receitaBruta), rl = avg((m) => m.receitaLiquida), cv = avg((m) => m.custosVariaveis), df = avg((m) => m.totalDespesasFixas);
  const sumRl = basis.reduce((s, m) => s + m.receitaLiquida, 0), sumMc = basis.reduce((s, m) => s + m.margemContribuicao, 0);
  const ratio = sumRl > 0 ? sumMc / sumRl : 0;
  const filled = { ...base, avgReceitaBruta: rb, avgReceitaLiquida: rl, avgCustosVariaveis: cv, avgDespesasFixas: df, contributionRatio: Math.round(ratio * 1000) / 1000 };
  if (ratio <= 0) return { ...filled, reason: "A margem de contribuição média é zero ou negativa: não existe volume de vendas que cubra as despesas fixas com a estrutura de custos atual." };
  const beRl = Math.round(df / ratio);
  const rlToRb = rl > 0 ? rb / rl : 1;
  const beRb = Math.round(beRl * rlToRb);
  return {
    ...filled, computable: true, breakEvenReceitaLiquida: beRl, breakEvenReceitaBruta: beRb, gapReceitaBruta: rb - beRb,
    calculations: [
      `Meses-base: ${basis.map((m) => m.month).join(", ")} (${n} ${n === 1 ? "mês" : "meses"}).`,
      `Índice de margem de contribuição = margem de contribuição ÷ receita líquida = ${(ratio * 100).toFixed(1)}%.`,
      `Despesas fixas médias = ${fmt(df)}/mês.`,
      `Ponto de equilíbrio (receita líquida) = ${fmt(df)} ÷ ${(ratio * 100).toFixed(1)}% = ${fmt(beRl)}/mês.`,
      `Convertido para receita bruta (fator ${rlToRb.toFixed(3)}) = ${fmt(beRb)}/mês.`,
      `Receita bruta média atual = ${fmt(rb)}/mês → ${rb >= beRb ? "acima" : "abaixo"} do equilíbrio em ${fmt(Math.abs(rb - beRb))}.`,
    ],
  };
}

export type CashBucket = { label: string; start: string; end: string; inflowCents: number; outflowCents: number; netCents: number; cumulativeCents: number; estInflowCents: number; estOutflowCents: number };

/** Fluxo projetado por semanas a partir de lançamentos EM ABERTO (não vencidos). Atrasados ficam fora e são informados à parte. */
export function computeCashflow(rows: CalcRow[], now: Date, weeks = 13, weeklyEstimate?: { inflow: number; outflow: number }) {
  const start = new Date(now); start.setHours(0, 0, 0, 0);
  const buckets: CashBucket[] = [];
  for (let i = 0; i < weeks; i++) {
    const s = new Date(start.getTime() + i * 7 * 864e5), e = new Date(s.getTime() + 7 * 864e5);
    buckets.push({ label: `Sem ${i + 1}`, start: s.toISOString(), end: e.toISOString(), inflowCents: 0, outflowCents: 0, netCents: 0, cumulativeCents: 0, estInflowCents: weeklyEstimate?.inflow ?? 0, estOutflowCents: weeklyEstimate?.outflow ?? 0 });
  }
  const end = new Date(start.getTime() + weeks * 7 * 864e5);
  let overdueIn = 0, overdueOut = 0;
  for (const r of rows) {
    if (r.status !== "open") continue;
    if (r.dueDate < start) { if (r.kind === "receivable") overdueIn += r.amountCents; else overdueOut += r.amountCents; continue; }
    if (r.dueDate >= end) continue;
    const idx = Math.floor((r.dueDate.getTime() - start.getTime()) / (7 * 864e5));
    const b = buckets[idx];
    if (r.kind === "receivable") b.inflowCents += r.amountCents; else b.outflowCents += r.amountCents;
  }
  let cum = 0;
  for (const b of buckets) { b.netCents = b.inflowCents - b.outflowCents; cum += b.netCents; b.cumulativeCents = cum; }
  return { buckets, overdueReceivableCents: overdueIn, overduePayableCents: overdueOut, totalInflowCents: buckets.reduce((s, b) => s + b.inflowCents, 0), totalOutflowCents: buckets.reduce((s, b) => s + b.outflowCents, 0) };
}

export type AgingResult = { buckets: { label: string; cents: number; count: number }[]; overdueCents: number; overdueCount: number; dueLast90Cents: number; ratePct: number | null };

/** Inadimplência = recebíveis vencidos em aberto ÷ recebíveis com vencimento nos últimos 90 dias (exceto cancelados). */
export function computeAging(rows: CalcRow[], now: Date): AgingResult {
  const defs = [["1–30 dias", 1, 30], ["31–60 dias", 31, 60], ["61–90 dias", 61, 90], ["Mais de 90 dias", 91, Infinity]] as const;
  const buckets = defs.map(([label]) => ({ label: label as string, cents: 0, count: 0 }));
  let overdue = 0, overdueN = 0, due90 = 0;
  const d90 = new Date(now.getTime() - 90 * 864e5);
  for (const r of rows) {
    if (r.kind !== "receivable" || r.status === "canceled") continue;
    if (r.dueDate >= d90 && r.dueDate < now) due90 += r.amountCents;
    if (r.status !== "open" || r.dueDate >= now) continue;
    const late = Math.floor((now.getTime() - r.dueDate.getTime()) / 864e5);
    const i = defs.findIndex(([, a, b]) => late >= a && late <= b);
    const b = buckets[i === -1 ? 0 : i];
    b.cents += r.amountCents; b.count++; overdue += r.amountCents; overdueN++;
  }
  return { buckets, overdueCents: overdue, overdueCount: overdueN, dueLast90Cents: due90, ratePct: due90 > 0 ? Math.round((buckets.reduce((s, b, i) => s + (i < 3 ? b.cents : 0), 0) / due90) * 1000) / 10 : null };
}

export type ProfitRow = { id: string; name: string; revenueCents: number; directCostsCents: number; marginCents: number; marginPct: number | null; overdueCents: number };

export function computeProfitability(rows: (CalcRow & { refId: string | null })[]) {
  const map = new Map<string, ProfitRow>();
  let unlinkedRevenue = 0, totalRevenue = 0;
  for (const r of rows) {
    if (r.kind === "receivable" && r.status === "paid") totalRevenue += r.amountCents;
    if (!r.refId) { if (r.kind === "receivable" && r.status === "paid") unlinkedRevenue += r.amountCents; continue; }
    const p = map.get(r.refId) ?? { id: r.refId, name: "", revenueCents: 0, directCostsCents: 0, marginCents: 0, marginPct: null, overdueCents: 0 };
    if (r.kind === "receivable" && r.status === "paid") p.revenueCents += r.amountCents;
    if (r.kind === "payable" && r.status === "paid") p.directCostsCents += r.amountCents;
    if (r.kind === "receivable" && r.status === "open" && r.dueDate < new Date()) p.overdueCents += r.amountCents;
    map.set(r.refId, p);
  }
  const list = [...map.values()].map((p) => ({ ...p, marginCents: p.revenueCents - p.directCostsCents, marginPct: p.revenueCents > 0 ? Math.round(((p.revenueCents - p.directCostsCents) / p.revenueCents) * 1000) / 10 : null }));
  list.sort((a, b) => b.marginCents - a.marginCents);
  return { rows: list, unlinkedRevenueCents: unlinkedRevenue, totalRevenueCents: totalRevenue };
}

/* ------------------------------------------------------------------ */
/* Relatórios (com banco)                                              */
/* ------------------------------------------------------------------ */

const fmtFor = (ctx: TenantContext) => (c: number) => (c / 100).toLocaleString(ctx.locale, { style: "currency", currency: ctx.currency, maximumFractionDigits: 0 });

async function loadRows(ctx: TenantContext, where: ReturnType<typeof and>) {
  const rows = await ctx.db.select({
    kind: financeEntries.kind, status: financeEntries.status, amountCents: financeEntries.amountCents, dueDate: financeEntries.dueDate,
    paidAt: financeEntries.paidAt, group: financeCategories.group, companyId: financeEntries.companyId, productId: financeEntries.productId,
  }).from(financeEntries).leftJoin(financeCategories, eq(financeCategories.id, financeEntries.categoryId)).where(where);
  return rows.map((r) => ({ ...r, amountCents: Number(r.amountCents) })) as CalcRow[];
}

const SOURCE = "Lançamentos financeiros (finance_entries)";

export async function dreReport(ctx: TenantContext, months = 6, now = new Date()) {
  requirePerm(ctx, "finance:read");
  const keys = lastMonths(months, now, ctx.timezone);
  const from = new Date(now.getTime() - (months + 1) * 31 * 864e5);
  const rows = await loadRows(ctx, and(eq(financeEntries.organizationId, ctx.organizationId), eq(financeEntries.status, "paid"), gte(financeEntries.paidAt, from)));
  const dre = computeDre(rows, keys, ctx.timezone);
  const n = dre.reduce((s, m) => s + m.lancamentos, 0);
  return {
    months: dre,
    evidence: buildEvidence({
      facts: [{ label: "Lançamentos pagos considerados", value: String(n), source: SOURCE, period: `${keys[0]} a ${keys[keys.length - 1]}` }],
      assumptions: ["Regime de caixa (mês do pagamento).", "Lançamento sem categoria: receita → receita bruta; despesa → outras despesas."],
      calculations: ["Receita líquida = receita bruta − deduções", "Margem de contribuição = receita líquida − custos variáveis", "Resultado operacional = margem de contribuição − despesas fixas", "Resultado líquido = operacional + receitas financeiras − despesas financeiras − impostos"],
      confidence: confidenceFrom(n, 0, 60),
      limitations: ["DRE gerencial: não substitui a contabilidade oficial nem apurações fiscais."],
    }),
  };
}

async function weeklyEstimate(ctx: TenantContext, now: Date) {
  const dre = (await dreReport(ctx, 4, now)).months;
  const cur = monthKey(now, ctx.timezone);
  const full = dre.filter((m) => m.month !== cur && m.lancamentos > 0).slice(-3);
  if (!full.length) return null;
  const inflow = full.reduce((s, m) => s + m.receitaBruta + m.receitasFinanceiras, 0) / full.length;
  const outflow = full.reduce((s, m) => s + m.deducoes + m.custosVariaveis + m.totalDespesasFixas + m.despesasFinanceiras + m.impostos, 0) / full.length;
  return { inflow: Math.round((inflow * 12) / 52), outflow: Math.round((outflow * 12) / 52), months: full.map((m) => m.month) };
}

export async function cashflowReport(ctx: TenantContext, now = new Date()) {
  requirePerm(ctx, "finance:read");
  const rows = await loadRows(ctx, and(eq(financeEntries.organizationId, ctx.organizationId), eq(financeEntries.status, "open")));
  const est = await weeklyEstimate(ctx, now);
  const cf = computeCashflow(rows, now, 13, est ? { inflow: est.inflow, outflow: est.outflow } : undefined);
  const fmt = fmtFor(ctx);
  return {
    ...cf,
    estimate: est ? { weeklyInflowCents: est.inflow, weeklyOutflowCents: est.outflow, basisMonths: est.months } : null,
    premises: [
      "Projeção confirmada: somente contas a receber e a pagar EM ABERTO, pelo vencimento.",
      "Valores vencidos e não pagos ficam fora das semanas e aparecem separados (não assumimos que serão recebidos).",
      "Saldo bancário inicial não é conhecido (nenhum banco conectado): o acumulado parte de zero.",
      ...(est ? [`Estimativa recorrente (separada, opcional): média mensal paga de ${est.months.join(", ")} convertida em semanas (×12÷52). É estimativa, não compromisso.`] : ["Sem meses completos pagos: não há estimativa recorrente."]),
    ],
    evidence: buildEvidence({
      facts: [
        { label: "Entradas confirmadas (13 semanas)", value: fmt(cf.totalInflowCents), source: SOURCE },
        { label: "Saídas confirmadas (13 semanas)", value: fmt(cf.totalOutflowCents), source: SOURCE },
        { label: "Recebíveis vencidos fora da projeção", value: fmt(cf.overdueReceivableCents), source: SOURCE },
      ],
      confidence: confidenceFrom(rows.length, 1, 40),
      missingData: ["Saldo bancário atual (requer integração bancária autorizada)."],
      limitations: ["Lançamentos futuros ainda não cadastrados não aparecem na projeção confirmada."],
    }),
  };
}

export async function agingReport(ctx: TenantContext, now = new Date()) {
  requirePerm(ctx, "finance:read");
  const rows = await loadRows(ctx, and(eq(financeEntries.organizationId, ctx.organizationId), eq(financeEntries.kind, "receivable"), ne(financeEntries.status, "canceled")));
  const a = computeAging(rows, now);
  const fmt = fmtFor(ctx);
  const topLate = await ctx.db.select({ name: companies.name, cents: sql<number>`coalesce(sum(${financeEntries.amountCents}),0)::bigint`, n: sql<number>`count(*)::int` })
    .from(financeEntries).leftJoin(companies, eq(companies.id, financeEntries.companyId))
    .where(and(eq(financeEntries.organizationId, ctx.organizationId), eq(financeEntries.kind, "receivable"), eq(financeEntries.status, "open"), lt(financeEntries.dueDate, now)))
    .groupBy(companies.name).orderBy(desc(sql`sum(${financeEntries.amountCents})`)).limit(8);
  return {
    ...a,
    byClient: topLate.map((t) => ({ name: t.name ?? "Sem cliente vinculado", cents: Number(t.cents), count: Number(t.n) })),
    formula: "Inadimplência (90 dias) = recebíveis vencidos há até 90 dias ainda em aberto ÷ recebíveis com vencimento nos últimos 90 dias (exceto cancelados).",
    evidence: buildEvidence({
      facts: [{ label: "Vencido em aberto", value: `${fmt(a.overdueCents)} (${a.overdueCount} títulos)`, source: SOURCE }],
      confidence: confidenceFrom(rows.length, 0, 30),
      limitations: ["Recebimentos feitos fora do sistema e não baixados aparecem como vencidos."],
    }),
  };
}

export async function profitabilityReport(ctx: TenantContext, by: "client" | "product" = "client", days = 180, now = new Date()) {
  requirePerm(ctx, "finance:read");
  const from = new Date(now.getTime() - days * 864e5);
  const rows = await loadRows(ctx, and(eq(financeEntries.organizationId, ctx.organizationId), ne(financeEntries.status, "canceled"),
    or(and(eq(financeEntries.status, "paid"), gte(financeEntries.paidAt, from)), and(eq(financeEntries.status, "open"), lt(financeEntries.dueDate, now)))!));
  const prof = computeProfitability(rows.map((r) => ({ ...r, refId: (by === "client" ? r.companyId : r.productId) ?? null })));
  const ids = prof.rows.map((r) => r.id);
  const names = ids.length
    ? by === "client"
      ? await ctx.db.select({ id: companies.id, name: companies.name }).from(companies).where(and(eq(companies.organizationId, ctx.organizationId), inArray(companies.id, ids)))
      : await ctx.db.select({ id: products.id, name: products.name }).from(products).where(and(eq(products.organizationId, ctx.organizationId), inArray(products.id, ids)))
    : [];
  const nm = new Map(names.map((n) => [n.id, n.name]));
  const fmt = fmtFor(ctx);
  const linkedPct = prof.totalRevenueCents > 0 ? Math.round(((prof.totalRevenueCents - prof.unlinkedRevenueCents) / prof.totalRevenueCents) * 1000) / 10 : 0;
  return {
    by, days,
    rows: prof.rows.map((r) => ({ ...r, name: nm.get(r.id) ?? "—" })),
    unlinkedRevenueCents: prof.unlinkedRevenueCents, totalRevenueCents: prof.totalRevenueCents, linkedPct,
    note: `${fmt(prof.unlinkedRevenueCents)} de receita recebida (${(100 - linkedPct).toFixed(1)}%) não está vinculada a ${by === "client" ? "um cliente" : "um produto"} e fica fora desta análise.`,
    evidence: buildEvidence({
      facts: [{ label: "Receita recebida vinculada", value: `${linkedPct}%`, source: SOURCE, period: `últimos ${days} dias` }],
      assumptions: ["Custo direto = despesas pagas vinculadas ao mesmo cliente/produto. Despesas gerais não são rateadas."],
      confidence: confidenceFrom(prof.rows.length, prof.totalRevenueCents > 0 && linkedPct < 50 ? 2 : 0, 15),
      limitations: ["Sem rateio de despesas fixas: a margem mostrada é margem direta, não lucro final por cliente/produto."],
    }),
  };
}

export async function breakEvenReport(ctx: TenantContext, now = new Date()) {
  requirePerm(ctx, "finance:read");
  const dre = (await dreReport(ctx, 4, now)).months;
  const be = computeBreakEven(dre, monthKey(now, ctx.timezone), fmtFor(ctx));
  return {
    ...be,
    evidence: buildEvidence({
      facts: [{ label: "Meses-base", value: be.basisMonths.join(", ") || "nenhum", source: SOURCE }],
      assumptions: be.premises, calculations: be.calculations,
      confidence: confidenceFrom(be.basisMonths.length, 0, 3),
      missingData: be.computable ? [] : [be.reason ?? ""],
      limitations: ["Estrutura de custos pode mudar com volume (economias de escala não são modeladas)."],
    }),
  };
}

/* ------------------------------------------------------------------ */
/* Orçamento                                                           */
/* ------------------------------------------------------------------ */

export const budgetInput = z.object({
  categoryId: z.string().uuid(),
  month: z.string().regex(/^\d{4}-(0[1-9]|1[0-2])$/, "Use o formato AAAA-MM"),
  amountCents: z.coerce.number().int().min(0).max(1e13),
});

export async function setBudget(ctx: TenantContext, raw: unknown) {
  requirePerm(ctx, "finance:write");
  const input = budgetInput.parse(raw);
  await owned(ctx, financeCategories, input.categoryId, "Categoria");
  const [b] = await ctx.db.insert(financeBudgets).values({ organizationId: ctx.organizationId, ...input })
    .onConflictDoUpdate({ target: [financeBudgets.organizationId, financeBudgets.categoryId, financeBudgets.month], set: { amountCents: input.amountCents } }).returning();
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "finance.budget.set", resource: "finance_budget", resourceId: b.id, metadata: input, ip: ctx.ip });
  return b;
}

export async function budgetVsActual(ctx: TenantContext, month?: string, now = new Date()) {
  requirePerm(ctx, "finance:read");
  const m = month && /^\d{4}-\d{2}$/.test(month) ? month : monthKey(now, ctx.timezone);
  const budgets = await ctx.db.select({ categoryId: financeBudgets.categoryId, amountCents: financeBudgets.amountCents, name: financeCategories.name, kind: financeCategories.kind })
    .from(financeBudgets).innerJoin(financeCategories, eq(financeCategories.id, financeBudgets.categoryId))
    .where(and(eq(financeBudgets.organizationId, ctx.organizationId), eq(financeBudgets.month, m)));
  const [y, mo] = m.split("-").map(Number);
  const from = new Date(Date.UTC(y, mo - 1, 1) - 2 * 864e5), to = new Date(Date.UTC(y, mo, 1) + 2 * 864e5);
  const paid = await ctx.db.select({ categoryId: financeEntries.categoryId, amountCents: financeEntries.amountCents, paidAt: financeEntries.paidAt })
    .from(financeEntries).where(and(eq(financeEntries.organizationId, ctx.organizationId), eq(financeEntries.status, "paid"), gte(financeEntries.paidAt, from), lt(financeEntries.paidAt, to)));
  const actual = new Map<string, number>();
  for (const p of paid) if (p.categoryId && p.paidAt && monthKey(p.paidAt, ctx.timezone) === m) actual.set(p.categoryId, (actual.get(p.categoryId) ?? 0) + Number(p.amountCents));
  return {
    month: m,
    rows: budgets.map((b) => {
      const a = actual.get(b.categoryId) ?? 0, bud = Number(b.amountCents);
      return { categoryId: b.categoryId, name: b.name, kind: b.kind, budgetCents: bud, actualCents: a, varianceCents: a - bud, usedPct: bud > 0 ? Math.round((a / bud) * 1000) / 10 : null };
    }),
  };
}

/* ------------------------------------------------------------------ */
/* Integrações e receita do CRM (rotuladas separadamente)              */
/* ------------------------------------------------------------------ */

export async function financeIntegrationStatus(ctx: TenantContext) {
  requirePerm(ctx, "finance:read");
  const rows = await ctx.db.select({ provider: integrations.provider, status: integrations.status, mode: integrations.mode, lastSyncAt: integrations.lastSyncAt })
    .from(integrations).where(and(eq(integrations.organizationId, ctx.organizationId), inArray(integrations.provider, ["stripe", "mercadopago", "asaas"])));
  const by = new Map(rows.map((r) => [r.provider, r]));
  const providers = (["stripe", "mercadopago", "asaas"] as const).map((p) => {
    const r = by.get(p);
    const connected = r?.status === "connected" && r.mode === "real";
    return { provider: p, label: { stripe: "Stripe", mercadopago: "Mercado Pago", asaas: "Asaas" }[p], connected, status: connected ? "conectado" : "não conectado", lastSyncAt: r?.lastSyncAt ?? null };
  });
  return {
    providers,
    anyConnected: providers.some((p) => p.connected),
    bank: { connected: false, status: "não disponível nesta versão (requer API bancária autorizada)" },
    erp: { connected: false, status: "não disponível nesta versão" },
    syncNote: "Lançamentos automáticos a partir de provedores ainda não são importados: cadastre-os manualmente.",
  };
}

/** Receita GANHA no CRM (negócios fechados) — diferente de dinheiro recebido. */
export async function crmWonRevenue(ctx: TenantContext, days = 30, now = new Date()) {
  requirePerm(ctx, "finance:read");
  const [r] = await ctx.db.select({ v: sql<number>`coalesce(sum(${opportunities.amountCents}),0)::bigint`, n: sql<number>`count(*)::int` }).from(opportunities)
    .where(and(eq(opportunities.organizationId, ctx.organizationId), eq(opportunities.status, "won"), gte(opportunities.closedAt, new Date(now.getTime() - days * 864e5))));
  return { cents: Number(r.v), deals: Number(r.n), label: "Receita ganha no CRM (negócios fechados, não necessariamente recebida)" };
}

/* ------------------------------------------------------------------ */
/* Assistente financeiro (determinístico)                              */
/* ------------------------------------------------------------------ */

export type FinancialAnswer = {
  intent: string; answer: string; calculations: string[]; premises: string[]; sources: string[];
  evidence: Evidence; missingData: string[]; needsInput?: string;
};

/** Extrai valores em reais do texto: "R$ 5.000", "5000", "5 mil", "5,5 mil". Retorna centavos. */
export function parseMoney(text: string): number | null {
  const t = text.toLowerCase();
  const mil = t.match(/(\d+(?:[.,]\d+)?)\s*mil\b/);
  if (mil) return Math.round(Number(mil[1].replace(",", ".")) * 1000 * 100);
  const rs = t.match(/r\$\s*([\d.]+(?:,\d{1,2})?)/);
  if (rs) return Math.round(Number(rs[1].replace(/\./g, "").replace(",", ".")) * 100);
  const sal = t.match(/(?:sal[aá]rio|custo)[^\d]{0,20}([\d.]+(?:,\d{1,2})?)/);
  if (sal) return Math.round(Number(sal[1].replace(/\./g, "").replace(",", ".")) * 100);
  return null;
}

const WORD_NUM: Record<string, number> = { um: 1, uma: 1, dois: 2, duas: 2, "três": 3, tres: 3, quatro: 4, cinco: 5, seis: 6, sete: 7, oito: 8, nove: 9, dez: 10 };

export function parseHeadcount(text: string): number {
  const t = text.toLowerCase();
  const m = t.match(/contratar\s+(\d+|um|uma|dois|duas|tr[eê]s|quatro|cinco|seis|sete|oito|nove|dez)\b/);
  if (!m) return 1;
  return /^\d+$/.test(m[1]) ? Number(m[1]) : WORD_NUM[m[1]] ?? 1;
}

export async function answerFinancialQuestion(ctx: TenantContext, question: string, now = new Date()): Promise<FinancialAnswer> {
  requirePerm(ctx, "finance:read");
  const q = z.string().trim().min(3).max(500).parse(question);
  const t = q.toLowerCase();
  const fmt = fmtFor(ctx);
  const cur = monthKey(now, ctx.timezone);
  const dre = (await dreReport(ctx, 4, now)).months;
  const full = dre.filter((m) => m.month !== cur && m.lancamentos > 0).slice(-3);
  const avg = (f: (m: DreMonth) => number) => (full.length ? Math.round(full.reduce((s, m) => s + f(m), 0) / full.length) : 0);
  const avgResult = avg((m) => m.resultadoOperacional);
  const avgRevenue = avg((m) => m.receitaBruta);
  const basis = full.map((m) => m.month).join(", ");
  const noData = !full.length;
  const baseMissing = noData ? ["Nenhum mês completo com lançamentos pagos: cadastre receitas e despesas para análises confiáveis."] : [];
  const conf = (extraMissing = 0) => confidenceFrom(full.length, extraMissing, 3);
  const mk = (a: Omit<FinancialAnswer, "evidence"> & { facts?: Evidence["facts"]; confidence?: number }): FinancialAnswer => ({
    ...a,
    evidence: buildEvidence({ facts: a.facts ?? [{ label: "Meses-base", value: basis || "nenhum", source: SOURCE }], assumptions: a.premises, calculations: a.calculations, confidence: a.confidence ?? conf(a.missingData.length), missingData: a.missingData, limitations: ["Análise gerencial: não substitui contador, obrigações fiscais ou regulatórias."] }),
  });

  if (/contrat/.test(t)) {
    const n = parseHeadcount(t);
    const cost = parseMoney(t);
    if (!cost) {
      return mk({
        intent: "hiring", answer: `Para avaliar a contratação de ${n} ${n === 1 ? "pessoa" : "pessoas"}, preciso do custo mensal por pessoa (salário + encargos + benefícios). Não uso valores de salário estimados. Exemplo: "Posso contratar ${n} funcionários com custo de R$ 6.500 cada?"`,
        calculations: [], premises: [], sources: [SOURCE], missingData: ["Custo mensal por pessoa (salário, encargos e benefícios)."], needsInput: "custo_por_pessoa", confidence: 0,
      });
    }
    const hasEncargos = /encargo|benef[ií]cio|custo total/.test(t);
    const total = cost * n;
    const after = avgResult - total;
    const newMargin = avgRevenue > 0 ? Math.round((after / avgRevenue) * 1000) / 10 : null;
    const answer = noData
      ? "Ainda não há histórico financeiro suficiente para avaliar a contratação. Cadastre ao menos um mês completo de receitas e despesas pagas."
      : after >= 0
        ? `Com base no resultado operacional médio de ${fmt(avgResult)}/mês, a contratação (${fmt(total)}/mês) cabe no resultado atual: sobraria ${fmt(after)}/mês (margem operacional de ${newMargin ?? "—"}%). Isso não considera saldo em caixa nem a sazonalidade.`
        : `A contratação custaria ${fmt(total)}/mês, acima do resultado operacional médio de ${fmt(avgResult)}/mês: o resultado ficaria negativo em ${fmt(Math.abs(after))}/mês. Só é sustentável com aumento de receita ou corte de outras despesas.`;
    return mk({
      intent: "hiring", answer,
      calculations: [`Custo adicional = ${n} × ${fmt(cost)} = ${fmt(total)}/mês.`, `Resultado operacional médio (${basis || "sem base"}) = ${fmt(avgResult)}/mês.`, `Resultado após contratação = ${fmt(avgResult)} − ${fmt(total)} = ${fmt(after)}/mês.`],
      premises: [hasEncargos ? "O valor informado já inclui encargos e benefícios." : "O valor informado foi tratado como custo TOTAL por pessoa. Se ele for só o salário, inclua encargos e benefícios para um resultado correto.", "A receita não muda com a contratação (impacto em vendas não é estimado)."],
      sources: [SOURCE], missingData: [...baseMissing, ...(hasEncargos ? [] : ["Confirmação de que o valor inclui encargos e benefícios."]), "Saldo de caixa atual (sem banco conectado)."],
      facts: [{ label: "Resultado operacional médio", value: fmt(avgResult), source: SOURCE, period: basis }],
    });
  }

  if (/marketing|m[ií]dia|investir/.test(t)) {
    const mkt = avg((m) => m.despesasFixas.marketing);
    return mk({
      intent: "marketing_budget",
      answer: noData ? "Ainda não há histórico financeiro para estimar a capacidade de investimento." : avgResult > 0
        ? `Hoje você investe em média ${fmt(mkt)}/mês em marketing (${avgRevenue > 0 ? ((mkt / avgRevenue) * 100).toFixed(1) : "—"}% da receita). O resultado operacional médio é ${fmt(avgResult)}/mês: esse é o teto para aumentar o investimento sem ficar no prejuízo, sem contar retorno das campanhas. Defina um valor e acompanhe CAC e receita gerada antes de ampliar.`
        : `O resultado operacional médio está negativo (${fmt(avgResult)}/mês). Aumentar marketing sem ganho de margem amplia o prejuízo; priorize ações com retorno medido.`,
      calculations: [`Marketing médio = ${fmt(mkt)}/mês.`, `Resultado operacional médio = ${fmt(avgResult)}/mês.`],
      premises: ["Retorno das campanhas não é estimado (sem dados de atribuição suficientes).", "Folga máxima = resultado operacional médio."],
      sources: [SOURCE], missingData: [...baseMissing, "Receita atribuída a campanhas (CAC/ROI por canal)."],
    });
  }

  if (/produto/.test(t) && /margem|rent[aá]v|lucr/.test(t)) {
    const p = await profitabilityReport(ctx, "product", 180, now);
    const top = p.rows.filter((r) => r.revenueCents > 0).sort((a, b) => (b.marginPct ?? -1e9) - (a.marginPct ?? -1e9));
    return mk({
      intent: "product_margin",
      answer: top.length ? `Maior margem direta: ${top[0].name} (${top[0].marginPct}% — receita ${fmt(top[0].revenueCents)}, custos diretos ${fmt(top[0].directCostsCents)}). ${top.length > 1 ? `Menor: ${top[top.length - 1].name} (${top[top.length - 1].marginPct}%).` : ""} ${p.note}` : `Não há receitas vinculadas a produtos nos últimos 180 dias. ${p.note}`,
      calculations: ["Margem direta = (receita recebida − custos diretos vinculados) ÷ receita recebida."],
      premises: p.evidence.assumptions, sources: [SOURCE], missingData: p.linkedPct < 100 ? [p.note] : [],
      facts: [{ label: "Receita vinculada a produtos", value: `${p.linkedPct}%`, source: SOURCE, period: "180 dias" }], confidence: p.evidence.confidence,
    });
  }

  if (/cliente/.test(t) && /preju|rentab|margem|inadimpl|risco|devend/.test(t)) {
    const p = await profitabilityReport(ctx, "client", 180, now);
    const bad = p.rows.filter((r) => r.marginCents < 0 || r.overdueCents > 0).sort((a, b) => (a.marginCents - a.overdueCents) - (b.marginCents - b.overdueCents)).slice(0, 5);
    return mk({
      intent: "clients_profitability",
      answer: bad.length ? `Clientes que mais pesam na rentabilidade: ${bad.map((b) => `${b.name} (margem ${fmt(b.marginCents)}${b.overdueCents ? `, ${fmt(b.overdueCents)} vencido` : ""})`).join("; ")}. ${p.note}` : `Nenhum cliente com margem direta negativa ou valores vencidos nos últimos 180 dias. ${p.note}`,
      calculations: ["Margem direta = receita recebida − custos diretos vinculados ao cliente.", "Vencido = recebíveis em aberto após o vencimento."],
      premises: p.evidence.assumptions, sources: [SOURCE], missingData: p.linkedPct < 100 ? [p.note] : [],
      facts: [{ label: "Clientes analisados", value: String(p.rows.length), source: SOURCE, period: "180 dias" }], confidence: p.evidence.confidence,
    });
  }

  if (/equil[ií]brio|quanto preciso vender|break.?even/.test(t)) {
    const be = await breakEvenReport(ctx, now);
    return mk({
      intent: "break_even",
      answer: be.computable ? `Para cobrir as despesas fixas, você precisa de cerca de ${fmt(be.breakEvenReceitaBruta!)}/mês de receita bruta. Hoje a média é ${fmt(be.avgReceitaBruta)}/mês (${be.gapReceitaBruta! >= 0 ? `${fmt(be.gapReceitaBruta!)} acima` : `${fmt(-be.gapReceitaBruta!)} abaixo`} do equilíbrio).` : `Não foi possível calcular: ${be.reason}`,
      calculations: be.calculations, premises: be.premises, sources: [SOURCE], missingData: be.computable ? [] : [be.reason ?? ""], confidence: be.evidence.confidence,
    });
  }

  if (/caixa|proje|fluxo/.test(t)) {
    const cf = await cashflowReport(ctx, now);
    const w4 = cf.buckets.slice(0, 4).reduce((s, b) => s + b.netCents, 0);
    return mk({
      intent: "cash_projection",
      answer: `Nas próximas 13 semanas, as contas já cadastradas somam ${fmt(cf.totalInflowCents)} a receber e ${fmt(cf.totalOutflowCents)} a pagar (saldo ${fmt(cf.totalInflowCents - cf.totalOutflowCents)}). Nas próximas 4 semanas o saldo confirmado é ${fmt(w4)}. Há ${fmt(cf.overdueReceivableCents)} vencidos a receber fora dessa conta.${cf.estimate ? ` Pela média recorrente, a estimativa semanal é de ${fmt(cf.estimate.weeklyInflowCents)} de entradas e ${fmt(cf.estimate.weeklyOutflowCents)} de saídas.` : ""}`,
      calculations: ["Saldo confirmado = soma dos recebíveis em aberto − soma das contas a pagar em aberto, por vencimento."],
      premises: cf.premises, sources: [SOURCE], missingData: cf.evidence.missingData, facts: cf.evidence.facts, confidence: cf.evidence.confidence,
    });
  }

  return mk({
    intent: "unknown",
    answer: "Ainda não sei responder essa pergunta. Tente: \"Posso contratar 3 funcionários com custo de R$ 6.000 cada?\", \"Quanto posso investir em marketing?\", \"Qual produto tem maior margem?\", \"Quais clientes prejudicam minha rentabilidade?\", \"Quanto preciso vender para atingir o ponto de equilíbrio?\" ou \"Qual é minha projeção de caixa?\".",
    calculations: [], premises: [], sources: [], missingData: [], confidence: 0,
  });
}

export const SUGGESTED_QUESTIONS = [
  "Posso contratar 3 funcionários com custo total de R$ 6.500 cada?",
  "Quanto posso investir em marketing?",
  "Qual produto possui maior margem?",
  "Quais clientes estão prejudicando minha rentabilidade?",
  "Quanto preciso vender para atingir o ponto de equilíbrio?",
  "Qual é minha projeção de caixa?",
];

/** Para o painel: tem algum lançamento? (independe de período) */
export async function hasFinanceData(ctx: TenantContext) {
  requirePerm(ctx, "finance:read");
  const [r] = await ctx.db.select({ id: financeEntries.id }).from(financeEntries).where(eq(financeEntries.organizationId, ctx.organizationId)).limit(1);
  return !!r;
}

