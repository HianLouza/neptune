/**
 * EXPERIMENTATION CENTER — testes A/B com atribuição determinística e avaliação estatística honesta.
 * Resultados só são "significativos" com amostra mínima e p < 0.05 (teste z de duas proporções).
 */
import { eq } from "drizzle-orm";
import type { DB } from "../../db/client";
import { experiments } from "../../db/schema";

export const MIN_SAMPLE_PER_VARIANT = 100;

/** Atribuição estável (mesmo usuário → mesma variante). */
export function assignVariant(experimentKey: string, subjectId: string, variants: { key: string; weight: number }[]) {
  let h = 2166136261;
  for (const c of `${experimentKey}:${subjectId}`) { h ^= c.charCodeAt(0); h = Math.imul(h, 16777619); }
  const bucket = (h >>> 0) % 10000 / 10000;
  const total = variants.reduce((a, v) => a + v.weight, 0) || 1;
  let acc = 0;
  for (const v of variants) { acc += v.weight / total; if (bucket < acc) return v.key; }
  return variants.at(-1)!.key;
}

function normCdf(z: number) {
  const t = 1 / (1 + 0.2316419 * Math.abs(z));
  const d = 0.3989423 * Math.exp(-z * z / 2);
  const p = d * t * (0.3193815 + t * (-0.3565638 + t * (1.781478 + t * (-1.821256 + t * 1.330274))));
  return z > 0 ? 1 - p : p;
}

export function evaluate(variants: { key: string; exposures: number; conversions: number }[]) {
  if (variants.length < 2) return { conclusive: false, message: "Experimento precisa de ao menos 2 variantes." };
  const [a, b] = variants;
  if (a.exposures < MIN_SAMPLE_PER_VARIANT || b.exposures < MIN_SAMPLE_PER_VARIANT) {
    return { conclusive: false, message: `Amostra insuficiente (mínimo ${MIN_SAMPLE_PER_VARIANT} exposições por variante). Resultado INCONCLUSIVO.` };
  }
  const p1 = a.conversions / a.exposures, p2 = b.conversions / b.exposures;
  const p = (a.conversions + b.conversions) / (a.exposures + b.exposures);
  const se = Math.sqrt(p * (1 - p) * (1 / a.exposures + 1 / b.exposures));
  const z = se ? (p2 - p1) / se : 0;
  const pValue = 2 * (1 - normCdf(Math.abs(z)));
  const lift = p1 ? ((p2 - p1) / p1) * 100 : null;
  return {
    conclusive: pValue < 0.05, pValue: Math.round(pValue * 10000) / 10000, z: Math.round(z * 100) / 100,
    rates: { [a.key]: p1, [b.key]: p2 }, liftPct: lift != null ? Math.round(lift * 10) / 10 : null,
    message: pValue < 0.05 ? `Diferença estatisticamente significativa (p=${pValue.toFixed(4)}).` : `Sem significância estatística (p=${pValue.toFixed(4)}). Resultado INCONCLUSIVO.`,
  };
}

export async function recordExposure(db: DB, key: string, variantKey: string, converted: boolean) {
  const [e] = await db.select().from(experiments).where(eq(experiments.key, key));
  if (!e || e.status !== "running") return false;
  const variants = e.variants.map((v) => v.key === variantKey ? { ...v, exposures: v.exposures + 1, conversions: v.conversions + (converted ? 1 : 0) } : v);
  await db.update(experiments).set({ variants }).where(eq(experiments.id, e.id));
  return true;
}
