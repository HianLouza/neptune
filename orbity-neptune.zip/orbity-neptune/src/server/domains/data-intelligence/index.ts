/**
 * DATA INTELLIGENCE & GOVERNANÇA — catálogo canônico de métricas, exportação (portabilidade) e exclusão (LGPD).
 */
import { and, eq } from "drizzle-orm";
import type { DB } from "../../db/client";
import { activities, auditLogs, companies, contacts, conversations, leads, messages, metricDefinitions, opportunities, tasks, dataSources } from "../../db/schema";
import { requirePerm, type TenantContext } from "../../tenancy/context";
import { audit } from "../../audit";
import { HttpError } from "../../http";

export const METRIC_CATALOG = [
  { key: "revenue", name: "Receita", description: "Soma do valor das oportunidades ganhas no período.", formula: "SUM(opportunities.amount_cents) WHERE status='won' AND closed_at IN período", source: "opportunities", dimensions: ["owner", "source", "segment"], periodicity: "daily", owner: "Sales Intelligence" },
  { key: "win_rate", name: "Taxa de conversão", description: "Oportunidades ganhas sobre oportunidades fechadas (ganhas + perdidas) no período.", formula: "COUNT(won) / COUNT(won + lost) WHERE closed_at IN período", source: "opportunities", dimensions: ["owner", "source"], periodicity: "daily", owner: "Sales Intelligence" },
  { key: "leads_generated", name: "Leads gerados", description: "Leads criados no período, por origem.", formula: "COUNT(leads) WHERE created_at IN período", source: "leads", dimensions: ["source", "campaign"], periodicity: "daily", owner: "Prospect.AI" },
  { key: "first_response_time", name: "Tempo de primeira resposta", description: "Tempo entre a primeira mensagem do cliente e a primeira resposta.", formula: "AVG(first_outbound.created_at - first_inbound.created_at)", source: "messages", dimensions: ["channel"], periodicity: "daily", owner: "Closer.AI" },
  { key: "mrr", name: "MRR", description: "Receita recorrente mensal das assinaturas ativas.", formula: "SUM(plans.monthly_price) WHERE subscriptions.status='active'", source: "subscriptions", dimensions: ["plan"], periodicity: "daily", owner: "Billing" },
  { key: "churn", name: "Churn de clientes", description: "Organizações canceladas no mês sobre organizações ativas no início do mês.", formula: "COUNT(canceled no mês) / COUNT(ativas no início)", source: "subscriptions", dimensions: ["plan", "segment"], periodicity: "monthly", owner: "Customer Success" },
  { key: "productivity", name: "Produtividade", description: "Atividades registradas por vendedor ativo no período.", formula: "COUNT(activities) / COUNT(DISTINCT users ativos)", source: "activities", dimensions: ["user", "team"], periodicity: "weekly", owner: "Sales Intelligence" },
];

export async function seedMetricCatalog(db: DB) {
  for (const m of METRIC_CATALOG) await db.insert(metricDefinitions).values({ ...m, version: 1 }).onConflictDoNothing();
}

/** Exportação completa dos dados da organização (portabilidade — formato JSON interoperável). */
export async function exportOrganizationData(ctx: TenantContext) {
  requirePerm(ctx, "export:data");
  const org = ctx.organizationId;
  const [c, ct, l, o, a, t, cv] = await Promise.all([
    ctx.db.select().from(companies).where(eq(companies.organizationId, org)),
    ctx.db.select().from(contacts).where(eq(contacts.organizationId, org)),
    ctx.db.select().from(leads).where(eq(leads.organizationId, org)),
    ctx.db.select().from(opportunities).where(eq(opportunities.organizationId, org)),
    ctx.db.select().from(activities).where(eq(activities.organizationId, org)),
    ctx.db.select().from(tasks).where(eq(tasks.organizationId, org)),
    ctx.db.select().from(conversations).where(eq(conversations.organizationId, org)),
  ]);
  await audit(ctx.db, { organizationId: org, actorId: ctx.userId, action: "data.exported", resource: "organization", resourceId: org, ip: ctx.ip });
  return { exportedAt: new Date().toISOString(), format: "orbity-neptune/export@1", organizationId: org, companies: c, contacts: ct, leads: l, opportunities: o, activities: a, tasks: t, conversations: cv };
}

/** LGPD: direitos do titular — localizar e excluir/anonimizar dados de um contato. */
export async function findDataSubject(ctx: TenantContext, email: string) {
  requirePerm(ctx, "admin:settings");
  const [ct] = await ctx.db.select().from(contacts).where(and(eq(contacts.organizationId, ctx.organizationId), eq(contacts.email, email.toLowerCase())));
  if (!ct) return null;
  const convs = await ctx.db.select().from(conversations).where(eq(conversations.contactId, ct.id));
  return { contact: ct, conversations: convs.length };
}

export async function eraseDataSubject(ctx: TenantContext, email: string) {
  requirePerm(ctx, "admin:settings");
  const found = await findDataSubject(ctx, email);
  if (!found) throw new HttpError(404, "Titular não encontrado.");
  await ctx.db.transaction(async (tx) => {
    const convs = await tx.select({ id: conversations.id }).from(conversations).where(eq(conversations.contactId, found.contact.id));
    for (const c of convs) await tx.update(messages).set({ body: "[conteúdo removido a pedido do titular — LGPD]" }).where(eq(messages.conversationId, c.id));
    await tx.update(contacts).set({ name: "Titular anonimizado", email: null, phone: null, jobTitle: null, consentStatus: "denied" }).where(eq(contacts.id, found.contact.id));
  });
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "lgpd.subject_erased", resource: "contact", resourceId: found.contact.id });
  return { erased: true };
}

export async function dataLineage(ctx: TenantContext) {
  requirePerm(ctx, "audit:read");
  return ctx.db.select().from(dataSources).where(eq(dataSources.organizationId, ctx.organizationId));
}

export async function auditTrail(ctx: TenantContext, limit = 100) {
  requirePerm(ctx, "audit:read");
  const { desc } = await import("drizzle-orm");
  return ctx.db.select().from(auditLogs).where(eq(auditLogs.organizationId, ctx.organizationId)).orderBy(desc(auditLogs.createdAt)).limit(limit);
}
