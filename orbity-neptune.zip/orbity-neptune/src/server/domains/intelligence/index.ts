/**
 * SALES INTELLIGENCE — métricas com definições canônicas (ver data-intelligence/metrics.ts),
 * previsão com cenários/premissas/incerteza e recomendações com evidência.
 * Nunca inventa dados: quando não há base suficiente, retorna "dados insuficientes".
 */
import { and, count, eq, gte, lt, sql, desc, isNotNull } from "drizzle-orm";
import {
  activities, companies, conversations, goals, leads, meetings, memberships, opportunities, pipelineStages, tasks, users,
} from "../../db/schema";
import { requirePerm, type TenantContext } from "../../tenancy/context";
import { slaBreaches } from "../closer";

export type Period = { start: Date; end: Date; prevStart: Date; prevEnd: Date; days: number };
export function periodFromDays(days: number, now = new Date()): Period {
  const end = now, start = new Date(now.getTime() - days * 864e5);
  return { start, end, prevStart: new Date(start.getTime() - days * 864e5), prevEnd: start, days };
}

const pct = (cur: number, prev: number) => (prev === 0 ? (cur > 0 ? null : 0) : Math.round(((cur - prev) / prev) * 1000) / 10);

/** Delegado ao serviço central de métricas (src/server/domains/metrics) — mesma definição em cards, relatórios e Flávio. */
async function kpisFor(ctx: TenantContext, start: Date, end: Date) {
  const { computeKpis, parseMetricFilters } = await import("../metrics");
  const k = await computeKpis(ctx, parseMetricFilters({}), { start, end });
  // Taxa de conversão (definição canônica "win_rate"): ganhas / (ganhas + perdidas) fechadas no período.
  return { leads: k.leads ?? 0, opportunities: k.opportunities, won: k.won, revenueCents: k.revenueCents, conversionRate: k.conversionRate };
}

export async function dashboardKpis(ctx: TenantContext, days = 30) {
  requirePerm(ctx, "intelligence:read");
  const p = periodFromDays(days);
  const [cur, prev] = await Promise.all([kpisFor(ctx, p.start, p.end), kpisFor(ctx, p.prevStart, p.prevEnd)]);
  return {
    period: p, current: cur, previous: prev,
    delta: {
      leads: pct(cur.leads, prev.leads), opportunities: pct(cur.opportunities, prev.opportunities), won: pct(cur.won, prev.won),
      revenue: pct(cur.revenueCents, prev.revenueCents),
      conversionPp: cur.conversionRate != null && prev.conversionRate != null ? Math.round((cur.conversionRate - prev.conversionRate) * 10) / 10 : null,
    },
  };
}

/** Série diária cumulativa de receita ganha e leads. */
export async function performanceSeries(ctx: TenantContext, days = 30) {
  requirePerm(ctx, "intelligence:read");
  const p = periodFromDays(days);
  const rev = await ctx.db.select({ d: sql<string>`to_char(${opportunities.closedAt}, 'YYYY-MM-DD')`, v: sql<number>`sum(${opportunities.amountCents})::bigint` })
    .from(opportunities).where(and(eq(opportunities.organizationId, ctx.organizationId), eq(opportunities.status, "won"), gte(opportunities.closedAt, p.start)))
    .groupBy(sql`1`);
  const lds = await ctx.db.select({ d: sql<string>`to_char(${leads.createdAt}, 'YYYY-MM-DD')`, v: count() })
    .from(leads).where(and(eq(leads.organizationId, ctx.organizationId), gte(leads.createdAt, p.start))).groupBy(sql`1`);
  const revMap = new Map(rev.map((r) => [r.d, Number(r.v)])), leadMap = new Map(lds.map((r) => [r.d, Number(r.v)]));
  const out: { date: string; revenueCents: number; leads: number; cumulativeRevenueCents: number; cumulativeLeads: number }[] = [];
  let cr = 0, cl = 0;
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(Date.now() - i * 864e5).toISOString().slice(0, 10);
    const r = revMap.get(d) ?? 0, l = leadMap.get(d) ?? 0;
    cr += r; cl += l;
    out.push({ date: d, revenueCents: r, leads: l, cumulativeRevenueCents: cr, cumulativeLeads: cl });
  }
  return out;
}

const SOURCE_LABELS: Record<string, string> = { prospect_ai: "Prospect.AI", website: "Site / Formulário", whatsapp: "WhatsApp", referral: "Indicações", import: "Importação", manual: "Manual", other: "Outros" };

export async function leadOrigins(ctx: TenantContext, days = 30) {
  requirePerm(ctx, "intelligence:read");
  const p = periodFromDays(days);
  const rows = await ctx.db.select({ source: leads.source, n: count() }).from(leads)
    .where(and(eq(leads.organizationId, ctx.organizationId), gte(leads.createdAt, p.start))).groupBy(leads.source);
  const total = rows.reduce((a, r) => a + Number(r.n), 0);
  const main = ["prospect_ai", "website", "whatsapp", "referral"];
  const buckets = main.map((k) => ({ key: k, label: SOURCE_LABELS[k], count: Number(rows.find((r) => r.source === k)?.n ?? 0) }));
  buckets.push({ key: "other", label: "Outros", count: rows.filter((r) => !main.includes(r.source)).reduce((a, r) => a + Number(r.n), 0) });
  return { total, buckets: buckets.map((b) => ({ ...b, pct: total ? Math.round((b.count / total) * 100) : 0 })) };
}

/** Sugestões de ação da IA baseadas em regras explícitas (evidência sempre anexada). */
export async function aiActionSuggestions(ctx: TenantContext) {
  requirePerm(ctx, "intelligence:read");
  const org = ctx.organizationId;
  const [hot] = await ctx.db.select({ n: count() }).from(leads).where(and(eq(leads.organizationId, org), gte(leads.score, 80), sql`${leads.status} in ('new','qualifying','qualified')`));
  const fiveDaysAgo = new Date(Date.now() - 5 * 864e5);
  const [stale] = await ctx.db.select({ n: count() }).from(opportunities).where(and(eq(opportunities.organizationId, org), eq(opportunities.status, "open"), lt(opportunities.lastActivityAt, fiveDaysAgo)));
  const breaches = await slaBreaches(ctx.db, org);
  const goal = await mainGoalProgress(ctx);
  const items = [];
  if (Number(hot.n)) items.push({ kind: "hot_leads", title: `${hot.n} leads quentes`, detail: "Alta chance de conversão (score ≥ 80)", href: "/prospect?filtro=quentes", evidence: `Leads abertos com score ≥ 80: ${hot.n}` });
  if (Number(stale.n)) items.push({ kind: "risk", title: "Risco de perda", detail: `${stale.n} oportunidades sem atividade há mais de 5 dias`, href: "/crm?filtro=paradas", evidence: `Oportunidades abertas com última atividade antes de ${fiveDaysAgo.toLocaleDateString("pt-BR")}` });
  if (breaches.length) items.push({ kind: "sla", title: "SLA de atendimento", detail: `${breaches.length} conversas aguardando resposta além do SLA`, href: "/closer?filtro=sla", evidence: `Conversas com prazo de SLA vencido: ${breaches.length}` });
  items.push({ kind: "automation", title: "Automação sugerida", detail: "Nutrição automática para leads novos sem contato em 48h", href: "/automacoes?modelo=nutricao", evidence: "Modelo pronto disponível no Workflow Engine" });
  if (goal) {
    const gap = Math.max(0, 100 - goal.pct);
    items.push({ kind: "goal", title: "Meta em foco", detail: gap > 0 ? `Você está a ${gap}% da meta "${goal.name}"` : `Meta "${goal.name}" atingida!`, href: "/tarefas", evidence: `Realizado ${goal.achieved} de ${goal.target}` });
  }
  return items;
}

export async function mainGoalProgress(ctx: TenantContext) {
  const now = new Date();
  const [g] = await ctx.db.select().from(goals).where(and(eq(goals.organizationId, ctx.organizationId), eq(goals.metric, "revenue"), eq(goals.scope, "organization"), lt(goals.periodStart, now), gte(goals.periodEnd, now))).limit(1);
  if (!g) return null;
  const [w] = await ctx.db.select({ v: sql<number>`coalesce(sum(${opportunities.amountCents}),0)::bigint` }).from(opportunities)
    .where(and(eq(opportunities.organizationId, ctx.organizationId), eq(opportunities.status, "won"), gte(opportunities.closedAt, g.periodStart), lt(opportunities.closedAt, g.periodEnd)));
  const achieved = Number(w.v), target = Number(g.targetValue);
  return { id: g.id, name: g.name, achieved, target, pct: target ? Math.round((achieved / target) * 100) : 0 };
}

export async function teamActivity(ctx: TenantContext) {
  requirePerm(ctx, "intelligence:read");
  const org = ctx.organizationId;
  const dayStart = new Date(); dayStart.setHours(0, 0, 0, 0);
  const dayEnd = new Date(dayStart.getTime() + 864e5);
  const [t] = await ctx.db.select({ n: count() }).from(tasks).where(and(eq(tasks.organizationId, org), gte(tasks.dueAt, dayStart), lt(tasks.dueAt, dayEnd)));
  const [m] = await ctx.db.select({ n: count() }).from(meetings).where(and(eq(meetings.organizationId, org), gte(meetings.startsAt, dayStart), lt(meetings.startsAt, new Date(dayStart.getTime() + 7 * 864e5))));
  const [f] = await ctx.db.select({ n: count() }).from(activities).where(and(eq(activities.organizationId, org), eq(activities.type, "follow_up"), gte(activities.occurredAt, new Date(Date.now() - 7 * 864e5))));
  const sellers = await ctx.db.select({ id: users.id, name: users.name, avatarUrl: users.avatarUrl }).from(memberships).innerJoin(users, eq(users.id, memberships.userId))
    .where(and(eq(memberships.organizationId, org), eq(memberships.status, "active")));
  return { tasksToday: Number(t.n), meetingsWeek: Number(m.n), followUpsWeek: Number(f.n), activeSellers: sellers.length, sellers: sellers.slice(0, 5) };
}

/** Previsão de receita: pipeline ponderado pela probabilidade da etapa, com cenários e premissas explícitas. */
export async function revenueForecast(ctx: TenantContext) {
  requirePerm(ctx, "intelligence:read");
  const rows = await ctx.db.select({ amount: opportunities.amountCents, prob: pipelineStages.probability, stage: pipelineStages.name }).from(opportunities)
    .innerJoin(pipelineStages, eq(pipelineStages.id, opportunities.stageId)).where(and(eq(opportunities.organizationId, ctx.organizationId), eq(opportunities.status, "open")));
  const closed = await ctx.db.select({ status: opportunities.status, n: count() }).from(opportunities)
    .where(and(eq(opportunities.organizationId, ctx.organizationId), sql`${opportunities.status} in ('won','lost')`, gte(opportunities.closedAt, new Date(Date.now() - 90 * 864e5)))).groupBy(opportunities.status);
  const wonN = Number(closed.find((c) => c.status === "won")?.n ?? 0), lostN = Number(closed.find((c) => c.status === "lost")?.n ?? 0);
  const historicalWinRate = wonN + lostN ? wonN / (wonN + lostN) : null;
  const pipelineTotal = rows.reduce((a, r) => a + Number(r.amount), 0);
  const weighted = rows.reduce((a, r) => a + Number(r.amount) * (r.prob / 100), 0);
  const sampleSize = wonN + lostN;
  const uncertainty = sampleSize >= 30 ? 0.15 : sampleSize >= 10 ? 0.25 : 0.4;
  return {
    pipelineTotalCents: pipelineTotal, openDeals: rows.length,
    scenarios: {
      pessimistic: Math.round(weighted * (1 - uncertainty)),
      base: Math.round(weighted),
      optimistic: Math.round(weighted * (1 + uncertainty)),
    },
    historicalWinRate, sampleSize, uncertaintyPct: Math.round(uncertainty * 100),
    assumptions: [
      "Receita esperada = soma(valor × probabilidade da etapa) das oportunidades abertas.",
      "Probabilidades por etapa são configuradas no funil (não aprendidas).",
      `Faixa de incerteza de ±${Math.round(uncertainty * 100)}% definida pelo tamanho da amostra histórica (${sampleSize} negócios fechados em 90 dias).`,
    ],
    limitations: sampleSize < 10 ? ["Amostra histórica pequena: previsão com baixa confiabilidade."] : [],
  };
}

/** Funil: conversão entre etapas e tempo médio. */
export async function funnelAnalysis(ctx: TenantContext) {
  requirePerm(ctx, "intelligence:read");
  const stages = await ctx.db.select({ id: pipelineStages.id, name: pipelineStages.name, position: pipelineStages.position, kind: pipelineStages.kind, n: count(opportunities.id), total: sql<number>`coalesce(sum(${opportunities.amountCents}),0)::bigint` })
    .from(pipelineStages).leftJoin(opportunities, eq(opportunities.stageId, pipelineStages.id))
    .where(eq(pipelineStages.organizationId, ctx.organizationId)).groupBy(pipelineStages.id).orderBy(pipelineStages.position);
  return stages.map((s) => ({ ...s, n: Number(s.n), total: Number(s.total) }));
}

/** Desempenho por vendedor. */
export async function sellerPerformance(ctx: TenantContext, days = 30) {
  requirePerm(ctx, "intelligence:read");
  const p = periodFromDays(days);
  const rows = await ctx.db.select({
    userId: users.id, name: users.name,
    won: sql<number>`count(*) filter (where ${opportunities.status} = 'won' and ${opportunities.closedAt} >= ${p.start})::int`,
    lost: sql<number>`count(*) filter (where ${opportunities.status} = 'lost' and ${opportunities.closedAt} >= ${p.start})::int`,
    open: sql<number>`count(*) filter (where ${opportunities.status} = 'open')::int`,
    revenue: sql<number>`coalesce(sum(${opportunities.amountCents}) filter (where ${opportunities.status} = 'won' and ${opportunities.closedAt} >= ${p.start}),0)::bigint`,
  }).from(opportunities).innerJoin(users, eq(users.id, opportunities.ownerId))
    .where(and(eq(opportunities.organizationId, ctx.organizationId), isNotNull(opportunities.ownerId))).groupBy(users.id, users.name);
  return rows.map((r) => ({ ...r, revenue: Number(r.revenue), winRate: r.won + r.lost ? Math.round((r.won / (r.won + r.lost)) * 100) : null })).sort((a, b) => b.revenue - a.revenue);
}

/** Recomendações estruturadas: problema, evidência, impacto, prioridade, ação, indicador. */
export async function recommendations(ctx: TenantContext) {
  requirePerm(ctx, "intelligence:read");
  const recs: { problem: string; evidence: string; impact: string; priority: "alta" | "média" | "baixa"; action: string; indicator: string }[] = [];
  const funnel = await funnelAnalysis(ctx);
  const open = funnel.filter((f) => f.kind === "open");
  for (let i = 1; i < open.length; i++) {
    const prev = open[i - 1], cur = open[i];
    if (prev.n >= 10 && cur.n / prev.n < 0.35) {
      recs.push({
        problem: `Gargalo entre "${prev.name}" e "${cur.name}"`, evidence: `${prev.n} oportunidades em ${prev.name} vs. ${cur.n} em ${cur.name} (${Math.round((cur.n / prev.n) * 100)}%).`,
        impact: `Valor parado em ${prev.name}: ${(prev.total / 100).toLocaleString(ctx.locale, { style: "currency", currency: ctx.currency })}.`,
        priority: "alta", action: `Revisar critérios de avanço de ${prev.name} e criar cadência de follow-up.`, indicator: `Taxa de passagem ${prev.name} → ${cur.name}`,
      });
    }
  }
  const [stale] = await ctx.db.select({ n: count(), v: sql<number>`coalesce(sum(${opportunities.amountCents}),0)::bigint` }).from(opportunities)
    .where(and(eq(opportunities.organizationId, ctx.organizationId), eq(opportunities.status, "open"), lt(opportunities.lastActivityAt, new Date(Date.now() - 5 * 864e5))));
  if (Number(stale.n) > 0) recs.push({
    problem: "Oportunidades sem atividade", evidence: `${stale.n} oportunidades abertas sem atividade há 5+ dias.`,
    impact: `${(Number(stale.v) / 100).toLocaleString(ctx.locale, { style: "currency", currency: ctx.currency })} em risco.`, priority: "alta",
    action: "Ativar automação de recuperação e distribuir tarefas de follow-up.", indicator: "Oportunidades paradas > 5 dias",
  });
  const [unscored] = await ctx.db.select({ n: count() }).from(leads).where(and(eq(leads.organizationId, ctx.organizationId), sql`${leads.score} is null`));
  if (Number(unscored.n) > 0) recs.push({
    problem: "Leads sem pontuação", evidence: `${unscored.n} leads sem score.`, impact: "Priorização comprometida.", priority: "média",
    action: "Definir ICP e recalcular scores no Prospect.AI.", indicator: "% de leads pontuados",
  });
  const [waiting] = await ctx.db.select({ n: count() }).from(conversations).where(and(eq(conversations.organizationId, ctx.organizationId), eq(conversations.status, "handoff")));
  if (Number(waiting.n) > 0) recs.push({
    problem: "Conversas aguardando humano", evidence: `${waiting.n} conversas em handoff.`, impact: "Risco de perda por tempo de resposta.", priority: "alta",
    action: "Atribuir responsáveis no Closer.AI.", indicator: "Tempo médio de primeira resposta",
  });
  return recs;
}

/** Consulta em linguagem natural → mapeada para métricas conhecidas (sem SQL livre gerado por IA, por segurança). */
export async function naturalLanguageQuery(ctx: TenantContext, q: string) {
  const t = q.toLowerCase();
  const daysMatch = t.match(/(\d+)\s*dias/);
  const days = daysMatch ? Math.min(365, Number(daysMatch[1])) : 30;
  if (/receita|faturamento|vend(as|i)/.test(t)) { const k = await dashboardKpis(ctx, days); return { metric: "revenue", days, answer: k.current, comparison: k.previous }; }
  if (/lead/.test(t)) { const o = await leadOrigins(ctx, days); return { metric: "leads_by_source", days, answer: o }; }
  if (/previs|forecast|projet/.test(t)) return { metric: "forecast", answer: await revenueForecast(ctx) };
  if (/vendedor|equipe|ranking/.test(t)) return { metric: "seller_performance", days, answer: await sellerPerformance(ctx, days) };
  if (/funil|etapa|gargalo/.test(t)) return { metric: "funnel", answer: await funnelAnalysis(ctx) };
  return { metric: null, answer: null, message: "Não reconheci a métrica. Tente: receita, leads, previsão, vendedores ou funil." };
}

export async function topCompanies(ctx: TenantContext) {
  return ctx.db.select({ id: companies.id, name: companies.name }).from(companies).where(eq(companies.organizationId, ctx.organizationId)).orderBy(desc(companies.createdAt)).limit(10);
}
