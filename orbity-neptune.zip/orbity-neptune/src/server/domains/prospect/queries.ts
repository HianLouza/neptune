/** Consultas do Prospect.AI: lista filtrada de leads e exportação CSV (auditada). */
import { and, desc, eq, gte, ilike, or } from "drizzle-orm";
import { companies, contacts, leads } from "../../db/schema";
import { requirePerm, type TenantContext } from "../../tenancy/context";
import { audit } from "../../audit";

export async function listProspectLeads(ctx: TenantContext, opts: { hot?: boolean; status?: string; q?: string; limit?: number; id?: string } = {}) {
  requirePerm(ctx, "prospect:read");
  const conds = [eq(leads.organizationId, ctx.organizationId)];
  if (opts.id) conds.push(eq(leads.id, opts.id));
  if (opts.hot) conds.push(gte(leads.score, 80));
  if (opts.status) conds.push(eq(leads.status, opts.status));
  if (opts.q) conds.push(or(ilike(leads.title, `%${opts.q}%`), ilike(companies.name, `%${opts.q}%`), ilike(contacts.email, `%${opts.q}%`))!);
  return ctx.db.select({
    id: leads.id, title: leads.title, status: leads.status, source: leads.source, score: leads.score, scoreExplanation: leads.scoreExplanation,
    createdAt: leads.createdAt, companyName: companies.name, companySegment: companies.segment, companyRegion: companies.region,
    contactName: contacts.name, contactEmail: contacts.email,
  }).from(leads).leftJoin(companies, eq(companies.id, leads.companyId)).leftJoin(contacts, eq(contacts.id, leads.contactId))
    .where(and(...conds)).orderBy(desc(leads.score), desc(leads.createdAt)).limit(opts.limit ?? 100);
}

export async function getLead(ctx: TenantContext, id: string) {
  requirePerm(ctx, "prospect:read");
  const [r] = await ctx.db.select({ id: leads.id, title: leads.title }).from(leads).where(and(eq(leads.id, id), eq(leads.organizationId, ctx.organizationId)));
  return r ?? null;
}

/** Calcula o score de UM lead pelo ICP ativo (evita reprocessar a base inteira a cada criação). */
export async function scoreOneLead(ctx: TenantContext, leadId: string) {
  const { activeIcp, scoreLead } = await import("./index");
  const icp = await activeIcp(ctx);
  const [r] = await ctx.db.select({ lead: leads, company: companies, contact: contacts }).from(leads)
    .leftJoin(companies, eq(companies.id, leads.companyId)).leftJoin(contacts, eq(contacts.id, leads.contactId))
    .where(and(eq(leads.id, leadId), eq(leads.organizationId, ctx.organizationId)));
  if (!r) return null;
  const { score, explanation } = scoreLead((icp?.criteria as Parameters<typeof scoreLead>[0]) ?? null, {
    segment: r.company?.segment, region: r.company?.region, employees: r.company?.employees, technologies: r.company?.technologies,
    hasEmail: !!r.contact?.email, hasPhone: !!r.contact?.phone, source: r.lead.source,
  });
  await ctx.db.update(leads).set({ score, scoreExplanation: explanation }).where(eq(leads.id, leadId));
  return { score, explanation };
}

const esc = (v: unknown) => {
  const s = v == null ? "" : String(v);
  // Proteção contra CSV/formula injection ao abrir no Excel.
  const safe = /^[=+\-@\t\r]/.test(s) ? `'${s}` : s;
  return /[";\n]/.test(safe) ? `"${safe.replace(/"/g, '""')}"` : safe;
};

export async function exportLeadsCsv(ctx: TenantContext) {
  requirePerm(ctx, "export:data");
  const rows = await ctx.db.select({
    title: leads.title, status: leads.status, source: leads.source, score: leads.score, createdAt: leads.createdAt,
    company: companies.name, segment: companies.segment, region: companies.region, contact: contacts.name, email: contacts.email, phone: contacts.phone,
  }).from(leads).leftJoin(companies, eq(companies.id, leads.companyId)).leftJoin(contacts, eq(contacts.id, leads.contactId))
    .where(eq(leads.organizationId, ctx.organizationId)).orderBy(desc(leads.createdAt)).limit(50_000);
  const header = ["Lead", "Status", "Origem", "Score", "Criado em", "Empresa", "Segmento", "Região", "Contato", "E-mail", "Telefone"];
  const lines = [header.join(";"), ...rows.map((r) => [r.title, r.status, r.source, r.score, r.createdAt.toISOString(), r.company, r.segment, r.region, r.contact, r.email, r.phone].map(esc).join(";"))];
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "data.exported", resource: "leads", metadata: { rows: rows.length, format: "csv" }, ip: ctx.ip });
  return "﻿" + lines.join("\n");
}
