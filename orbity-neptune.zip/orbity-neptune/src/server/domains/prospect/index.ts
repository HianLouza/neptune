/**
 * PROSPECT.AI — ICP, lead scoring explicável, importação CSV (mapeamento, validação, deduplicação), abordagem com IA.
 * Fontes: dados fornecidos pelo cliente (CSV/CRM) e fontes públicas/licenciadas via integrações. Sem base universal de contatos.
 */
import { and, desc, eq, inArray } from "drizzle-orm";
import { z } from "zod";
import { companies, contacts, dataSources, icpProfiles, leads } from "../../db/schema";
import { requirePerm, type TenantContext } from "../../tenancy/context";
import { createLead } from "../crm";
import { createDraft } from "../../ai/collab";
import { audit } from "../../audit";
import { HttpError } from "../../http";
import { publish, EVENT_TYPES } from "../../events";

export const icpInput = z.object({
  name: z.string().trim().min(2).max(120),
  segments: z.array(z.string().trim().min(1).max(80)).max(30).default([]),
  regions: z.array(z.string().trim().min(1).max(80)).max(30).default([]),
  sizes: z.array(z.string().max(20)).max(10).default([]),
  minEmployees: z.coerce.number().int().min(0).optional(),
  maxEmployees: z.coerce.number().int().min(0).optional(),
  technologies: z.array(z.string().max(60)).max(30).default([]),
  needs: z.array(z.string().max(120)).max(20).default([]),
});

export async function saveIcp(ctx: TenantContext, raw: z.input<typeof icpInput>) {
  requirePerm(ctx, "prospect:write");
  const { name, ...criteria } = icpInput.parse(raw);
  await ctx.db.update(icpProfiles).set({ active: false }).where(eq(icpProfiles.organizationId, ctx.organizationId));
  const [icp] = await ctx.db.insert(icpProfiles).values({ organizationId: ctx.organizationId, name, criteria, active: true }).returning();
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "icp.saved", resource: "icp", resourceId: icp.id });
  return icp;
}

export async function activeIcp(ctx: TenantContext) {
  const [icp] = await ctx.db.select().from(icpProfiles).where(and(eq(icpProfiles.organizationId, ctx.organizationId), eq(icpProfiles.active, true))).orderBy(desc(icpProfiles.createdAt)).limit(1);
  return icp ?? null;
}

type Criteria = z.infer<typeof icpInput>;
type ScoreInput = { segment?: string | null; region?: string | null; employees?: number | null; technologies?: string[]; hasEmail: boolean; hasPhone: boolean; source: string };
const norm = (s: string) => s.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().trim();

/**
 * Lead scoring explicável e determinístico (modelo "icp-rules-v1").
 * Cada fator tem peso, valor obtido (0..1) e justificativa. Confiabilidade = fração de fatores com dado disponível.
 */
export function scoreLead(icp: Omit<Criteria, "name"> | null, d: ScoreInput) {
  const factors: { name: string; weight: number; value: number; reason: string; known: boolean }[] = [];
  const push = (name: string, weight: number, value: number, reason: string, known: boolean) => factors.push({ name, weight, value, reason, known });
  if (icp?.segments.length) {
    const ok = !!d.segment && icp.segments.some((s) => norm(s) === norm(d.segment!));
    push("Segmento", 30, ok ? 1 : 0, d.segment ? (ok ? `Segmento "${d.segment}" está no ICP.` : `Segmento "${d.segment}" fora do ICP.`) : "Segmento desconhecido.", !!d.segment);
  }
  if (icp?.regions.length) {
    const ok = !!d.region && icp.regions.some((r) => norm(d.region!).includes(norm(r)));
    push("Região", 15, ok ? 1 : 0, d.region ? (ok ? `Região "${d.region}" atendida.` : `Região "${d.region}" fora da área-alvo.`) : "Região desconhecida.", !!d.region);
  }
  if (icp && (icp.minEmployees != null || icp.maxEmployees != null)) {
    const e = d.employees;
    const ok = e != null && (icp.minEmployees == null || e >= icp.minEmployees) && (icp.maxEmployees == null || e <= icp.maxEmployees);
    push("Porte", 20, ok ? 1 : 0, e != null ? (ok ? `${e} colaboradores dentro da faixa do ICP.` : `${e} colaboradores fora da faixa.`) : "Porte desconhecido.", e != null);
  }
  if (icp?.technologies.length) {
    const techs = (d.technologies ?? []).map(norm);
    const hits = icp.technologies.filter((t) => techs.includes(norm(t)));
    push("Tecnologias", 10, hits.length ? Math.min(1, hits.length / Math.max(1, icp.technologies.length) * 2) : 0, hits.length ? `Usa ${hits.join(", ")}.` : "Nenhuma tecnologia do ICP identificada.", techs.length > 0);
  }
  push("Dados de contato", 15, (d.hasEmail ? 0.6 : 0) + (d.hasPhone ? 0.4 : 0), d.hasEmail || d.hasPhone ? `Contato disponível: ${[d.hasEmail && "e-mail", d.hasPhone && "telefone"].filter(Boolean).join(" e ")}.` : "Sem dados de contato.", true);
  const srcScore: Record<string, number> = { referral: 1, website: 0.9, whatsapp: 0.8, prospect_ai: 0.6, import: 0.5, manual: 0.5, other: 0.4 };
  push("Origem", 10, srcScore[d.source] ?? 0.4, `Origem "${d.source}" com taxa de intenção ${Math.round((srcScore[d.source] ?? 0.4) * 100)}% (heurística inicial).`, true);
  const totalW = factors.reduce((a, f) => a + f.weight, 0) || 1;
  const score = Math.round(factors.reduce((a, f) => a + f.weight * f.value, 0) / totalW * 100);
  const confidence = Math.round(factors.filter((f) => f.known).length / Math.max(1, factors.length) * 100) / 100;
  return { score, explanation: { factors: factors.map(({ known: _k, ...f }) => f), confidence, model: icp ? "icp-rules-v1" : "baseline-v1" } };
}

/** Recalcula a pontuação de todos os leads da organização a partir do ICP ativo. */
export async function rescoreAll(ctx: TenantContext, onlyIds?: string[]) {
  requirePerm(ctx, "prospect:write");
  const icp = await activeIcp(ctx);
  const rows = await ctx.db.select({ lead: leads, company: companies, contact: contacts }).from(leads)
    .leftJoin(companies, eq(companies.id, leads.companyId)).leftJoin(contacts, eq(contacts.id, leads.contactId))
    .where(onlyIds?.length ? and(eq(leads.organizationId, ctx.organizationId), inArray(leads.id, onlyIds)) : eq(leads.organizationId, ctx.organizationId));
  for (const r of rows) {
    const { score, explanation } = scoreLead(icp?.criteria as Criteria | null ?? null, {
      segment: r.company?.segment, region: r.company?.region, employees: r.company?.employees, technologies: r.company?.technologies,
      hasEmail: !!r.contact?.email, hasPhone: !!r.contact?.phone, source: r.lead.source,
    });
    await ctx.db.update(leads).set({ score, scoreExplanation: explanation }).where(eq(leads.id, r.lead.id));
  }
  return { updated: rows.length };
}

/* ---------------- Importação CSV ---------------- */

export function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [], cell = "", q = false;
  const sep = (text.split("\n")[0].match(/;/g)?.length ?? 0) > (text.split("\n")[0].match(/,/g)?.length ?? 0) ? ";" : ",";
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) {
      if (c === '"' && text[i + 1] === '"') { cell += '"'; i++; } else if (c === '"') q = false; else cell += c;
    } else if (c === '"') q = true;
    else if (c === sep) { row.push(cell.trim()); cell = ""; }
    else if (c === "\n" || c === "\r") {
      if (c === "\r" && text[i + 1] === "\n") i++;
      row.push(cell.trim()); cell = "";
      if (row.some((x) => x)) rows.push(row);
      row = [];
    } else cell += c;
  }
  row.push(cell.trim());
  if (row.some((x) => x)) rows.push(row);
  return rows;
}

const FIELD_ALIASES: Record<string, string[]> = {
  company: ["empresa", "company", "razao social", "nome da empresa", "organizacao"],
  contact: ["contato", "nome", "name", "contact", "responsavel"],
  email: ["email", "e-mail", "mail"],
  phone: ["telefone", "phone", "celular", "whatsapp", "fone"],
  segment: ["segmento", "segment", "setor", "industria", "industry"],
  region: ["regiao", "cidade", "estado", "uf", "region", "city"],
  employees: ["funcionarios", "colaboradores", "employees", "porte", "tamanho"],
};

/** Sugere mapeamento automático das colunas (migração assistida). */
export function suggestMapping(headers: string[]) {
  const map: Record<string, number> = {};
  headers.forEach((h, i) => {
    const n = norm(h);
    for (const [field, aliases] of Object.entries(FIELD_ALIASES)) if (map[field] === undefined && aliases.some((a) => n === a || n.includes(a))) map[field] = i;
  });
  return map;
}

export async function importCsv(ctx: TenantContext, csv: string, opts: { mapping?: Record<string, number>; dryRun?: boolean; sourceName?: string; legalBasis?: string } = {}) {
  requirePerm(ctx, "prospect:write");
  if (csv.length > 5_000_000) throw new HttpError(413, "Arquivo muito grande (máx. 5 MB).");
  const rows = parseCsv(csv);
  if (rows.length < 2) throw new HttpError(400, "CSV vazio ou sem linhas de dados.");
  const [header, ...data] = rows;
  const mapping = opts.mapping ?? suggestMapping(header);
  if (mapping.company === undefined && mapping.contact === undefined) throw new HttpError(400, "Não foi possível identificar coluna de empresa ou contato.");
  const report = { total: data.length, created: 0, duplicates: 0, invalid: 0, errors: [] as { line: number; error: string }[], mapping, header };
  const seen = new Set<string>();
  const createdIds: string[] = [];
  const get = (r: string[], f: string) => (mapping[f] !== undefined ? r[mapping[f]]?.trim() : undefined) || undefined;
  for (let i = 0; i < data.length && i < 5000; i++) {
    const r = data[i];
    const company = get(r, "company"), contact = get(r, "contact"), email = get(r, "email")?.toLowerCase();
    if (!company && !contact) { report.invalid++; report.errors.push({ line: i + 2, error: "Sem empresa e sem contato." }); continue; }
    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { report.invalid++; report.errors.push({ line: i + 2, error: `E-mail inválido: ${email}` }); continue; }
    const key = email || norm(company ?? "") + "|" + norm(contact ?? "");
    if (seen.has(key)) { report.duplicates++; continue; }
    seen.add(key);
    if (email) {
      const [dup] = await ctx.db.select({ id: contacts.id }).from(contacts).where(and(eq(contacts.organizationId, ctx.organizationId), eq(contacts.email, email))).limit(1);
      if (dup) { report.duplicates++; continue; }
    }
    if (opts.dryRun) { report.created++; continue; }
    const emp = get(r, "employees");
    const created = await createLead(ctx, {
      title: company ? `${company}${contact ? ` — ${contact}` : ""}` : contact!, companyName: company, contactName: contact ?? undefined,
      contactEmail: email ?? "", contactPhone: get(r, "phone"), source: "import", segment: get(r, "segment"), region: get(r, "region"),
      employees: emp && /^\d+$/.test(emp) ? Number(emp) : undefined,
    });
    createdIds.push(created.id);
    report.created++;
  }
  if (!opts.dryRun) {
    await ctx.db.insert(dataSources).values({ organizationId: ctx.organizationId, name: opts.sourceName ?? "Importação CSV", kind: "csv", classification: "personal", legalBasis: opts.legalBasis ?? "legitimo_interesse", recordsImported: report.created });
    await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "prospect.csv_import", resource: "data_source", metadata: { created: report.created, duplicates: report.duplicates, invalid: report.invalid } });
    if (createdIds.length) await rescoreAll(ctx, createdIds);
  }
  return report;
}

/** Copiloto de abordagem: gera rascunho de mensagem (nunca envia — envio exige aprovação humana). */
/**
 * Copiloto de abordagem: usa o serviço transversal de colaboração com a IA (rascunho versionado, novas sugestões
 * ilimitadas, instruções, edição). O Prospect.AI nunca envia: o funcionário copia o texto escolhido.
 */
export async function draftOutreach(ctx: TenantContext, leadId: string, channel: "email" | "whatsapp" | "linkedin") {
  requirePerm(ctx, "prospect:write");
  const view = await createDraft(ctx, { module: "prospect", subjectId: leadId, channel });
  const current = view.versions.find((v) => v.id === view.currentVersionId);
  return { draftId: view.draft.id, text: current?.content ?? "", simulated: current?.simulated ?? true, status: "success" as const, view };
}

export async function qualifyLead(ctx: TenantContext, leadId: string) {
  requirePerm(ctx, "prospect:write");
  const [l] = await ctx.db.update(leads).set({ status: "qualified" }).where(and(eq(leads.id, leadId), eq(leads.organizationId, ctx.organizationId))).returning();
  if (!l) throw new HttpError(404, "Lead não encontrado.");
  await publish(ctx.db, ctx.organizationId, EVENT_TYPES.LEAD_QUALIFIED, { leadId, by: ctx.userId });
  return l;
}
