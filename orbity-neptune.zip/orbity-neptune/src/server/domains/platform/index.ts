/**
 * PAINEL GLOBAL ORBITY-NEPTUNE — acesso exclusivo de administradores da plataforma.
 * Toda função exige ctx.isPlatformAdmin e toda mutação é auditada.
 */
import { desc, eq, sql } from "drizzle-orm";
import { z } from "zod";
import {
  aiExecutions, coupons, experiments, featureFlagOverrides, featureFlags, healthScoreConfig, incidents, organizations, plans, subscriptions, memberships,
} from "../../db/schema";
import type { TenantContext } from "../../tenancy/context";
import { audit } from "../../audit";
import { HttpError } from "../../http";
import { evaluate } from "../experimentation";
import { openIncident, updateIncident, CATEGORIES, SEVERITIES } from "../incidents";
import { healthOverview, logInteraction, getHealthConfig } from "../customer-success";

export function requirePlatform(ctx: TenantContext) {
  if (!ctx.isPlatformAdmin) throw new HttpError(403, "Acesso restrito à administração da plataforma.");
}
const log = (ctx: TenantContext, action: string, resource: string, resourceId?: string | null, metadata?: Record<string, unknown>) =>
  audit(ctx.db, { organizationId: null, actorId: ctx.userId, action: `platform.${action}`, resource, resourceId, metadata, ip: ctx.ip });

export async function auditPlatformAccess(ctx: TenantContext, area: string) {
  requirePlatform(ctx);
  await log(ctx, "accessed", "platform", null, { area });
}

export async function platformOverview(ctx: TenantContext) {
  requirePlatform(ctx);
  const subs = await ctx.db.select({ orgId: subscriptions.organizationId, status: subscriptions.status, price: plans.monthlyPriceCents, cycle: subscriptions.billingCycle, discount: plans.annualDiscountPct, plan: plans.name, periodEnd: subscriptions.currentPeriodEnd })
    .from(subscriptions).innerJoin(plans, eq(plans.id, subscriptions.planId));
  const active = subs.filter((s) => s.status === "active");
  const priced = active.filter((s) => s.price != null);
  const mrrCents = priced.reduce((a, s) => a + Number(s.price) * (s.cycle === "annual" ? (100 - s.discount) / 100 : 1), 0);
  const orgs = await ctx.db.select({ id: organizations.id, name: organizations.name, status: organizations.status, segment: organizations.segment, isDemo: organizations.isDemo, createdAt: organizations.createdAt, users: sql<number>`(select count(*)::int from ${memberships} m where m.organization_id = ${organizations.id} and m.status = 'active')` }).from(organizations).orderBy(desc(organizations.createdAt));
  const [ai] = await ctx.db.select({ credits: sql<number>`coalesce(sum(${aiExecutions.credits}),0)::int`, tokens: sql<number>`coalesce(sum(${aiExecutions.inputTokens} + ${aiExecutions.outputTokens}),0)::bigint`, runs: sql<number>`count(*)::int`, simulated: sql<number>`count(*) filter (where ${aiExecutions.simulated})::int` }).from(aiExecutions);
  const byStatus = (s: string) => subs.filter((x) => x.status === s).length;
  return {
    orgs: orgs.map((o) => ({ ...o, users: Number(o.users), sub: subs.find((s) => s.orgId === o.id) ?? null })),
    mrrCents, arrCents: mrrCents * 12, pricedActive: priced.length, unpricedActive: active.length - priced.length,
    counts: { active: byStatus("active"), trialing: byStatus("trialing"), pastDue: byStatus("past_due"), suspended: byStatus("suspended"), canceled: byStatus("canceled"), total: subs.length },
    retentionPct: subs.length ? Math.round(((subs.length - byStatus("canceled")) / subs.length) * 1000) / 10 : null,
    ai: { credits: Number(ai.credits), tokens: Number(ai.tokens), runs: Number(ai.runs), simulated: Number(ai.simulated) },
  };
}

export async function setOrganizationStatus(ctx: TenantContext, organizationId: string, status: "active" | "suspended") {
  requirePlatform(ctx);
  if (organizationId === ctx.organizationId && status === "suspended") throw new HttpError(409, "Você não pode suspender a própria organização.");
  const [o] = await ctx.db.update(organizations).set({ status, updatedAt: new Date() }).where(eq(organizations.id, organizationId)).returning();
  if (!o) throw new HttpError(404, "Organização não encontrada.");
  await ctx.db.update(subscriptions).set({ status: status === "suspended" ? "suspended" : "active" }).where(eq(subscriptions.organizationId, organizationId));
  await log(ctx, status === "suspended" ? "org_suspended" : "org_reactivated", "organization", organizationId);
  return o;
}

/* ---------- Feature flags ---------- */
export async function listFlags(ctx: TenantContext) {
  requirePlatform(ctx);
  const flags = await ctx.db.select().from(featureFlags).orderBy(featureFlags.key);
  const ovs = await ctx.db.select({ o: featureFlagOverrides, orgName: organizations.name }).from(featureFlagOverrides).leftJoin(organizations, eq(organizations.id, featureFlagOverrides.organizationId));
  return flags.map((f) => ({ ...f, overrides: ovs.filter((x) => x.o.flagKey === f.key).map((x) => ({ ...x.o, orgName: x.orgName })) }));
}
export const flagInput = z.object({
  key: z.string().trim().regex(/^[a-z0-9_]{2,60}$/, "Use letras minúsculas, números e _"),
  description: z.string().trim().min(3).max(200),
  enabled: z.boolean(),
  rolloutPct: z.coerce.number().int().min(0).max(100),
  plans: z.array(z.enum(["starter", "growth", "business", "enterprise"])).default([]),
  segments: z.array(z.string().max(60)).default([]),
});
export async function saveFlag(ctx: TenantContext, raw: z.input<typeof flagInput>) {
  requirePlatform(ctx);
  const f = flagInput.parse(raw);
  const [r] = await ctx.db.insert(featureFlags).values(f).onConflictDoUpdate({ target: featureFlags.key, set: { description: f.description, enabled: f.enabled, rolloutPct: f.rolloutPct, plans: f.plans, segments: f.segments } }).returning();
  await log(ctx, "flag_saved", "feature_flag", r.id, f);
  return r;
}
export async function setFlagOverride(ctx: TenantContext, flagKey: string, organizationId: string, enabled: boolean | null) {
  requirePlatform(ctx);
  await ctx.db.delete(featureFlagOverrides).where(sql`${featureFlagOverrides.flagKey} = ${flagKey} and ${featureFlagOverrides.organizationId} = ${organizationId}`);
  if (enabled !== null) await ctx.db.insert(featureFlagOverrides).values({ flagKey, organizationId, enabled });
  await log(ctx, "flag_override", "feature_flag", flagKey, { organizationId, enabled });
  return { ok: true };
}

/* ---------- Experimentos ---------- */
export const experimentInput = z.object({
  key: z.string().trim().regex(/^[a-z0-9-]{3,60}$/, "Use letras minúsculas, números e -"),
  hypothesis: z.string().trim().min(10).max(500),
  objective: z.string().trim().min(3).max(200),
  audience: z.string().trim().min(3).max(200),
  primaryMetric: z.string().trim().min(2).max(80),
  owner: z.string().trim().min(2).max(80),
  variantA: z.string().trim().min(1).max(40).default("controle"),
  variantB: z.string().trim().min(1).max(40).default("variante"),
});
export async function listExperiments(ctx: TenantContext) {
  requirePlatform(ctx);
  const ex = await ctx.db.select().from(experiments).orderBy(desc(experiments.createdAt));
  return ex.map((e) => ({ ...e, evaluation: evaluate(e.variants) }));
}
export async function createExperiment(ctx: TenantContext, raw: z.input<typeof experimentInput>) {
  requirePlatform(ctx);
  const i = experimentInput.parse(raw);
  if (i.variantA === i.variantB) throw new HttpError(400, "As variantes precisam ter nomes diferentes.");
  const [e] = await ctx.db.insert(experiments).values({
    key: i.key, hypothesis: i.hypothesis, objective: i.objective, audience: i.audience, primaryMetric: i.primaryMetric, owner: i.owner,
    variants: [{ key: i.variantA, weight: 50, exposures: 0, conversions: 0 }, { key: i.variantB, weight: 50, exposures: 0, conversions: 0 }],
  }).onConflictDoNothing().returning();
  if (!e) throw new HttpError(409, "Já existe um experimento com esta chave.");
  await log(ctx, "experiment_created", "experiment", e.id, { key: i.key });
  return e;
}
export async function setExperimentStatus(ctx: TenantContext, id: string, status: "running" | "stopped" | "concluded", conclusion?: string) {
  requirePlatform(ctx);
  const [e] = await ctx.db.select().from(experiments).where(eq(experiments.id, id));
  if (!e) throw new HttpError(404, "Experimento não encontrado.");
  if (status === "running") {
    // Prevenção de experimentos conflitantes: mesmo público + mesma métrica primária em execução.
    const conflict = await ctx.db.select().from(experiments).where(sql`${experiments.status} = 'running' and ${experiments.id} <> ${id} and ${experiments.audience} = ${e.audience} and ${experiments.primaryMetric} = ${e.primaryMetric}`);
    if (conflict.length) throw new HttpError(409, `Conflito com o experimento "${conflict[0].key}" (mesmo público e métrica).`);
  }
  const ev = evaluate(e.variants);
  const finalConclusion = status === "concluded" ? (conclusion?.trim() || ev.message) : e.conclusion;
  const [u] = await ctx.db.update(experiments).set({ status, conclusion: finalConclusion, startsAt: status === "running" && !e.startsAt ? new Date() : e.startsAt, endsAt: status !== "running" ? new Date() : null }).where(eq(experiments.id, id)).returning();
  await log(ctx, `experiment_${status}`, "experiment", id, { evaluation: ev.message });
  return u;
}

/* ---------- Incidentes ---------- */
export const incidentInput = z.object({
  title: z.string().trim().min(5).max(200),
  category: z.enum(Object.keys(CATEGORIES) as [keyof typeof CATEGORIES, ...(keyof typeof CATEGORIES)[]]),
  severity: z.enum(Object.keys(SEVERITIES) as [keyof typeof SEVERITIES, ...(keyof typeof SEVERITIES)[]]),
  impact: z.string().max(1000).optional(),
});
export async function listIncidents(ctx: TenantContext) {
  requirePlatform(ctx);
  return ctx.db.select().from(incidents).orderBy(desc(incidents.createdAt)).limit(100);
}
export async function createIncident(ctx: TenantContext, raw: z.input<typeof incidentInput>) {
  requirePlatform(ctx);
  return openIncident(ctx.db, ctx.userId, incidentInput.parse(raw));
}
export async function patchIncident(ctx: TenantContext, id: string, raw: { status?: string; note?: string; rootCause?: string; correctiveActions?: string }) {
  requirePlatform(ctx);
  const p = z.object({ status: z.enum(["investigating", "identified", "monitoring", "resolved", "postmortem"]).optional(), note: z.string().max(1000).optional(), rootCause: z.string().max(2000).optional(), correctiveActions: z.string().max(2000).optional() }).parse(raw);
  const r = await updateIncident(ctx.db, ctx.userId, id, p);
  if (!r) throw new HttpError(404, "Incidente não encontrado.");
  return r;
}

/* ---------- Cupons (somente admins globais) ---------- */
export async function listCoupons(ctx: TenantContext) {
  requirePlatform(ctx);
  return ctx.db.select().from(coupons).orderBy(desc(coupons.createdAt));
}
export async function createCoupon(ctx: TenantContext, raw: { code: string; percentOff: number; maxRedemptions?: number | null; expiresAt?: string | null }) {
  requirePlatform(ctx);
  const i = z.object({ code: z.string().trim().toUpperCase().regex(/^[A-Z0-9_-]{3,30}$/), percentOff: z.coerce.number().int().min(1).max(100), maxRedemptions: z.coerce.number().int().positive().nullable().optional(), expiresAt: z.coerce.date().nullable().optional() }).parse(raw);
  const [c] = await ctx.db.insert(coupons).values({ code: i.code, percentOff: i.percentOff, maxRedemptions: i.maxRedemptions ?? null, expiresAt: i.expiresAt ?? null, createdBy: ctx.userId }).onConflictDoNothing().returning();
  if (!c) throw new HttpError(409, "Código de cupom já existe.");
  await log(ctx, "coupon_created", "coupon", c.id, { code: c.code, percentOff: c.percentOff });
  return c;
}

/* ---------- Customer Success ---------- */
export async function csOverview(ctx: TenantContext) {
  requirePlatform(ctx);
  const rows = await healthOverview(ctx.db);
  const counts = { "Saudável": 0, "Atenção": 0, "Risco": 0, "Crítico": 0 } as Record<string, number>;
  rows.forEach((r) => { counts[r.health.status] = (counts[r.health.status] ?? 0) + 1; });
  const soon = Date.now() + 30 * 864e5;
  const renewals = rows.filter((r) => r.periodEnd && new Date(r.periodEnd).getTime() <= soon);
  return { rows, counts, renewals, config: await getHealthConfig(ctx.db) };
}
export async function csLogInteraction(ctx: TenantContext, raw: { organizationId: string; type: string; note: string }) {
  requirePlatform(ctx);
  const i = z.object({ organizationId: z.string().uuid(), type: z.enum(["call", "email", "meeting", "playbook", "task"]), note: z.string().trim().min(3).max(2000) }).parse(raw);
  const r = await logInteraction(ctx.db, i.organizationId, ctx.userId, i.type, i.note);
  await log(ctx, "cs_interaction", "organization", i.organizationId, { type: i.type });
  return r;
}
export async function saveHealthConfig(ctx: TenantContext, raw: { weights: Record<string, number>; thresholds: { healthy: number; attention: number; risk: number } }) {
  requirePlatform(ctx);
  const i = z.object({
    weights: z.record(z.string(), z.coerce.number().min(0).max(1)),
    thresholds: z.object({ healthy: z.coerce.number().int().min(1).max(100), attention: z.coerce.number().int().min(1).max(100), risk: z.coerce.number().int().min(0).max(100) }),
  }).parse(raw);
  if (!(i.thresholds.healthy > i.thresholds.attention && i.thresholds.attention > i.thresholds.risk)) throw new HttpError(400, "Limiares devem obedecer: Saudável > Atenção > Risco.");
  const [cur] = await ctx.db.select().from(healthScoreConfig).limit(1);
  if (cur) await ctx.db.update(healthScoreConfig).set({ weights: i.weights, thresholds: i.thresholds, updatedAt: new Date() }).where(eq(healthScoreConfig.id, cur.id));
  else await ctx.db.insert(healthScoreConfig).values(i);
  await log(ctx, "health_config_saved", "health_score_config", cur?.id ?? null, i);
  return { ok: true };
}
