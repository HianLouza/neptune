/** Registro central dos consumidores de eventos (importado pelo worker e pelas rotas). */
import { and, eq } from "drizzle-orm";
import { registerHandler, processPending, EVENT_TYPES } from "./index";
import { executeApprovedAction, executeDefinition, runWorkflowsForEvent } from "../workflows/engine";
import { notifications, workflowRuns, workflowVersions, approvalRequests, leads } from "../db/schema";
import type { DB } from "../db/client";

let registered = false;
export function registerAllHandlers() {
  if (registered) return;
  registered = true;

  registerHandler({ name: "workflow-engine", types: "*", run: (db, e) => (e.type.startsWith("workflow.") ? Promise.resolve() : runWorkflowsForEvent(db, e)) });

  registerHandler({
    name: "workflow-resume", types: ["workflow.resume"],
    run: async (db, e) => {
      const p = e.payload as { runId: string; node: string | null; data: Record<string, unknown>; _wfDepth: number };
      const [run] = await db.select().from(workflowRuns).where(eq(workflowRuns.id, p.runId));
      if (!run || ["completed", "failed"].includes(run.status)) return;
      const [ver] = await db.select().from(workflowVersions).where(and(eq(workflowVersions.workflowId, run.workflowId), eq(workflowVersions.version, run.version)));
      if (!p.node) { await db.update(workflowRuns).set({ status: "completed", finishedAt: new Date() }).where(eq(workflowRuns.id, run.id)); return; }
      const r = await executeDefinition(ver.definition, p.data, { simulate: false, organizationId: run.organizationId, runId: run.id, depth: p._wfDepth, db, startAt: p.node });
      await db.update(workflowRuns).set({ status: r.status, log: [...run.log, ...r.log], finishedAt: ["completed", "failed"].includes(r.status) ? new Date() : null }).where(eq(workflowRuns.id, run.id));
    },
  });

  registerHandler({
    name: "workflow-approval-resume", types: [EVENT_TYPES.APPROVAL_DECIDED],
    run: async (db, e) => {
      const p = e.payload as { approvalId: string; approved: boolean };
      const [a] = await db.select().from(approvalRequests).where(eq(approvalRequests.id, p.approvalId));
      const ap = a?.payload as { runId?: string; resumeNode?: string | null; data?: Record<string, unknown>; action?: string; config?: Record<string, unknown>; event?: Record<string, unknown>; node?: string } | undefined;
      if (!a || a.kind !== "workflow_step" || !ap?.runId) return;
      const [run] = await db.select().from(workflowRuns).where(eq(workflowRuns.id, ap.runId));
      if (!run || run.status !== "waiting_approval") return;
      const at = () => new Date().toISOString();
      if (!p.approved) {
        await db.update(workflowRuns).set({ status: "completed", finishedAt: new Date(), log: [...run.log, { node: ap.node ?? "approval", status: "rejected", message: "Rejeitado por humano", at: at() }] }).where(eq(workflowRuns.id, run.id));
        return;
      }
      let log = [...run.log];
      // Ação sensível aprovada (send_message / webhook): executa agora, só depois da decisão humana.
      if (ap.action) {
        const r = await executeApprovedAction(db, run.organizationId, { action: ap.action, config: ap.config ?? {}, event: ap.event, runId: run.id }, run.workflowId);
        log.push({ node: ap.node ?? ap.action, status: r.ok ? "ok" : "error", message: `Aprovado por humano. ${r.message}`, at: at() });
        if (!r.ok) { await db.update(workflowRuns).set({ status: "failed", finishedAt: new Date(), log }).where(eq(workflowRuns.id, run.id)); return; }
      } else {
        log.push({ node: "approval", status: "ok", message: "Aprovado por humano", at: at() });
      }
      if (!ap.resumeNode) { await db.update(workflowRuns).set({ status: "completed", finishedAt: new Date(), log }).where(eq(workflowRuns.id, run.id)); return; }
      const [ver] = await db.select().from(workflowVersions).where(and(eq(workflowVersions.workflowId, run.workflowId), eq(workflowVersions.version, run.version)));
      const r = await executeDefinition(ver.definition, ap.data ?? {}, { simulate: false, organizationId: run.organizationId, runId: run.id, workflowId: run.workflowId, depth: run.depth, db, startAt: ap.resumeNode });
      log = [...log, ...r.log];
      await db.update(workflowRuns).set({ status: r.status, log, finishedAt: r.status === "waiting" || r.status === "waiting_approval" ? null : new Date() }).where(eq(workflowRuns.id, run.id));
    },
  });

  registerHandler({
    name: "notifications", types: [EVENT_TYPES.LEAD_QUALIFIED, EVENT_TYPES.LIMIT_REACHED, EVENT_TYPES.OPPORTUNITY_WON, EVENT_TYPES.CONVERSATION_RECEIVED],
    run: async (db, e) => {
      if (!e.organizationId) return;
      const p = e.payload as Record<string, string>;
      const map: Record<string, { title: string; body?: string; href?: string } | null> = {
        [EVENT_TYPES.LEAD_QUALIFIED]: { title: "Lead qualificado", body: await leadTitle(db, p.leadId), href: "/prospect" },
        [EVENT_TYPES.LIMIT_REACHED]: { title: "Limite do plano atingido", body: `Recurso: ${p.metric}`, href: "/billing" },
        [EVENT_TYPES.OPPORTUNITY_WON]: { title: "Negócio ganho! 🎉", href: `/crm/oportunidade/${p.opportunityId}` },
        [EVENT_TYPES.CONVERSATION_RECEIVED]: p.intent === "human" ? { title: "Cliente pediu atendimento humano", href: `/closer?c=${p.conversationId}` } : null,
      };
      const n = map[e.type];
      if (n) await db.insert(notifications).values({ organizationId: e.organizationId, ...n });
    },
  });
}

async function leadTitle(db: DB, id?: string) {
  if (!id) return undefined;
  const [l] = await db.select({ t: leads.title }).from(leads).where(eq(leads.id, id));
  return l?.t;
}

/** Processa a fila logo após a requisição (best-effort). O worker garante o processamento contínuo. */
export function kickOutbox(db: DB) {
  registerAllHandlers();
  setTimeout(() => { processPending(db, { limit: 25 }).catch((err) => console.error(JSON.stringify({ level: "error", msg: "outbox", err: String(err) }))); }, 10);
}
