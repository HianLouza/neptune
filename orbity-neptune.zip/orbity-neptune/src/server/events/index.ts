/**
 * EVENT ENGINE
 *  - Transactional Outbox: `publish` grava o evento na MESMA transação da mudança de domínio.
 *  - Idempotency Keys: chave única evita eventos duplicados.
 *  - Handlers registrados por tipo; cada (evento, handler) só conclui uma vez (tabela event_handler_runs).
 *  - Retry com backoff exponencial; após maxAttempts o evento vai para "dead" (dead-letter queue).
 *  - Versionamento (`version`) e correlação (`correlationId`/`causationId`).
 *
 * O processamento roda no worker (`npm run worker`) e também é disparado após requisições (best-effort).
 * Com REDIS_URL configurado, o worker pode ser escalado horizontalmente; a fonte de verdade continua sendo o outbox.
 */
import { and, asc, eq, inArray, lte, sql } from "drizzle-orm";
import type { DB } from "../db/client";
import { eventHandlerRuns, events } from "../db/schema";

export const EVENT_TYPES = {
  LEAD_CREATED: "lead.created",
  LEAD_QUALIFIED: "lead.qualified",
  OPPORTUNITY_CREATED: "opportunity.created",
  OPPORTUNITY_STAGE_CHANGED: "opportunity.stage_changed",
  OPPORTUNITY_LOST: "opportunity.lost",
  OPPORTUNITY_WON: "opportunity.won",
  CONVERSATION_RECEIVED: "conversation.received",
  MESSAGE_REPLIED: "message.replied",
  MEETING_SCHEDULED: "meeting.scheduled",
  PROPOSAL_SENT: "proposal.sent",
  PAYMENT_CONFIRMED: "payment.confirmed",
  CREDIT_CONSUMED: "credit.consumed",
  LIMIT_REACHED: "limit.reached",
  APPROVAL_DECIDED: "approval.decided",
  // Intelligence Layer (Master Prompt 4.0)
  INSIGHT_CREATED: "insight.created",
  DECISION_APPROVED: "decision.approved",
} as const;
export type EventType = (typeof EVENT_TYPES)[keyof typeof EVENT_TYPES];

export const EVENT_LABELS: Record<string, string> = {
  "lead.created": "Lead criado", "lead.qualified": "Lead qualificado", "opportunity.created": "Oportunidade criada",
  "opportunity.stage_changed": "Etapa da oportunidade alterada", "opportunity.lost": "Oportunidade perdida",
  "opportunity.won": "Oportunidade ganha", "conversation.received": "Conversa recebida", "message.replied": "Mensagem respondida",
  "meeting.scheduled": "Reunião agendada", "proposal.sent": "Proposta enviada", "payment.confirmed": "Pagamento confirmado",
  "credit.consumed": "Crédito consumido", "limit.reached": "Limite atingido", "approval.decided": "Aprovação decidida",
  "insight.created": "Insight da IA gerado", "decision.approved": "Decisão aprovada",
};

export type PublishOptions = { idempotencyKey?: string; correlationId?: string; causationId?: string; version?: number; maxAttempts?: number };
type Executor = Pick<DB, "insert">;

export async function publish(tx: Executor, organizationId: string | null, type: string, payload: Record<string, unknown>, opts: PublishOptions = {}) {
  const rows = await tx.insert(events).values({
    organizationId, type, payload, version: opts.version ?? 1, idempotencyKey: opts.idempotencyKey ?? null,
    correlationId: opts.correlationId ?? crypto.randomUUID(), causationId: opts.causationId ?? null, maxAttempts: opts.maxAttempts ?? 5,
  }).onConflictDoNothing({ target: events.idempotencyKey }).returning({ id: events.id });
  return rows[0]?.id ?? null; // null = evento duplicado ignorado (idempotência)
}

export type EventRecord = typeof events.$inferSelect;
export type Handler = { name: string; types: string[] | "*"; run: (db: DB, e: EventRecord) => Promise<void> };

const g = globalThis as unknown as { __orbityHandlers?: Map<string, Handler> };
const registry = (g.__orbityHandlers ??= new Map());

export function registerHandler(h: Handler) { registry.set(h.name, h); }
export function listHandlers() { return [...registry.values()]; }

export function backoffMs(attempt: number) {
  return Math.min(60 * 60_000, 2 ** attempt * 1000) + Math.floor(Math.random() * 250);
}

/** Processa um lote de eventos pendentes. Retorna estatísticas. */
export async function processPending(db: DB, opts: { limit?: number } = {}) {
  const stats = { processed: 0, failed: 0, dead: 0 };
  const due = await db.select().from(events)
    .where(and(inArray(events.status, ["pending", "failed"]), lte(events.nextAttemptAt, new Date())))
    .orderBy(asc(events.createdAt)).limit(opts.limit ?? 50);

  for (const e of due) {
    // "claim" otimista: só um worker transiciona pending/failed -> processing.
    const claimed = await db.update(events).set({ status: "processing", attempts: sql`${events.attempts} + 1` })
      .where(and(eq(events.id, e.id), inArray(events.status, ["pending", "failed"]))).returning();
    if (!claimed.length) continue;
    const ev = claimed[0];
    const done = new Set((await db.select().from(eventHandlerRuns)
      .where(and(eq(eventHandlerRuns.eventId, ev.id), eq(eventHandlerRuns.status, "done")))).map((r) => r.handler));
    const errors: string[] = [];
    for (const h of registry.values()) {
      if (h.types !== "*" && !h.types.includes(ev.type)) continue;
      if (done.has(h.name)) continue; // idempotência por handler
      try {
        await h.run(db, ev);
        await db.insert(eventHandlerRuns).values({ eventId: ev.id, handler: h.name, status: "done" }).onConflictDoNothing();
      } catch (err) {
        errors.push(`${h.name}: ${(err as Error).message}`);
      }
    }
    if (!errors.length) {
      await db.update(events).set({ status: "done", processedAt: new Date(), lastError: null }).where(eq(events.id, ev.id));
      stats.processed++;
    } else if (ev.attempts >= ev.maxAttempts) {
      await db.update(events).set({ status: "dead", lastError: errors.join(" | ") }).where(eq(events.id, ev.id));
      stats.dead++;
    } else {
      await db.update(events).set({ status: "failed", lastError: errors.join(" | "), nextAttemptAt: new Date(Date.now() + backoffMs(ev.attempts)) })
        .where(eq(events.id, ev.id));
      stats.failed++;
    }
  }
  return stats;
}

/** Recuperação manual: devolve um evento da DLQ para a fila. */
export async function replayEvent(db: DB, eventId: string, organizationId: string | null) {
  const where = organizationId ? and(eq(events.id, eventId), eq(events.organizationId, organizationId)) : eq(events.id, eventId);
  const r = await db.update(events).set({ status: "pending", attempts: 0, nextAttemptAt: new Date(), lastError: null }).where(where).returning();
  return r.length > 0;
}
