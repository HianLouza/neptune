/**
 * Camada de provedores de IA (independente de fornecedor).
 * Ordem de preferência configurável; fallback automático para o próximo provedor disponível.
 * O provedor "local-heuristic" NÃO é um LLM: é determinístico e sempre marcado como SIMULAÇÃO na interface.
 */
import Anthropic from "@anthropic-ai/sdk";

export type ChatMessage = { role: "user" | "assistant"; content: string };
export type CompletionRequest = { system: string; messages: ChatMessage[]; maxTokens: number; model?: string; context?: string };
export type CompletionResult = { text: string; inputTokens: number; outputTokens: number; model: string; provider: string; simulated: boolean };

export interface AIProvider {
  name: string;
  available(): boolean;
  complete(req: CompletionRequest): Promise<CompletionResult>;
}

const estimateTokens = (s: string) => Math.ceil(s.length / 4);

type Effort = "low" | "medium" | "high" | "xhigh" | "max";
const EFFORTS: Effort[] = ["low", "medium", "high", "xhigh", "max"];
let anthropicClient: Anthropic | null = null;
const getAnthropic = () => (anthropicClient ??= new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY, timeout: 120_000, maxRetries: 2 }));

/** Cliente oficial da Anthropic compartilhado (usado também pelo laço de ferramentas do Flávio). */
export const getAnthropicClient = () => getAnthropic();
/** Modelo e esforço configurados no ambiente (mesmas regras do provedor anthropic). */
export const anthropicModel = (requested?: string) => (requested && requested !== "auto" ? requested : (process.env.ANTHROPIC_MODEL || "claude-opus-5-5"));
export const anthropicEffort = (): Effort => { const e = process.env.ANTHROPIC_EFFORT as Effort | undefined; return e && EFFORTS.includes(e) ? e : "medium"; };
/** Fallback de recusa no servidor só existe para os modelos da geração atual. */
export const supportsServerFallback = (model: string) => /^claude-(opus-5|fable-5|sonnet-5-5)/.test(model);

/** Recusa de segurança do modelo. Não é falha técnica: não deve cair para outro provedor. */
export class AIRefusalError extends Error {}

export const anthropicProvider: AIProvider = {
  name: "anthropic",
  available: () => !!process.env.ANTHROPIC_API_KEY,
  async complete(req) {
    const model = req.model && req.model !== "auto" ? req.model : (process.env.ANTHROPIC_MODEL || "claude-opus-5-5");
    const envEffort = process.env.ANTHROPIC_EFFORT as Effort | undefined;
    const effort: Effort = envEffort && EFFORTS.includes(envEffort) ? envEffort : "medium";
    // Fallback no servidor só existe para os modelos da geração atual.
    const supportsFallback = /^claude-(opus-5|fable-5|sonnet-5-5)/.test(model);
    const msg = await getAnthropic().beta.messages.create({
      model,
      max_tokens: Math.max(req.maxTokens, 1024),
      system: req.system,
      messages: req.messages,
      output_config: { effort },
      ...(supportsFallback ? { betas: ["server-side-fallback-2026-07-01"], fallbacks: "default" as const } : {}),
    });
    if (msg.stop_reason === "refusal") throw new AIRefusalError("O modelo recusou este pedido por política de segurança.");
    const text = msg.content.flatMap((b) => (b.type === "text" ? [b.text] : [])).join("\n").trim();
    if (!text) throw new Error(msg.stop_reason === "max_tokens" ? "Limite de tokens do agente atingido antes da resposta. Aumente o limite por execução." : "Resposta vazia do modelo.");
    return { text, inputTokens: msg.usage.input_tokens, outputTokens: msg.usage.output_tokens, model: msg.model, provider: "anthropic", simulated: false };
  },
};

export const openaiProvider: AIProvider = {
  name: "openai",
  available: () => !!process.env.OPENAI_API_KEY && !!process.env.OPENAI_MODEL,
  async complete(req) {
    const model = process.env.OPENAI_MODEL!;
    const res = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: { "content-type": "application/json", authorization: `Bearer ${process.env.OPENAI_API_KEY}` },
      body: JSON.stringify({ model, max_tokens: req.maxTokens, messages: [{ role: "system", content: req.system }, ...req.messages] }),
      signal: AbortSignal.timeout(60_000),
    });
    if (!res.ok) throw new Error(`OpenAI HTTP ${res.status}`);
    const j = (await res.json()) as { choices: { message: { content: string } }[]; usage: { prompt_tokens: number; completion_tokens: number } };
    return { text: j.choices[0]?.message.content ?? "", inputTokens: j.usage.prompt_tokens, outputTokens: j.usage.completion_tokens, model, provider: "openai", simulated: false };
  },
};

/**
 * Provedor local determinístico: responde a partir do CONTEXTO recuperado (RAG) e de regras.
 * Serve para desenvolvimento e como fallback sem custo. Não gera texto criativo.
 */
export const localProvider: AIProvider = {
  name: "local-heuristic",
  available: () => true,
  async complete(req) {
    const question = req.messages.filter((m) => m.role === "user").at(-1)?.content ?? "";
    let text: string;
    if (req.context && req.context.trim()) {
      text = `Com base nas informações disponíveis:\n${req.context.trim().split("\n").slice(0, 8).join("\n")}\n\n(Resposta gerada em modo simulado — configure um provedor de IA para respostas em linguagem natural.)`;
    } else {
      text = `Não encontrei informações suficientes para responder "${question.slice(0, 120)}" com segurança. Posso encaminhar para um especialista humano.\n\n(Modo simulado — nenhum provedor de IA configurado.)`;
    }
    return { text, inputTokens: estimateTokens(req.system + question + (req.context ?? "")), outputTokens: estimateTokens(text), model: "local-heuristic-v1", provider: "local-heuristic", simulated: true };
  },
};

export const PROVIDERS: AIProvider[] = [anthropicProvider, openaiProvider, localProvider];

export function providerChain(preferred?: string): AIProvider[] {
  const avail = PROVIDERS.filter((p) => p.available());
  if (!preferred) return avail;
  return [...avail.filter((p) => p.name === preferred), ...avail.filter((p) => p.name !== preferred)];
}

/** Créditos cobrados por execução: 1 crédito a cada 1.000 tokens (mínimo 1). Simulações custam 0. */
export function creditsFor(r: Pick<CompletionResult, "inputTokens" | "outputTokens" | "simulated">) {
  if (r.simulated) return 0;
  return Math.max(1, Math.ceil((r.inputTokens + r.outputTokens) / 1000));
}
