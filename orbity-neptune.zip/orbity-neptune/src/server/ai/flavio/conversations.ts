/**
 * Investigações do Flávio / Business Brain — conversas persistidas com contexto (flavio_conversations / flavio_messages).
 * Isolamento: cada usuário vê e apaga SÓ as próprias investigações, na própria organização.
 */
import { and, asc, count, desc, eq, inArray } from "drizzle-orm";
import { flavioConversations, flavioMessages } from "../../db/schema";
import { requirePerm, type TenantContext } from "../../tenancy/context";
import { HttpError } from "../../http";
import { audit } from "../../audit";

export type Surface = "brain" | "dock";

/** Contexto que dá continuidade à investigação (follow-ups não precisam repetir o assunto). */
export type InvestigationContext = {
  topic?: string; topicLabel?: string; days?: number; lastQuestion?: string; lastTools?: string[];
  /** Ferramentas e assunto da pergunta que ABRIU a investigação ("o que podemos fazer?" volta a ela). */
  rootTools?: string[]; rootTopicLabel?: string;
  findings?: string[]; recommendations?: string[]; entities?: string[]; lastIntent?: string;
};

const uuidRe = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export async function getOwnConversation(ctx: TenantContext, id: string) {
  requirePerm(ctx, "ai:use");
  if (!uuidRe.test(id)) throw new HttpError(404, "Investigação não encontrada.");
  const [c] = await ctx.db.select().from(flavioConversations)
    .where(and(eq(flavioConversations.id, id), eq(flavioConversations.organizationId, ctx.organizationId), eq(flavioConversations.userId, ctx.userId)));
  if (!c) throw new HttpError(404, "Investigação não encontrada.");
  return c;
}

export async function createConversation(ctx: TenantContext, title: string, surface: Surface) {
  requirePerm(ctx, "ai:use");
  const [c] = await ctx.db.insert(flavioConversations).values({
    organizationId: ctx.organizationId, userId: ctx.userId, title: title.trim().slice(0, 120) || "Nova investigação", surface,
  }).returning();
  return c;
}

export async function appendMessage(ctx: TenantContext, conversationId: string, m: { role: "user" | "assistant"; content: string; payload?: Record<string, unknown> | null; executionId?: string | null }) {
  const [row] = await ctx.db.insert(flavioMessages).values({
    organizationId: ctx.organizationId, conversationId, role: m.role, content: m.content.slice(0, 20000), payload: m.payload ?? null, executionId: m.executionId ?? null,
  }).returning();
  return row;
}

export async function saveContext(ctx: TenantContext, conversationId: string, context: InvestigationContext) {
  await ctx.db.update(flavioConversations).set({ context: context as Record<string, unknown>, updatedAt: new Date() })
    .where(and(eq(flavioConversations.id, conversationId), eq(flavioConversations.organizationId, ctx.organizationId), eq(flavioConversations.userId, ctx.userId)));
}

export async function listInvestigations(ctx: TenantContext, opts: { surface?: Surface; limit?: number } = {}) {
  requirePerm(ctx, "ai:use");
  const conds = [eq(flavioConversations.organizationId, ctx.organizationId), eq(flavioConversations.userId, ctx.userId), eq(flavioConversations.status, "active")];
  if (opts.surface) conds.push(eq(flavioConversations.surface, opts.surface));
  const rows = await ctx.db.select().from(flavioConversations).where(and(...conds)).orderBy(desc(flavioConversations.updatedAt)).limit(opts.limit ?? 40);
  const ids = rows.map((r) => r.id);
  const counts = ids.length ? await ctx.db.select({ id: flavioMessages.conversationId, n: count() }).from(flavioMessages).where(inArray(flavioMessages.conversationId, ids)).groupBy(flavioMessages.conversationId) : [];
  const n = new Map(counts.map((c) => [c.id, Number(c.n)]));
  return rows.map((r) => ({ id: r.id, title: r.title, surface: r.surface as Surface, createdAt: r.createdAt.toISOString(), updatedAt: r.updatedAt.toISOString(), messages: n.get(r.id) ?? 0, topic: (r.context as InvestigationContext).topicLabel ?? null }));
}

export async function getInvestigation(ctx: TenantContext, id: string) {
  const c = await getOwnConversation(ctx, id);
  const msgs = await ctx.db.select().from(flavioMessages).where(and(eq(flavioMessages.conversationId, c.id), eq(flavioMessages.organizationId, ctx.organizationId))).orderBy(asc(flavioMessages.createdAt));
  return {
    id: c.id, title: c.title, surface: c.surface as Surface, context: c.context as InvestigationContext, createdAt: c.createdAt.toISOString(), updatedAt: c.updatedAt.toISOString(),
    messages: msgs.map((m) => ({ id: m.id, role: m.role as "user" | "assistant", content: m.content, payload: m.payload, createdAt: m.createdAt.toISOString() })),
  };
}

/** LGPD: apaga de verdade (não só oculta) a investigação do próprio usuário, ou todas. Mantém registro de auditoria sem conteúdo. */
export async function deleteInvestigations(ctx: TenantContext, id?: string) {
  requirePerm(ctx, "ai:use");
  if (id) await getOwnConversation(ctx, id);
  const conds = [eq(flavioConversations.organizationId, ctx.organizationId), eq(flavioConversations.userId, ctx.userId)];
  if (id) conds.push(eq(flavioConversations.id, id));
  const res = await ctx.db.delete(flavioConversations).where(and(...conds)).returning({ id: flavioConversations.id });
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "flavio.investigation.deleted", resource: "flavio_conversation", resourceId: id ?? null, metadata: { count: res.length, scope: id ? "one" : "all" } });
  return { deleted: res.length };
}
