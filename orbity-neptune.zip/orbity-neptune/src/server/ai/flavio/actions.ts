/**
 * Ações do Flávio — o assistente PREPARA, o usuário CONFIRMA, o backend EXECUTA.
 *
 * Fluxo:
 *  1. A análise gera uma proposta (tipo + dados) e o servidor a assina (HMAC-SHA256, chave derivada de ENCRYPTION_KEY),
 *     vinculando organização, usuário, validade (15 min) e um identificador único.
 *  2. A interface mostra o resumo e pede confirmação explícita.
 *  3. Na confirmação o servidor verifica assinatura, validade, usuário/organização, permissão ATUAL e posse dos registros,
 *     executa pelos serviços de domínio existentes dentro de uma transação (tudo ou nada) e registra auditoria.
 *  4. A mesma proposta não pode ser executada duas vezes (trava transacional + registro de auditoria).
 * O modelo de IA nunca chama estas funções.
 */
import crypto from "node:crypto";
import { and, eq, sql } from "drizzle-orm";
import { z } from "zod";
import { auditLogs, leads, memberships, opportunities, tasks } from "../../db/schema";
import { assertOwned, createTask, updateLeadStatus } from "../../domains/crm";
import { saveWorkflow } from "../../workflows/engine";
import { TEMPLATES } from "../../workflows/templates";
import { createDecision } from "../../intelligence-layer/decisions";
import { saveScenario } from "../../domains/strategy";
import { audit } from "../../audit";
import { HttpError } from "../../http";
import { requirePerm, type TenantContext } from "../../tenancy/context";
import type { Permission } from "../../permissions";

const uuid = z.string().uuid();
export const AUTOMATION_TEMPLATES = ["nutricao", "perda", "lead-quente"] as const;

export const taskItemSchema = z.object({
  title: z.string().trim().min(2).max(200),
  description: z.string().max(2000).optional(),
  dueAt: z.string().datetime().optional(),
  priority: z.enum(["low", "medium", "high"]).default("medium"),
  opportunityId: uuid.optional(),
  leadId: uuid.optional(),
  assigneeId: uuid.optional(),
});

export const actionSchema = z.discriminatedUnion("kind", [
  z.object({ kind: z.literal("create_tasks"), items: z.array(taskItemSchema).min(1).max(20) }),
  z.object({ kind: z.literal("draft_automation"), templateKey: z.enum(AUTOMATION_TEMPLATES) }),
  z.object({ kind: z.literal("update_lead_status"), leadId: uuid, status: z.enum(["new", "qualifying", "qualified", "disqualified"]) }),
  // Business Brain: recomendação → decisão registrada (vai para aprovação no Decision Engine) e cenário salvo no Simulador.
  z.object({ kind: z.literal("register_decision"), title: z.string().trim().min(3).max(200), problem: z.string().trim().min(3).max(2000),
    alternatives: z.array(z.object({ name: z.string().trim().min(2).max(120), description: z.string().trim().max(1000).default("") })).max(6).default([]) }),
  z.object({ kind: z.literal("save_scenario"), name: z.string().trim().min(3).max(120),
    scenarioKind: z.enum(["price", "cost", "hiring", "volume", "conversion", "marketing", "churn", "custom"]).default("custom"),
    variables: z.object({ priceChangePct: z.number().optional(), volumeChangePct: z.number().optional(), fixedCostChangePct: z.number().optional(), newHires: z.number().int().optional(), monthlyCostPerHireCents: z.number().int().nullable().optional() }) }),
]);
export type FlavioAction = z.infer<typeof actionSchema>;

export const ACTION_PERMISSION: Record<FlavioAction["kind"], Permission> = {
  create_tasks: "crm:write", draft_automation: "automations:write", update_lead_status: "crm:write",
  register_decision: "intelligence:read", save_scenario: "strategy:write",
};

export type ActionProposal = {
  token: string; kind: FlavioAction["kind"]; title: string; summary: string; details: string[];
  permission: Permission; allowed: boolean; expiresAt: string; changesData: true;
};

const TTL_MS = 15 * 60 * 1000;

function signingKey() {
  const raw = process.env.ENCRYPTION_KEY;
  if (!raw) throw new HttpError(503, "Ações do Flávio indisponíveis: chave do servidor não configurada.");
  return crypto.createHash("sha256").update("flavio-actions:v1:" + raw).digest();
}
const b64 = (s: string) => Buffer.from(s, "utf8").toString("base64url");
const unb64 = (s: string) => Buffer.from(s, "base64url").toString("utf8");

type Signed = { v: 1; id: string; org: string; user: string; exp: number; action: FlavioAction; title: string; summary: string; details: string[] };

/** Cria uma proposta assinada. Não executa nada. */
export function proposeAction(ctx: TenantContext, action: FlavioAction, text: { title: string; summary: string; details?: string[] }, now = Date.now()): ActionProposal {
  const parsed = actionSchema.parse(action);
  const body: Signed = { v: 1, id: crypto.randomUUID(), org: ctx.organizationId, user: ctx.userId, exp: now + TTL_MS, action: parsed, title: text.title, summary: text.summary, details: (text.details ?? []).slice(0, 25) };
  const payload = b64(JSON.stringify(body));
  const sig = crypto.createHmac("sha256", signingKey()).update(payload).digest("base64url");
  const permission = ACTION_PERMISSION[parsed.kind];
  return {
    token: `${payload}.${sig}`, kind: parsed.kind, title: body.title, summary: body.summary, details: body.details,
    permission, allowed: ctx.permissions.includes("*") || ctx.permissions.includes(permission), expiresAt: new Date(body.exp).toISOString(), changesData: true,
  };
}

/** Valida a proposta (assinatura, validade, dono). Lança erro 400/403 com motivo legível. */
export function verifyProposal(ctx: TenantContext, token: string, now = Date.now()): Signed {
  const [payload, sig] = String(token ?? "").split(".");
  if (!payload || !sig) throw new HttpError(400, "Proposta inválida.");
  const expected = crypto.createHmac("sha256", signingKey()).update(payload).digest();
  const given = Buffer.from(sig, "base64url");
  if (given.length !== expected.length || !crypto.timingSafeEqual(given, expected)) throw new HttpError(400, "Proposta adulterada ou inválida.");
  let body: Signed;
  try { body = JSON.parse(unb64(payload)); } catch { throw new HttpError(400, "Proposta inválida."); }
  if (body.v !== 1) throw new HttpError(400, "Versão de proposta não suportada.");
  if (body.org !== ctx.organizationId || body.user !== ctx.userId) throw new HttpError(403, "Esta proposta pertence a outro usuário ou organização.");
  if (now > body.exp) throw new HttpError(410, "A proposta expirou. Peça ao Flávio para prepará-la de novo.");
  body.action = actionSchema.parse(body.action);
  return body;
}

async function assertMember(ctx: TenantContext, userId: string) {
  const [m] = await ctx.db.select({ id: memberships.id }).from(memberships)
    .where(and(eq(memberships.organizationId, ctx.organizationId), eq(memberships.userId, userId), eq(memberships.status, "active")));
  if (!m) throw new HttpError(404, "Responsável não pertence à organização.");
}

/** Confirma e executa a proposta. Tudo ou nada. */
export async function confirmAction(ctx: TenantContext, token: string) {
  const body = verifyProposal(ctx, token);
  const action = body.action;
  requirePerm(ctx, ACTION_PERMISSION[action.kind]); // permissão ATUAL (pode ter mudado desde a proposta)

  try {
    const result = await ctx.db.transaction(async (tx) => {
      // Trava pela proposta: duas confirmações simultâneas não executam duas vezes.
      await tx.execute(sql`select pg_advisory_xact_lock(hashtext(${"flavio:" + body.id}))`);
      const [done] = await tx.select({ id: auditLogs.id }).from(auditLogs)
        .where(and(eq(auditLogs.organizationId, ctx.organizationId), eq(auditLogs.action, "flavio.action.executed"), eq(auditLogs.resourceId, body.id))).limit(1);
      if (done) throw new HttpError(409, "Esta proposta já foi executada.");
      const tctx = { ...ctx, db: tx as unknown as TenantContext["db"] };

      let out: { message: string; records: { kind: string; id: string; href: string }[] };
      if (action.kind === "create_tasks") {
        const records: { kind: string; id: string; href: string }[] = [];
        for (const it of action.items) {
          if (it.opportunityId) await assertOwned(tctx, opportunities, it.opportunityId);
          if (it.leadId) await assertOwned(tctx, leads, it.leadId);
          if (it.assigneeId) await assertMember(tctx, it.assigneeId);
          const t = await createTask(tctx, { title: it.title, description: it.description, priority: it.priority, dueAt: it.dueAt, opportunityId: it.opportunityId, assigneeId: it.assigneeId });
          if (it.leadId) await tx.update(tasks).set({ leadId: it.leadId }).where(and(eq(tasks.id, t.id), eq(tasks.organizationId, ctx.organizationId)));
          records.push({ kind: "task", id: t.id, href: "/tarefas" });
        }
        out = { message: `${records.length} tarefa(s) criada(s).`, records };
      } else if (action.kind === "draft_automation") {
        const tpl = TEMPLATES.find((t) => t.key === action.templateKey);
        if (!tpl) throw new HttpError(404, "Modelo de automação não encontrado.");
        const wf = await saveWorkflow(tctx, { name: `${tpl.name} (preparada pelo Flávio)`, description: tpl.description, triggerEvent: tpl.triggerEvent, definition: tpl.definition });
        out = { message: `Automação "${wf.name}" criada como RASCUNHO. Revise, simule e publique em Automações.`, records: [{ kind: "workflow", id: wf.id, href: "/automacoes" }] };
      } else if (action.kind === "register_decision") {
        const d = await createDecision(tctx, { title: action.title, problem: action.problem, alternatives: action.alternatives.map((a) => ({ name: a.name, description: a.description })) });
        out = { message: `Decisão "${d.title}" registrada como rascunho. Envie para aprovação no Command Center.`, records: [{ kind: "decision", id: d.id, href: "/command-center" }] };
      } else if (action.kind === "save_scenario") {
        const sc = await saveScenario(tctx, { name: action.name, kind: action.scenarioKind, variables: action.variables });
        out = { message: `Cenário "${sc.name}" salvo no Simulador Estratégico (rascunho).`, records: [{ kind: "scenario", id: sc.id, href: "/simulador" }] };
      } else {
        await assertOwned(tctx, leads, action.leadId);
        const l = await updateLeadStatus(tctx, action.leadId, action.status);
        out = { message: `Lead "${l.title}" atualizado para "${action.status}".`, records: [{ kind: "lead", id: l.id, href: `/prospect?lead=${l.id}` }] };
      }
      await audit(tx as unknown as TenantContext["db"], {
        organizationId: ctx.organizationId, actorId: ctx.userId, action: "flavio.action.executed", resource: "flavio_action", resourceId: body.id,
        metadata: { kind: action.kind, title: body.title, summary: body.summary, records: out.records.map((r) => `${r.kind}:${r.id}`), confirmedBy: ctx.userId, via: "flavio" }, ip: ctx.ip,
      });
      return out;
    });
    return { ok: true as const, proposalId: body.id, kind: action.kind, ...result };
  } catch (err) {
    if (!(err instanceof HttpError && err.status === 409)) {
      await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "flavio.action.failed", resource: "flavio_action", resourceId: body.id, metadata: { kind: action.kind, error: (err as Error).message.slice(0, 300) }, ip: ctx.ip });
    }
    throw err;
  }
}
