/**
 * FLÁVIO — Assistente de Inteligência Comercial.
 *
 * Não é um segundo motor de IA: é a identidade conversacional sobre a infraestrutura existente.
 *   pergunta → guardrails → intenção (determinística) → análise (serviço central de métricas, com permissões)
 *            → narrativa: runAgent (agente "executive", mesmas proteções, créditos e auditoria) com a persona do Flávio
 *            → se não houver provedor real, ou se ele falhar: narrativa determinística das próprias métricas.
 * Os números exibidos vêm sempre da análise, nunca do texto do modelo.
 */
import { and, desc, eq, gte, inArray } from "drizzle-orm";
import { z } from "zod";
import { aiAgents, aiExecutions } from "../../db/schema";
import { requirePerm, can, type TenantContext } from "../../tenancy/context";
import { audit } from "../../audit";
import { checkInput } from "../guardrails";
import { AgentDisabledError, runAgent } from "../orchestrator";
import { PROVIDERS, type ChatMessage } from "../providers";
import { PERIOD_PRESETS, metricFiltersSchema, type MetricFilters } from "../../../lib/metrics-filters";
import { FLAVIO, FLAVIO_PERSONA, moduleFor, suggestionsFor } from "./identity";
import { INTENTS, INTENT_LABELS, classifyIntent, isFollowUp, periodFromText, type Intent } from "./intents";
import { contextForModel, narrative, runAnalysis, type Analysis } from "./analyses";
import { appendMessage, createConversation, getOwnConversation, saveContext, type InvestigationContext } from "./conversations";

export { FLAVIO };

export const askSchema = z.object({
  message: z.string().trim().min(1).max(2000),
  route: z.string().max(300).optional(),
  filters: z.record(z.string(), z.unknown()).optional(),
  /** Início da conversa atual (ISO). O histórico enviado ao modelo é lido do servidor a partir daqui. */
  conversationSince: z.string().datetime().optional(),
  lastIntent: z.enum(INTENTS).optional(),
  /** Investigação persistida (flavio_conversations) à qual esta pergunta pertence. */
  conversationId: z.string().uuid().optional(),
});
export type AskInput = z.input<typeof askSchema>;

export type FlavioMode = "ia" | "deterministico" | "bloqueado" | "indisponivel";
export type FlavioAnswer = {
  executionId: string | null; text: string; mode: FlavioMode; intent: Intent | null; intentLabel: string | null;
  analysis: Analysis | null; suggestions: string[]; screen: { route: string | null; module: string };
  provider: string; model: string; credits: number; simulated: boolean; warnings: string[]; at: string;
  /** Investigação onde a troca foi salva (abre no Business Brain). */
  conversationId?: string | null;
};

const DETERMINISTIC_MODEL = "flavio-metricas-v1";

export function realProviderAvailable() {
  return PROVIDERS.some((p) => p.name !== "local-heuristic" && p.available());
}

function lenientFilters(raw: unknown): MetricFilters {
  const r = metricFiltersSchema.safeParse(raw ?? {});
  return r.success ? r.data : metricFiltersSchema.parse({});
}

function applyTextPeriod(f: MetricFilters, message: string, now: Date): MetricFilters {
  const p = periodFromText(message);
  if (!p) return f;
  if (p.days && (PERIOD_PRESETS as readonly number[]).includes(p.days)) return { ...f, days: p.days, from: undefined, to: undefined };
  const iso = (d: Date) => d.toISOString().slice(0, 10);
  if (p.month === "current") return { ...f, from: iso(new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1))), to: iso(now) };
  if (p.month === "previous") return { ...f, from: iso(new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - 1, 1))), to: iso(new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 0))) };
  return f;
}

/** Histórico confiável (lido do servidor), nunca o enviado pelo navegador. */
async function serverHistory(ctx: TenantContext, since?: string): Promise<ChatMessage[]> {
  if (!since) return [];
  const from = new Date(Math.max(Date.parse(since), Date.now() - 24 * 3600e3));
  const rows = await ctx.db.select({ input: aiExecutions.input, output: aiExecutions.output }).from(aiExecutions)
    .where(and(eq(aiExecutions.organizationId, ctx.organizationId), eq(aiExecutions.userId, ctx.userId), eq(aiExecutions.agentKey, FLAVIO.agentKey),
      inArray(aiExecutions.status, ["success", "fallback"]), gte(aiExecutions.createdAt, from)))
    .orderBy(desc(aiExecutions.createdAt)).limit(5);
  return rows.reverse().flatMap((r) => [{ role: "user" as const, content: r.input.slice(0, 1500) }, { role: "assistant" as const, content: (r.output ?? "").slice(0, 2000) }]);
}

export async function flavioStatus(ctx: TenantContext) {
  const canUse = can(ctx, "ai:use");
  const [agent] = await ctx.db.select({ enabled: aiAgents.enabled }).from(aiAgents).where(and(eq(aiAgents.organizationId, ctx.organizationId), eq(aiAgents.key, FLAVIO.agentKey)));
  const real = realProviderAvailable();
  const available = canUse && !!agent?.enabled;
  return {
    name: FLAVIO.name, title: FLAVIO.title, greeting: FLAVIO.greeting, available, canUse,
    agentEnabled: !!agent?.enabled, mode: (real ? "ia" : "deterministico") as FlavioMode,
    reason: !canUse ? "Seu perfil não tem a permissão ai:use." : !agent ? "Agente executivo não provisionado nesta organização." : !agent.enabled ? "O administrador desativou o agente executivo (IA e Agentes)." : null,
    modeLabel: real ? "IA conectada" : "Modo determinístico: respostas calculadas das métricas, sem modelo de IA",
  };
}

/**
 * Pergunta pelo painel do Flávio (dock). A troca é salva na MESMA base de investigações do Business Brain
 * (flavio_conversations, surface "dock"), para poder ser aberta e continuada em /business-brain.
 */
export async function askFlavio(ctx: TenantContext, raw: AskInput, now = new Date()): Promise<FlavioAnswer> {
  const answer = await askFlavioCore(ctx, raw, now);
  const input = askSchema.parse(raw);
  try {
    const conv = input.conversationId ? await getOwnConversation(ctx, input.conversationId) : await createConversation(ctx, input.message, "dock");
    await appendMessage(ctx, conv.id, { role: "user", content: input.message });
    await appendMessage(ctx, conv.id, { role: "assistant", content: answer.text, payload: { kind: "flavio_answer", mode: answer.mode, intent: answer.intent, intentLabel: answer.intentLabel, sources: answer.analysis?.sources ?? [], period: answer.analysis?.period ?? null }, executionId: answer.executionId });
    await saveContext(ctx, conv.id, { ...(conv.context as InvestigationContext), lastQuestion: input.message, lastIntent: answer.intent ?? undefined, findings: answer.analysis?.facts.slice(0, 6) ?? [] });
    return { ...answer, conversationId: conv.id };
  } catch {
    return { ...answer, conversationId: null };
  }
}

async function askFlavioCore(ctx: TenantContext, raw: AskInput, now = new Date()): Promise<FlavioAnswer> {
  requirePerm(ctx, "ai:use");
  const input = askSchema.parse(raw);
  const mod = moduleFor(input.route);
  const base = { screen: { route: input.route ?? null, module: mod.label }, suggestions: suggestionsFor(mod.key), at: now.toISOString() };
  const guard = checkInput(input.message, 2000);

  // Intenção e análise determinísticas (sempre com as permissões do usuário).
  let intent = classifyIntent(input.message);
  let continued = false, unknownQuestion = false;
  if (!intent && input.lastIntent && isFollowUp(input.message)) { intent = input.lastIntent; continued = true; }
  if (!intent) { intent = "overview"; unknownQuestion = true; }
  const filters = applyTextPeriod(lenientFilters(input.filters), input.message, now);

  let analysis: Analysis | null = null;
  const warnings: string[] = [];
  if (!guard.blocked) {
    try {
      analysis = await runAnalysis(ctx, intent, filters, { now, route: input.route, message: input.message });
    } catch (err) {
      warnings.push("Não consegui consultar os dados para esta análise. Nenhuma conclusão foi gerada.");
      console.error(JSON.stringify({ level: "error", at: now.toISOString(), where: "flavio.analysis", message: (err as Error).message }));
    }
  }
  const fallbackText = analysis ? narrative(analysis, { unknownQuestion, continued }) : "Não consegui consultar os dados agora. Tente novamente em instantes; nenhuma ação foi preparada.";

  // Narrativa pelo orquestrador existente (governança, créditos, auditoria). Sem provedor real, o orquestrador usa o
  // provedor local e a resposta mostrada é a determinística.
  let out: Awaited<ReturnType<typeof runAgent>> | null = null;
  try {
    out = await runAgent(ctx, {
      agentKey: FLAVIO.agentKey, input: input.message, persona: FLAVIO_PERSONA,
      history: await serverHistory(ctx, input.conversationSince),
      context: analysis ? contextForModel(analysis, `${mod.label}${input.route ? ` (${input.route.split("?")[0]})` : ""}`) : undefined,
    });
  } catch (err) {
    if (err instanceof AgentDisabledError) {
      return { ...base, executionId: null, text: `O ${FLAVIO.name} está indisponível: ${err.message} Fale com um administrador.`, mode: "indisponivel", intent: null, intentLabel: null, analysis: null, provider: "none", model: "none", credits: 0, simulated: false, warnings: [err.message] };
    }
    warnings.push(`IA indisponível (${(err as Error).message.slice(0, 160)}). Resposta calculada diretamente das métricas.`);
  }

  if (out?.status === "blocked") {
    return { ...base, executionId: out.executionId, text: out.text, mode: "bloqueado", intent: null, intentLabel: null, analysis: null, provider: out.provider, model: out.model, credits: 0, simulated: false, warnings: out.warnings };
  }

  const useModel = !!out && !out.simulated && out.status === "success" && !!analysis;
  let executionId = out?.executionId ?? null;
  if (!useModel) {
    if (out?.status === "fallback" || out?.status === "error") warnings.push("O provedor de IA falhou; a resposta foi calculada diretamente das métricas, sem modelo.");
    // Registra o que o usuário realmente recebeu.
    if (executionId) await ctx.db.update(aiExecutions).set({ output: fallbackText.slice(0, 8000), model: DETERMINISTIC_MODEL })
      .where(and(eq(aiExecutions.id, executionId), eq(aiExecutions.organizationId, ctx.organizationId)));
  }
  if (!executionId && analysis) {
    // Orquestrador indisponível (ex.: limite de créditos): ainda assim registra a resposta determinística, sem custo.
    const [row] = await ctx.db.insert(aiExecutions).values({
      organizationId: ctx.organizationId, agentKey: FLAVIO.agentKey, provider: "local-heuristic", model: DETERMINISTIC_MODEL, input: guard.sanitized.slice(0, 4000),
      output: fallbackText.slice(0, 8000), status: "fallback", simulated: true, credits: 0, userId: ctx.userId,
    }).returning({ id: aiExecutions.id });
    executionId = row.id;
  }
  await audit(ctx.db, {
    organizationId: ctx.organizationId, actorId: ctx.userId, action: "flavio.analysis", resource: "flavio", resourceId: executionId,
    metadata: { intent, mode: useModel ? "ia" : "deterministico", module: mod.key, filters, sources: analysis?.sources ?? [], proposals: analysis?.proposals.map((p) => p.kind) ?? [] },
  });
  return {
    ...base, executionId, text: useModel ? out!.text : fallbackText, mode: useModel ? "ia" : "deterministico", intent, intentLabel: INTENT_LABELS[intent],
    analysis, provider: useModel ? out!.provider : "deterministico", model: useModel ? out!.model : DETERMINISTIC_MODEL,
    credits: out?.credits ?? 0, simulated: !useModel, warnings: [...warnings, ...(out?.warnings ?? []).filter((w) => !/MODO SIMULADO/.test(w))],
  };
}

/* ------------------------------------------------------------------ histórico */

const ERASED = "[conteúdo removido pelo usuário]";
const SESSION_GAP_MS = 30 * 60 * 1000;

export async function listConversations(ctx: TenantContext) {
  requirePerm(ctx, "ai:use");
  const rows = await ctx.db.select({ id: aiExecutions.id, input: aiExecutions.input, output: aiExecutions.output, status: aiExecutions.status, provider: aiExecutions.provider, model: aiExecutions.model, createdAt: aiExecutions.createdAt })
    .from(aiExecutions)
    .where(and(eq(aiExecutions.organizationId, ctx.organizationId), eq(aiExecutions.userId, ctx.userId), eq(aiExecutions.agentKey, FLAVIO.agentKey)))
    .orderBy(desc(aiExecutions.createdAt)).limit(300);
  const sessions: { id: string; startedAt: string; endedAt: string; title: string; turns: { id: string; question: string; answer: string; at: string; mode: FlavioMode }[] }[] = [];
  for (const r of rows.reverse()) {
    const turn = { id: r.id, question: r.input, answer: r.output ?? "", at: r.createdAt.toISOString(), mode: (r.status === "blocked" ? "bloqueado" : r.provider === "local-heuristic" || r.model === DETERMINISTIC_MODEL ? "deterministico" : "ia") as FlavioMode };
    const last = sessions.at(-1);
    if (last && r.createdAt.getTime() - Date.parse(last.endedAt) <= SESSION_GAP_MS) { last.turns.push(turn); last.endedAt = turn.at; }
    else sessions.push({ id: r.id, startedAt: turn.at, endedAt: turn.at, title: r.input === ERASED ? "Conversa removida" : r.input.slice(0, 80), turns: [turn] });
  }
  return sessions.reverse().slice(0, 30);
}

/**
 * Apaga o CONTEÚDO do histórico do próprio usuário (todas as conversas ou uma, pelo intervalo).
 * O registro de uso e custo (tokens, créditos, data) é mantido para auditoria, sem texto.
 */
export async function eraseConversations(ctx: TenantContext, range?: { from: string; to: string }) {
  requirePerm(ctx, "ai:use");
  const conds = [eq(aiExecutions.organizationId, ctx.organizationId), eq(aiExecutions.userId, ctx.userId), eq(aiExecutions.agentKey, FLAVIO.agentKey)];
  if (range) {
    const { lte } = await import("drizzle-orm");
    conds.push(gte(aiExecutions.createdAt, new Date(range.from)), lte(aiExecutions.createdAt, new Date(range.to)));
  }
  const res = await ctx.db.update(aiExecutions).set({ input: ERASED, output: ERASED }).where(and(...conds)).returning({ id: aiExecutions.id });
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "flavio.history.erased", resource: "ai_execution", metadata: { count: res.length, range: range ?? "all" } });
  return { erased: res.length };
}
