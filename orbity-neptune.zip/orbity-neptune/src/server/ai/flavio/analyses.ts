/**
 * Análises do Flávio — determinísticas, sobre o serviço central de métricas e os domínios existentes.
 * Cada análise devolve fatos (números do banco), hipóteses (marcadas como tal), recomendações, evidências com links,
 * fontes, período e critérios. É também a resposta de fallback quando não há provedor de IA.
 */
import { and, asc, count, desc, eq, gte, inArray, isNull, lt, sql } from "drizzle-orm";
import { activities, leads, opportunities, pipelineStages, tasks, users, companies, memberships, campaigns } from "../../db/schema";
import { can, type TenantContext } from "../../tenancy/context";
import { money, num, pct } from "../../../lib/format";
import { SOURCE_LABELS, describeFilters, filtersToParams, resolvePeriod, type MetricFilters } from "../../../lib/metrics-filters";
import { METRIC_DEFINITIONS, metricsBreakdown, metricsOverview, type BreakdownRow } from "../../domains/metrics";
import { mainGoalProgress, recommendations, revenueForecast } from "../../domains/intelligence";
import { slaBreaches } from "../../domains/closer";
import { STALE_DAYS } from "../../domains/crm/queries";
import { proposeAction, type ActionProposal } from "./actions";
import { INTENT_LABELS, normalize, parseTaskRequest, type Intent } from "./intents";
import { FLAVIO } from "./identity";

export type Indicator = { label: string; value: string; detail?: string; trend?: "up" | "down" | "flat" | null };
export type Evidence = { label: string; detail: string; href?: string };
export type Analysis = {
  intent: Intent; title: string;
  facts: string[]; inferences: string[]; recommendations: string[];
  indicators: Indicator[]; evidence: Evidence[];
  sources: string[]; period: string | null; criteria: string[]; filters: string[];
  proposals: ActionProposal[]; links: { label: string; href: string }[];
  insufficientData: boolean; permissionNotes: string[];
};

type Opts = { now?: Date; route?: string | null; message?: string };

const empty = (intent: Intent, title: string): Analysis => ({
  intent, title, facts: [], inferences: [], recommendations: [], indicators: [], evidence: [], sources: [], period: null,
  criteria: [], filters: [], proposals: [], links: [], insufficientData: false, permissionNotes: [],
});

const trend = (v: number | null | undefined): Indicator["trend"] => (v == null ? null : v > 0 ? "up" : v < 0 ? "down" : "flat");
const signed = (v: number | null | undefined, suffix = "%") => (v == null ? "sem base de comparação" : `${v > 0 ? "+" : ""}${String(v).replace(".", ",")}${suffix}`);

function lo(ctx: TenantContext) { return { locale: ctx.locale, currency: ctx.currency }; }
function dashHref(f: MetricFilters, extra: Partial<MetricFilters> = {}) { const p = filtersToParams({ ...f, ...extra }); const s = p.toString(); return `/dashboard${s ? "?" + s : ""}`; }

function denied(a: Analysis, perm: string, what: string) {
  a.permissionNotes.push(`Seu perfil não tem a permissão "${perm}", necessária para consultar ${what}. Nada foi consultado.`);
  a.insufficientData = true;
  return a;
}

/* ------------------------------------------------------------------ visão geral e variação */

async function overview(ctx: TenantContext, f: MetricFilters, a: Analysis) {
  if (!can(ctx, "intelligence:read")) { denied(a, "intelligence:read", "indicadores"); return null; }
  const o = await metricsOverview(ctx, f);
  const L = lo(ctx);
  a.period = o.meta.period.label + (o.meta.comparison ? ` · comparação: ${o.meta.comparison.label}` : "");
  a.filters = o.meta.filtersApplied;
  a.sources.push("Serviço central de métricas (leads, opportunities)");
  a.indicators.push(
    { label: METRIC_DEFINITIONS.revenue.label, value: money(o.current.revenueCents, L), detail: signed(o.delta?.revenue), trend: trend(o.delta?.revenue) },
    { label: METRIC_DEFINITIONS.won.label, value: num(o.current.won, ctx.locale), detail: signed(o.delta?.won), trend: trend(o.delta?.won) },
    { label: METRIC_DEFINITIONS.conversion.label, value: pct(o.current.conversionRate, ctx.locale), detail: signed(o.delta?.conversionPp, " p.p."), trend: trend(o.delta?.conversionPp) },
    { label: METRIC_DEFINITIONS.leads.label, value: o.current.leads == null ? "n/a" : num(o.current.leads, ctx.locale), detail: signed(o.delta?.leads), trend: trend(o.delta?.leads) },
    { label: METRIC_DEFINITIONS.open_pipeline.label, value: money(o.pipeline.valueCents, L), detail: `${num(o.pipeline.openDeals, ctx.locale)} oportunidades abertas` },
  );
  a.criteria.push(METRIC_DEFINITIONS.revenue.formula, METRIC_DEFINITIONS.conversion.formula);
  a.facts.push(
    `Receita de ${money(o.current.revenueCents, L)} em ${num(o.current.won, ctx.locale)} venda(s)${o.previous ? `, contra ${money(o.previous.revenueCents, L)} na comparação (${signed(o.delta?.revenue)})` : ""}.`,
    `Conversão (ganhas/fechadas): ${pct(o.current.conversionRate, ctx.locale)} com ${num(o.current.won + o.current.lost, ctx.locale)} negócio(s) fechado(s).`,
  );
  if (o.current.leads != null) a.facts.push(`${num(o.current.leads, ctx.locale)} lead(s) gerado(s) e ${num(o.current.opportunities, ctx.locale)} oportunidade(s) criada(s) no período.`);
  if (o.current.won + o.current.lost < 10) a.inferences.push("Hipótese: com menos de 10 negócios fechados, a taxa de conversão oscila muito; interprete com cautela.");
  if (o.current.won === 0 && o.current.opportunities === 0 && (o.current.leads ?? 0) === 0) a.insufficientData = true;
  a.links.push({ label: "Abrir dashboard com estes filtros", href: dashHref(f) });
  return o;
}

async function revenueChange(ctx: TenantContext, f: MetricFilters, a: Analysis) {
  if (!can(ctx, "intelligence:read")) return denied(a, "intelligence:read", "indicadores");
  const fc: MetricFilters = { ...f, compare: f.compare === "none" ? "previous" : f.compare };
  const o = await overview(ctx, fc, a);
  if (!o || !o.previous) return a;
  const L = lo(ctx);
  const cur = o.current, prev = o.previous;
  const dRev = cur.revenueCents - prev.revenueCents;
  if (cur.revenueCents === 0 && prev.revenueCents === 0) { a.facts.push("Não houve receita nem no período atual nem na comparação: não há variação a explicar."); a.insufficientData = true; return a; }
  // Decomposição exata: receita = vendas × ticket médio.
  const tPrev = prev.won ? prev.revenueCents / prev.won : 0, tCur = cur.won ? cur.revenueCents / cur.won : 0;
  const volumeEffect = Math.round((cur.won - prev.won) * tPrev), ticketEffect = Math.round((tCur - tPrev) * cur.won);
  a.facts.push(`Variação da receita: ${dRev >= 0 ? "+" : "-"}${money(Math.abs(dRev), L)} (${signed(o.delta?.revenue)}).`);
  a.facts.push(`Decomposição (receita = vendas × ticket médio): efeito volume ${volumeEffect >= 0 ? "+" : "-"}${money(Math.abs(volumeEffect), L)} (${prev.won} → ${cur.won} vendas); efeito ticket ${ticketEffect >= 0 ? "+" : "-"}${money(Math.abs(ticketEffect), L)} (${money(Math.round(tPrev), L)} → ${money(Math.round(tCur), L)}).`);
  a.criteria.push("Decomposição: efeito volume = (vendas atuais − vendas anteriores) × ticket anterior; efeito ticket = (ticket atual − ticket anterior) × vendas atuais. A soma é igual à variação.");
  for (const dim of ["seller", "source"] as const) {
    const b = await metricsBreakdown(ctx, fc, dim);
    const movers = b.rows.filter((r) => r.prevRevenueCents != null).map((r) => ({ r, d: r.revenueCents - (r.prevRevenueCents ?? 0) })).filter((x) => x.d !== 0).sort((x, y) => Math.abs(y.d) - Math.abs(x.d)).slice(0, 3);
    if (movers.length) {
      a.facts.push(`Maiores variações por ${b.label.toLowerCase()}: ${movers.map((m) => `${m.r.label} ${m.d >= 0 ? "+" : "-"}${money(Math.abs(m.d), L)}`).join("; ")}.`);
      for (const m of movers) a.evidence.push({ label: `${b.label}: ${m.r.label}`, detail: `Receita ${money(m.r.revenueCents, L)} (comparação ${money(m.r.prevRevenueCents ?? 0, L)}), ${m.r.won} venda(s)`, href: dashHref(fc, dim === "seller" ? { seller: m.r.key } : { source: m.r.key as MetricFilters["source"] }) });
    }
  }
  if (Math.abs(volumeEffect) > Math.abs(ticketEffect)) a.inferences.push(`Hipótese: a variação vem principalmente do número de vendas, não do valor médio. Vale olhar o funil e as oportunidades paradas.`);
  else if (ticketEffect !== 0) a.inferences.push(`Hipótese: a variação vem principalmente do ticket médio. Vale revisar o mix de negócios e descontos.`);
  a.recommendations.push("Abra as vendas do período no drill-down do card de receita para ver os negócios que compõem a variação.");
  return a;
}

/* ------------------------------------------------------------------ equipe e canais */

function sample(r: BreakdownRow) { return r.won + r.lost; }

async function sellerConversion(ctx: TenantContext, f: MetricFilters, a: Analysis, withTeams = false) {
  if (!can(ctx, "intelligence:read")) return denied(a, "intelligence:read", "indicadores");
  const b = await metricsBreakdown(ctx, f, "seller");
  const p = resolvePeriod(f);
  const L = lo(ctx);
  a.period = p.label; a.filters = describeFilters(f); a.sources.push("Serviço central de métricas — segmentação por vendedor");
  a.criteria.push(METRIC_DEFINITIONS.conversion.formula, "Para ranquear conversão, considera só quem tem 5 ou mais negócios fechados no período.");
  const rows = b.rows.filter((r) => r.key !== "__none__");
  if (!rows.length) { a.facts.push("Nenhum negócio atribuído a vendedores no período."); a.insufficientData = true; return a; }
  const eligible = rows.filter((r) => sample(r) >= 5 && r.conversionRate != null).sort((x, y) => (y.conversionRate ?? 0) - (x.conversionRate ?? 0));
  if (eligible.length) {
    const best = eligible[0];
    a.facts.push(`Melhor conversão: ${best.label}, com ${pct(best.conversionRate, ctx.locale)} (${best.won} ganhas de ${sample(best)} fechadas).`);
    if (eligible.length > 1) { const w = eligible[eligible.length - 1]; a.facts.push(`Menor conversão entre os elegíveis: ${w.label}, com ${pct(w.conversionRate, ctx.locale)} (${w.won} de ${sample(w)}).`); }
  } else {
    a.facts.push("Nenhum vendedor tem 5 ou mais negócios fechados no período: não dá para comparar conversão com segurança.");
    a.insufficientData = true;
  }
  const byRev = [...rows].sort((x, y) => y.revenueCents - x.revenueCents);
  a.facts.push(`Maior receita: ${byRev[0].label} (${money(byRev[0].revenueCents, L)}, ${byRev[0].won} venda(s)).`);
  for (const r of byRev.slice(0, 8)) {
    a.evidence.push({ label: r.label, detail: `Receita ${money(r.revenueCents, L)} · ${r.won} ganhas / ${r.lost} perdidas · conversão ${pct(r.conversionRate, ctx.locale)}${sample(r) < 5 ? " (amostra pequena)" : ""}`, href: dashHref(f, { seller: r.key }) });
  }
  if (withTeams) {
    const t = await metricsBreakdown(ctx, f, "team");
    const teamRows = t.rows.filter((r) => r.key !== "__none__");
    if (teamRows.length) a.facts.push(`Por equipe: ${teamRows.map((r) => `${r.label} ${money(r.revenueCents, L)} (${pct(r.conversionRate, ctx.locale)})`).join("; ")}.`);
    a.sources.push("Segmentação por equipe (team_members)");
  }
  a.inferences.push("Hipótese: diferenças de conversão também refletem a carteira de cada vendedor (origem e porte dos leads), não só a habilidade.");
  a.links.push({ label: "Ver segmentação por vendedor no dashboard", href: dashHref(f) });
  return a;
}

async function bestChannel(ctx: TenantContext, f: MetricFilters, a: Analysis) {
  if (!can(ctx, "intelligence:read")) return denied(a, "intelligence:read", "indicadores");
  const b = await metricsBreakdown(ctx, f, "source");
  const L = lo(ctx);
  a.period = resolvePeriod(f).label; a.filters = describeFilters(f); a.sources.push("Serviço central de métricas — segmentação por origem");
  a.criteria.push("\"Melhores clientes\" = maior receita ganha; desempate por ticket médio e conversão.", "Origem da oportunidade: a própria ou, se vazia, a do lead.");
  const rows = b.rows.filter((r) => r.won + r.lost + (r.leads ?? 0) > 0);
  if (!rows.length) { a.facts.push("Sem leads ou negócios fechados no período para comparar canais."); a.insufficientData = true; return a; }
  const withRev = rows.filter((r) => r.revenueCents > 0).sort((x, y) => y.revenueCents - x.revenueCents);
  if (withRev.length) {
    const top = withRev[0];
    a.facts.push(`Canal com maior receita: ${top.label}, ${money(top.revenueCents, L)} (${pct(top.revenueSharePct, ctx.locale)} do total), ticket médio ${money(Math.round(top.revenueCents / Math.max(1, top.won)), L)}.`);
  } else a.facts.push("Nenhuma venda no período: a comparação de canais por receita não é possível.");
  const conv = rows.filter((r) => r.won + r.lost >= 5).sort((x, y) => (y.conversionRate ?? 0) - (x.conversionRate ?? 0));
  if (conv.length) a.facts.push(`Melhor conversão (5+ fechados): ${conv[0].label} com ${pct(conv[0].conversionRate, ctx.locale)}.`);
  for (const r of rows.slice(0, 7)) a.evidence.push({ label: r.label, detail: `${r.leads ?? "n/a"} leads · ${r.won} vendas · ${money(r.revenueCents, L)} · conversão ${pct(r.conversionRate, ctx.locale)}`, href: dashHref(f, { source: r.key as MetricFilters["source"] }) });
  const volume = [...rows].sort((x, y) => (y.leads ?? 0) - (x.leads ?? 0))[0];
  if (withRev.length && volume && volume.key !== withRev[0].key) a.inferences.push(`Hipótese: ${volume.label} traz mais leads, mas ${withRev[0].label} traz mais receita; volume de leads não é o mesmo que qualidade.`);
  return a;
}

/* ------------------------------------------------------------------ leads e oportunidades */

async function topLeads(ctx: TenantContext, f: MetricFilters, a: Analysis, opts: { propose: boolean }) {
  if (!can(ctx, "prospect:read") && !can(ctx, "crm:read")) return denied(a, "prospect:read", "leads");
  const conds = [eq(leads.organizationId, ctx.organizationId), inArray(leads.status, ["new", "qualifying", "qualified"])];
  if (f.seller) conds.push(eq(leads.ownerId, f.seller));
  if (f.source) conds.push(eq(leads.source, f.source));
  const rows = await ctx.db.select({ id: leads.id, title: leads.title, score: leads.score, status: leads.status, source: leads.source, ownerId: leads.ownerId, ownerName: users.name, companyName: companies.name, explanation: leads.scoreExplanation, createdAt: leads.createdAt })
    .from(leads).leftJoin(users, eq(users.id, leads.ownerId)).leftJoin(companies, eq(companies.id, leads.companyId))
    .where(and(...conds)).orderBy(sql`${leads.score} desc nulls last`, desc(leads.createdAt)).limit(10);
  const [{ n }] = await ctx.db.select({ n: count() }).from(leads).where(and(...conds));
  a.sources.push("leads (score do Prospect.AI e fatores explicáveis)");
  a.criteria.push("Leads abertos (novo, em qualificação, qualificado), ordenados pelo score do ICP; desempate pelo mais recente.");
  a.filters = describeFilters({ ...f, team: undefined, campaign: undefined, stage: undefined });
  if (!rows.length) { a.facts.push("Não há leads abertos com os filtros atuais."); a.insufficientData = true; return a; }
  const scored = rows.filter((r) => r.score != null);
  a.facts.push(`${num(Number(n), ctx.locale)} lead(s) aberto(s). Os ${rows.length} com maior score estão listados nas evidências.`);
  if (!scored.length) a.facts.push("Nenhum desses leads tem score: defina o ICP e recalcule no Prospect.AI.");
  for (const r of rows) {
    const factors = r.explanation?.factors?.filter((x) => x.value > 0).sort((x, y) => y.weight * y.value - x.weight * x.value).slice(0, 2).map((x) => x.reason).join("; ");
    a.evidence.push({ label: `${r.companyName ?? r.title}${r.score != null ? ` — score ${r.score}` : " — sem score"}`, detail: `${SOURCE_LABELS[r.source] ?? r.source} · ${r.status} · responsável ${r.ownerName ?? "nenhum"}${factors ? ` · ${factors}` : ""}`, href: `/prospect?lead=${r.id}` });
  }
  a.inferences.push("O score mede aderência ao ICP, não intenção de compra. Combine com o histórico de contato antes de priorizar.");
  if (opts.propose) {
    const items = rows.slice(0, 5).map((r) => ({ title: `Contato prioritário: ${r.companyName ?? r.title}`.slice(0, 200), description: `Preparado pelo ${FLAVIO.name}: lead com score ${r.score ?? "n/d"}.`, priority: "high" as const, leadId: r.id, assigneeId: r.ownerId ?? undefined, dueAt: tomorrow9(ctx).toISOString() }));
    a.proposals.push(proposeAction(ctx, { kind: "create_tasks", items }, { title: `Criar ${items.length} tarefa(s) de contato prioritário`, summary: "Uma tarefa por lead de maior score, atribuída ao responsável do lead (ou a você, se não houver), com prazo amanhã às 9h.", details: items.map((i) => i.title) }));
  }
  a.links.push({ label: "Abrir leads quentes no Prospect.AI", href: "/prospect?filtro=quentes" });
  return a;
}

function tomorrow9(_ctx: TenantContext, now = new Date()) { const d = new Date(now); d.setDate(d.getDate() + 1); d.setHours(9, 0, 0, 0); return d; }

async function stalledOpportunities(ctx: TenantContext, f: MetricFilters, a: Analysis, now: Date) {
  if (!can(ctx, "crm:read")) return denied(a, "crm:read", "oportunidades");
  const limitDate = new Date(now.getTime() - STALE_DAYS * 864e5);
  const conds = [eq(opportunities.organizationId, ctx.organizationId), eq(opportunities.status, "open"), lt(opportunities.lastActivityAt, limitDate)];
  if (f.seller) conds.push(eq(opportunities.ownerId, f.seller));
  if (f.stage) conds.push(eq(opportunities.stageId, f.stage));
  const where = and(...conds);
  const [[tot], rows] = await Promise.all([
    ctx.db.select({ n: count(), v: sql<number>`coalesce(sum(${opportunities.amountCents}),0)::bigint` }).from(opportunities).where(where),
    ctx.db.select({ id: opportunities.id, title: opportunities.title, amount: opportunities.amountCents, last: opportunities.lastActivityAt, ownerId: opportunities.ownerId, ownerName: users.name, stage: pipelineStages.name, companyName: companies.name })
      .from(opportunities).leftJoin(users, eq(users.id, opportunities.ownerId)).leftJoin(pipelineStages, eq(pipelineStages.id, opportunities.stageId)).leftJoin(companies, eq(companies.id, opportunities.companyId))
      .where(where).orderBy(desc(opportunities.amountCents)).limit(15),
  ]);
  const L = lo(ctx);
  a.sources.push("opportunities (status aberto, last_activity_at)");
  a.criteria.push(`Parada = oportunidade aberta sem atividade há mais de ${STALE_DAYS} dias (mesmo critério do CRM).`);
  a.filters = describeFilters({ ...f, team: undefined, campaign: undefined, source: undefined });
  a.period = "Posição atual";
  const n = Number(tot.n);
  if (!n) { a.facts.push(`Nenhuma oportunidade aberta está sem atividade há mais de ${STALE_DAYS} dias.`); return a; }
  a.facts.push(`${num(n, ctx.locale)} oportunidade(s) parada(s), somando ${money(Number(tot.v), L)} em pipeline.`);
  a.indicators.push({ label: "Oportunidades paradas", value: num(n, ctx.locale) }, { label: "Valor parado", value: money(Number(tot.v), L) });
  for (const r of rows) {
    const idle = Math.floor((now.getTime() - new Date(r.last).getTime()) / 864e5);
    a.evidence.push({ label: `${r.companyName ?? r.title} — ${money(Number(r.amount), L)}`, detail: `${r.stage ?? "sem etapa"} · ${idle} dias sem atividade · responsável ${r.ownerName ?? "nenhum"}`, href: `/crm/oportunidade/${r.id}` });
  }
  const items = rows.slice(0, 10).map((r) => ({ title: `Follow-up: ${r.companyName ?? r.title}`.slice(0, 200), description: `Preparado pelo ${FLAVIO.name}: oportunidade sem atividade desde ${new Date(r.last).toLocaleDateString(ctx.locale)}.`, priority: "high" as const, opportunityId: r.id, assigneeId: r.ownerId ?? undefined, dueAt: tomorrow9(ctx, now).toISOString() }));
  a.proposals.push(proposeAction(ctx, { kind: "create_tasks", items }, { title: `Organizar ${items.length} follow-up(s)`, summary: "Uma tarefa de follow-up por oportunidade parada de maior valor, atribuída ao responsável, com prazo amanhã às 9h.", details: items.map((i) => i.title) }));
  a.recommendations.push("Priorize as de maior valor e etapa mais avançada; registre a atividade no CRM para que deixem de aparecer como paradas.");
  a.links.push({ label: "Ver paradas no CRM", href: "/crm?filtro=paradas" });
  return a;
}

async function leadsWithoutFollowUp(ctx: TenantContext, f: MetricFilters, a: Analysis, now: Date) {
  if (!can(ctx, "prospect:read") && !can(ctx, "crm:read")) return denied(a, "prospect:read", "leads");
  const since = new Date(now.getTime() - 7 * 864e5), grace = new Date(now.getTime() - 2 * 864e5);
  const org = ctx.organizationId;
  const conds = [
    eq(leads.organizationId, org), inArray(leads.status, ["new", "qualifying", "qualified"]), lt(leads.createdAt, grace),
    sql`not exists (select 1 from ${activities} a where a.lead_id = ${leads.id} and a.organization_id = ${org} and a.occurred_at >= ${since.toISOString()}::timestamptz)`,
    sql`not exists (select 1 from ${tasks} t where t.lead_id = ${leads.id} and t.organization_id = ${org} and t.status = 'open')`,
  ];
  if (f.seller) conds.push(eq(leads.ownerId, f.seller));
  if (f.source) conds.push(eq(leads.source, f.source));
  const where = and(...conds);
  const [[tot], rows] = await Promise.all([
    ctx.db.select({ n: count() }).from(leads).where(where),
    ctx.db.select({ id: leads.id, title: leads.title, score: leads.score, ownerId: leads.ownerId, ownerName: users.name, companyName: companies.name, createdAt: leads.createdAt, source: leads.source })
      .from(leads).leftJoin(users, eq(users.id, leads.ownerId)).leftJoin(companies, eq(companies.id, leads.companyId))
      .where(where).orderBy(sql`${leads.score} desc nulls last`).limit(15),
  ]);
  a.sources.push("leads, activities, tasks");
  a.criteria.push("Sem acompanhamento = lead aberto, criado há mais de 48h, sem atividade registrada nos últimos 7 dias e sem tarefa aberta.");
  a.period = "Posição atual"; a.filters = describeFilters({ ...f, team: undefined, campaign: undefined, stage: undefined });
  const n = Number(tot.n);
  if (!n) { a.facts.push("Todos os leads abertos têm atividade recente ou tarefa aberta."); return a; }
  a.facts.push(`${num(n, ctx.locale)} lead(s) aberto(s) sem acompanhamento pelo critério acima.`);
  a.indicators.push({ label: "Leads sem acompanhamento", value: num(n, ctx.locale) });
  for (const r of rows) a.evidence.push({ label: `${r.companyName ?? r.title}${r.score != null ? ` — score ${r.score}` : ""}`, detail: `${SOURCE_LABELS[r.source] ?? r.source} · criado em ${r.createdAt.toLocaleDateString(ctx.locale)} · responsável ${r.ownerName ?? "nenhum"}`, href: `/prospect?lead=${r.id}` });
  const items = rows.slice(0, 10).map((r) => ({ title: `Primeiro retorno: ${r.companyName ?? r.title}`.slice(0, 200), description: `Preparado pelo ${FLAVIO.name}: lead sem atividade nos últimos 7 dias.`, priority: (r.score ?? 0) >= 70 ? "high" as const : "medium" as const, leadId: r.id, assigneeId: r.ownerId ?? undefined, dueAt: tomorrow9(ctx, now).toISOString() }));
  a.proposals.push(proposeAction(ctx, { kind: "create_tasks", items }, { title: `Criar ${items.length} tarefa(s) de acompanhamento`, summary: "Uma tarefa por lead (os de maior score primeiro), atribuída ao responsável, com prazo amanhã às 9h.", details: items.map((i) => i.title) }));
  a.proposals.push(proposeAction(ctx, { kind: "draft_automation", templateKey: "nutricao" }, { title: "Preparar automação de nutrição de leads (rascunho)", summary: "Cria o modelo \"Nutrição de leads novos\" como RASCUNHO em Automações. Não publica nem envia mensagens.", details: ["Gatilho: lead criado", "Ação: tarefa de primeiro contato em 4h", "Espera de 48h e notificação se o lead continuar novo"] }));
  return a;
}

/* ------------------------------------------------------------------ prioridades, previsão e metas */

async function weeklyPriorities(ctx: TenantContext, f: MetricFilters, a: Analysis, now: Date) {
  const sub = (i: Intent) => empty(i, "");
  const L = lo(ctx);
  a.period = "Próximos 7 dias (posição atual)";
  if (can(ctx, "crm:read")) {
    const s = await stalledOpportunities(ctx, f, sub("stalled_opportunities"), now);
    if (s.evidence.length) { a.facts.push(s.facts[0]); a.evidence.push(...s.evidence.slice(0, 4)); }
    const [{ n }] = await ctx.db.select({ n: count() }).from(tasks).where(and(eq(tasks.organizationId, ctx.organizationId), eq(tasks.status, "open"), lt(tasks.dueAt, now)));
    if (Number(n)) a.facts.push(`${num(Number(n), ctx.locale)} tarefa(s) aberta(s) com prazo vencido.`);
    a.proposals.push(...s.proposals);
  } else a.permissionNotes.push("Sem permissão crm:read: oportunidades e tarefas não foram consideradas.");
  if (can(ctx, "prospect:read") || can(ctx, "crm:read")) {
    const [{ n }] = await ctx.db.select({ n: count() }).from(leads).where(and(eq(leads.organizationId, ctx.organizationId), gte(leads.score, 80), inArray(leads.status, ["new", "qualifying", "qualified"])));
    if (Number(n)) { a.facts.push(`${num(Number(n), ctx.locale)} lead(s) quente(s) (score ≥ 80) abertos.`); a.links.push({ label: "Leads quentes", href: "/prospect?filtro=quentes" }); }
  }
  if (can(ctx, "closer:read")) {
    const b = await slaBreaches(ctx.db, ctx.organizationId);
    if (b.length) { a.facts.push(`${b.length} conversa(s) com SLA de resposta vencido.`); a.links.push({ label: "Conversas fora do SLA", href: "/closer?filtro=sla" }); }
  }
  if (can(ctx, "intelligence:read")) {
    const g = await mainGoalProgress(ctx);
    if (g) a.facts.push(`Meta "${g.name}": ${money(g.achieved, L)} de ${money(g.target, L)} (${g.pct}%).`);
    const recs = await recommendations(ctx);
    for (const r of recs.slice(0, 3)) a.recommendations.push(`[${r.priority}] ${r.action} (${r.evidence})`);
  }
  a.sources.push("opportunities, tasks, leads, conversations, goals, recomendações do Sales Intelligence");
  a.criteria.push("Ordem sugerida: dinheiro parado de maior valor, prazos vencidos, leads quentes, atendimento fora do SLA, meta.");
  if (!a.facts.length) { a.facts.push("Nenhum ponto de atenção encontrado pelas regras atuais."); }
  return a;
}

async function forecast(ctx: TenantContext, f: MetricFilters, a: Analysis, now: Date) {
  if (!can(ctx, "intelligence:read")) return denied(a, "intelligence:read", "indicadores");
  const L = lo(ctx);
  const fc = await revenueForecast(ctx);
  a.sources.push("revenueForecast (pipeline ponderado) e receita do mês corrente");
  a.indicators.push({ label: "Pessimista", value: money(fc.scenarios.pessimistic, L) }, { label: "Base", value: money(fc.scenarios.base, L) }, { label: "Otimista", value: money(fc.scenarios.optimistic, L) });
  a.facts.push(`Pipeline aberto de ${money(fc.pipelineTotalCents, L)} em ${fc.openDeals} negócio(s); receita esperada (cenário base) ${money(fc.scenarios.base, L)}, faixa ±${fc.uncertaintyPct}%.`);
  a.criteria.push(...fc.assumptions);
  // Ritmo do mês: receita do mês até hoje projetada linearmente para o mês inteiro.
  const monthStart = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1));
  const daysInMonth = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + 1, 0)).getUTCDate();
  const elapsed = Math.max(1, (now.getTime() - monthStart.getTime()) / 864e5);
  const o = await metricsOverview(ctx, { ...f, from: monthStart.toISOString().slice(0, 10), to: now.toISOString().slice(0, 10), compare: "none" }, now);
  const runRate = Math.round((o.current.revenueCents / elapsed) * daysInMonth);
  a.facts.push(`Mês corrente: ${money(o.current.revenueCents, L)} até hoje (${Math.floor(elapsed)} de ${daysInMonth} dias). No ritmo atual, o mês fecharia em cerca de ${money(runRate, L)}.`);
  a.criteria.push("Projeção do mês = receita do mês até hoje ÷ dias decorridos × dias do mês (extrapolação linear, não considera sazonalidade).");
  for (const l of fc.limitations) a.inferences.push(l);
  a.inferences.push("Projeções são estimativas a partir do histórico disponível, não compromissos de resultado.");
  a.period = "Posição atual e mês corrente";
  a.links.push({ label: "Previsão no Sales Intelligence", href: "/intelligence" });
  return a;
}

async function goals(ctx: TenantContext, _f: MetricFilters, a: Analysis, now: Date) {
  if (!can(ctx, "intelligence:read")) return denied(a, "intelligence:read", "metas");
  const g = await mainGoalProgress(ctx);
  const L = lo(ctx);
  a.sources.push("goals (meta de receita da organização vigente) e opportunities ganhas");
  if (!g) { a.facts.push("Não há meta de receita da organização vigente hoje."); a.links.push({ label: "Criar meta", href: "/tarefas" }); a.insufficientData = true; return a; }
  a.indicators.push({ label: g.name, value: `${g.pct}%`, detail: `${money(g.achieved, L)} de ${money(g.target, L)}` });
  a.facts.push(`Meta "${g.name}": ${money(g.achieved, L)} de ${money(g.target, L)} (${g.pct}%).`);
  a.criteria.push("Realizado = receita de oportunidades ganhas dentro do período da meta.");
  void now;
  a.links.push({ label: "Ver metas", href: "/tarefas" });
  return a;
}

/* ------------------------------------------------------------------ qualidade de dados */

async function inconsistencies(ctx: TenantContext, _f: MetricFilters, a: Analysis, now: Date) {
  if (!can(ctx, "crm:read")) return denied(a, "crm:read", "registros do CRM");
  const org = ctx.organizationId;
  const checks: { label: string; where: ReturnType<typeof and>; fix: string }[] = [
    { label: "Ganhas ou perdidas sem data de fechamento", where: and(eq(opportunities.organizationId, org), inArray(opportunities.status, ["won", "lost"]), isNull(opportunities.closedAt)), fix: "Sem data de fechamento, a venda não entra em nenhum período: corrija pelo CRM." },
    { label: "Fechadas antes de serem criadas", where: and(eq(opportunities.organizationId, org), sql`${opportunities.closedAt} < ${opportunities.createdAt}`), fix: "Datas invertidas distorcem ciclo de venda e séries." },
    { label: "Status diferente do tipo da etapa", where: and(eq(opportunities.organizationId, org), sql`${opportunities.status} <> (select ps.kind from ${pipelineStages} ps where ps.id = ${opportunities.stageId})`), fix: "Ex.: aberta numa etapa de ganho. Mova pela tela do CRM para registrar corretamente." },
    { label: "Abertas com previsão de fechamento vencida", where: and(eq(opportunities.organizationId, org), eq(opportunities.status, "open"), lt(opportunities.expectedCloseDate, now)), fix: "Atualize a data prevista ou o status." },
    { label: "Oportunidades sem valor", where: and(eq(opportunities.organizationId, org), inArray(opportunities.status, ["open", "won"]), eq(opportunities.amountCents, 0)), fix: "Valor zero subestima receita e pipeline." },
    { label: "Oportunidades sem responsável", where: and(eq(opportunities.organizationId, org), isNull(opportunities.ownerId)), fix: "Sem responsável, não aparecem no desempenho por vendedor." },
  ];
  a.sources.push("opportunities, pipeline_stages, leads");
  a.period = "Base completa (posição atual)";
  let found = 0;
  for (const c of checks) {
    const [{ n }] = await ctx.db.select({ n: count() }).from(opportunities).where(c.where);
    a.criteria.push(c.label);
    if (Number(n)) {
      found++;
      a.facts.push(`${c.label}: ${num(Number(n), ctx.locale)}.`);
      const ex = await ctx.db.select({ id: opportunities.id, title: opportunities.title }).from(opportunities).where(c.where).orderBy(asc(opportunities.createdAt)).limit(3);
      for (const e of ex) a.evidence.push({ label: c.label, detail: e.title, href: `/crm/oportunidade/${e.id}` });
      a.recommendations.push(c.fix);
    }
  }
  const [conv] = await ctx.db.select({ n: count() }).from(leads).where(and(eq(leads.organizationId, org), eq(leads.status, "converted"), sql`not exists (select 1 from ${opportunities} o where o.lead_id = ${leads.id} and o.organization_id = ${org})`));
  a.criteria.push("Leads convertidos sem oportunidade vinculada");
  if (Number(conv.n)) { found++; a.facts.push(`Leads marcados como convertidos sem oportunidade vinculada: ${num(Number(conv.n), ctx.locale)}.`); }
  const [unscored] = await ctx.db.select({ n: count() }).from(leads).where(and(eq(leads.organizationId, org), isNull(leads.score)));
  a.criteria.push("Leads sem score");
  if (Number(unscored.n)) { found++; a.facts.push(`Leads sem score: ${num(Number(unscored.n), ctx.locale)}.`); }
  if (!found) a.facts.push("Nenhuma inconsistência encontrada pelas verificações listadas nos critérios.");
  return a;
}

/* ------------------------------------------------------------------ explicação de indicadores */

async function explainMetric(ctx: TenantContext, f: MetricFilters, a: Analysis, message: string) {
  const t = normalize(message);
  const key: keyof typeof METRIC_DEFINITIONS =
    /convers|taxa/.test(t) ? "conversion" : /ticket/.test(t) ? "avg_ticket" : /pipeline/.test(t) ? "open_pipeline" : /oportunidade/.test(t) ? "opportunities"
    : /\blead/.test(t) ? "leads" : /venda/.test(t) && !/receita/.test(t) ? "won" : "revenue";
  const d = METRIC_DEFINITIONS[key];
  a.title = `Como é calculado: ${d.label}`;
  a.facts.push(`${d.label}: ${d.formula}.`, `Fonte: tabela ${d.source}; campo de data: ${d.dateField}.`, `Pode ser segmentado por: ${d.dimensions.map((x) => ({ seller: "vendedor", team: "equipe", campaign: "campanha", source: "origem", stage: "etapa" }[x])).join(", ")}.`);
  a.sources.push("Catálogo de definições do serviço central de métricas");
  if (can(ctx, "intelligence:read")) {
    const o = await metricsOverview(ctx, f);
    const L = lo(ctx);
    const v: Record<string, string> = {
      revenue: money(o.current.revenueCents, L), won: num(o.current.won, ctx.locale), lost: num(o.current.lost, ctx.locale), leads: o.current.leads == null ? "n/a" : num(o.current.leads, ctx.locale),
      opportunities: num(o.current.opportunities, ctx.locale), conversion: pct(o.current.conversionRate, ctx.locale), avg_ticket: o.current.avgTicketCents == null ? "n/d" : money(o.current.avgTicketCents, L), open_pipeline: money(o.pipeline.valueCents, L),
    };
    a.indicators.push({ label: d.label, value: v[key] });
    a.period = o.meta.period.label; a.filters = o.meta.filtersApplied;
  }
  if (/grafico|dashboard/.test(t)) {
    a.facts.push("No dashboard, o gráfico \"Performance de vendas\" mostra receita e leads por dia (ou por semana em períodos acima de 92 dias), com a série de comparação tracejada. Clique ou pressione Enter num ponto para abrir os registros daquele dia.");
    a.facts.push("Os gráficos de segmentação mostram a receita por origem, vendedor ou etapa; clicar numa barra aplica o filtro em todo o dashboard (filtro cruzado).");
  }
  return a;
}

/* ------------------------------------------------------------------ campanhas e recuperação */

async function campaignSuggestions(ctx: TenantContext, f: MetricFilters, a: Analysis, now: Date) {
  if (!can(ctx, "intelligence:read")) return denied(a, "intelligence:read", "indicadores");
  const p = resolvePeriod(f, now);
  const L = lo(ctx);
  const lost = await ctx.db.select({ reason: opportunities.lostReason, n: count(), v: sql<number>`coalesce(sum(${opportunities.amountCents}),0)::bigint` }).from(opportunities)
    .where(and(eq(opportunities.organizationId, ctx.organizationId), eq(opportunities.status, "lost"), gte(opportunities.closedAt, p.start), lt(opportunities.closedAt, p.end)))
    .groupBy(opportunities.lostReason).orderBy(desc(count()));
  const [camp] = await ctx.db.select({ n: count() }).from(campaigns).where(eq(campaigns.organizationId, ctx.organizationId));
  a.period = p.label; a.sources.push("opportunities perdidas (lost_reason), campaigns, segmentação por origem");
  const totalLost = lost.reduce((s, r) => s + Number(r.n), 0);
  if (totalLost) {
    a.facts.push(`${totalLost} oportunidade(s) perdida(s) no período (${money(lost.reduce((s, r) => s + Number(r.v), 0), L)}). Motivos: ${lost.map((r) => `${r.reason ?? "sem motivo"} ${r.n}`).join("; ")}.`);
    a.recommendations.push(`Sugestão: campanha de reativação para os perdidos por "${lost[0].reason ?? "sem motivo"}" após 30 dias, com abordagem específica para esse motivo.`);
    a.proposals.push(proposeAction(ctx, { kind: "draft_automation", templateKey: "perda" }, { title: "Preparar automação de análise de perda (rascunho)", summary: "Cria o modelo \"Análise de oportunidade perdida\" como RASCUNHO: registra atividade e agenda follow-up em 30 dias. Não publica.", details: ["Gatilho: oportunidade perdida", "Ação: registrar atividade", "Ação: follow-up em 30 dias"] }));
  } else a.facts.push("Nenhuma oportunidade perdida no período.");
  const ch = await bestChannel(ctx, f, empty("best_channel", ""));
  if (ch.facts[0]) a.facts.push(ch.facts[0]);
  if (ch.facts[0] && !ch.insufficientData) a.recommendations.push("Sugestão: concentre a próxima campanha de aquisição no canal com maior receita e acompanhe a conversão por 30 dias.");
  if (!Number(camp.n)) a.facts.push("Nenhuma campanha cadastrada: leads ainda não podem ser atribuídos a campanhas, então o retorno por campanha não é mensurável.");
  a.inferences.push("As sugestões acima são recomendações a partir dos dados, não resultados garantidos.");
  a.links.push({ label: "Modelos de automação", href: "/automacoes" });
  return a;
}

/* ------------------------------------------------------------------ relatório e tarefas */

async function report(ctx: TenantContext, f: MetricFilters, a: Analysis) {
  await overview(ctx, f, a);
  if (!can(ctx, "intelligence:read")) return a;
  const recs = await recommendations(ctx);
  for (const r of recs.slice(0, 4)) a.recommendations.push(`[${r.priority}] ${r.problem}: ${r.action}`);
  const s = await sellerConversion(ctx, f, empty("team_performance", ""));
  if (s.facts.length) a.facts.push(...s.facts.slice(0, 2));
  const params = filtersToParams(f).toString();
  a.links.push({ label: "Relatório executivo", href: `/relatorios?tipo=executive&periodo=${f.days}` }, { label: "Baixar resumo filtrado (CSV)", href: `/api/metrics/export?tipo=resumo${params ? "&" + params : ""}` });
  return a;
}

async function createTaskIntent(ctx: TenantContext, a: Analysis, message: string, route: string | null | undefined, now: Date) {
  const { title, dueAt } = parseTaskRequest(message, now);
  const m = (route ?? "").match(/^\/crm\/oportunidade\/([0-9a-f-]{36})/i);
  let opportunityId: string | undefined;
  if (m) {
    const [o] = await ctx.db.select({ id: opportunities.id }).from(opportunities).where(and(eq(opportunities.id, m[1]), eq(opportunities.organizationId, ctx.organizationId)));
    if (o) opportunityId = o.id;
  }
  a.facts.push(`Tarefa preparada: "${title}"${dueAt ? `, prazo ${dueAt.toLocaleString(ctx.locale, { dateStyle: "short", timeStyle: "short" })}` : ", sem prazo"}${opportunityId ? ", vinculada à oportunidade aberta na tela" : ""}.`);
  a.criteria.push("Título e prazo extraídos da sua mensagem (\"hoje\", \"amanhã\", \"em N dias\", \"próxima semana\"). Responsável: você.");
  a.proposals.push(proposeAction(ctx, { kind: "create_tasks", items: [{ title, priority: "medium", dueAt: dueAt?.toISOString(), opportunityId, description: `Criada a pedido, preparada pelo ${FLAVIO.name}.` }] }, { title: "Criar 1 tarefa", summary: `"${title}"`, details: [dueAt ? `Prazo: ${dueAt.toLocaleString(ctx.locale, { dateStyle: "short", timeStyle: "short" })}` : "Sem prazo", "Responsável: você", ...(opportunityId ? ["Vinculada à oportunidade da tela atual"] : [])] }));
  a.sources.push("Sua mensagem (nenhum dado consultado)");
  return a;
}

function help(a: Analysis) {
  a.facts.push(
    "Analiso receita, vendas, conversão, metas e desempenho por vendedor, equipe, origem, campanha e etapa, sempre com os dados da sua organização.",
    "Encontro oportunidades paradas, leads sem acompanhamento, leads de maior potencial e inconsistências nos dados.",
    "Explico indicadores e gráficos, projeto resultados com premissas explícitas e preparo relatórios.",
    "Preparo tarefas, follow-ups, planos de ação e rascunhos de automação. Nada é criado sem a sua confirmação.",
  );
  a.sources.push("Nenhum dado consultado");
  return a;
}

/* ------------------------------------------------------------------ roteador */

export async function runAnalysis(ctx: TenantContext, intent: Intent, f: MetricFilters, o: Opts = {}): Promise<Analysis> {
  const now = o.now ?? new Date();
  const a = empty(intent, INTENT_LABELS[intent]);
  switch (intent) {
    case "overview": await overview(ctx, f, a); if (can(ctx, "intelligence:read")) for (const r of (await recommendations(ctx)).slice(0, 3)) a.recommendations.push(`[${r.priority}] ${r.problem}: ${r.action}`); break;
    case "revenue_change": await revenueChange(ctx, f, a); break;
    case "best_seller_conversion": await sellerConversion(ctx, f, a); break;
    case "team_performance": await sellerConversion(ctx, f, a, true); break;
    case "top_leads": await topLeads(ctx, f, a, { propose: true }); break;
    case "stalled_opportunities": await stalledOpportunities(ctx, f, a, now); break;
    case "leads_without_follow_up": await leadsWithoutFollowUp(ctx, f, a, now); break;
    case "best_channel": await bestChannel(ctx, f, a); break;
    case "weekly_priorities": await weeklyPriorities(ctx, f, a, now); break;
    case "forecast": await forecast(ctx, f, a, now); break;
    case "goals": await goals(ctx, f, a, now); break;
    case "inconsistencies": await inconsistencies(ctx, f, a, now); break;
    case "explain_metric": await explainMetric(ctx, f, a, o.message ?? ""); break;
    case "campaign_suggestions": await campaignSuggestions(ctx, f, a, now); break;
    case "report": await report(ctx, f, a); break;
    case "create_task": await createTaskIntent(ctx, a, o.message ?? "", o.route, now); break;
    case "help": help(a); break;
  }
  // Ações que o usuário não pode executar continuam visíveis, mas marcadas.
  for (const p of a.proposals) if (!p.allowed) a.permissionNotes.push(`A ação "${p.title}" exige a permissão "${p.permission}", que seu perfil não tem.`);
  void memberships;
  return a;
}

/** Texto determinístico (fallback e modo sem provedor). Sem emojis; só fatos, hipóteses marcadas e próximos passos. */
export function narrative(a: Analysis, opts: { unknownQuestion?: boolean; continued?: boolean } = {}) {
  const lines: string[] = [];
  if (opts.unknownQuestion) lines.push("Não identifiquei exatamente o que você quer analisar, então trago a visão geral do período. Reformule citando receita, conversão, vendedores, canais, leads, oportunidades paradas, metas ou previsão.");
  if (opts.continued) lines.push(`Continuando a análise anterior (${INTENT_LABELS[a.intent].toLowerCase()}).`);
  lines.push(`${a.title}${a.period ? ` — ${a.period}` : ""}${a.filters.length ? ` (${a.filters.join(", ")})` : ""}`);
  for (const f of a.facts) lines.push(`- ${f}`);
  for (const i of a.inferences) lines.push(`- ${i.startsWith("Hipótese") || i.startsWith("O score") || i.startsWith("Projeções") || i.startsWith("As sugestões") || i.startsWith("Amostra") ? i : "Hipótese: " + i}`);
  if (a.recommendations.length) { lines.push("Próximos passos sugeridos:"); for (const r of a.recommendations.slice(0, 5)) lines.push(`- ${r}`); }
  if (a.proposals.length) lines.push(`Preparei ${a.proposals.length} ação(ões) abaixo. Nada foi criado: revise e confirme se quiser executar.`);
  for (const p of a.permissionNotes) lines.push(p);
  if (a.insufficientData && !a.permissionNotes.length) lines.push("Os dados disponíveis são insuficientes para uma conclusão firme.");
  return lines.join("\n");
}

/** Contexto MINIMIZADO para o modelo: só agregados, rótulos e títulos necessários (sem e-mail, telefone ou documento). */
export function contextForModel(a: Analysis, screen: string) {
  return [
    `Tela atual: ${screen}`,
    `Análise: ${a.title}`,
    a.period ? `Período: ${a.period}` : "",
    a.filters.length ? `Filtros: ${a.filters.join(", ")}` : "",
    a.indicators.length ? `Indicadores:\n${a.indicators.map((i) => `- ${i.label}: ${i.value}${i.detail ? ` (${i.detail})` : ""}`).join("\n")}` : "",
    a.facts.length ? `Fatos:\n${a.facts.map((f) => `- ${f}`).join("\n")}` : "",
    a.inferences.length ? `Hipóteses (não são fatos):\n${a.inferences.map((f) => `- ${f}`).join("\n")}` : "",
    a.evidence.length ? `Evidências:\n${a.evidence.slice(0, 10).map((e) => `- ${e.label}: ${e.detail}`).join("\n")}` : "",
    a.recommendations.length ? `Recomendações do sistema:\n${a.recommendations.map((r) => `- ${r}`).join("\n")}` : "",
    a.criteria.length ? `Critérios:\n${a.criteria.map((c) => `- ${c}`).join("\n")}` : "",
    a.proposals.length ? `Ações preparadas (aguardando confirmação do usuário, NÃO executadas): ${a.proposals.map((p) => p.title).join("; ")}` : "",
    a.permissionNotes.length ? `Limitações de permissão: ${a.permissionNotes.join(" ")}` : "",
  ].filter(Boolean).join("\n").slice(0, 9000);
}
