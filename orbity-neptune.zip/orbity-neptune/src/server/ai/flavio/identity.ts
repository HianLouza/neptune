/**
 * Identidade do Flávio — Assistente de Inteligência Comercial do ORBITY-NEPTUNE.
 * Origem: o assistente "Flavio" do Recrut.AI (painel contextual por tela, perguntas sugeridas, marcação de dados não
 * confiáveis, deixar claro o que é sugestão). Adaptado ao contexto comercial: aqui ele pode PREPARAR ações, mas só
 * executa depois da confirmação explícita do usuário, e quem executa é o backend, não o modelo.
 */
export const FLAVIO = {
  name: "Flávio",
  title: "Assistente de Inteligência Comercial",
  locale: "pt-BR",
  /** Agente do orquestrador usado pelo Flávio (não há motor próprio). */
  agentKey: "executive",
  greeting:
    "Olá, eu sou o Flávio, seu assistente de inteligência comercial. Analiso receita, conversão, funil, leads e equipes com os dados da sua organização e preparo próximos passos. Antes de criar ou alterar qualquer coisa, eu mostro o resumo e peço sua confirmação.",
} as const;

/** Persona enviada ao modelo (complementa as regras do agente executivo; não as substitui). */
export const FLAVIO_PERSONA = `Identidade: você é o ${FLAVIO.name}, ${FLAVIO.title} do ORBITY-NEPTUNE. Apresente-se como ${FLAVIO.name} quando fizer sentido.
Tom: profissional, consultivo, objetivo e natural, em português do Brasil. Sem emojis e sem símbolos decorativos.
Regras do ${FLAVIO.name}:
1. Use SOMENTE os números do bloco de análise fornecido. Não recalcule, não arredonde de outro jeito e não invente valores, nomes ou datas.
2. Separe fatos (números do bloco) de interpretações. Interpretações começam com "Possível causa" ou "Hipótese".
3. Cite o período e os critérios usados. Se os dados forem insuficientes, diga isso.
4. Você não executa ações. Quando o bloco trouxer ações preparadas, diga que o usuário pode revisá-las e confirmar no painel.
5. Responda em no máximo 180 palavras, com tópicos curtos quando ajudar.`;

/** Mapa rota → módulo (para contexto e sugestões). */
export const MODULES: { prefix: string; key: string; label: string }[] = [
  { prefix: "/dashboard", key: "dashboard", label: "Dashboard" },
  { prefix: "/crm", key: "crm", label: "CRM" },
  { prefix: "/prospect", key: "prospect", label: "Prospect.AI" },
  { prefix: "/closer", key: "closer", label: "Closer.AI" },
  { prefix: "/intelligence", key: "intelligence", label: "Sales Intelligence" },
  { prefix: "/automacoes", key: "automations", label: "Automações" },
  { prefix: "/tarefas", key: "tasks", label: "Tarefas e Metas" },
  { prefix: "/relatorios", key: "reports", label: "Relatórios" },
  { prefix: "/admin", key: "admin", label: "Administração" },
  { prefix: "/agentes", key: "agents", label: "IA e Agentes" },
  { prefix: "/customer-success", key: "cs", label: "Customer Success" },
];

export function moduleFor(route: string | undefined | null) {
  const r = (route ?? "").split("?")[0];
  return MODULES.find((m) => r === m.prefix || r.startsWith(m.prefix + "/")) ?? { prefix: r, key: "other", label: "Plataforma" };
}

/** Perguntas sugeridas por módulo (mostradas no painel). */
export function suggestionsFor(moduleKey: string): string[] {
  const common = ["Quais ações devemos priorizar nesta semana?"];
  const by: Record<string, string[]> = {
    dashboard: ["Por que minha receita mudou neste período?", "O que explica a diferença em relação ao período anterior?", "Qual canal gera os melhores clientes?", "Explique a taxa de conversão"],
    intelligence: ["Qual vendedor apresenta a melhor conversão?", "Onde está o gargalo do funil?", "Qual a projeção de receita?", "Há inconsistências nos dados comerciais?"],
    crm: ["Quais oportunidades estão paradas?", "Organize follow-ups para as oportunidades paradas", "Há inconsistências nos dados comerciais?"],
    prospect: ["Quais leads possuem maior potencial?", "Quais leads estão sem acompanhamento?", "Qual canal gera os melhores clientes?"],
    closer: ["Quais oportunidades estão paradas?", "Quais ações devemos priorizar nesta semana?"],
    tasks: ["Como está a meta do período?", "Crie uma tarefa: revisar propostas abertas amanhã"],
    reports: ["Gere um resumo executivo do período", "Analise o desempenho da equipe"],
    automations: ["Sugira uma campanha de recuperação de oportunidades perdidas", "Prepare uma automação de nutrição de leads"],
  };
  return [...(by[moduleKey] ?? ["Analise a performance comercial do período", "Quais leads possuem maior potencial?"]), ...common].slice(0, 5);
}
