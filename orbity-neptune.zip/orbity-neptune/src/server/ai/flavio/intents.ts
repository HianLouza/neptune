/**
 * Classificação determinística de intenção (pt-BR). Não usa modelo: o mesmo texto sempre leva à mesma análise,
 * o que torna o Flávio auditável e funcional sem provedor de IA.
 */
export const INTENTS = [
  "revenue_change", "best_seller_conversion", "team_performance", "top_leads", "stalled_opportunities", "leads_without_follow_up",
  "best_channel", "weekly_priorities", "forecast", "goals", "inconsistencies", "explain_metric", "campaign_suggestions", "report",
  "create_task", "help", "overview",
] as const;
export type Intent = (typeof INTENTS)[number];

export const INTENT_LABELS: Record<Intent, string> = {
  revenue_change: "Variação de receita", best_seller_conversion: "Conversão por vendedor", team_performance: "Desempenho da equipe",
  top_leads: "Leads com maior potencial", stalled_opportunities: "Oportunidades paradas", leads_without_follow_up: "Leads sem acompanhamento",
  best_channel: "Desempenho por canal", weekly_priorities: "Prioridades da semana", forecast: "Projeção de resultados", goals: "Metas",
  inconsistencies: "Inconsistências nos dados", explain_metric: "Explicação de indicador", campaign_suggestions: "Campanhas e recuperação",
  report: "Relatório executivo", create_task: "Criar tarefa", help: "Ajuda", overview: "Visão geral",
};

export const normalize = (s: string) => s.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/\s+/g, " ").trim();

/** Ordem importa: regras mais específicas primeiro. */
const RULES: [Intent, RegExp][] = [
  ["create_task", /\b(cri[ae]r?|adicion[ae]r?|agend[ae]r?|registr[ae]r?)\b.{0,20}\b(tarefa|lembrete|follow.?up)\b|\blembre(-| )?me\b|\bme lembr/],
  ["inconsistencies", /inconsisten|contradi|qualidade dos dados|dados (errados|incorretos|inconsistentes)|erros? nos dados|dados duvidosos/],
  ["explain_metric", /\b(o que (e|significa)|como (e )?calculad|como se calcula|explique|explica|entender) .{0,40}(indicador|metrica|grafico|taxa|conversao|ticket|receita|pipeline|card|kpi)|\bexplique o (grafico|dashboard)/],
  ["revenue_change", /(por ?que|porque|o que explica|motivo|causa).{0,60}(receita|faturamento|vendas?).{0,30}(cai|caiu|caindo|subi|subiu|aument|diminu|queda|mud|vari)|(receita|faturamento).{0,40}(caiu|subiu|queda|mudou|variou|aumentou|diminuiu)|diferenca.{0,40}(mes|periodo) anterior|o que explica a diferenca|comparad[oa] (ao|com o) (mes|periodo)/],
  ["best_seller_conversion", /(vendedor|vendedora|consultor|representante).{0,40}(melhor|maior|pior|menor).{0,20}(conversao|taxa)|(melhor|maior) (taxa de )?conversao.{0,30}(vendedor|equipe)/],
  ["team_performance", /desempenho (da|do|de) (equipe|time|vendedores?|cada)|ranking|performance (da|do) (equipe|time)|desempenho individual|produtividade/],
  ["leads_without_follow_up", /leads?.{0,30}(sem|nao tem|falta de) (acompanhamento|follow|contato|retorno|atividade)|sem acompanhamento/],
  ["stalled_opportunities", /(oportunidades?|negocios?|negociac|deals?).{0,30}(parad|estagnad|sem atividade|travad|esquecid)|parad[ao]s/],
  ["top_leads", /leads?.{0,40}(potencial|priorizar|quentes?|melhores|chance|converter)|quais leads/],
  ["best_channel", /(canal|canais|origem|origens|fonte).{0,40}(melhor|melhores|gera|traz|convert|performa)|melhores clientes/],
  ["campaign_suggestions", /campanha|recupera(r|cao)|reativ|estrategias? de conversao|reconquist/],
  ["weekly_priorities", /priori|esta semana|nessa semana|desta semana|proximos passos|o que (devo|devemos) fazer|plano de acao/],
  ["forecast", /projec|projet|previs|forecast|tendencia|vamos fechar|quanto vamos/],
  ["goals", /\bmetas?\b|atingir|bater a meta|cota/],
  ["report", /relatorio|resumo executivo|sumario|resumo do periodo|resumo gerencial/],
  ["help", /^(oi|ola|bom dia|boa tarde|boa noite)\b|o que voce (faz|pode)|como (voce )?funciona|quem e voce|ajuda$/],
  ["overview", /analis|performance|desempenho|resultado|como (estamos|esta|vai)|panorama|visao geral|receita|vendas|conversao|funil|gargalo/],
];

export function classifyIntent(text: string): Intent | null {
  const t = normalize(text);
  for (const [intent, re] of RULES) if (re.test(t)) return intent;
  return null;
}

/** Perguntas curtas de continuação ("e por vendedor?", "e no mês anterior?") reaproveitam a análise anterior. */
export function isFollowUp(text: string) {
  const t = normalize(text);
  return t.length <= 60 && /^(e |e\?|e o |e a |e os |e as |e no |e na |e por |agora |mas |entao |detalhe|mais detalhes|por que\??$|explique melhor)/.test(t);
}

/** Período citado na pergunta (sobrepõe o filtro da tela). */
export function periodFromText(text: string): { days?: number; month?: "current" | "previous" } | null {
  const t = normalize(text);
  const m = t.match(/(\d{1,3})\s*dias/);
  if (m) {
    const d = Number(m[1]);
    const presets = [7, 30, 90, 180, 365];
    return { days: presets.reduce((a, b) => (Math.abs(b - d) < Math.abs(a - d) ? b : a), 30) };
  }
  if (/\b(este|neste|esse|nesse) mes\b|mes atual/.test(t)) return { month: "current" };
  if (/mes (passado|anterior)/.test(t) && !/em relacao ao mes anterior|comparad|diferenca/.test(t)) return { month: "previous" };
  if (/(ultima|esta|nesta) semana/.test(t)) return { days: 7 };
  if (/trimestre|ultimos 3 meses/.test(t)) return { days: 90 };
  if (/semestre|ultimos 6 meses/.test(t)) return { days: 180 };
  if (/\bano\b|12 meses/.test(t)) return { days: 365 };
  return null;
}

/** Extrai título e prazo de um pedido de tarefa ("crie uma tarefa: ligar para X amanhã"). */
export function parseTaskRequest(text: string, now = new Date()): { title: string; dueAt: Date | null } {
  const raw = text.replace(/\s+/g, " ").trim();
  const afterColon = raw.includes(":") ? raw.slice(raw.indexOf(":") + 1) : raw.replace(/^.*?\b(tarefa|lembrete|follow.?up)\b( para| de)?/i, "");
  let title = afterColon.trim();
  const t = normalize(title);
  let dueAt: Date | null = null;
  const day = (n: number) => { const d = new Date(now); d.setHours(9, 0, 0, 0); d.setDate(d.getDate() + n); return d; };
  if (/\bamanha\b/.test(t)) dueAt = day(1);
  else if (/\bhoje\b/.test(t)) dueAt = day(0);
  else { const m = t.match(/em (\d{1,2}) dias?/); if (m) dueAt = day(Number(m[1])); else if (/proxima semana/.test(t)) dueAt = day(7); }
  title = title.replace(/\b(amanh[aã]|hoje|em \d{1,2} dias?|na pr[oó]xima semana|pr[oó]xima semana)\b/gi, "").replace(/\s+/g, " ").replace(/[.;,]\s*$/, "").trim();
  if (title.length < 2) title = "Tarefa criada pelo Flávio";
  return { title: title.charAt(0).toUpperCase() + title.slice(1, 200), dueAt };
}
