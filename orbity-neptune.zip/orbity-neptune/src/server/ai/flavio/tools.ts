/**
 * FERRAMENTAS DO FLÁVIO — a única forma de o Business Brain / Flávio consultar dados.
 *
 * Regras (Master Prompt 4.0 · Integração Business Brain × Flávio, §5, §10, §12, §13):
 *  - Cada ferramenta EMBRULHA uma função de domínio existente (métricas, CRM, Financeiro, Estratégia, Insights…).
 *    Nenhuma lógica de cálculo é duplicada aqui; nenhuma consulta livre é gerada por IA.
 *  - Toda chamada passa pelo registro: validação de entrada (zod), permissão do USUÁRIO que perguntou (nunca elevada),
 *    escopo da organização (as funções de domínio já filtram por tenant), tempo limite, auditoria e erro honesto.
 *  - Toda saída traz a fonte: módulo, tabela/serviço, período, horário da consulta, indicadores, premissas, método,
 *    confiança, limitações e o estado do dado (real, incompleto, sem permissão, indisponível).
 *  - O modelo de IA (quando houver) só vê o resultado destas ferramentas, como DADO NÃO CONFIÁVEL, nunca o banco.
 */
import { z } from "zod";
import { and, count, eq, gte, sql } from "drizzle-orm";
import { aiExecutions, conversations, workflowRuns } from "../../db/schema";
import { can, type TenantContext } from "../../tenancy/context";
import type { Permission } from "../../permissions";
import { audit } from "../../audit";
import { HttpError } from "../../http";
import { metricFiltersSchema } from "../../domains/metrics";
import { funnelAnalysis, sellerPerformance } from "../../domains/intelligence";
import { slaBreaches } from "../../domains/closer";
import { financialSnapshot } from "../../domains/finance/snapshot";
import { agingReport, breakEvenReport, cashflowReport } from "../../domains/finance";
import { runSimulation, MissingInputError } from "../../domains/strategy";
import { getWallet } from "../../domains/billing";
import { BRAIN_ANALYSES, type Draft } from "../../intelligence-layer/brain";
import { listInsights, ruleStats, scanInsights } from "../../intelligence-layer/insights";

const lastInsightScan = new Map<string, number>();
import { listDecisions } from "../../intelligence-layer/decisions";
import { executionIntelligence } from "../../domains/task-alerts";
import { fmtMoney } from "../../intelligence-layer/evidence";
import { runAnalysis, type Analysis, type Indicator } from "./analyses";
import type { ActionProposal } from "./actions";
import type { Intent } from "./intents";

/* ------------------------------------------------------------------ tipos */

export type Nature = "fato" | "inferência" | "estimativa" | "hipótese" | "recomendação";
export type SectionKey = "situacao" | "fatos" | "comparacao" | "diagnostico" | "impacto" | "riscos" | "oportunidades" | "recomendacoes" | "plano";
export type ToolItem = { text: string; nature: Nature; section: SectionKey };
export type Chart = { title: string; kind: "bar" | "line"; unit: "brl" | "count" | "pct"; points: { label: string; value: number }[] };
export type DataStatus = "real" | "incompleto" | "sem_permissao" | "indisponivel" | "erro";

export type SourceInfo = {
  tool: string; label: string; module: string; source: string; period: string | null; queriedAt: string;
  indicators: string[]; assumptions: string[]; method: string; confidence: number | null; limitations: string[]; missing: string[];
  dataStatus: DataStatus;
};

type ToolOutput = {
  title: string; headline: string | null; items: ToolItem[]; indicators: Indicator[]; chart?: Chart | null;
  proposals?: ActionProposal[]; links?: { label: string; href: string }[];
  source: Partial<SourceInfo> & { source: string }; dataStatus?: DataStatus; data?: unknown;
};

export type ToolResult = Omit<ToolOutput, "source" | "dataStatus"> & {
  tool: string; status: "ok" | "sem_permissao" | "sem_dados" | "indisponivel" | "erro"; message: string | null; durationMs: number;
  source: SourceInfo; proposals: ActionProposal[]; links: { label: string; href: string }[];
};

export type ToolEnv = { question: string; now: Date };

type ToolDef = {
  name: string; label: string; module: string; description: string;
  permissions: Permission[]; input: z.ZodTypeAny; schema: Record<string, unknown>;
  // A entrada já chega validada pelo esquema zod da própria ferramenta (callTool).
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  run: (ctx: TenantContext, input: any, env: ToolEnv) => Promise<ToolOutput>;
};

/* ------------------------------------------------------------------ conversores (reuso das análises existentes) */

const COMPARE_RE = /anterior|\bvs\.?\b|varia|compar|antes|cresceu|caiu|queda|aument/i;

/** Análise do Flávio (analyses.ts) → resultado de ferramenta. */
export function fromAnalysis(a: Analysis, module: string): ToolOutput {
  const items: ToolItem[] = [
    ...a.facts.map((t): ToolItem => ({ text: t, nature: "fato", section: COMPARE_RE.test(t) ? "comparacao" : "fatos" })),
    ...a.inferences.map((t): ToolItem => ({ text: t.replace(/^Hipótese:\s*/i, ""), nature: /^Projeç|projeç|previs/i.test(t) ? "estimativa" : "hipótese", section: "diagnostico" })),
    ...a.recommendations.map((t): ToolItem => ({ text: t, nature: "recomendação", section: "recomendacoes" })),
  ];
  const denied = a.permissionNotes.length > 0 && a.facts.length === 0 && a.indicators.length === 0;
  return {
    title: a.title, headline: a.facts[0] ?? null, items, indicators: a.indicators, proposals: a.proposals, links: a.links,
    dataStatus: denied ? "sem_permissao" : a.insufficientData ? "incompleto" : "real",
    source: {
      module, source: a.sources.join("; ") || "—", period: a.period, indicators: a.indicators.map((i) => i.label),
      method: a.criteria.join(" "), limitations: [...a.permissionNotes, ...(a.insufficientData ? ["Dados insuficientes para conclusão firme."] : [])],
    },
    data: { indicadores: a.indicators, fatos: a.facts, hipoteses: a.inferences, recomendacoes: a.recommendations, filtros: a.filters },
  };
}

/** Análise do Business Brain (brain.ts) → resultado de ferramenta. */
export function fromDraft(d: Draft, module: string, title: string): ToolOutput {
  const nat = (n: string): Nature => (n === "inferência" ? "inferência" : n === "estimativa" ? "estimativa" : n === "recomendação" ? "recomendação" : "fato");
  const items: ToolItem[] = [
    ...d.diagnostico.map((i): ToolItem => ({ text: i.text, nature: nat(i.nature), section: COMPARE_RE.test(i.text) ? "comparacao" : "fatos" })),
    ...d.causasPossiveis.map((i): ToolItem => ({ text: i.text, nature: i.nature === "fato" ? "fato" : "hipótese", section: "diagnostico" })),
    ...d.impactoFinanceiro.map((i): ToolItem => ({ text: i.text, nature: nat(i.nature), section: "impacto" })),
    ...d.alternativas.map((i): ToolItem => ({ text: i.text, nature: "recomendação", section: "oportunidades" })),
    ...d.recomendacoes.map((i): ToolItem => ({ text: i.text, nature: "recomendação", section: "recomendacoes" })),
    ...d.planoDeAcao.map((p): ToolItem => ({ text: `${p.passo} · prazo: ${p.prazo}`, nature: "recomendação", section: "plano" })),
  ];
  const ev = d.evidencias;
  const missing = ev.missingData.filter(Boolean);
  const noPerm = missing.some((m) => /permiss/i.test(m));
  const empty = ev.facts.length === 0 && ev.confidence === 0;
  return {
    title, headline: d.resumoExecutivo, items, indicators: [],
    dataStatus: empty ? (noPerm ? "sem_permissao" : "incompleto") : missing.length ? "incompleto" : "real",
    source: {
      module, source: d.dadosUtilizados.map((x) => x.fonte).join("; ") || ev.facts.map((f) => f.source).join("; ") || "—",
      period: d.dadosUtilizados.find((x) => x.periodo)?.periodo ?? ev.facts.find((f) => f.period)?.period ?? null,
      indicators: d.indicadores, assumptions: ev.assumptions, method: ev.calculations.join(" "), confidence: ev.confidence,
      limitations: ev.limitations, missing,
    },
    data: { resumo: d.resumoExecutivo, fatos: ev.facts, diagnostico: d.diagnostico.map((x) => x.text), causas: d.causasPossiveis.map((x) => x.text), impacto: d.impactoFinanceiro.map((x) => x.text) },
  };
}

/* ------------------------------------------------------------------ entradas e esquemas */

const DAYS = [7, 30, 90, 180, 365] as const;
const periodInput = z.object({ dias: z.coerce.number().int().refine((d) => (DAYS as readonly number[]).includes(d), "Período inválido").default(30) });
const periodSchema = { type: "object", properties: { dias: { type: "integer", enum: [...DAYS], description: "Janela de análise em dias (comparada com a janela anterior de mesmo tamanho)." } }, required: ["dias"], additionalProperties: false };
const noInput = z.object({}).passthrough();
const noSchema = { type: "object", properties: {}, required: [], additionalProperties: false };

const money = (ctx: TenantContext, c: number) => fmtMoney(c, ctx.locale, ctx.currency);
const flavio = (intent: Intent, module: string) => async (ctx: TenantContext, input: { dias: number }, env: ToolEnv) =>
  fromAnalysis(await runAnalysis(ctx, intent, metricFiltersSchema.parse({ days: input.dias }), { now: env.now, message: env.question }), module);

const UNAVAILABLE: Record<string, { label: string; missing: string }> = {
  market_radar: { label: "Market Radar", missing: "fontes externas licenciadas (notícias, preços públicos, concorrentes) ainda não conectadas" },
  benchmark: { label: "Business Benchmark", missing: "base anonimizada de várias empresas com consentimento e metodologia estatística" },
  document_intelligence: { label: "Document Intelligence", missing: "leitura de PDF/OCR e indexação de contratos e propostas" },
  customer_360: { label: "Customer 360 completo", missing: "contratos, pagamentos por cliente, uso do produto e satisfação integrados" },
  revenue_operations: { label: "Revenue Operations", missing: "territórios, quotas, CPQ e gestão de contratos" },
};

/* ------------------------------------------------------------------ catálogo */

const TOOLS: ToolDef[] = [
  {
    name: "visao_geral_comercial", label: "Visão geral comercial", module: "Sales Intelligence", permissions: ["intelligence:read"],
    description: "Indicadores comerciais do período (receita ganha, vendas, leads, oportunidades, conversão, ticket médio) com variação contra o período anterior.",
    input: periodInput, schema: periodSchema, run: flavio("overview", "Sales Intelligence"),
  },
  {
    name: "variacao_receita", label: "Variação de receita", module: "Sales Intelligence", permissions: ["intelligence:read"],
    description: "Decompõe a variação da receita ganha em volume × ticket médio e mostra as maiores variações por vendedor e por origem.",
    input: periodInput, schema: periodSchema, run: flavio("revenue_change", "Sales Intelligence"),
  },
  {
    name: "desempenho_vendedores", label: "Desempenho por vendedor", module: "CRM / Sales Intelligence", permissions: ["intelligence:read"],
    description: "Receita, vendas, perdas, oportunidades abertas e taxa de ganho por vendedor no período, com conversão por vendedor.",
    input: periodInput, schema: periodSchema,
    run: async (ctx, input, env) => {
      const out = fromAnalysis(await runAnalysis(ctx, "team_performance", metricFiltersSchema.parse({ days: input.dias }), { now: env.now, message: env.question }), "CRM / Sales Intelligence");
      const sellers = await sellerPerformance(ctx, input.dias);
      out.chart = sellers.length ? { title: `Receita ganha por vendedor (${input.dias} dias)`, kind: "bar", unit: "brl", points: sellers.slice(0, 10).map((s) => ({ label: s.name, value: s.revenue / 100 })) } : null;
      out.data = { ...(out.data as object), vendedores: sellers.slice(0, 15).map((s) => ({ nome: s.name, ganhos: s.won, perdidos: s.lost, abertos: s.open, receitaCentavos: s.revenue, taxaGanhoPct: s.winRate })) };
      return out;
    },
  },
  {
    name: "metas", label: "Metas e ritmo", module: "Tarefas & Metas", permissions: ["goals:read"],
    description: "Progresso das metas ativas, ritmo necessário e probabilidade de cumprimento pelo ritmo atual.",
    input: periodInput, schema: periodSchema, run: flavio("goals", "Tarefas & Metas"),
  },
  {
    name: "previsao_receita", label: "Previsão de receita", module: "Sales Intelligence", permissions: ["intelligence:read"],
    description: "Previsão de receita ponderada pelo pipeline aberto (cenários pessimista, base e otimista) e projeção do período.",
    input: periodInput, schema: periodSchema, run: flavio("forecast", "Sales Intelligence"),
  },
  {
    name: "funil_vendas", label: "Funil de vendas", module: "CRM", permissions: ["intelligence:read"],
    description: "Quantidade e valor das oportunidades por etapa do funil e taxa de passagem entre etapas (gargalos).",
    input: noInput, schema: noSchema,
    run: async (ctx) => {
      const f = await funnelAnalysis(ctx);
      const open = f.filter((s) => s.kind === "open");
      const items: ToolItem[] = f.map((s) => ({ text: `${s.name}: ${s.n} oportunidade(s), ${money(ctx, s.total)}.`, nature: "fato", section: "fatos" }));
      for (let i = 1; i < open.length; i++) {
        const prev = open[i - 1], cur = open[i];
        if (prev.n >= 10 && cur.n / prev.n < 0.35) items.push({ text: `Possível gargalo entre "${prev.name}" e "${cur.name}": ${Math.round((cur.n / prev.n) * 100)}% de passagem.`, nature: "inferência", section: "diagnostico" });
      }
      const biggest = [...open].sort((a, b) => b.total - a.total)[0];
      return {
        title: "Funil de vendas", headline: biggest ? `Maior valor parado em "${biggest.name}" (${biggest.n} oportunidades, ${money(ctx, biggest.total)}).` : "Sem oportunidades abertas.",
        items, indicators: [], dataStatus: f.length ? "real" : "incompleto",
        chart: open.length ? { title: "Oportunidades abertas por etapa", kind: "bar", unit: "count", points: open.map((s) => ({ label: s.name, value: s.n })) } : null,
        source: { module: "CRM", source: "CRM · oportunidades e etapas do funil", period: "posição atual", indicators: ["Oportunidades por etapa", "Valor por etapa", "Taxa de passagem"], method: "Contagem e soma por etapa; passagem = etapa seguinte ÷ etapa anterior." },
        data: f.map((s) => ({ etapa: s.name, tipo: s.kind, quantidade: s.n, valorCentavos: s.total })),
      };
    },
  },
  {
    name: "motivos_perda", label: "Onde perdemos oportunidades", module: "CRM", permissions: ["intelligence:read"],
    description: "Oportunidades perdidas por motivo e etapa, valor perdido e padrões de perda.",
    input: noInput, schema: noSchema, run: async (ctx) => fromDraft(await BRAIN_ANALYSES.lostOpportunities(ctx), "CRM", "Motivos de perda"),
  },
  {
    name: "oportunidades_paradas", label: "Oportunidades paradas", module: "CRM", permissions: ["crm:read"],
    description: "Oportunidades abertas sem atividade recente, com valor em risco e responsáveis.",
    input: periodInput, schema: periodSchema, run: flavio("stalled_opportunities", "CRM"),
  },
  {
    name: "canais_e_origens", label: "Canais e origens", module: "Prospect.AI / CRM", permissions: ["intelligence:read"],
    description: "Leads, conversão e receita por origem/canal no período (qual canal gera os clientes mais rentáveis, com os dados disponíveis).",
    input: periodInput, schema: periodSchema, run: flavio("best_channel", "Prospect.AI / CRM"),
  },
  {
    name: "leads_prioritarios", label: "Leads prioritários", module: "Prospect.AI", permissions: ["prospect:read"],
    description: "Leads com maior pontuação e potencial, ainda não convertidos.",
    input: periodInput, schema: periodSchema, run: flavio("top_leads", "Prospect.AI"),
  },
  {
    name: "leads_sem_acompanhamento", label: "Leads sem acompanhamento", module: "Prospect.AI", permissions: ["prospect:read"],
    description: "Leads sem contato ou tarefa recente.",
    input: periodInput, schema: periodSchema, run: flavio("leads_without_follow_up", "Prospect.AI"),
  },
  {
    name: "prioridades_semana", label: "Prioridades da semana", module: "Sales Intelligence", permissions: ["intelligence:read"],
    description: "Lista priorizada do que fazer nesta semana (negócios em fechamento, paradas, metas, leads quentes).",
    input: periodInput, schema: periodSchema, run: flavio("weekly_priorities", "Sales Intelligence"),
  },
  {
    name: "inconsistencias_dados", label: "Qualidade dos dados", module: "Data Intelligence", permissions: ["intelligence:read"],
    description: "Inconsistências e lacunas nos dados comerciais (sem dono, sem valor, sem origem, datas incoerentes).",
    input: periodInput, schema: periodSchema, run: flavio("inconsistencies", "Data Intelligence"),
  },
  {
    name: "atendimento_closer", label: "Atendimento (Closer.AI)", module: "Closer.AI", permissions: ["closer:read"],
    description: "Conversas abertas, fora do prazo de resposta (SLA) e aguardando atendimento humano.",
    input: noInput, schema: noSchema,
    run: async (ctx) => {
      const breaches = await slaBreaches(ctx.db, ctx.organizationId);
      const [st] = await ctx.db.select({
        open: sql<number>`count(*) filter (where ${conversations.status} <> 'closed')::int`,
        handoff: sql<number>`count(*) filter (where ${conversations.status} = 'handoff')::int`,
      }).from(conversations).where(eq(conversations.organizationId, ctx.organizationId));
      const items: ToolItem[] = [
        { text: `${st.open} conversa(s) abertas; ${breaches.length} fora do SLA; ${st.handoff} aguardando humano.`, nature: "fato", section: "fatos" },
      ];
      if (breaches.length) items.push({ text: `${breaches.length} cliente(s) esperando resposta além do prazo: risco de perda por tempo de resposta.`, nature: "inferência", section: "riscos" });
      return {
        title: "Atendimento", headline: items[0].text, items, indicators: [
          { label: "Conversas abertas", value: String(st.open) }, { label: "Fora do SLA", value: String(breaches.length) }, { label: "Aguardando humano", value: String(st.handoff) },
        ],
        source: { module: "Closer.AI", source: "Closer.AI · conversas", period: "posição atual", indicators: ["Conversas abertas", "SLA vencido", "Handoff"], method: "SLA vencido = prazo de resposta anterior a agora e conversa não encerrada." },
        data: { abertas: st.open, foraDoSla: breaches.length, aguardandoHumano: st.handoff },
      };
    },
  },
  {
    name: "insights_abertos", label: "Alertas e insights", module: "Intelligence Layer", permissions: ["intelligence:read"],
    description: "Insights proativos abertos (riscos e oportunidades detectados por regras, com evidência) e a precisão histórica de cada regra.",
    input: noInput, schema: noSchema,
    run: async (ctx) => {
      // Alertas guardados podem estar desatualizados (o processo de fundo pode não estar rodando): recalcula se a
      // última análise desta organização tem mais de 15 minutos, para não misturar números antigos com dados atuais.
      const last = lastInsightScan.get(ctx.organizationId) ?? 0;
      if (Date.now() - last > 15 * 60_000) {
        try { await scanInsights(ctx); lastInsightScan.set(ctx.organizationId, Date.now()); } catch { /* segue com os alertas guardados */ }
      }
      const rank = { high: 0, medium: 1, low: 2 } as Record<string, number>;
      const rows = (await listInsights(ctx, { status: ["open", "accepted", "modified"], limit: 15 })).sort((a, b) => (rank[a.priority] ?? 3) - (rank[b.priority] ?? 3));
      const stats = await ruleStats(ctx);
      const items: ToolItem[] = rows.flatMap((r): ToolItem[] => [
        {
          text: `[${r.priority === "high" ? "alta" : r.priority === "medium" ? "média" : "baixa"}] ${r.title} — ${r.summary}`,
          nature: r.nature === "estimate" ? "estimativa" : r.nature === "recommendation" ? "recomendação" : r.nature === "inference" ? "inferência" : "fato",
          section: /expans|oportunidade de|potencial/i.test(r.title) ? "oportunidades" : "riscos",
        },
        ...(r.recommendedAction ? [{ text: `${r.recommendedAction} (${r.title})`, nature: "recomendação" as const, section: "recomendacoes" as const }] : []),
      ]);
      const demoted = stats.filter((s) => s.demoted);
      return {
        title: "Alertas e insights",
        headline: rows.length
          ? `${rows.length === 1 ? "O principal ponto de atenção é" : `Os ${Math.min(3, rows.length)} principais pontos de atenção são`}: ${rows.slice(0, 3).map((r, i) => `${rows.length > 1 ? `${i + 1}) ` : ""}${r.title}`).join("; ")}.`
          : "Nenhum alerta aberto.",
        items, indicators: [{ label: "Alertas abertos", value: String(rows.length) }],
        source: { module: "Intelligence Layer", source: "Insights (regras determinísticas com evidência)", period: "abertos agora", indicators: ["Alertas por prioridade"], method: "Regras fixas sobre CRM, Closer.AI, metas, Financeiro e IA.", limitations: demoted.length ? [`Regras com prioridade reduzida pelo histórico de rejeição: ${demoted.map((d) => d.label).join(", ")}.`] : [] },
        data: rows.map((r) => ({ id: r.id, titulo: r.title, resumo: r.summary, prioridade: r.priority, dominio: r.domain, acao: r.recommendedAction })),
      };
    },
  },
  {
    name: "decisoes_pendentes", label: "Decisões pendentes", module: "Decision Engine", permissions: ["intelligence:read"],
    description: "Decisões aguardando aprovação ou em monitoramento.",
    input: noInput, schema: noSchema,
    run: async (ctx) => {
      const rows = await listDecisions(ctx, { status: ["pending_approval", "monitoring", "draft"], limit: 15 });
      return {
        title: "Decisões", headline: rows.length ? `${rows.length} decisão(ões) em aberto.` : "Nenhuma decisão em aberto.",
        items: rows.map((d) => ({ text: `${d.title} (${d.status === "pending_approval" ? "aguardando aprovação" : d.status === "monitoring" ? "em monitoramento" : "rascunho"}).`, nature: "fato" as const, section: "fatos" as const })),
        indicators: [], source: { module: "Decision Engine", source: "Decisões registradas", period: "em aberto", method: "Lista de decisões nos estados rascunho, aguardando aprovação e monitoramento." },
        data: rows.map((d) => ({ id: d.id, titulo: d.title, status: d.status })),
      };
    },
  },
  {
    name: "execucao_e_alertas", label: "Execução de tarefas e alertas", module: "Task Intelligence", permissions: ["alerts:send"],
    description: "Tarefas atrasadas por equipe, bloqueios, sobrecarga, motivos de atraso, prorrogações e resultado dos alertas. Fatos, inferências e recomendações separados; não avalia pessoas e não afirma causalidade.",
    input: periodInput, schema: periodSchema,
    run: async (ctx, input: { dias: number }) => {
      const r = await executionIntelligence(ctx, input.dias);
      const f = r.facts;
      const items: ToolItem[] = [
        { text: `${f.openTasks} tarefa(s) aberta(s), ${f.overdueTasks} atrasada(s), ${f.blockedTasks} bloqueada(s) com justificativa e ${f.tasksWithoutUpdate7d} sem atualização há mais de 7 dias.`, nature: "fato", section: "fatos" },
        { text: `${f.unassignedCriticalTasks} tarefa(s) de prioridade alta sem responsável.`, nature: "fato", section: "fatos" },
        ...Object.entries(f.overdueByTeam).map(([team, n]): ToolItem => ({ text: `Equipe ${team}: ${n} tarefa(s) atrasada(s).`, nature: "fato", section: "fatos" })),
        { text: `${f.alertsSent} alerta(s) enviado(s) no período.`, nature: "fato", section: "fatos" },
        ...r.inferences.map((t): ToolItem => ({ text: t, nature: "hipótese", section: "diagnostico" })),
        ...r.recommendations.map((t): ToolItem => ({ text: t, nature: "recomendação", section: "recomendacoes" })),
      ];
      return {
        title: "Execução de tarefas e alertas", headline: items[0].text, items, indicators: [],
        links: [{ label: "Abrir a Central de Alertas", href: "/alertas" }],
        source: { module: "Task Intelligence", source: "Tarefas, alertas, respostas e prorrogações da organização", period: `últimos ${input.dias} dias`, method: "Contagens diretas no banco; inferências são hipóteses.", limitations: r.caveats },
        data: r,
      };
    },
  },
  {
    name: "resumo_financeiro", label: "Resumo financeiro", module: "Financial Intelligence", permissions: ["finance:read"],
    description: "Recebimentos, pagamentos, resultado, margem de caixa, títulos em aberto e vencidos e saldo projetado de 30 dias.",
    input: periodInput, schema: periodSchema,
    run: async (ctx, input) => {
      const s = await financialSnapshot(ctx, input.dias);
      if (!s.hasData) return {
        title: "Resumo financeiro", headline: "Não há lançamentos financeiros registrados.", items: [], indicators: [], dataStatus: "incompleto",
        source: { module: "Financial Intelligence", source: "Financeiro · lançamentos", period: `últimos ${input.dias} dias`, missing: ["Lançamentos de contas a pagar e a receber (ou integração de pagamentos)"] },
      };
      const pct = (cur: number, prev: number) => (prev ? Math.round(((cur - prev) / prev) * 1000) / 10 : null);
      const dRev = pct(s.revenueCents, s.previous.revenueCents), dExp = pct(s.expensesCents, s.previous.expensesCents);
      const items: ToolItem[] = [
        { text: `Recebido: ${money(ctx, s.revenueCents)}; pago: ${money(ctx, s.expensesCents)}; resultado de caixa: ${money(ctx, s.resultCents)}${s.marginPct != null ? ` (margem ${s.marginPct}%)` : ""}.`, nature: "fato", section: "fatos" },
        { text: `Período anterior: recebido ${money(ctx, s.previous.revenueCents)}, pago ${money(ctx, s.previous.expensesCents)}${dRev != null ? ` (recebimentos ${dRev > 0 ? "+" : ""}${dRev}%` : ""}${dExp != null ? `, despesas ${dExp > 0 ? "+" : ""}${dExp}%)` : dRev != null ? ")" : ""}.`, nature: "fato", section: "comparacao" },
        { text: `A receber em aberto: ${money(ctx, s.receivableOpenCents)} (vencido: ${money(ctx, s.overdueReceivableCents)} em ${s.overdueReceivableCount} título(s)). A pagar em aberto: ${money(ctx, s.payableOpenCents)}.`, nature: "fato", section: "fatos" },
        { text: `Saldo projetado dos próximos 30 dias (títulos em aberto): ${money(ctx, s.next30.netCents)}.`, nature: "estimativa", section: "impacto" },
      ];
      if (s.overdueReceivableCents > 0) items.push({ text: `Recebíveis vencidos (${money(ctx, s.overdueReceivableCents)}) pressionam o caixa.`, nature: "inferência", section: "riscos" });
      if (s.next30.netCents < 0) items.push({ text: `Saídas previstas superam as entradas em ${money(ctx, -s.next30.netCents)} nos próximos 30 dias.`, nature: "estimativa", section: "riscos" });
      return {
        title: "Resumo financeiro", headline: items[0].text, items,
        indicators: [{ label: "Resultado de caixa", value: money(ctx, s.resultCents) }, { label: "Margem de caixa", value: s.marginPct != null ? `${s.marginPct}%` : "—" }, { label: "Saldo projetado 30d", value: money(ctx, s.next30.netCents) }],
        source: { module: "Financial Intelligence", source: "Financeiro · lançamentos (regime de caixa)", period: `últimos ${input.dias} dias vs. ${input.dias} anteriores`, indicators: ["Recebimentos", "Pagamentos", "Resultado", "Margem", "Vencidos", "Projeção 30d"], method: "Soma de títulos pagos no período; projeção = títulos em aberto com vencimento em 30 dias.", limitations: ["Sem integração bancária: saldo em conta não é considerado."] },
        data: s,
      };
    },
  },
  {
    name: "despesas_crescentes", label: "Despesas que cresceram", module: "Financial Intelligence", permissions: ["finance:read"],
    description: "Despesas por categoria comparadas com o período anterior (quais cresceram e quanto).",
    input: noInput, schema: noSchema, run: async (ctx) => fromDraft(await BRAIN_ANALYSES.expensesGrowth(ctx), "Financial Intelligence", "Despesas por categoria"),
  },
  {
    name: "caixa_projetado", label: "Fluxo de caixa projetado", module: "Financial Intelligence", permissions: ["finance:read"],
    description: "Fluxo de caixa das próximas semanas, recebíveis vencidos e decisões com maior efeito no caixa.",
    input: noInput, schema: noSchema,
    run: async (ctx, _i, env) => {
      const out = fromDraft(await BRAIN_ANALYSES.cashflow(ctx), "Financial Intelligence", "Fluxo de caixa");
      if (out.dataStatus !== "sem_permissao") {
        const cf = await cashflowReport(ctx, env.now);
        if (cf.buckets.length) out.chart = { title: "Saldo líquido previsto por semana (títulos em aberto)", kind: "bar", unit: "brl", points: cf.buckets.map((b) => ({ label: b.label, value: b.netCents / 100 })) };
      }
      return out;
    },
  },
  {
    name: "rentabilidade_produtos", label: "Rentabilidade por produto", module: "Financial Intelligence", permissions: ["finance:read"],
    description: "Margem direta por produto (quando os lançamentos estão vinculados a produtos) e qual priorizar.",
    input: noInput, schema: noSchema, run: async (ctx) => fromDraft(await BRAIN_ANALYSES.productProfitability(ctx, true), "Financial Intelligence", "Rentabilidade por produto"),
  },
  {
    name: "inadimplencia", label: "Inadimplência", module: "Financial Intelligence", permissions: ["finance:read"],
    description: "Recebíveis vencidos por faixa de atraso, taxa de inadimplência de 90 dias e maiores devedores.",
    input: noInput, schema: noSchema,
    run: async (ctx, _i, env) => {
      const a = await agingReport(ctx, env.now);
      const items: ToolItem[] = [
        { text: `Vencido em aberto: ${money(ctx, a.overdueCents)} em ${a.overdueCount} título(s)${a.ratePct != null ? `; inadimplência de 90 dias: ${a.ratePct}%` : ""}.`, nature: "fato", section: "fatos" },
        ...a.byClient.slice(0, 5).map((c): ToolItem => ({ text: `${c.name}: ${money(ctx, c.cents)} vencidos (${c.count} título[s]).`, nature: "fato", section: "riscos" })),
      ];
      return {
        title: "Inadimplência", headline: items[0].text, items, indicators: [{ label: "Vencido em aberto", value: money(ctx, a.overdueCents) }, { label: "Inadimplência 90d", value: a.ratePct != null ? `${a.ratePct}%` : "—" }],
        chart: { title: "Vencidos por faixa de atraso", kind: "bar", unit: "brl", points: a.buckets.map((b) => ({ label: b.label, value: b.cents / 100 })) },
        dataStatus: a.overdueCount === 0 && a.dueLast90Cents === 0 ? "incompleto" : "real",
        source: { module: "Financial Intelligence", source: "Financeiro · contas a receber", period: "últimos 90 dias", method: a.formula, confidence: a.evidence.confidence, limitations: a.evidence.limitations },
        data: { faixas: a.buckets, taxaPct: a.ratePct, porCliente: a.byClient },
      };
    },
  },
  {
    name: "ponto_de_equilibrio", label: "Ponto de equilíbrio", module: "Financial Intelligence", permissions: ["finance:read"],
    description: "Receita mínima mensal para cobrir custos fixos, a partir da margem de contribuição dos últimos meses completos.",
    input: noInput, schema: noSchema,
    run: async (ctx, _i, env) => {
      const b = await breakEvenReport(ctx, env.now);
      const items: ToolItem[] = b.computable
        ? [{ text: `Ponto de equilíbrio (receita bruta): ${money(ctx, b.breakEvenReceitaBruta ?? 0)}/mês; média atual: ${money(ctx, b.avgReceitaBruta)}/mês.`, nature: "estimativa", section: "fatos" },
          ...(b.gapReceitaBruta != null ? [{ text: b.gapReceitaBruta > 0 ? `Folga de ${money(ctx, b.gapReceitaBruta)}/mês acima do equilíbrio.` : `Faltam ${money(ctx, -b.gapReceitaBruta)}/mês para o equilíbrio.`, nature: "estimativa" as const, section: "impacto" as const }] : [])]
        : [{ text: `Não foi possível calcular: ${b.reason ?? "dados insuficientes"}.`, nature: "fato", section: "fatos" }];
      return {
        title: "Ponto de equilíbrio", headline: items[0].text, items, indicators: [], dataStatus: b.computable ? "real" : "incompleto",
        source: { module: "Financial Intelligence", source: "Financeiro · DRE gerencial", period: b.basisMonths.join(", ") || null, assumptions: b.premises, method: b.calculations.join(" "), confidence: b.evidence.confidence, limitations: b.evidence.limitations, missing: b.evidence.missingData },
        data: b,
      };
    },
  },
  {
    name: "capacidade_contratacao", label: "Capacidade de contratação", module: "Financial Intelligence", permissions: ["finance:read"],
    description: "Impacto de novas contratações no resultado e no caixa. Informe o número de pessoas e o salário mensal se o usuário disse; senão use null (a ferramenta pede o salário em vez de supor).",
    input: z.object({ pessoas: z.coerce.number().int().min(1).max(100).nullable().default(null), salario_mensal_reais: z.coerce.number().min(0).max(1e7).nullable().default(null) }),
    schema: { type: "object", properties: { pessoas: { type: ["integer", "null"] }, salario_mensal_reais: { type: ["number", "null"] } }, required: ["pessoas", "salario_mensal_reais"], additionalProperties: false },
    run: async (ctx, input, env) => {
      const q = input.pessoas || input.salario_mensal_reais
        ? `posso contratar ${input.pessoas ?? 1} funcionários${input.salario_mensal_reais ? ` de R$ ${String(input.salario_mensal_reais).replace(".", ",")}` : ""}`
        : env.question;
      return fromDraft(await BRAIN_ANALYSES.hiring(ctx, q), "Financial Intelligence", "Capacidade de contratação");
    },
  },
  {
    name: "clientes_em_risco", label: "Clientes em risco", module: "Customer 360 (parcial)", permissions: ["crm:read"],
    description: "Clientes com sinais de risco (perdas recentes, inatividade, recebíveis vencidos).",
    input: noInput, schema: noSchema, run: async (ctx) => fromDraft(await BRAIN_ANALYSES.customersRisk(ctx), "Customer 360 (parcial)", "Clientes em risco"),
  },
  {
    name: "clientes_expansao", label: "Clientes com potencial de expansão", module: "Customer 360 (parcial)", permissions: ["crm:read"],
    description: "Clientes com sinais de expansão (compras recorrentes, oportunidades abertas, engajamento recente).",
    input: noInput, schema: noSchema, run: async (ctx) => fromDraft(await BRAIN_ANALYSES.expansion(ctx), "Customer 360 (parcial)", "Potencial de expansão"),
  },
  {
    name: "simulacao_estrategica", label: "Simulação estratégica", module: "Strategy Simulator", permissions: ["strategy:read"],
    description: "Simula mudanças de preço, volume, custos fixos e contratações sobre a base real (mês típico) e devolve cenários pessimista/base/otimista. Use 0 para o que não muda; custo_por_contratacao_reais null se desconhecido.",
    input: z.object({
      preco_pct: z.coerce.number().min(-90).max(500).default(0), volume_pct: z.coerce.number().min(-100).max(1000).default(0),
      custos_fixos_pct: z.coerce.number().min(-100).max(1000).default(0), contratacoes: z.coerce.number().int().min(-1000).max(1000).default(0),
      custo_por_contratacao_reais: z.coerce.number().min(0).max(1e8).nullable().default(null),
    }),
    schema: { type: "object", properties: { preco_pct: { type: "number" }, volume_pct: { type: "number" }, custos_fixos_pct: { type: "number" }, contratacoes: { type: "integer" }, custo_por_contratacao_reais: { type: ["number", "null"] } }, required: ["preco_pct", "volume_pct", "custos_fixos_pct", "contratacoes", "custo_por_contratacao_reais"], additionalProperties: false },
    run: async (ctx, input) => {
      try {
        const r = await runSimulation(ctx, {
          priceChangePct: input.preco_pct, volumeChangePct: input.volume_pct, fixedCostChangePct: input.custos_fixos_pct, newHires: input.contratacoes,
          monthlyCostPerHireCents: input.custo_por_contratacao_reais != null ? Math.round(input.custo_por_contratacao_reais * 100) : null,
        });
        const s = r.result;
        const items: ToolItem[] = [
          { text: `Base (mês típico): receita ${money(ctx, s.current.revenueCents)}, resultado ${money(ctx, s.current.resultCents)}.`, nature: "fato", section: "situacao" },
          { text: `Cenário base simulado: receita ${money(ctx, s.scenarios.base.revenueCents)}, resultado ${money(ctx, s.scenarios.base.resultCents)} (${s.delta.resultCents >= 0 ? "+" : ""}${money(ctx, s.delta.resultCents)}/mês).`, nature: "estimativa", section: "impacto" },
          { text: `Faixa: pessimista ${money(ctx, s.scenarios.pessimista.resultCents)} a otimista ${money(ctx, s.scenarios.otimista.resultCents)} de resultado/mês.`, nature: "estimativa", section: "impacto" },
          ...s.notes.map((n): ToolItem => ({ text: n, nature: "fato", section: "fatos" })),
        ];
        return {
          title: "Simulação estratégica", headline: items[1].text, items, indicators: [],
          chart: { title: "Resultado mensal por cenário", kind: "bar", unit: "brl", points: [{ label: "Hoje", value: s.current.resultCents / 100 }, { label: "Pessimista", value: s.scenarios.pessimista.resultCents / 100 }, { label: "Base", value: s.scenarios.base.resultCents / 100 }, { label: "Otimista", value: s.scenarios.otimista.resultCents / 100 }] },
          source: { module: "Strategy Simulator", source: `Base real: ${r.baseline.revenueSource === "finance" ? "Financeiro (recebimentos)" : "CRM (negócios ganhos)"}`, period: "mês típico (últimos 90 dias)", assumptions: s.assumptions, method: "Modelo determinístico do Simulador Estratégico (elasticidade, custos variáveis acompanham o volume).", confidence: r.evidence.confidence, limitations: r.evidence.limitations, missing: r.evidence.missingData },
          data: { variaveis: input, atual: s.current, cenarios: s.scenarios, delta: s.delta },
        };
      } catch (err) {
        if (err instanceof MissingInputError) return {
          title: "Simulação estratégica", headline: err.message, items: [{ text: err.message, nature: "fato", section: "fatos" }], indicators: [], dataStatus: "incompleto",
          source: { module: "Strategy Simulator", source: "Base real (CRM/Financeiro)", missing: err.fields },
        };
        throw err;
      }
    },
  },
  {
    name: "uso_ia_e_creditos", label: "Uso de IA e créditos", module: "AI Control Plane / Billing", permissions: ["ai:use"],
    description: "Execuções de IA nos últimos 30 dias (sucesso, falha, bloqueio, simuladas), créditos consumidos e saldo da carteira.",
    input: noInput, schema: noSchema,
    run: async (ctx, _i, env) => {
      const since = new Date(env.now.getTime() - 30 * 864e5);
      const [r] = await ctx.db.select({
        total: count(), credits: sql<number>`coalesce(sum(${aiExecutions.credits}),0)::int`,
        failed: sql<number>`count(*) filter (where ${aiExecutions.status} = 'error')::int`, blocked: sql<number>`count(*) filter (where ${aiExecutions.status} = 'blocked')::int`,
        simulated: sql<number>`count(*) filter (where ${aiExecutions.simulated})::int`,
      }).from(aiExecutions).where(and(eq(aiExecutions.organizationId, ctx.organizationId), gte(aiExecutions.createdAt, since)));
      const wallet = can(ctx, "billing:read") ? await getWallet(ctx.db, ctx.organizationId) : null;
      const items: ToolItem[] = [{ text: `${r.total} execução(ões) de IA em 30 dias: ${r.failed} com falha, ${r.blocked} bloqueadas, ${r.simulated} em modo simulado; ${r.credits} crédito(s) consumido(s).`, nature: "fato", section: "fatos" }];
      if (wallet) items.push({ text: `Saldo de créditos: ${wallet.balance}.`, nature: "fato", section: "situacao" });
      return {
        title: "Uso de IA", headline: items[0].text, items, indicators: [],
        source: { module: "AI Control Plane / Billing", source: "Execuções de IA e carteira de créditos", period: "últimos 30 dias", limitations: wallet ? [] : ["Saldo da carteira omitido: requer billing:read."] },
        data: { ...r, saldo: wallet?.balance ?? null },
      };
    },
  },
  {
    name: "automacoes_execucoes", label: "Automações", module: "Automation Center", permissions: ["automations:read"],
    description: "Execuções de automações nos últimos 30 dias por status (concluídas, com falha, aguardando aprovação).",
    input: noInput, schema: noSchema,
    run: async (ctx, _i, env) => {
      const since = new Date(env.now.getTime() - 30 * 864e5);
      const rows = await ctx.db.select({ status: workflowRuns.status, n: count() }).from(workflowRuns)
        .where(and(eq(workflowRuns.organizationId, ctx.organizationId), gte(workflowRuns.createdAt, since))).groupBy(workflowRuns.status);
      const by = Object.fromEntries(rows.map((r) => [r.status, Number(r.n)]));
      const total = rows.reduce((a, r) => a + Number(r.n), 0);
      return {
        title: "Automações", headline: `${total} execução(ões) em 30 dias${by.failed ? `, ${by.failed} com falha` : ""}.`,
        items: [{ text: `Execuções de automações em 30 dias: ${Object.entries(by).map(([k, v]) => `${k}: ${v}`).join(", ") || "nenhuma"}.`, nature: "fato", section: "fatos" }],
        indicators: [], dataStatus: total ? "real" : "incompleto",
        source: { module: "Automation Center", source: "Execuções de workflows", period: "últimos 30 dias" }, data: by,
      };
    },
  },
  {
    name: "modulo_indisponivel", label: "Módulo ainda não disponível", module: "Ecossistema ORBITY", permissions: [],
    description: "Use quando a pergunta exigir Market Radar, Business Benchmark, Document Intelligence, Customer 360 completo ou Revenue Operations: informa o que ainda falta.",
    input: z.object({ modulo: z.enum(["market_radar", "benchmark", "document_intelligence", "customer_360", "revenue_operations"]) }),
    schema: { type: "object", properties: { modulo: { type: "string", enum: Object.keys(UNAVAILABLE) } }, required: ["modulo"], additionalProperties: false },
    run: async (_ctx, input) => {
      const u = UNAVAILABLE[input.modulo];
      return {
        title: u.label, headline: `${u.label} não está disponível ainda.`, dataStatus: "indisponivel", indicators: [],
        items: [{ text: `${u.label} ainda não está disponível no ORBITY-NEPTUNE: falta ${u.missing}. Nenhum dado desse módulo foi usado.`, nature: "fato", section: "fatos" }],
        source: { module: u.label, source: "—", missing: [u.missing] },
      };
    },
  },
];

const BY_NAME = new Map(TOOLS.map((t) => [t.name, t]));

/* ------------------------------------------------------------------ registro */

export const TOOL_NAMES = TOOLS.map((t) => t.name);
export function getTool(name: string) { return BY_NAME.get(name) ?? null; }
export function toolAllowed(ctx: TenantContext, name: string) {
  const t = BY_NAME.get(name);
  return !!t && t.permissions.every((p) => can(ctx, p));
}

/** Ferramentas que ESTE usuário pode usar, no formato da API de mensagens (strict). */
export function toolDefinitionsFor(ctx: TenantContext) {
  return TOOLS.filter((t) => t.permissions.every((p) => can(ctx, p))).map((t) => ({
    name: t.name, description: `${t.label}. ${t.description}`, input_schema: t.schema as { type: "object"; [k: string]: unknown }, strict: true as const,
  }));
}

/** Catálogo legível (UI e auditoria). */
export function toolCatalog(ctx: TenantContext) {
  return TOOLS.map((t) => ({ name: t.name, label: t.label, module: t.module, allowed: t.permissions.every((p) => can(ctx, p)), permissions: t.permissions }));
}

export const TOOL_TIMEOUT_MS = 20_000;

function summarize(input: unknown) {
  try { return JSON.stringify(input).slice(0, 200); } catch { return "—"; }
}

/**
 * Executa UMA ferramenta com o contexto do usuário que perguntou.
 * Nunca lança: devolve status "sem_permissao" | "erro" com mensagem honesta (o laço de IA recebe o mesmo texto).
 */
export async function callTool(ctx: TenantContext, name: string, rawInput: unknown, env: ToolEnv): Promise<ToolResult> {
  const started = Date.now();
  const queriedAt = env.now.toISOString();
  const t = BY_NAME.get(name);
  const base = (status: ToolResult["status"], message: string, dataStatus: DataStatus, extra: Partial<SourceInfo> = {}): ToolResult => ({
    tool: name, status, message, durationMs: Date.now() - started, title: t?.label ?? name, headline: message, items: [], indicators: [], chart: null, proposals: [], links: [],
    source: { tool: name, label: t?.label ?? name, module: t?.module ?? "—", source: "—", period: null, queriedAt, indicators: [], assumptions: [], method: "", confidence: null, limitations: [message], missing: [], dataStatus, ...extra },
  });
  let result: ToolResult;
  if (!t) {
    result = base("erro", `Ferramenta desconhecida: ${name}.`, "erro");
  } else if (!t.permissions.every((p) => can(ctx, p))) {
    const missing = t.permissions.filter((p) => !can(ctx, p));
    result = base("sem_permissao", `Seu perfil não tem a permissão ${missing.map((m) => `"${m}"`).join(", ")}, necessária para consultar ${t.label}. Nada foi consultado.`, "sem_permissao", { missing: missing.map((m) => `Permissão ${m}`) });
  } else {
    const parsed = t.input.safeParse(rawInput ?? {});
    if (!parsed.success) {
      result = base("erro", `Entrada inválida para ${t.label}: ${parsed.error.issues.map((i) => `${i.path.join(".")} ${i.message}`).join("; ")}.`, "erro");
    } else {
      try {
        let timer: ReturnType<typeof setTimeout> | undefined;
        const out = await Promise.race([
          t.run(ctx, parsed.data, env),
          new Promise<never>((_, rej) => { timer = setTimeout(() => rej(new Error(`tempo limite de ${TOOL_TIMEOUT_MS / 1000}s excedido`)), TOOL_TIMEOUT_MS); }),
        ]).finally(() => clearTimeout(timer));
        const ds = out.dataStatus ?? "real";
        result = {
          ...out, tool: name, chart: out.chart ?? null, proposals: out.proposals ?? [], links: out.links ?? [],
          status: ds === "sem_permissao" ? "sem_permissao" : ds === "indisponivel" ? "indisponivel" : ds === "incompleto" && !out.items.length ? "sem_dados" : "ok",
          message: ds === "real" || (ds === "incompleto" && out.items.length) ? null : (out.items[0]?.text ?? out.headline ?? null), durationMs: Date.now() - started,
          source: {
            tool: name, label: t.label, module: out.source.module ?? t.module, source: out.source.source, period: out.source.period ?? null, queriedAt,
            indicators: out.source.indicators ?? out.indicators.map((i) => i.label), assumptions: out.source.assumptions ?? [], method: out.source.method ?? "",
            confidence: out.source.confidence ?? null, limitations: out.source.limitations ?? [], missing: out.source.missing ?? [], dataStatus: ds,
          },
        };
      } catch (err) {
        const msg = err instanceof HttpError ? err.message : (err as Error).message?.startsWith("tempo limite") ? (err as Error).message : "falha ao consultar os dados";
        console.error(JSON.stringify({ level: "error", at: queriedAt, where: "flavio.tool", tool: name, message: (err as Error).message?.slice(0, 300) }));
        result = base("erro", `Não consegui consultar ${t.label}: ${msg}. Nenhuma conclusão foi tirada deste módulo.`, "erro");
      }
    }
  }
  await audit(ctx.db, {
    organizationId: ctx.organizationId, actorId: ctx.userId, action: "flavio.tool", resource: "flavio_tool", resourceId: name,
    metadata: { tool: name, input: summarize(rawInput), status: result.status, ms: result.durationMs },
  });
  return result;
}

/** Versão compacta para o modelo: só agregados, rótulos e fontes (sem e-mail, telefone ou documento). */
export function toolResultForModel(r: ToolResult) {
  return JSON.stringify({
    ferramenta: r.tool, status: r.status, mensagem: r.message, titulo: r.title, resumo: r.headline,
    itens: r.items.map((i) => ({ texto: i.text, natureza: i.nature, secao: i.section })).slice(0, 30),
    indicadores: r.indicators, fonte: { modulo: r.source.module, origem: r.source.source, periodo: r.source.period, consultadoEm: r.source.queriedAt, premissas: r.source.assumptions, metodo: r.source.method, confianca: r.source.confidence, limitacoes: r.source.limitations, faltando: r.source.missing, estadoDoDado: r.source.dataStatus },
  }).slice(0, 12000);
}
