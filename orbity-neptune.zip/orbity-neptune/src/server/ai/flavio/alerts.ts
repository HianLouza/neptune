/**
 * Inteligência proativa do Flávio (§7): preferências de alerta por usuário e organização, e itens proativos.
 *
 * - Preferências ficam em user_preferences.ai_personalization.alerts[organizationId] (por organização: nada vaza entre tenants).
 * - O scan de insights usa recipientsFor() para notificar SÓ quem quer aquele domínio/prioridade e tem permissão de ver.
 * - Frequência diária/semanal: deliverDigests() manda um resumo por período em vez de um alerta por insight.
 */
import { and, eq, inArray } from "drizzle-orm";
import { z } from "zod";
import { insights, memberships, notifications, roles, userPreferences } from "../../db/schema";
import type { DB } from "../../db/client";
import { requirePerm, can, type TenantContext } from "../../tenancy/context";
import { hasPermission } from "../../permissions";
import { audit } from "../../audit";

export const ALERT_DOMAINS = [
  { key: "sales", label: "Vendas e funil" }, { key: "prospect", label: "Prospecção" }, { key: "engagement", label: "Atendimento" },
  { key: "finance", label: "Financeiro" }, { key: "customer", label: "Clientes" }, { key: "ai", label: "IA e agentes" }, { key: "operations", label: "Operações e metas" },
] as const;
const DOMAIN_KEYS = ALERT_DOMAINS.map((d) => d.key) as [string, ...string[]];

export const alertPrefsSchema = z.object({
  enabled: z.boolean().default(true),
  domains: z.array(z.enum(DOMAIN_KEYS)).default([...DOMAIN_KEYS]),
  minPriority: z.enum(["high", "medium", "low"]).default("high"),
  frequency: z.enum(["immediate", "daily", "weekly"]).default("immediate"),
});
export type AlertPrefs = z.output<typeof alertPrefsSchema> & { lastDigestAt?: string };
export const DEFAULT_ALERT_PREFS: AlertPrefs = alertPrefsSchema.parse({});

const RANK = { high: 3, medium: 2, low: 1 } as const;
export const priorityPasses = (p: string, min: AlertPrefs["minPriority"]) => (RANK[p as keyof typeof RANK] ?? 1) >= RANK[min];

type AiPersonalization = { alerts?: Record<string, Partial<AlertPrefs>> } & Record<string, unknown>;

function prefsFrom(ai: unknown, organizationId: string): AlertPrefs {
  const raw = (ai as AiPersonalization | undefined)?.alerts?.[organizationId];
  if (!raw) return { ...DEFAULT_ALERT_PREFS };
  const parsed = alertPrefsSchema.safeParse(raw);
  return { ...(parsed.success ? parsed.data : DEFAULT_ALERT_PREFS), lastDigestAt: typeof raw.lastDigestAt === "string" ? raw.lastDigestAt : undefined };
}

export async function getAlertPrefs(ctx: TenantContext): Promise<AlertPrefs> {
  requirePerm(ctx, "ai:use");
  const [p] = await ctx.db.select({ ai: userPreferences.aiPersonalization }).from(userPreferences).where(eq(userPreferences.userId, ctx.userId));
  return prefsFrom(p?.ai, ctx.organizationId);
}

async function writePrefs(db: DB, userId: string, organizationId: string, prefs: AlertPrefs) {
  const [p] = await db.select({ ai: userPreferences.aiPersonalization }).from(userPreferences).where(eq(userPreferences.userId, userId));
  const ai = { ...((p?.ai as AiPersonalization) ?? {}) };
  ai.alerts = { ...(ai.alerts ?? {}), [organizationId]: prefs };
  if (p) await db.update(userPreferences).set({ aiPersonalization: ai }).where(eq(userPreferences.userId, userId));
  else await db.insert(userPreferences).values({ userId, aiPersonalization: ai });
}

export async function setAlertPrefs(ctx: TenantContext, raw: unknown) {
  requirePerm(ctx, "ai:use");
  const current = await getAlertPrefs(ctx);
  const next: AlertPrefs = { ...alertPrefsSchema.parse({ ...current, ...(raw as object) }), lastDigestAt: current.lastDigestAt };
  await writePrefs(ctx.db, ctx.userId, ctx.organizationId, next);
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "flavio.alerts.updated", resource: "user_preferences", resourceId: ctx.userId, metadata: { enabled: next.enabled, domains: next.domains, minPriority: next.minPriority, frequency: next.frequency } });
  return next;
}

/** Membros ativos com permissão para ver o domínio e cujas preferências pedem este alerta AGORA (frequência imediata). */
export async function recipientsFor(db: DB, organizationId: string, insight: { domain: string; priority: string }) {
  const members = await db.select({ userId: memberships.userId, perms: roles.permissions }).from(memberships).innerJoin(roles, eq(roles.id, memberships.roleId))
    .where(and(eq(memberships.organizationId, organizationId), eq(memberships.status, "active")));
  if (!members.length) return [];
  const prefs = await db.select({ userId: userPreferences.userId, ai: userPreferences.aiPersonalization }).from(userPreferences).where(inArray(userPreferences.userId, members.map((m) => m.userId)));
  const byUser = new Map(prefs.map((p) => [p.userId, prefsFrom(p.ai, organizationId)]));
  return members.filter((m) => {
    if (!hasPermission(m.perms, "intelligence:read")) return false;
    if (insight.domain === "finance" && !hasPermission(m.perms, "finance:read")) return false;
    const p = byUser.get(m.userId) ?? DEFAULT_ALERT_PREFS;
    return p.enabled && p.frequency === "immediate" && p.domains.includes(insight.domain) && priorityPasses(insight.priority, p.minPriority);
  }).map((m) => m.userId);
}

/** Resumos diários/semanais para quem escolheu essa frequência. Idempotente por período (lastDigestAt). */
export async function deliverDigests(db: DB, organizationId: string, now = new Date()) {
  const members = await db.select({ userId: memberships.userId, perms: roles.permissions }).from(memberships).innerJoin(roles, eq(roles.id, memberships.roleId))
    .where(and(eq(memberships.organizationId, organizationId), eq(memberships.status, "active")));
  if (!members.length) return 0;
  const prefRows = await db.select({ userId: userPreferences.userId, ai: userPreferences.aiPersonalization }).from(userPreferences).where(inArray(userPreferences.userId, members.map((m) => m.userId)));
  const open = await db.select().from(insights).where(and(eq(insights.organizationId, organizationId), eq(insights.status, "open")));
  let sent = 0;
  for (const m of members) {
    const row = prefRows.find((p) => p.userId === m.userId);
    const p = prefsFrom(row?.ai, organizationId);
    if (!p.enabled || p.frequency === "immediate" || !hasPermission(m.perms, "intelligence:read")) continue;
    const periodMs = (p.frequency === "daily" ? 1 : 7) * 864e5;
    if (p.lastDigestAt && now.getTime() - Date.parse(p.lastDigestAt) < periodMs) continue;
    const items = open.filter((i) => p.domains.includes(i.domain) && priorityPasses(i.priority, p.minPriority) && (i.domain !== "finance" || hasPermission(m.perms, "finance:read")));
    if (items.length) {
      await db.insert(notifications).values({
        organizationId, userId: m.userId, title: `Resumo ${p.frequency === "daily" ? "diário" : "semanal"} do Flávio: ${items.length} alerta(s)`,
        body: items.slice(0, 5).map((i) => `• ${i.title}`).join("\n"), href: "/business-brain",
      });
      sent++;
    }
    await writePrefs(db, m.userId, organizationId, { ...p, lastDigestAt: now.toISOString() });
  }
  return sent;
}

export type ProactiveItem = {
  id: string; whatHappened: string; indicator: string | null; impact: string | null; evidence: string[]; urgency: "alta" | "média" | "baixa";
  recommendation: string | null; domain: string; link: string | null; createdAt: string;
};

/** Itens proativos para o Flávio: alertas abertos que o usuário pode ver e que passam nas preferências dele. */
export async function proactiveItems(ctx: TenantContext, limit = 6): Promise<{ prefs: AlertPrefs; items: ProactiveItem[] }> {
  requirePerm(ctx, "ai:use");
  const prefs = await getAlertPrefs(ctx);
  if (!can(ctx, "intelligence:read")) return { prefs, items: [] };
  const rows = await ctx.db.select().from(insights).where(and(eq(insights.organizationId, ctx.organizationId), eq(insights.status, "open")));
  const visible = rows.filter((r) => (r.domain !== "finance" || can(ctx, "finance:read")) && (!prefs.enabled || (prefs.domains.includes(r.domain) && priorityPasses(r.priority, prefs.minPriority))))
    .sort((a, b) => (RANK[b.priority as keyof typeof RANK] ?? 0) - (RANK[a.priority as keyof typeof RANK] ?? 0) || b.createdAt.getTime() - a.createdAt.getTime());
  return {
    prefs,
    items: visible.slice(0, limit).map((r) => ({
      id: r.id, whatHappened: `${r.title}. ${r.summary}`, domain: r.domain, link: r.link, createdAt: r.createdAt.toISOString(),
      indicator: r.indicator ? `${r.indicator.metric} (linha de base ${r.indicator.baseline} ${r.indicator.unit})` : null,
      impact: r.evidence.facts.find((f) => /R\$|valor|receita|caixa|risco/i.test(`${f.label} ${f.value}`))?.value ?? null,
      evidence: r.evidence.facts.slice(0, 4).map((f) => `${f.label}: ${f.value} (${f.source}${f.period ? `, ${f.period}` : ""})`),
      urgency: r.priority === "high" ? "alta" : r.priority === "medium" ? "média" : "baixa",
      recommendation: r.recommendedAction,
    })),
  };
}
