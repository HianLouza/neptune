/**
 * MOTOR DE INVESTIGAÇÃO EMPRESARIAL DO FLÁVIO — o Business Brain conversacional (Master Prompt 4.0 · §2–§10).
 *
 * Etapas (§4): interpretar → indicadores necessários → consultar módulos (ferramentas) → qualidade dos dados →
 * comparar períodos → padrões e anomalias → hipóteses → validar com evidências → recomendações → conclusões e limitações.
 *
 * Executores:
 *  (a) DETERMINÍSTICO: planejador por intenção/palavras-chave → várias ferramentas → composição. Sem custo de IA.
 *  (b) IA (Anthropic, quando configurada): laço de ferramentas governado (tool-loop.ts). Falhou/recusou/estourou → (a).
 * Em ambos, os fatos vêm das ferramentas; as fontes exibidas são as das ferramentas efetivamente consultadas.
 */
import { z } from "zod";
import { checkInput, checkOutput } from "../guardrails";
import { consumeCredits, getWallet, PaymentRequiredError } from "../../domains/billing";
import { creditsFor } from "../providers";
import { AgentDisabledError, checkAgentSpend, loadAgentForRun, logAgentExecution } from "../orchestrator";
import { audit } from "../../audit";
import { can, requirePerm, type TenantContext } from "../../tenancy/context";
import { FLAVIO, FLAVIO_PERSONA } from "./identity";
import { normalize, isFollowUp } from "./intents";
import { proposeAction, type ActionProposal } from "./actions";
import { callTool, getTool, toolAllowed, type Chart, type Nature, type SectionKey, type SourceInfo, type ToolResult } from "./tools";
import { BRAIN_RULES, runToolLoop, type ModelAnswer } from "./tool-loop";
import { appendMessage, createConversation, getOwnConversation, saveContext, type InvestigationContext, type Surface } from "./conversations";
import { realProviderAvailable } from "./index";

/* ------------------------------------------------------------------ tipos públicos */

export type AnswerItem = { text: string; nature: Nature; tool?: string };
export type AnswerSection = { key: SectionKey; title: string; items: AnswerItem[] };
export type InvestigationStep = { key: string; label: string; status: "ok" | "aviso" | "pulado"; detail: string };
export type Recommendation = { id: string; text: string; proposals: ActionProposal[] };
export type InvestigationMode = "ia" | "deterministico" | "bloqueado" | "indisponivel";

export type Investigation = {
  conversationId: string | null; messageId: string | null; question: string; format: "curta" | "completa";
  mode: InvestigationMode; modeLabel: string; executiveAnswer: string; sections: AnswerSection[]; steps: InvestigationStep[];
  sources: SourceInfo[]; charts: Chart[]; recommendations: Recommendation[]; proposals: ActionProposal[]; links: { label: string; href: string }[];
  limitations: string[]; missing: string[]; followUp: boolean; topicLabel: string | null; toolsUsed: string[];
  executionId: string | null; provider: string; model: string; credits: number; warnings: string[]; at: string; suggestions: string[];
};

export const SECTION_TITLES: Record<SectionKey, string> = {
  situacao: "Situação atual", fatos: "Fatos identificados", comparacao: "Comparação histórica", diagnostico: "Diagnóstico",
  impacto: "Impacto financeiro", riscos: "Riscos", oportunidades: "Oportunidades", recomendacoes: "Recomendações", plano: "Plano de ação",
};
const SECTION_ORDER: SectionKey[] = ["situacao", "fatos", "comparacao", "diagnostico", "impacto", "riscos", "oportunidades", "recomendacoes", "plano"];

export const BRAIN_SUGGESTIONS = [
  "Por que minha receita caiu?", "Quais são os três maiores problemas da empresa atualmente?", "O que devo priorizar nesta semana?",
  "Quais clientes representam maior risco?", "Qual vendedor está abaixo da meta?", "Onde estamos perdendo oportunidades?",
  "Qual canal gera os clientes mais rentáveis?", "Como aumentar minha margem de lucro?", "Quais despesas estão crescendo?",
  "Posso contratar mais funcionários?", "Quanto posso investir em marketing?", "E se eu aumentar o preço em 10%?",
];

export const askInvestigationSchema = z.object({
  question: z.string().trim().min(2).max(2000),
  conversationId: z.string().uuid().optional(),
  surface: z.enum(["brain", "dock"]).default("brain"),
});

/* ------------------------------------------------------------------ planejador determinístico */

type Topic = { key: string; label: string; test: RegExp; tools: string[] };

const TOPICS: Topic[] = [
  { key: "simulation", label: "Simulação de cenário", test: /\bsimul|\be se (eu )?(aument|reduz|baix|sub|contrat|cort)|aumentar (o )?preco|reduzir (o )?preco/, tools: ["simulacao_estrategica"] },
  { key: "hiring", label: "Capacidade de contratação", test: /contrat|funcionari|admitir|nova vaga/, tools: ["capacidade_contratacao", "resumo_financeiro"] },
  { key: "marketing_budget", label: "Orçamento de marketing", test: /investir em marketing|quanto (posso|devo) investir|verba de marketing/, tools: ["resumo_financeiro", "canais_e_origens", "ponto_de_equilibrio"] },
  { key: "problems", label: "Principais problemas", test: /maiores problemas|principais problemas|problemas da empresa|o que (esta|ta) errado|pontos fracos|maiores riscos/, tools: ["insights_abertos", "funil_vendas", "resumo_financeiro", "metas", "atendimento_closer", "inconsistencias_dados"] },
  { key: "priorities", label: "Prioridades", test: /prioriz|nesta semana|essa semana|o que (devo|posso) fazer (hoje|agora)|onde focar|foco/, tools: ["prioridades_semana", "insights_abertos", "metas", "oportunidades_paradas"] },
  { key: "margin", label: "Margem e rentabilidade", test: /margem|lucro|lucrativ|rentabil/, tools: ["resumo_financeiro", "rentabilidade_produtos", "despesas_crescentes", "ponto_de_equilibrio"] },
  { key: "revenue", label: "Receita", test: /receita|faturament|vendas? (cai|caiu|cair|diminu|cresc|subiu)|(caiu|queda).*(venda|receita)/, tools: ["variacao_receita", "visao_geral_comercial", "desempenho_vendedores", "canais_e_origens", "funil_vendas", "resumo_financeiro"] },
  { key: "risk_clients", label: "Clientes em risco", test: /client.*(risco|cancel|churn|perder|insatisf)/, tools: ["clientes_em_risco", "inadimplencia"] },
  { key: "expansion", label: "Expansão de clientes", test: /expans|upsell|cross.?sell|potencial de (compra|expans)|vender mais para/, tools: ["clientes_expansao"] },
  { key: "sellers", label: "Vendedores e equipe", test: /vendedor|equipe|\btime\b|ranking|desempenho|abaixo da meta|mais afetad/, tools: ["desempenho_vendedores", "metas"] },
  { key: "goals", label: "Metas", test: /\bmeta/, tools: ["metas", "previsao_receita"] },
  { key: "lost", label: "Perdas de oportunidades", test: /perd|motivo de perda|onde estamos perdendo/, tools: ["motivos_perda", "funil_vendas", "oportunidades_paradas"] },
  { key: "channel", label: "Canais e origens", test: /canal|canais|origem|origens|campanha/, tools: ["canais_e_origens"] },
  { key: "expenses", label: "Despesas", test: /despesa|custo|gasto/, tools: ["despesas_crescentes", "resumo_financeiro"] },
  { key: "products", label: "Produtos", test: /produto/, tools: ["rentabilidade_produtos"] },
  { key: "cash", label: "Caixa", test: /caixa|fluxo de caixa|liquidez/, tools: ["caixa_projetado", "inadimplencia", "resumo_financeiro"] },
  { key: "default", label: "Inadimplência", test: /inadimpl|vencid|atrasad|cobranc/, tools: ["inadimplencia"] },
  { key: "breakeven", label: "Ponto de equilíbrio", test: /equilibrio|empatar|break.?even/, tools: ["ponto_de_equilibrio"] },
  { key: "leads", label: "Leads", test: /\blead/, tools: ["leads_prioritarios", "leads_sem_acompanhamento", "canais_e_origens"] },
  { key: "stalled", label: "Oportunidades paradas", test: /parad|esquecid|sem atividade|travad/, tools: ["oportunidades_paradas"] },
  { key: "forecast", label: "Previsão", test: /previs|projec|forecast|vamos fechar|fechar o mes/, tools: ["previsao_receita", "metas"] },
  { key: "service", label: "Atendimento", test: /atendimento|\bsla\b|convers|whatsapp|responder client/, tools: ["atendimento_closer"] },
  { key: "funnel", label: "Funil", test: /funil|gargalo|etapa/, tools: ["funil_vendas"] },
  { key: "ai", label: "Uso de IA", test: /\bia\b|agente|credito|token|inteligencia artificial/, tools: ["uso_ia_e_creditos"] },
  { key: "automations", label: "Automações", test: /automac|workflow/, tools: ["automacoes_execucoes"] },
  { key: "data_quality", label: "Qualidade dos dados", test: /inconsist|qualidade dos dados|dados errad|dados incomplet/, tools: ["inconsistencias_dados"] },
  { key: "decisions", label: "Decisões", test: /decis/, tools: ["decisoes_pendentes", "insights_abertos"] },
  { key: "market", label: "Mercado e concorrência", test: /concorren|mercado|setor|tendenc|noticia/, tools: ["modulo_indisponivel:market_radar"] },
  { key: "benchmark", label: "Benchmark", test: /benchmark|outras empresas|media do mercado|comparad[oa] (com|ao) mercado/, tools: ["modulo_indisponivel:benchmark"] },
  { key: "documents", label: "Documentos e contratos", test: /contrato|documento|\bpdf\b|clausula/, tools: ["modulo_indisponivel:document_intelligence"] },
];

const SIMPLE_RE = /^(quanto|quantos|quantas|qual (e|foi|o|a) |qual o |qual a |quais sao os? (numeros|valores)|me (diga|mostre) (o|a) )/;
const WHY_RE = /por que|porque|como |devo|posso|o que (podemos|devo|posso|fazer)|explique|analise|investig/;
const DO_WHAT_RE = /o que (podemos|devo|posso|da para|dá para) fazer|como (resolver|melhorar|corrigir|reverter)|recomend|proximos passos|plano de acao|e agora/;

function periodDays(q: string, fallback: number) {
  const m = q.match(/(\d+)\s*dias/);
  if (m) { const n = Number(m[1]); return [7, 30, 90, 180, 365].reduce((a, b) => (Math.abs(b - n) < Math.abs(a - n) ? b : a), 30); }
  if (/semana/.test(q)) return 7;
  if (/trimestre/.test(q)) return 90;
  if (/semestre/.test(q)) return 180;
  if (/\bano\b|anual|12 meses/.test(q)) return 365;
  if (/\bmes\b|mensal/.test(q)) return 30;
  return fallback;
}

function parseHiring(q: string) {
  const n = Number(q.match(/(\d+)\s*(funcionari|pessoa|vendedor|colaborador|contrata)/)?.[1] ?? 0) || null;
  const s = q.match(/r\$\s*([\d.]+(?:,\d{1,2})?)/)?.[1];
  return { pessoas: n, salario_mensal_reais: s ? Number(s.replace(/\./g, "").replace(",", ".")) : null };
}

/** Variáveis de simulação citadas na pergunta (ex.: "e se eu aumentar o preço em 10%?"). O que não for citado fica 0. */
function parseSimulation(q: string) {
  const grab = (re: RegExp) => { const m = q.match(re); if (!m) return 0; const num = Number(m[m.length - 1].replace(",", ".")); return /(reduz|baix|diminu|cort)/.test(m[1]) ? -num : num; };
  return {
    preco_pct: grab(/(aument\w*|subi\w*|reduz\w*|baix\w*|diminu\w*) (?:o |os )?preco\w* (?:em )?([\d,]+)\s*%/) || grab(/(aument\w*|reduz\w*|baix\w*) ([\d,]+)\s*% (?:no|do|nos|dos) preco/),
    volume_pct: grab(/(aument\w*|reduz\w*|diminu\w*) (?:o )?volume (?:em )?([\d,]+)\s*%/),
    custos_fixos_pct: grab(/(aument\w*|reduz\w*|cort\w*|diminu\w*) (?:os )?custos? fixos? (?:em )?([\d,]+)\s*%/),
    contratacoes: Number(q.match(/contrat\w* (\d+)/)?.[1] ?? 0),
    custo_por_contratacao_reais: parseHiring(q).salario_mensal_reais,
  };
}

type Plan = { topics: Topic[]; calls: { tool: string; input: unknown }[]; followUp: boolean; unknown: boolean; days: number; doWhat: boolean; format: "curta" | "completa" };

export function planInvestigation(question: string, context: InvestigationContext | null): Plan {
  const q = normalize(question);
  const topics = TOPICS.filter((t) => t.test.test(q));
  const doWhat = DO_WHAT_RE.test(q);
  const hasContext = !!context?.lastTools?.length;
  const followUp = hasContext && (isFollowUp(question) || doWhat || q.length < 70 && /^(e |qual|quais|quem|como|onde|por que|porque|isso|esse|essa|mais afetad)/.test(q));
  const days = periodDays(q, context?.days ?? 30);
  let names: string[] = [];
  if (topics.length) names = topics.flatMap((t) => t.tools);
  else if (followUp) names = context!.lastTools!;
  if (doWhat && followUp) names = [...(context!.rootTools ?? []), ...context!.lastTools!, ...names];
  const unknown = !names.length;
  if (unknown) names = ["visao_geral_comercial", "insights_abertos", "resumo_financeiro"];
  const unique = [...new Set(names)].slice(0, 8);
  const calls = unique.map((n) => {
    const [tool, arg] = n.split(":");
    if (tool === "modulo_indisponivel") return { tool, input: { modulo: arg } };
    if (tool === "capacidade_contratacao") return { tool, input: parseHiring(q) };
    if (tool === "simulacao_estrategica") return { tool, input: parseSimulation(q) };
    const def = getTool(tool);
    return { tool, input: def && "dias" in ((def.schema.properties as object) ?? {}) ? { dias: days } : {} };
  });
  const format: "curta" | "completa" = SIMPLE_RE.test(q) && !WHY_RE.test(q) && topics.length <= 1 && !doWhat ? "curta" : "completa";
  return { topics, calls, followUp, unknown, days, doWhat, format };
}

/* ------------------------------------------------------------------ composição */

const uniq = (items: AnswerItem[]) => { const seen = new Set<string>(); return items.filter((i) => (seen.has(i.text) ? false : (seen.add(i.text), true))); };

function composeDeterministic(results: ToolResult[], plan: Plan, context: InvestigationContext | null) {
  const ok = results.filter((r) => r.status === "ok");
  const buckets = new Map<SectionKey, AnswerItem[]>(SECTION_ORDER.map((k) => [k, []]));
  for (const r of results) {
    for (const ind of r.indicators) buckets.get("situacao")!.push({ text: `${ind.label}: ${ind.value}${ind.detail ? ` (${ind.detail})` : ""}`, nature: "fato", tool: r.tool });
    for (const it of r.items) buckets.get(it.section)!.push({ text: it.text, nature: it.nature, tool: r.tool });
    if (r.status !== "ok" && r.message) buckets.get("fatos")!.push({ text: r.message, nature: "fato", tool: r.tool });
  }
  if (plan.followUp && plan.doWhat && context?.findings?.length && !buckets.get("diagnostico")!.length) {
    for (const f of context.findings.slice(0, 3)) buckets.get("diagnostico")!.push({ text: `Da análise anterior: ${f}`, nature: "fato" });
  }
  const recs = uniq(buckets.get("recomendacoes")!).slice(0, 6);
  if (!buckets.get("plano")!.length) {
    recs.slice(0, 3).forEach((r, i) => buckets.get("plano")!.push({ text: `${i + 1}. ${r.text} · responsável: a definir · acompanhar: ${ok.find((x) => x.tool === r.tool)?.source.indicators[0] ?? "indicador da recomendação"}`, nature: "recomendação", tool: r.tool }));
  }
  let sections: AnswerSection[] = SECTION_ORDER.map((k) => ({ key: k, title: SECTION_TITLES[k], items: uniq(buckets.get(k)!).slice(0, k === "situacao" ? 10 : 8) })).filter((s) => s.items.length);
  if (plan.format === "curta") sections = sections.filter((s) => s.key === "fatos" || s.key === "situacao").map((s) => ({ ...s, items: s.items.slice(0, 5) }));
  // "O que podemos fazer?" numa investigação em andamento: foco em ação, sem repetir os números já mostrados.
  if (plan.followUp && plan.doWhat && recs.length) {
    const keep: SectionKey[] = ["diagnostico", "recomendacoes", "plano", "oportunidades"];
    sections = sections.filter((s) => keep.includes(s.key)).map((s) => (s.key === "diagnostico" ? { ...s, items: s.items.slice(0, 3) } : s));
  }

  const lead = ok.find((r) => r.headline) ?? results.find((r) => r.headline);
  const limited = results.filter((r) => r.status !== "ok");
  let executive = lead?.headline ?? "Não encontrei dados suficientes para responder com segurança.";
  if (plan.followUp && plan.doWhat && recs.length) executive = `Para ${(context?.rootTopicLabel ?? context?.topicLabel)?.toLowerCase() ?? "o problema analisado"}, as ações com maior efeito pelos dados são: ${recs.slice(0, 2).map((r) => r.text.replace(/\.$/, "")).join("; ")}.`;
  if (plan.unknown) executive = `Não identifiquei exatamente o assunto da pergunta, então fiz uma investigação geral. ${executive}`;
  if (limited.length) executive += ` Parte da análise ficou limitada (${limited.map((r) => r.source.label).join(", ")}).`;
  return { executive, sections, recs: recs.map((r) => r.text) };
}

function composeFromModel(a: ModelAnswer): { executive: string; sections: AnswerSection[]; recs: string[]; limitations: string[] } {
  const sections = SECTION_ORDER.map((k) => ({ key: k, title: SECTION_TITLES[k], items: a.secoes.filter((s) => s.chave === k).flatMap((s) => s.itens.map((i) => ({ text: checkOutput(i.texto).text, nature: i.natureza as Nature }))) }))
    .filter((s) => s.items.length);
  return { executive: checkOutput(a.resposta_executiva).text, sections, recs: a.recomendacoes, limitations: a.limitacoes };
}

function buildSteps(question: string, plan: Plan, results: ToolResult[], mode: InvestigationMode, sections: AnswerSection[], limitations: string[]): InvestigationStep[] {
  const by = (s: ToolResult["status"]) => results.filter((r) => r.status === s).length;
  const count = (k: SectionKey) => sections.find((s) => s.key === k)?.items.length ?? 0;
  const issues = results.length - by("ok");
  return [
    { key: "interpretar", label: "Interpretar a pergunta", status: plan.unknown ? "aviso" : "ok", detail: plan.unknown ? "Assunto não identificado: investigação geral de melhor esforço." : `${plan.followUp ? "Continuação da investigação · " : ""}${plan.topics.map((t) => t.label).join(", ") || "mesmo assunto da pergunta anterior"}${mode === "ia" ? " (com IA)" : ""}.` },
    { key: "indicadores", label: "Definir indicadores e fontes", status: "ok", detail: results.map((r) => r.source.label).join(", ") || "—" },
    { key: "consultar", label: "Consultar os módulos autorizados", status: issues ? "aviso" : "ok", detail: `${results.length} consulta(s): ${by("ok")} com dados${issues ? `, ${by("sem_permissao")} sem permissão, ${by("sem_dados")} sem dados, ${by("indisponivel")} indisponível(is), ${by("erro")} com erro` : ""}.` },
    { key: "qualidade", label: "Verificar qualidade dos dados", status: results.some((r) => r.source.dataStatus !== "real") ? "aviso" : "ok", detail: results.map((r) => `${r.source.label}: ${r.source.dataStatus}${r.source.confidence != null ? ` (confiança ${Math.round(r.source.confidence * 100)}%)` : ""}`).join(" · ") || "—" },
    { key: "comparar", label: "Comparar períodos", status: count("comparacao") ? "ok" : "pulado", detail: count("comparacao") ? `${count("comparacao")} comparação(ões) com o período anterior (${plan.days} dias).` : "Sem série comparável nas fontes consultadas." },
    { key: "padroes", label: "Identificar padrões e anomalias", status: count("riscos") + count("diagnostico") ? "ok" : "pulado", detail: `${count("riscos")} risco(s) e ${count("diagnostico")} sinal(is) de diagnóstico.` },
    { key: "hipoteses", label: "Formular hipóteses", status: count("diagnostico") ? "ok" : "pulado", detail: count("diagnostico") ? `${count("diagnostico")} hipótese(s)/inferência(s), marcadas como tal.` : "Nenhuma hipótese sustentada pelos dados." },
    { key: "validar", label: "Validar com evidências", status: "ok", detail: `Cada afirmação vem das ${results.filter((r) => r.status === "ok").length} fonte(s) listadas, com período e horário da consulta.` },
    { key: "recomendar", label: "Elaborar recomendações", status: count("recomendacoes") ? "ok" : "pulado", detail: `${count("recomendacoes")} recomendação(ões).` },
    { key: "concluir", label: "Conclusões e limitações", status: limitations.length ? "aviso" : "ok", detail: limitations.length ? `${limitations.length} limitação(ões) declarada(s).` : `Sem limitações relevantes para: "${question.slice(0, 80)}".` },
  ];
}

function safePropose(ctx: TenantContext, ...args: Parameters<typeof proposeAction>): ActionProposal | null {
  try { return proposeAction(...args); } catch { void ctx; return null; }
}

function recommendationProposals(ctx: TenantContext, question: string, executive: string, recs: string[], results: ToolResult[]): Recommendation[] {
  const sim = results.find((r) => r.tool === "simulacao_estrategica" && r.status === "ok");
  return recs.slice(0, 5).map((text, i) => {
    const title = text.replace(/\s+/g, " ").slice(0, 195);
    const proposals = [
      safePropose(ctx, ctx, { kind: "create_tasks", items: [{ title, description: `Recomendação do Flávio (Business Brain) para: "${question.slice(0, 300)}"`, priority: i === 0 ? "high" : "medium" }] },
        { title: "Criar tarefa", summary: title, details: ["Uma tarefa será criada em Tarefas & Metas, sem responsável definido."] }),
      safePropose(ctx, ctx, { kind: "register_decision", title: title.length >= 3 ? title : `Decisão: ${title}`, problem: `${question}\n\n${executive}`.slice(0, 2000), alternatives: recs.filter((r) => r !== text).slice(0, 3).map((r) => ({ name: r.slice(0, 115), description: "" })) },
        { title: "Registrar decisão", summary: title, details: ["A decisão entra como rascunho no Decision Engine e precisa de aprovação de outra pessoa."] }),
      ...(sim && i === 0 ? [safePropose(ctx, ctx, { kind: "save_scenario", name: `Cenário do Flávio: ${question.slice(0, 90)}`, scenarioKind: "custom", variables: simVars(sim) },
        { title: "Salvar simulação", summary: "Salvar este cenário no Simulador Estratégico", details: ["O cenário fica em rascunho para comparação e aprovação."] })] : []),
    ].filter((p): p is ActionProposal => !!p);
    return { id: `r${i + 1}`, text, proposals };
  });
}

function simVars(r: ToolResult) {
  const v = ((r as { data?: { variaveis?: Record<string, number | null> } }).data?.variaveis) ?? {};
  return { priceChangePct: Number(v.preco_pct ?? 0), volumeChangePct: Number(v.volume_pct ?? 0), fixedCostChangePct: Number(v.custos_fixos_pct ?? 0), newHires: Number(v.contratacoes ?? 0), monthlyCostPerHireCents: v.custo_por_contratacao_reais != null ? Math.round(Number(v.custo_por_contratacao_reais) * 100) : null };
}

const MODE_LABEL: Record<InvestigationMode, string> = {
  ia: "IA conectada · fatos das ferramentas do ORBITY", deterministico: "Análise determinística (sem modelo de IA) · dados reais da empresa",
  bloqueado: "Bloqueado por segurança", indisponivel: "Indisponível",
};

/* ------------------------------------------------------------------ entrada principal */

export async function investigate(ctx: TenantContext, raw: z.input<typeof askInvestigationSchema>, now = new Date()): Promise<Investigation> {
  requirePerm(ctx, "ai:use");
  const input = askInvestigationSchema.parse(raw);
  const surface: Surface = input.surface;
  const conv = input.conversationId ? await getOwnConversation(ctx, input.conversationId) : await createConversation(ctx, input.question, surface);
  const context = (conv.context ?? {}) as InvestigationContext;
  const at = now.toISOString();
  const base = {
    conversationId: conv.id, question: input.question, sources: [] as SourceInfo[], charts: [] as Chart[], recommendations: [] as Recommendation[],
    proposals: [] as ActionProposal[], links: [] as { label: string; href: string }[], toolsUsed: [] as string[], at, suggestions: BRAIN_SUGGESTIONS.slice(0, 6),
  };
  await appendMessage(ctx, conv.id, { role: "user", content: input.question });

  const finish = async (inv: Omit<Investigation, "messageId">, ctxPatch?: InvestigationContext) => {
    const msg = await appendMessage(ctx, conv.id, { role: "assistant", content: inv.executiveAnswer, payload: { kind: "investigation", ...inv } as Record<string, unknown>, executionId: inv.executionId });
    await saveContext(ctx, conv.id, { ...context, ...(ctxPatch ?? {}) });
    await audit(ctx.db, {
      organizationId: ctx.organizationId, actorId: ctx.userId, action: "flavio.investigation", resource: "flavio_conversation", resourceId: conv.id,
      metadata: { mode: inv.mode, tools: inv.toolsUsed, format: inv.format, followUp: inv.followUp, surface },
    });
    return { ...inv, messageId: msg.id };
  };
  const stop = (mode: InvestigationMode, text: string, warnings: string[], executionId: string | null = null) => finish({
    ...base, format: "curta", mode, modeLabel: MODE_LABEL[mode], executiveAnswer: text, sections: [], steps: [], limitations: warnings, missing: [],
    followUp: false, topicLabel: null, executionId, provider: "none", model: "none", credits: 0, warnings,
  });

  // Segurança da entrada (prompt injection) e governança do agente ANTES de consultar qualquer dado.
  const guard = checkInput(input.question, 2000);
  let loaded: Awaited<ReturnType<typeof loadAgentForRun>>;
  try { loaded = await loadAgentForRun(ctx, FLAVIO.agentKey); }
  catch (err) {
    if (err instanceof AgentDisabledError) return stop("indisponivel", `O ${FLAVIO.name} está indisponível: ${err.message} Fale com um administrador.`, [err.message]);
    throw err;
  }
  const started = Date.now();
  if (loaded.blockedBy) {
    const id = await logAgentExecution(ctx, loaded.agent, loaded.version, { input: guard.sanitized, output: loaded.blockedBy, status: "blocked", credits: 0, startedAt: started });
    return stop("bloqueado", `O ${FLAVIO.name} está interrompido e não pode investigar agora. ${loaded.blockedBy}`, [loaded.blockedBy], id);
  }
  if (guard.blocked) {
    const text = "Sua pergunta contém instruções que não posso seguir por motivos de segurança. Reformule a pergunta sobre a empresa.";
    const id = await logAgentExecution(ctx, loaded.agent, loaded.version, { input: guard.sanitized, output: text, status: "blocked", credits: 0, startedAt: started });
    return stop("bloqueado", text, guard.reasons, id);
  }

  const plan = planInvestigation(guard.sanitized, context);
  const env = { question: guard.sanitized, now };
  const warnings: string[] = [];
  let results: ToolResult[] = [];
  let mode: InvestigationMode = "deterministico";
  let modelAnswer: ModelAnswer | null = null;
  let usage = { inputTokens: 0, outputTokens: 0 }, modelName = "flavio-investigacao-v1", provider = "deterministico", credits = 0;

  // (b) IA com ferramentas, quando há provedor Anthropic e saldo; qualquer falha cai para (a).
  if (realProviderAvailable() && process.env.ANTHROPIC_API_KEY) {
    try {
      const budget = await checkAgentSpend(ctx, loaded.agent);
      warnings.push(...budget.warnings);
      const wallet = await getWallet(ctx.db, ctx.organizationId);
      if ((wallet?.balance ?? 0) <= 0) warnings.push("Sem créditos de IA: investigação feita sem modelo de IA.");
      else {
        const historyMsgs = (context.lastQuestion && context.findings?.length) ? [{ role: "user" as const, content: context.lastQuestion }, { role: "assistant" as const, content: context.findings.join("\n") }] : [];
        const summary = plan.followUp ? `Assunto anterior: ${context.topicLabel ?? "—"}. Período: ${context.days ?? 30} dias. Constatações: ${(context.findings ?? []).join(" | ")}` : null;
        const out = await runToolLoop(ctx, {
          system: `${loaded.prompt.systemPrompt}\n\n${FLAVIO_PERSONA}\n\n${BRAIN_RULES}\n\nOrganização: ${ctx.organizationId}. Nunca utilize ou mencione dados de outras organizações.`,
          question: guard.sanitized, history: historyMsgs, contextSummary: summary, hintTools: plan.calls.map((c) => c.tool), env,
        });
        usage = out.usage; modelName = out.model; results = out.results;
        if (out.ok) { modelAnswer = out.answer; mode = "ia"; provider = "anthropic"; }
        else warnings.push(out.reason === "refusal" ? "O modelo recusou parte do pedido por segurança; a investigação foi concluída sem IA." : `IA indisponível (${out.message}). Investigação concluída sem modelo de IA.`);
      }
    } catch (err) {
      if (err instanceof PaymentRequiredError) warnings.push(`${err.message} Investigação feita sem modelo de IA.`);
      else warnings.push(`IA indisponível (${(err as Error).message.slice(0, 160)}). Investigação concluída sem modelo de IA.`);
    }
  }

  // (a) Determinístico: executa o plano (e completa o que a IA não consultou, se ela falhou).
  if (mode !== "ia") {
    const done = new Set(results.map((r) => r.tool));
    for (const c of plan.calls) if (!done.has(c.tool)) results.push(await callTool(ctx, c.tool, c.input, env));
  }

  const det = composeDeterministic(results, plan, context);
  const fromModel = modelAnswer ? composeFromModel(modelAnswer) : null;
  const executiveAnswer = fromModel?.executive ?? det.executive;
  const sections = fromModel?.sections.length ? fromModel.sections : det.sections;
  const recTexts = fromModel?.recs.length ? fromModel.recs : det.recs;
  const format: "curta" | "completa" = modelAnswer?.formato ?? plan.format;

  const sources = results.map((r) => r.source);
  const missing = [...new Set(sources.flatMap((s) => s.missing).filter(Boolean))];
  const limitations = [...new Set([
    ...(fromModel?.limitations ?? []),
    ...results.filter((r) => r.status !== "ok" && r.message).map((r) => r.message!),
    ...sources.flatMap((s) => s.limitations).filter(Boolean),
    ...(plan.unknown && mode !== "ia" ? ["Pergunta fora dos assuntos reconhecidos: investigação geral de melhor esforço."] : []),
  ])].slice(0, 12);
  const proposals = results.flatMap((r) => r.proposals).slice(0, 6);
  const recommendations = recommendationProposals(ctx, input.question, executiveAnswer, recTexts, results);

  // Custo e registro: IA cobra por tokens; determinístico registra a execução sem custo.
  if (mode === "ia" || usage.inputTokens + usage.outputTokens > 0) {
    credits = creditsFor({ inputTokens: usage.inputTokens, outputTokens: usage.outputTokens, simulated: false });
    if (credits > 0) await consumeCredits(ctx.db, ctx.organizationId, credits, "ai_execution", { agentKey: loaded.agent.key });
  }
  const executionId = await logAgentExecution(ctx, loaded.agent, loaded.version, {
    input: guard.sanitized, output: executiveAnswer, status: mode === "ia" ? "success" : "fallback", provider: mode === "ia" ? provider : usage.inputTokens ? "anthropic" : "local-heuristic",
    model: modelName, simulated: mode !== "ia", inputTokens: usage.inputTokens, outputTokens: usage.outputTokens, credits, startedAt: started,
  });

  const topicLabel = plan.topics.map((t) => t.label).join(" · ") || (plan.followUp ? context.topicLabel ?? null : null);
  // Constatações guardadas para a continuação: riscos e diagnóstico primeiro (o que importa), depois fatos e comparações.
  const findings = (["riscos", "diagnostico", "comparacao", "fatos"] as SectionKey[]).flatMap((k) => sections.find((s) => s.key === k)?.items.map((i) => i.text) ?? []).filter((t) => !t.startsWith("Da análise anterior")).slice(0, 6);
  return finish({
    ...base, format, mode, modeLabel: MODE_LABEL[mode], executiveAnswer, sections,
    steps: buildSteps(input.question, plan, results, mode, sections, limitations),
    sources, charts: results.flatMap((r) => (r.chart ? [r.chart] : [])).slice(0, 4), recommendations, proposals,
    links: results.flatMap((r) => r.links).slice(0, 6), limitations, missing, followUp: plan.followUp, topicLabel,
    toolsUsed: results.map((r) => r.tool), executionId, provider: mode === "ia" ? provider : "deterministico", model: modelName, credits, warnings,
  }, {
    topic: plan.topics[0]?.key ?? context.topic, topicLabel: topicLabel ?? context.topicLabel, days: plan.days, lastQuestion: input.question,
    lastTools: results.filter((r) => r.status === "ok").map((r) => r.tool).filter((t) => toolAllowed(ctx, t)), findings, recommendations: recTexts.slice(0, 5),
    ...(!plan.followUp || !context.rootTools?.length ? { rootTools: results.filter((r) => r.status === "ok").map((r) => r.tool).filter((t) => toolAllowed(ctx, t)), rootTopicLabel: topicLabel ?? undefined } : {}),
  });
}

/* ------------------------------------------------------------------ exportação */

export function investigationToMarkdown(title: string, messages: { role: string; content: string; payload: unknown; createdAt: string }[]) {
  const lines = [`# ${title}`, "", `Exportado do ORBITY-NEPTUNE · Business Brain (Flávio) em ${new Date().toISOString()}`, ""];
  for (const m of messages) {
    if (m.role === "user") { lines.push(`## Pergunta (${m.createdAt})`, "", m.content, ""); continue; }
    const p = (m.payload ?? {}) as Partial<Investigation> & { kind?: string };
    lines.push(`### Resposta — ${p.modeLabel ?? "Flávio"}`, "", m.content, "");
    for (const s of p.sections ?? []) { lines.push(`#### ${s.title}`); for (const i of s.items) lines.push(`- [${i.nature}] ${i.text}`); lines.push(""); }
    if (p.sources?.length) { lines.push("#### Fontes"); for (const s of p.sources) lines.push(`- ${s.label} · ${s.module} · ${s.source} · período: ${s.period ?? "—"} · consultado em ${s.queriedAt} · estado: ${s.dataStatus}${s.confidence != null ? ` · confiança ${Math.round(s.confidence * 100)}%` : ""}`); lines.push(""); }
    if (p.limitations?.length) { lines.push("#### Limitações"); for (const l of p.limitations) lines.push(`- ${l}`); lines.push(""); }
  }
  return lines.join("\n");
}

export function investigationToCsv(messages: { role: string; payload: unknown; createdAt: string }[]) {
  const cell = (v: unknown) => { const s = String(v ?? ""); const safe = /^[=+\-@]/.test(s) ? `'${s}` : s; return `"${safe.replace(/"/g, '""')}"`; };
  const rows = [["data", "secao", "natureza", "texto", "ferramenta"].map(cell).join(",")];
  for (const m of messages) {
    if (m.role !== "assistant") continue;
    const p = (m.payload ?? {}) as Partial<Investigation>;
    for (const s of p.sections ?? []) for (const i of s.items) rows.push([m.createdAt, s.title, i.nature, i.text, i.tool ?? ""].map(cell).join(","));
  }
  return rows.join("\n");
}
