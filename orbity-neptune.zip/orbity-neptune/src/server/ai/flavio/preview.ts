/**
 * Prévia "antes → depois" das ações do Flávio.
 *
 * Mostra, ANTES da confirmação, o que cada ação vai criar ou alterar: campo, valor atual e valor proposto.
 * Só LÊ dados (com as permissões e a organização de quem pede). Nunca executa nem grava nada:
 * a execução continua exclusiva de confirmAction, depois da confirmação explícita.
 */
import { and, eq, inArray } from "drizzle-orm";
import { leads, memberships, opportunities, users } from "../../db/schema";
import { TEMPLATES } from "../../workflows/templates";
import { verifyProposal, type FlavioAction } from "./actions";
import type { TenantContext } from "../../tenancy/context";

export type FieldChange = {
  field: string;
  /** Valor atual. null quando não existe (criação) ou não está disponível. */
  before: string | null;
  after: string;
  /** false quando não há valor atual para comparar (o resumo mostra só o proposto). */
  comparable: boolean;
};
export type RecordChange = {
  kind: "create" | "update";
  entity: string; // Tarefa, Lead, Automação, Decisão, Cenário
  label: string; // nome do registro
  fields: FieldChange[];
  note?: string;
};

/** Valores atuais lidos do banco (podem faltar: registro inexistente, sem permissão ou de outra organização). */
export type CurrentValues = {
  leads: Record<string, { title: string; status: string }>;
  opportunities: Record<string, { title: string }>;
  users: Record<string, { name: string }>;
};

export const LEAD_STATUS_LABEL: Record<string, string> = { new: "Novo", qualifying: "Em qualificação", qualified: "Qualificado", disqualified: "Desqualificado", converted: "Convertido" };
const PRIORITY_LABEL: Record<string, string> = { low: "Baixa", medium: "Média", high: "Alta" };
const SCENARIO_KIND_LABEL: Record<string, string> = { price: "Preço", cost: "Custos", hiring: "Contratação", volume: "Volume", conversion: "Conversão", marketing: "Marketing", churn: "Perda de clientes", custom: "Personalizado" };
const TRIGGER_LABEL: Record<string, string> = { "lead.created": "Lead criado", "lead.qualified": "Lead qualificado", "opportunity.lost": "Oportunidade perdida", "opportunity.created": "Oportunidade criada" };

const created = (field: string, after: string): FieldChange => ({ field, before: null, after, comparable: false });
const pct = (v: number) => `${v > 0 ? "+" : ""}${v.toLocaleString("pt-BR")}%`;

function fmtDate(iso: string, timezone?: string) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  try { return d.toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short", timeZone: timezone || "America/Sao_Paulo" }); }
  catch { return d.toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" }); }
}

/** Função pura: transforma a ação + valores atuais no resumo exibido. */
export function summarizeChanges(action: FlavioAction, current: CurrentValues, opts: { timezone?: string } = {}): RecordChange[] {
  switch (action.kind) {
    case "create_tasks":
      return action.items.map((it) => {
        const fields: FieldChange[] = [created("Título", it.title), created("Prioridade", PRIORITY_LABEL[it.priority] ?? it.priority)];
        if (it.dueAt) fields.push(created("Prazo", fmtDate(it.dueAt, opts.timezone)));
        if (it.description) fields.push(created("Descrição", it.description.length > 160 ? `${it.description.slice(0, 157)}…` : it.description));
        if (it.leadId) fields.push(created("Lead vinculado", current.leads[it.leadId]?.title ?? "Lead não encontrado (será verificado na confirmação)"));
        if (it.opportunityId) fields.push(created("Oportunidade vinculada", current.opportunities[it.opportunityId]?.title ?? "Oportunidade não encontrada (será verificada na confirmação)"));
        fields.push(created("Responsável", it.assigneeId ? current.users[it.assigneeId]?.name ?? "Pessoa não encontrada (será verificada na confirmação)" : "Sem responsável definido"));
        return { kind: "create", entity: "Tarefa", label: it.title, fields };
      });
    case "draft_automation": {
      const tpl = TEMPLATES.find((t) => t.key === action.templateKey);
      const name = tpl ? `${tpl.name} (preparada pelo Flávio)` : action.templateKey;
      return [{
        kind: "create", entity: "Automação", label: name,
        fields: [
          created("Nome", name),
          created("Gatilho", tpl ? TRIGGER_LABEL[tpl.triggerEvent] ?? tpl.triggerEvent : "—"),
          created("Passos", tpl ? String(tpl.definition.nodes.length) : "—"),
          created("Situação", "Rascunho (não é publicada)"),
        ],
      }];
    }
    case "update_lead_status": {
      const lead = current.leads[action.leadId];
      const after = LEAD_STATUS_LABEL[action.status] ?? action.status;
      if (!lead) {
        return [{
          kind: "update", entity: "Lead", label: "Lead não localizado",
          fields: [{ field: "Status", before: null, after, comparable: false }],
          note: "Valor atual indisponível: não há comparação. A confirmação verifica se o lead existe e pertence à sua organização.",
        }];
      }
      const before = LEAD_STATUS_LABEL[lead.status] ?? lead.status;
      return [{
        kind: "update", entity: "Lead", label: lead.title,
        fields: [{ field: "Status", before, after, comparable: true }],
        note: lead.status === action.status ? "O status atual já é o proposto: nada muda." : undefined,
      }];
    }
    case "register_decision":
      return [{
        kind: "create", entity: "Decisão", label: action.title,
        fields: [
          created("Título", action.title),
          created("Problema", action.problem.length > 200 ? `${action.problem.slice(0, 197)}…` : action.problem),
          created("Alternativas", action.alternatives.length ? action.alternatives.map((a) => a.name).join("; ") : "Nenhuma (pode incluir depois)"),
          created("Situação", "Rascunho (vai para aprovação depois)"),
        ],
      }];
    case "save_scenario": {
      const v = action.variables;
      const fields: FieldChange[] = [created("Nome", action.name), created("Tipo", SCENARIO_KIND_LABEL[action.scenarioKind] ?? action.scenarioKind)];
      if (v.priceChangePct !== undefined) fields.push(created("Preço", pct(v.priceChangePct)));
      if (v.volumeChangePct !== undefined) fields.push(created("Volume", pct(v.volumeChangePct)));
      if (v.fixedCostChangePct !== undefined) fields.push(created("Custos fixos", pct(v.fixedCostChangePct)));
      if (v.newHires !== undefined) fields.push(created("Contratações", String(v.newHires)));
      if (v.monthlyCostPerHireCents) fields.push(created("Custo mensal por pessoa", (v.monthlyCostPerHireCents / 100).toLocaleString("pt-BR", { style: "currency", currency: "BRL" })));
      fields.push(created("Situação", "Rascunho no Simulador"));
      return [{ kind: "create", entity: "Cenário", label: action.name, fields }];
    }
  }
}

/** Lê os valores atuais citados pela ação, sempre restritos à organização de quem pede. */
async function loadCurrent(ctx: TenantContext, action: FlavioAction): Promise<CurrentValues> {
  const leadIds = new Set<string>(), oppIds = new Set<string>(), userIds = new Set<string>();
  if (action.kind === "update_lead_status") leadIds.add(action.leadId);
  if (action.kind === "create_tasks") for (const it of action.items) {
    if (it.leadId) leadIds.add(it.leadId);
    if (it.opportunityId) oppIds.add(it.opportunityId);
    if (it.assigneeId) userIds.add(it.assigneeId);
  }
  const org = ctx.organizationId;
  const cur: CurrentValues = { leads: {}, opportunities: {}, users: {} };
  if (leadIds.size) {
    for (const l of await ctx.db.select({ id: leads.id, title: leads.title, status: leads.status }).from(leads).where(and(eq(leads.organizationId, org), inArray(leads.id, [...leadIds])))) cur.leads[l.id] = { title: l.title, status: l.status };
  }
  if (oppIds.size) {
    for (const o of await ctx.db.select({ id: opportunities.id, title: opportunities.title }).from(opportunities).where(and(eq(opportunities.organizationId, org), inArray(opportunities.id, [...oppIds])))) cur.opportunities[o.id] = { title: o.title };
  }
  if (userIds.size) {
    const rows = await ctx.db.select({ id: users.id, name: users.name }).from(memberships).innerJoin(users, eq(users.id, memberships.userId))
      .where(and(eq(memberships.organizationId, org), inArray(memberships.userId, [...userIds])));
    for (const u of rows) cur.users[u.id] = { name: u.name };
  }
  return cur;
}

/** Prévia de uma proposta assinada. Valida a proposta (dono, organização, validade) e não executa nada. */
export async function previewAction(ctx: TenantContext, token: string) {
  const body = verifyProposal(ctx, token);
  const changes = summarizeChanges(body.action, await loadCurrent(ctx, body.action), { timezone: ctx.timezone });
  return { title: body.title, kind: body.action.kind, changes };
}
