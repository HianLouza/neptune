/** Proteções de IA: prompt injection, PII, validação de entrada e de saída. */

const INJECTION_PATTERNS: RegExp[] = [
  /ignore (all|any|the)? ?(previous|prior|above) (instructions|rules)/i,
  /ignore (as|todas as)? ?(instru[cç][oõ]es|regras) (anteriores|acima)/i,
  /desconsidere (as )?(instru[cç][oõ]es|regras)/i,
  /(system prompt|prompt do sistema|suas instru[cç][oõ]es)/i,
  /you are now|a partir de agora voc[eê] [eé]/i,
  /(reveal|mostre|revele).{0,30}(secret|senha|token|api key|chave)/i,
  /(outra|other) (organiza[cç][aã]o|tenant|empresa).{0,40}(dados|data)/i,
  /\bDAN\b|jailbreak|modo desenvolvedor/i,
];

export type GuardResult = { blocked: boolean; reasons: string[]; sanitized: string };

export function checkInput(input: string, maxLen = 8000): GuardResult {
  const reasons: string[] = [];
  if (input.length > maxLen) reasons.push(`Entrada excede ${maxLen} caracteres.`);
  for (const p of INJECTION_PATTERNS) if (p.test(input)) reasons.push(`Possível prompt injection: ${p.source.slice(0, 40)}`);
  // Remove caracteres de controle e delimita dados não confiáveis.
  const sanitized = input.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, "").slice(0, maxLen);
  return { blocked: reasons.length > 0, reasons, sanitized };
}

/** Envolve dados não confiáveis (mensagens de clientes, documentos) para o modelo tratá-los como DADOS. */
export function asUntrustedData(label: string, content: string) {
  return `<dados_nao_confiaveis origem="${label}">\n${content.replace(/<\/?dados_nao_confiaveis[^>]*>/g, "")}\n</dados_nao_confiaveis>`;
}

const PII = [
  { name: "cpf", re: /\b\d{3}\.?\d{3}\.?\d{3}-?\d{2}\b/g },
  { name: "cartao", re: /\b(?:\d[ -]?){13,16}\b/g },
];
export function redactPII(text: string) {
  let out = text;
  for (const p of PII) out = out.replace(p.re, `[${p.name.toUpperCase()} REMOVIDO]`);
  return out;
}

/** Saída: a IA não pode alegar execução de ações. */
const FALSE_EXECUTION = /\b(j[aá] (enviei|agendei|cobrei|transferi|executei)|i have (sent|scheduled|charged))\b/i;
export function checkOutput(text: string) {
  const issues: string[] = [];
  if (FALSE_EXECUTION.test(text)) issues.push("A resposta alega uma execução que não ocorreu.");
  return { ok: issues.length === 0, issues, text: redactPII(text) };
}
