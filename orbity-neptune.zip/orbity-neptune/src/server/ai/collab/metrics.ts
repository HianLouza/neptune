/**
 * Métricas da colaboração humano × IA nas sugestões (AI Control Plane e Sales Intelligence).
 * Importante: "aprovada" não significa "melhor". A associação com conversão é só associação (não causalidade),
 * sempre exibida com o tamanho da amostra.
 */
import { and, eq, gte, inArray } from "drizzle-orm";
import { aiDrafts, aiDraftVersions, auditLogs, contacts, conversations, opportunities, teamMembers, teams, users } from "../../db/schema";
import { can, type TenantContext } from "../../tenancy/context";
import { ForbiddenError } from "../../permissions";

const avg = (xs: number[]) => (xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : null);
const pct = (n: number, d: number) => (d ? Math.round((n / d) * 1000) / 10 : null);

export async function aiSuggestionMetrics(ctx: TenantContext, days = 30, now = new Date()) {
  if (!can(ctx, "intelligence:read") && !can(ctx, "ai:manage")) throw new ForbiddenError("intelligence:read");
  const since = new Date(now.getTime() - days * 864e5);
  const ds = await ctx.db.select().from(aiDrafts).where(and(eq(aiDrafts.organizationId, ctx.organizationId), gte(aiDrafts.createdAt, since))).limit(5000);
  const ids = ds.map((d) => d.id);
  const vs = ids.length ? await ctx.db.select().from(aiDraftVersions).where(and(eq(aiDraftVersions.organizationId, ctx.organizationId), inArray(aiDraftVersions.draftId, ids))) : [];
  const byDraft = new Map<string, typeof vs>();
  for (const v of vs) { const l = byDraft.get(v.draftId) ?? []; l.push(v); byDraft.set(v.draftId, l); }

  const used = ds.filter((d) => d.status === "sent" || d.status === "copied");
  const aiVersions = vs.filter((v) => v.origin === "ai");
  const regenPerDraft = ds.map((d) => Math.max(0, (byDraft.get(d.id) ?? []).filter((v) => v.origin === "ai").length - 1));
  let unchanged = 0, edited = 0, manual = 0;
  const timesMin: number[] = [];
  for (const d of used) {
    const list = (byDraft.get(d.id) ?? []).sort((a, b) => a.seq - b.seq);
    const sent = list.find((v) => v.id === d.sentVersionId);
    if (!sent) continue;
    if (list.some((v) => v.origin === "ai" && v.content === sent.content)) unchanged++;
    else if (list.some((v) => v.origin === "ai")) edited++;
    else manual++;
    if (d.sentAt) timesMin.push((d.sentAt.getTime() - d.createdAt.getTime()) / 60000);
  }

  // Motivos de descarte (opcionais) vêm da auditoria.
  const discards = await ctx.db.select({ metadata: auditLogs.metadata }).from(auditLogs)
    .where(and(eq(auditLogs.organizationId, ctx.organizationId), eq(auditLogs.action, "ai_draft.discarded"), gte(auditLogs.createdAt, since)));
  const reasons: Record<string, number> = {};
  for (const r of discards) { const k = String((r.metadata as { reason?: string | null }).reason ?? "sem_motivo"); reasons[k] = (reasons[k] ?? 0) + 1; }

  const byAgent = Object.values(ds.reduce<Record<string, { agentKey: string; drafts: number; generated: number; used: number; discarded: number }>>((acc, d) => {
    const a = (acc[d.agentKey] ??= { agentKey: d.agentKey, drafts: 0, generated: 0, used: 0, discarded: 0 });
    const list = byDraft.get(d.id) ?? [];
    a.drafts++; a.generated += list.filter((v) => v.origin === "ai").length; a.discarded += list.filter((v) => v.rejected).length;
    if (d.status === "sent" || d.status === "copied") a.used++;
    return acc;
  }, {}));

  const people = [...new Set(ds.map((d) => d.createdBy))];
  const names = people.length ? await ctx.db.select({ id: users.id, name: users.name }).from(users).where(inArray(users.id, people)) : [];
  const tm = people.length ? await ctx.db.select({ userId: teamMembers.userId, team: teams.name }).from(teamMembers).innerJoin(teams, eq(teams.id, teamMembers.teamId))
    .where(and(eq(teams.organizationId, ctx.organizationId), inArray(teamMembers.userId, people))) : [];
  const byUser = people.map((u) => {
    const mine = ds.filter((d) => d.createdBy === u);
    return { userId: u, name: names.find((n) => n.id === u)?.name ?? "—", team: tm.filter((t) => t.userId === u).map((t) => t.team).sort()[0] ?? null,
      drafts: mine.length, used: mine.filter((d) => d.status === "sent" || d.status === "copied").length,
      regenerations: mine.reduce((s, d) => s + Math.max(0, (byDraft.get(d.id) ?? []).filter((v) => v.origin === "ai").length - 1), 0) };
  }).sort((a, b) => b.drafts - a.drafts);
  const byTeam = Object.values(byUser.reduce<Record<string, { team: string; drafts: number; used: number }>>((acc, u) => {
    const k = u.team ?? "Sem equipe"; const t = (acc[k] ??= { team: k, drafts: 0, used: 0 }); t.drafts += u.drafts; t.used += u.used; return acc;
  }, {}));

  // Associação com conversão: conversas com resposta enviada a partir de rascunho × negócio ganho do mesmo contato/empresa em até 30 dias.
  const sentCloser = used.filter((d) => d.module === "closer" && d.status === "sent" && d.sentAt);
  let associated = 0;
  if (sentCloser.length) {
    const convs = await ctx.db.select({ id: conversations.id, contactId: conversations.contactId, companyId: contacts.companyId }).from(conversations)
      .leftJoin(contacts, eq(contacts.id, conversations.contactId)).where(and(eq(conversations.organizationId, ctx.organizationId), inArray(conversations.id, sentCloser.map((d) => d.subjectId))));
    const won = await ctx.db.select({ contactId: opportunities.contactId, companyId: opportunities.companyId, closedAt: opportunities.closedAt }).from(opportunities)
      .where(and(eq(opportunities.organizationId, ctx.organizationId), eq(opportunities.status, "won"), gte(opportunities.closedAt, since)));
    for (const d of sentCloser) {
      const c = convs.find((x) => x.id === d.subjectId);
      if (!c) continue;
      const t0 = d.sentAt!.getTime(), t1 = t0 + 30 * 864e5;
      if (won.some((o) => o.closedAt && o.closedAt.getTime() >= t0 && o.closedAt.getTime() <= t1 && ((c.contactId && o.contactId === c.contactId) || (c.companyId && o.companyId === c.companyId)))) associated++;
    }
  }

  return {
    days, since: since.toISOString(),
    totals: {
      drafts: ds.length, generated: aiVersions.length, used: used.length, sent: ds.filter((d) => d.status === "sent").length, copied: ds.filter((d) => d.status === "copied").length,
      pendingApproval: ds.filter((d) => d.status === "pending_approval").length, open: ds.filter((d) => d.status === "open" || d.status === "manual").length,
      discardedVersions: vs.filter((v) => v.rejected).length,
      avgRegenerations: avg(regenPerDraft), editedPct: pct(edited, used.length), unchangedPct: pct(unchanged, used.length), manualPct: pct(manual, used.length),
      avgMinutesToSend: avg(timesMin),
    },
    reasons, byAgent, byUser, byTeam,
    conversion: { sample: sentCloser.length, associatedWins: associated, ratePct: pct(associated, sentCloser.length),
      note: "Associação, não causalidade: negócio ganho do mesmo contato ou empresa em até 30 dias após a resposta. Amostras pequenas não permitem conclusões." },
    notes: [
      "Uma sugestão aprovada não é necessariamente melhor: avalie junto com o resultado comercial.",
      "Descartes refletem preferência do funcionário, não erro dele nem necessariamente da IA.",
    ],
  };
}
export type AiSuggestionMetrics = Awaited<ReturnType<typeof aiSuggestionMetrics>>;
