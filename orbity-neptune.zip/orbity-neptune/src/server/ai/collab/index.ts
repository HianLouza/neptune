/**
 * COLABORAÇÃO HUMANO × IA EM SUGESTÕES (transversal: Closer.AI, Prospect.AI e qualquer módulo que registre um adaptador).
 *
 * A IA propõe. O funcionário decide. A IA aprimora. O funcionário mantém o controle.
 *  - Toda geração (nova sugestão, instrução, tom, trecho…) cria uma NOVA versão em ai_draft_versions — nada é sobrescrito.
 *  - Edições manuais viram versões humanas; a IA nunca as substitui.
 *  - Sem limite artificial de regenerações. Créditos/orçamento/kill switch bloqueiam com mensagem clara e as versões ficam.
 *  - Versões descartadas nunca são enviadas automaticamente e são passadas à IA como "não repita".
 *  - Envio respeita permissões e a política de autonomia; envio duplicado é impedido por atualização condicional.
 */
import { and, asc, desc, eq, inArray, sql } from "drizzle-orm";
import { z } from "zod";
import { aiAgents, aiDrafts, aiDraftVersions, approvalRequests, companies, contacts, conversations, icpProfiles, leads, opportunities, pipelineStages, users } from "../../db/schema";
import { requirePerm, can, type TenantContext } from "../../tenancy/context";
import type { Permission } from "../../permissions";
import { HttpError } from "../../http";
import { audit } from "../../audit";
import { runAgent } from "../orchestrator";
import type { ChatMessage } from "../providers";
import { authorizeAgentAction } from "../control-plane";
import { getConversation, searchKnowledge, sendReply } from "../../domains/closer";
import {
  APPROACHES, OPERATIONS, OPERATION_LABEL, OPERATION_TASK, REPEAT_THRESHOLD, applyInstruction, approachText, detectApproach, figuresWarning,
  nextApproach, similarity, spellcheckText, transformText, unsupportedFigures, type Approach, type LocalContext, type Operation,
} from "./text";

export { OPERATIONS, OPERATION_LABEL };

/* ------------------------------------------------------------------ adaptadores por módulo */

type Loaded = {
  contextText: string;           // contexto autorizado enviado ao modelo (tratado como dado não confiável)
  corpus: string;                // texto das fontes (guarda de preços/condições)
  history: ChatMessage[];
  lastMessage: string | null;
  sources: { title: string; similarity?: number }[];
  local: LocalContext;
  aiEnabled: boolean;
  needsHuman: boolean;
};

type Adapter = {
  module: string; subjectType: string; agentKey: string; readPerm: Permission; writePerm: Permission;
  sendMode: "send" | "copy"; // copy = o módulo nunca envia (ex.: Prospect: o funcionário copia o texto)
  load(ctx: TenantContext, subjectId: string, channel?: string | null): Promise<Loaded>;
};

const money = (cents: number, ctx: TenantContext) => (cents / 100).toLocaleString(ctx.locale, { style: "currency", currency: ctx.currency });

const closerAdapter: Adapter = {
  module: "closer", subjectType: "conversation", agentKey: "support_chat", readPerm: "closer:read", writePerm: "closer:write", sendMode: "send",
  async load(ctx, subjectId) {
    const conv = await getConversation(ctx, subjectId); // tenant + permissão closer:read
    const lastIn = [...conv.messages].reverse().find((m) => m.direction === "inbound");
    const [ct] = conv.c.contactId ? await ctx.db.select({ c: contacts, company: companies }).from(contacts).leftJoin(companies, eq(companies.id, contacts.companyId))
      .where(and(eq(contacts.id, conv.c.contactId), eq(contacts.organizationId, ctx.organizationId))) : [];
    const oppConds = [eq(opportunities.organizationId, ctx.organizationId), eq(opportunities.status, "open")];
    const opps = can(ctx, "crm:read") && (ct?.c.id || ct?.company?.id)
      ? await ctx.db.select({ title: opportunities.title, amount: opportunities.amountCents, stage: pipelineStages.name }).from(opportunities)
        .innerJoin(pipelineStages, eq(pipelineStages.id, opportunities.stageId))
        .where(and(...oppConds, ct?.company?.id ? eq(opportunities.companyId, ct.company.id) : eq(opportunities.contactId, ct!.c.id))).limit(5)
      : [];
    const kb = lastIn ? await searchKnowledge(ctx.db, ctx.organizationId, lastIn.body) : [];
    const history: ChatMessage[] = conv.messages.slice(-20).map((m) => ({ role: m.direction === "inbound" ? "user" : "assistant", content: m.body.slice(0, 1500) }));
    const crm = [
      `Cliente: ${conv.contactName ?? "não identificado"}${ct?.c.jobTitle ? ` (${ct.c.jobTitle})` : ""}`,
      ct?.company ? `Empresa: ${ct.company.name}${ct.company.segment ? ` · segmento ${ct.company.segment}` : ""}${ct.company.size ? ` · porte ${ct.company.size}` : ""}` : "Empresa: não informada",
      `Canal: ${conv.c.channel} · intenção detectada: ${conv.c.intent ?? "não classificada"}`,
      opps.length ? `Oportunidades abertas: ${opps.map((o) => `${o.title} (${o.stage}, ${money(Number(o.amount), ctx)})`).join("; ")}` : "Oportunidades abertas: nenhuma registrada",
    ].join("\n");
    const kbText = kb.length ? kb.map((k) => `[${k.title}] ${k.content}`).join("\n") : "Nenhum documento relevante encontrado na base de conhecimento.";
    return {
      contextText: `${crm}\n\nBASE DE CONHECIMENTO (única fonte para preços, prazos, condições e políticas):\n${kbText}`,
      corpus: [kb.map((k) => k.content).join("\n"), conv.messages.map((m) => m.body).join("\n"), crm].join("\n"),
      history, lastMessage: lastIn?.body ?? null, sources: kb.map((k) => ({ title: k.title, similarity: Number(k.similarity) })),
      local: { module: "closer", customerName: conv.contactName, lastMessage: lastIn?.body ?? null, knowledge: kb[0]?.content ?? null, company: ct?.company?.name ?? null, segment: ct?.company?.segment ?? null, role: ct?.c.jobTitle ?? null, channel: conv.c.channel },
      aiEnabled: conv.c.aiEnabled, needsHuman: !kb.length,
    };
  },
};

const prospectAdapter: Adapter = {
  module: "prospect", subjectType: "lead", agentKey: "outreach", readPerm: "prospect:read", writePerm: "prospect:write", sendMode: "copy",
  async load(ctx, subjectId, channel) {
    requirePerm(ctx, "prospect:read");
    const [r] = await ctx.db.select({ lead: leads, company: companies, contact: contacts }).from(leads)
      .leftJoin(companies, eq(companies.id, leads.companyId)).leftJoin(contacts, eq(contacts.id, leads.contactId))
      .where(and(eq(leads.id, subjectId), eq(leads.organizationId, ctx.organizationId)));
    if (!r) throw new HttpError(404, "Lead não encontrado.");
    const [icp] = await ctx.db.select().from(icpProfiles).where(and(eq(icpProfiles.organizationId, ctx.organizationId), eq(icpProfiles.active, true))).orderBy(desc(icpProfiles.createdAt)).limit(1);
    const needs = (icp?.criteria as { needs?: string[] } | undefined)?.needs ?? [];
    const ctxText = [
      `Canal da abordagem: ${channel ?? "email"}`,
      `Empresa: ${r.company?.name ?? "não informada"}`, `Segmento: ${r.company?.segment ?? "não informado"}`, `Região: ${r.company?.region ?? "não informada"}`,
      `Contato: ${r.contact?.name ?? "não informado"} (${r.contact?.jobTitle ?? "cargo não informado"})`,
      `Necessidades do ICP: ${needs.join(", ") || "não definidas"}`, `Pontuação do lead: ${r.lead.score ?? "sem pontuação"}`,
    ].join("\n");
    return {
      contextText: ctxText, corpus: ctxText, history: [], lastMessage: null, sources: [{ title: "Lead e ICP (Prospect.AI)" }],
      local: { module: "prospect", customerName: r.contact?.name ?? null, company: r.company?.name ?? r.lead.title, segment: r.company?.segment ?? null, role: r.contact?.jobTitle ?? null, needs: needs.slice(0, 2).join(" e ") || null, channel: channel ?? "email" },
      aiEnabled: true, needsHuman: false,
    };
  },
};

export const ADAPTERS: Record<string, Adapter> = { closer: closerAdapter, prospect: prospectAdapter };
export const MODULES = Object.keys(ADAPTERS) as [string, ...string[]];

function adapterFor(module: string) {
  const a = ADAPTERS[module];
  if (!a) throw new HttpError(400, `Módulo sem colaboração de IA: ${module}.`);
  return a;
}

/* ------------------------------------------------------------------ leitura */

type DraftRow = typeof aiDrafts.$inferSelect;
type VersionRow = typeof aiDraftVersions.$inferSelect;

async function loadDraft(ctx: TenantContext, draftId: string) {
  const id = z.string().uuid().parse(draftId);
  const [d] = await ctx.db.select().from(aiDrafts).where(and(eq(aiDrafts.id, id), eq(aiDrafts.organizationId, ctx.organizationId)));
  if (!d) throw new HttpError(404, "Sugestão não encontrada.");
  const adapter = adapterFor(d.module);
  requirePerm(ctx, adapter.readPerm);
  return { d, adapter };
}

async function versionsOf(ctx: TenantContext, draftId: string) {
  return ctx.db.select().from(aiDraftVersions).where(and(eq(aiDraftVersions.draftId, draftId), eq(aiDraftVersions.organizationId, ctx.organizationId))).orderBy(asc(aiDraftVersions.seq));
}

export type DraftView = Awaited<ReturnType<typeof buildView>>;

async function buildView(ctx: TenantContext, d: DraftRow, adapter: Adapter, extra: { warnings?: string[]; loaded?: Loaded } = {}) {
  const vs = await versionsOf(ctx, d.id);
  const authorIds = [...new Set(vs.map((v) => v.createdBy))];
  const names = authorIds.length ? await ctx.db.select({ id: users.id, name: users.name }).from(users).where(inArray(users.id, authorIds)) : [];
  const nameOf = (id: string) => names.find((n) => n.id === id)?.name ?? "—";
  const corpus = extra.loaded?.corpus ?? null;
  const versions = vs.map((v) => ({
    id: v.id, seq: v.seq, origin: v.origin as "ai" | "human", operation: v.operation, operationLabel: OPERATION_LABEL[v.operation as Operation] ?? v.operation,
    instruction: v.instruction, content: v.content, basedOnVersionId: v.basedOnVersionId, simulated: v.simulated, provider: v.provider, model: v.model,
    sources: v.sources, rejected: v.rejected, createdBy: v.createdBy, createdByName: v.origin === "ai" ? `IA (pedido de ${nameOf(v.createdBy)})` : nameOf(v.createdBy),
    createdAt: v.createdAt, figures: corpus && v.origin === "ai" ? unsupportedFigures(v.content, corpus) : [],
  }));
  const current = [...versions].reverse().find((v) => !v.rejected) ?? versions[versions.length - 1] ?? null;
  return {
    draft: { id: d.id, module: d.module, subjectType: d.subjectType, subjectId: d.subjectId, agentKey: d.agentKey, channel: d.channel, status: d.status,
      createdAt: d.createdAt, sentAt: d.sentAt, sentVersionId: d.sentVersionId, discardReason: d.discardReason },
    versions, currentVersionId: current?.id ?? null,
    policy: policyFor(ctx, adapter, d),
    regenerations: Math.max(0, versions.filter((v) => v.origin === "ai").length - 1),
    warnings: extra.warnings ?? [],
    needsHuman: extra.loaded?.needsHuman ?? false,
  };
}

function policyFor(ctx: TenantContext, adapter: Adapter, d: DraftRow) {
  const writable = can(ctx, adapter.writePerm);
  if (adapter.sendMode === "copy") return { mode: "copy" as const, canWrite: writable, label: "Copiar texto", reason: "Este módulo não envia mensagens: copie o texto e envie pelo seu canal." };
  if (!writable) return { mode: "none" as const, canWrite: false, label: "Sem permissão", reason: "Seu perfil não pode responder conversas." };
  const decide = can(ctx, "approvals:decide");
  return d.status === "manual" || decide
    ? { mode: "send" as const, canWrite: true, label: "Aprovar e enviar", reason: decide ? "Você pode aprovar e enviar." : "Resposta escrita por você: envio direto." }
    : { mode: "approval" as const, canWrite: true, label: "Enviar para aprovação", reason: "Texto baseado em sugestão da IA: um gestor aprova antes do envio (política da organização). Textos escritos por você são enviados direto." };
}

export async function getDraft(ctx: TenantContext, draftId: string) {
  const { d, adapter } = await loadDraft(ctx, draftId);
  const loaded = await adapter.load(ctx, d.subjectId, d.channel).catch(() => undefined);
  return buildView(ctx, d, adapter, { loaded });
}

/** Rascunho em andamento (não enviado/copiado) do assunto, se houver. */
export async function getDraftForSubject(ctx: TenantContext, module: string, subjectId: string, channel?: string | null) {
  const adapter = adapterFor(module);
  requirePerm(ctx, adapter.readPerm);
  const sid = z.string().uuid().parse(subjectId);
  const [d] = await ctx.db.select().from(aiDrafts)
    .where(and(eq(aiDrafts.organizationId, ctx.organizationId), eq(aiDrafts.module, module), eq(aiDrafts.subjectId, sid), inArray(aiDrafts.status, ["open", "manual", "pending_approval"]),
      ...(channel && adapter.sendMode === "copy" ? [eq(aiDrafts.channel, channel)] : [])))
    .orderBy(desc(aiDrafts.createdAt)).limit(1);
  if (!d) return null;
  const loaded = await adapter.load(ctx, d.subjectId, d.channel).catch(() => undefined);
  return buildView(ctx, d, adapter, { loaded });
}

/* ------------------------------------------------------------------ geração */

const LOCAL_MODEL = "variantes-locais";
const approachOf = (v: Pick<VersionRow, "model" | "content">): Approach | null => {
  const m = v.model?.match(/^variantes-locais:(\w+)$/)?.[1];
  return (APPROACHES as readonly string[]).includes(m ?? "") ? (m as Approach) : detectApproach(v.content);
};

type GenArgs = {
  op: Operation; instruction?: string | null; base: VersionRow | null; rejected: VersionRow[]; previousAi: VersionRow[];
  selection?: { start: number; end: number } | null;
};
type GenResult = { content: string; executionId: string | null; simulated: boolean; provider: string; model: string; warnings: string[] };

function buildPrompt(args: GenArgs, selected: string | null, stronger: boolean) {
  const parts = [`TAREFA: ${OPERATION_TASK[args.op]}`];
  if (args.instruction) parts.push(`INSTRUÇÃO DO FUNCIONÁRIO (siga com prioridade, desde que respeite as regras): ${args.instruction}`);
  if (args.base) parts.push(`VERSÃO BASE:\n"""${args.base.content}"""`);
  if (selected !== null) parts.push(`TRECHO A REESCREVER (responda só com o novo trecho):\n"""${selected}"""`);
  if (args.rejected.length) parts.push(`ABORDAGENS JÁ DESCARTADAS PELO FUNCIONÁRIO — não repita estrutura, argumentos nem frases:\n${args.rejected.slice(-6).map((r, i) => `${i + 1}) """${r.content.slice(0, 700)}"""`).join("\n")}`);
  if (stronger) parts.push("ATENÇÃO: a tentativa anterior ficou parecida demais com uma versão descartada. Mude completamente a abordagem.");
  parts.push("REGRAS: responda somente com o texto final, em português do Brasil, pronto para o cliente, sem comentários, títulos ou aspas. Não invente preços, descontos, prazos, condições, disponibilidade ou informações sobre a empresa: use só o que estiver no contexto autorizado e na conversa; se faltar, diga que a equipe vai confirmar.");
  return parts.join("\n\n");
}

function localGenerate(args: GenArgs, loaded: Loaded, selected: string | null, attempt: number): { content: string; model: string } {
  const avoid = [...args.rejected, ...(args.op === "regenerate" && args.base ? [args.base] : [])].map(approachOf).filter(Boolean) as Approach[];
  if (args.op === "initial" || args.op === "regenerate" || (!args.base && args.op !== "custom")) {
    const used = args.previousAi.map(approachOf).filter(Boolean) as Approach[];
    const a = nextApproach([...new Set([...avoid, ...(args.op === "regenerate" ? used : [])])], attempt);
    return { content: approachText(a, loaded.local), model: `${LOCAL_MODEL}:${a}` };
  }
  if (args.op === "improve_selection" && selected !== null) {
    const improved = args.instruction ? applyInstruction(selected, loaded.local, args.instruction) : spellcheckText(selected).replace(/^\s*\w/, (m) => m.toUpperCase());
    return { content: improved === selected ? `${selected.trim()}${/[.!?]$/.test(selected.trim()) ? "" : "."}` : improved, model: `${LOCAL_MODEL}:${args.op}` };
  }
  if (args.op === "custom" && !args.base) return { content: applyInstruction(approachText(nextApproach(avoid, attempt), loaded.local), loaded.local, args.instruction ?? ""), model: `${LOCAL_MODEL}:custom` };
  return { content: transformText(args.op, args.base!.content, loaded.local, args.instruction), model: `${LOCAL_MODEL}:${args.op}` };
}

function aiError(err: unknown): never {
  const status = (err as { status?: number }).status;
  const msg = (err as Error).message ?? "falha desconhecida";
  throw new HttpError(status && status >= 400 && status < 600 ? status : 503, `A IA não conseguiu gerar agora: ${msg} Todas as versões anteriores foram preservadas — você pode continuar editando ou escrever manualmente.`);
}

async function generate(ctx: TenantContext, adapter: Adapter, loaded: Loaded, args: GenArgs): Promise<GenResult> {
  const base = args.base?.content ?? "";
  const sel = args.selection && args.base ? args.selection : null;
  const selected = sel ? base.slice(sel.start, sel.end) : null;
  const warnings: string[] = [];
  let out: Awaited<ReturnType<typeof runAgent>> | null = null;
  let content = "", model = "", attempt = 0, simulated = true, provider = "local-heuristic", executionId: string | null = null;

  for (attempt = 0; attempt < 2; attempt++) {
    try {
      out = await runAgent(ctx, { agentKey: adapter.agentKey, input: buildPrompt(args, selected, attempt > 0), history: loaded.history, context: loaded.contextText });
    } catch (err) { aiError(err); }
    if (out!.status === "blocked") throw new HttpError(409, `${out!.text} Suas versões anteriores foram preservadas.`);
    if (out!.status === "error") throw new HttpError(503, `${out!.text} Suas versões anteriores foram preservadas.`);
    executionId = out!.executionId; provider = out!.provider;
    if (out!.simulated) {
      const g = localGenerate(args, loaded, selected, attempt + args.previousAi.length);
      content = g.content; model = g.model; simulated = true;
    } else {
      content = out!.text.trim().replace(/^"""|"""$/g, "").replace(/^["“]|["”]$/g, "").trim(); model = out!.model; simulated = false;
    }
    if (sel && selected !== null) content = base.slice(0, sel.start) + content + base.slice(sel.end);
    const compareTo = [...args.rejected, ...(args.op === "regenerate" && args.base ? [args.base] : [])];
    const tooClose = compareTo.some((r) => similarity(r.content, content) > REPEAT_THRESHOLD);
    if (!tooClose) break;
    if (attempt === 1) warnings.push("A nova versão ficou parecida com uma já descartada. Peça com instruções ou escreva manualmente.");
  }
  const figs = unsupportedFigures(content, loaded.corpus);
  const fw = figuresWarning(figs);
  if (fw) warnings.push(fw);
  if (simulated) warnings.push("Sugestão gerada em modo simulado (sem provedor de IA real configurado).");
  for (const w of out?.warnings ?? []) if (!/MODO SIMULADO/.test(w)) warnings.push(w);
  return { content, executionId, simulated, provider: simulated ? "local-heuristic" : provider, model, warnings };
}

async function assertAiAllowed(ctx: TenantContext, adapter: Adapter, loaded: Loaded) {
  if (!loaded.aiEnabled) throw new HttpError(409, "A IA está desativada nesta conversa. Você pode escrever a resposta manualmente.");
  const [agent] = await ctx.db.select().from(aiAgents).where(and(eq(aiAgents.organizationId, ctx.organizationId), eq(aiAgents.key, adapter.agentKey)));
  if (agent) {
    const p = await authorizeAgentAction(ctx, agent, "send_message", "draft");
    if (p.decision === "deny") throw new HttpError(409, `A IA não pode preparar sugestões agora. ${p.reason} Você pode escrever manualmente.`);
  }
}

const createSchema = z.object({ module: z.enum(MODULES), subjectId: z.string().uuid(), channel: z.string().max(30).nullish() });

/** Abre (ou reaproveita) o rascunho do assunto e gera a primeira sugestão. */
export async function createDraft(ctx: TenantContext, raw: z.input<typeof createSchema>) {
  const input = createSchema.parse(raw);
  const adapter = adapterFor(input.module);
  requirePerm(ctx, adapter.writePerm);
  const existing = await getDraftForSubject(ctx, input.module, input.subjectId, input.channel);
  if (existing) return existing;
  const loaded = await adapter.load(ctx, input.subjectId, input.channel);
  await assertAiAllowed(ctx, adapter, loaded);
  const g = await generate(ctx, adapter, loaded, { op: "initial", base: null, rejected: [], previousAi: [] });
  const d = await ctx.db.transaction(async (tx) => {
    const [d] = await tx.insert(aiDrafts).values({ organizationId: ctx.organizationId, module: adapter.module, subjectType: adapter.subjectType, subjectId: input.subjectId, agentKey: adapter.agentKey, channel: input.channel ?? null, createdBy: ctx.userId }).returning();
    await tx.insert(aiDraftVersions).values({ organizationId: ctx.organizationId, draftId: d.id, seq: 1, origin: "ai", operation: "initial", content: g.content, executionId: g.executionId, simulated: g.simulated, provider: g.provider, model: g.model, sources: loaded.sources, createdBy: ctx.userId });
    return d;
  });
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "ai_draft.created", resource: "ai_draft", resourceId: d.id, metadata: { module: d.module, subjectId: d.subjectId, simulated: g.simulated } });
  return buildView(ctx, d, adapter, { warnings: g.warnings, loaded });
}

const regenSchema = z.object({
  operation: z.enum(OPERATIONS).refine((o) => o !== "initial", "Operação inválida."),
  instruction: z.string().trim().max(1000).nullish(),
  baseVersionId: z.string().uuid().nullish(),
  selection: z.object({ start: z.number().int().min(0), end: z.number().int().min(1) }).nullish(),
});

function assertEditable(d: DraftRow) {
  if (d.status === "sent" || d.status === "copied") throw new HttpError(409, "Esta sugestão já foi enviada. Gere uma nova sugestão para continuar.");
  if (d.status === "pending_approval") throw new HttpError(409, "Esta resposta está aguardando aprovação. Aguarde a decisão do gestor.");
}

async function nextSeq(ctx: TenantContext, draftId: string) {
  const [r] = await ctx.db.select({ m: sql<number>`coalesce(max(${aiDraftVersions.seq}),0)::int` }).from(aiDraftVersions).where(eq(aiDraftVersions.draftId, draftId));
  return Number(r.m) + 1;
}

/** Nova versão pela IA (sem limite). Nunca altera versões existentes. */
export async function regenerate(ctx: TenantContext, draftId: string, raw: z.input<typeof regenSchema>) {
  const input = regenSchema.parse(raw);
  const { d, adapter } = await loadDraft(ctx, draftId);
  requirePerm(ctx, adapter.writePerm);
  assertEditable(d);
  if ((input.operation === "instruct" || input.operation === "custom") && !input.instruction) throw new HttpError(400, "Escreva a instrução para a IA.");
  const vs = await versionsOf(ctx, d.id);
  const base = input.baseVersionId ? vs.find((v) => v.id === input.baseVersionId) : [...vs].reverse().find((v) => !v.rejected) ?? vs[vs.length - 1];
  if (input.baseVersionId && !base) throw new HttpError(404, "Versão base não encontrada.");
  if (input.operation === "improve_selection") {
    if (!input.selection || !base) throw new HttpError(400, "Selecione o trecho que deseja melhorar.");
    if (input.selection.end > base.content.length || input.selection.start >= input.selection.end) throw new HttpError(400, "Seleção inválida para esta versão.");
  }
  const loaded = await adapter.load(ctx, d.subjectId, d.channel);
  await assertAiAllowed(ctx, adapter, loaded);
  const g = await generate(ctx, adapter, loaded, {
    op: input.operation, instruction: input.instruction ?? null, base: base ?? null, selection: input.selection ?? null,
    rejected: vs.filter((v) => v.rejected), previousAi: vs.filter((v) => v.origin === "ai"),
  });
  const seq = await nextSeq(ctx, d.id);
  await ctx.db.insert(aiDraftVersions).values({ organizationId: ctx.organizationId, draftId: d.id, seq, origin: "ai", operation: input.operation, instruction: input.instruction ?? null, content: g.content, basedOnVersionId: base?.id ?? null, executionId: g.executionId, simulated: g.simulated, provider: g.provider, model: g.model, sources: loaded.sources, createdBy: ctx.userId });
  await ctx.db.update(aiDrafts).set({ updatedAt: new Date() }).where(eq(aiDrafts.id, d.id));
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "ai_draft.regenerated", resource: "ai_draft", resourceId: d.id, metadata: { operation: input.operation, seq, hasInstruction: !!input.instruction, simulated: g.simulated } });
  return buildView(ctx, d, adapter, { warnings: g.warnings, loaded });
}

/* ------------------------------------------------------------------ ações humanas */

const editSchema = z.object({ content: z.string().max(5000), baseVersionId: z.string().uuid().nullish() });

/** Edição manual: vira uma versão humana. A IA nunca a sobrescreve. */
export async function saveManualEdit(ctx: TenantContext, draftId: string, raw: z.input<typeof editSchema>) {
  const input = editSchema.parse(raw);
  const { d, adapter } = await loadDraft(ctx, draftId);
  requirePerm(ctx, adapter.writePerm);
  assertEditable(d);
  const vs = await versionsOf(ctx, d.id);
  const last = vs[vs.length - 1];
  if (last && last.content === input.content && !last.rejected) return buildView(ctx, d, adapter);
  const seq = await nextSeq(ctx, d.id);
  await ctx.db.insert(aiDraftVersions).values({ organizationId: ctx.organizationId, draftId: d.id, seq, origin: "human", operation: "manual_edit", content: input.content, basedOnVersionId: input.baseVersionId ?? last?.id ?? null, createdBy: ctx.userId });
  await ctx.db.update(aiDrafts).set({ updatedAt: new Date() }).where(eq(aiDrafts.id, d.id));
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "ai_draft.edited", resource: "ai_draft", resourceId: d.id, metadata: { seq, chars: input.content.length } });
  return buildView(ctx, d, adapter);
}

/** Recupera uma versão anterior como nova versão (o histórico continua intacto). */
export async function restoreVersion(ctx: TenantContext, draftId: string, versionId: string) {
  const { d, adapter } = await loadDraft(ctx, draftId);
  requirePerm(ctx, adapter.writePerm);
  assertEditable(d);
  const vs = await versionsOf(ctx, d.id);
  const v = vs.find((x) => x.id === z.string().uuid().parse(versionId));
  if (!v) throw new HttpError(404, "Versão não encontrada.");
  const seq = await nextSeq(ctx, d.id);
  await ctx.db.insert(aiDraftVersions).values({ organizationId: ctx.organizationId, draftId: d.id, seq, origin: "human", operation: "restore", instruction: `Recuperada da versão ${v.seq}`, content: v.content, basedOnVersionId: v.id, createdBy: ctx.userId });
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "ai_draft.restored", resource: "ai_draft", resourceId: d.id, metadata: { fromSeq: v.seq, seq } });
  return buildView(ctx, d, adapter);
}

export const DISCARD_REASONS = ["outra_abordagem", "tom", "informacao_incorreta", "muito_longa", "muito_curta", "vou_escrever", "outro"] as const;
const discardSchema = z.object({ versionId: z.string().uuid(), reason: z.enum(DISCARD_REASONS).nullish(), note: z.string().trim().max(500).nullish() });

/**
 * Descartar uma versão: ela nunca será enviada nem repetida pela IA. O rascunho continua aberto para nova sugestão,
 * instruções ou escrita manual. O motivo é opcional e nunca penaliza o funcionário (preferência ≠ erro da IA).
 */
export async function discardVersion(ctx: TenantContext, draftId: string, raw: z.input<typeof discardSchema>) {
  const input = discardSchema.parse(raw);
  const { d, adapter } = await loadDraft(ctx, draftId);
  requirePerm(ctx, adapter.writePerm);
  assertEditable(d);
  const [v] = await ctx.db.update(aiDraftVersions).set({ rejected: true })
    .where(and(eq(aiDraftVersions.id, input.versionId), eq(aiDraftVersions.draftId, d.id), eq(aiDraftVersions.organizationId, ctx.organizationId))).returning();
  if (!v) throw new HttpError(404, "Versão não encontrada.");
  await ctx.db.update(aiDrafts).set({ discardReason: input.reason ?? d.discardReason, discardNote: input.note ?? d.discardNote, updatedAt: new Date() }).where(eq(aiDrafts.id, d.id));
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "ai_draft.discarded", resource: "ai_draft", resourceId: d.id, metadata: { seq: v.seq, origin: v.origin, reason: input.reason ?? null } });
  return buildView(ctx, d, adapter);
}

/** O funcionário assume a resposta: modo manual, envio direto com a permissão do módulo. */
export async function takeOverManually(ctx: TenantContext, draftId: string, raw: { content?: string | null }) {
  const content = z.string().max(5000).nullish().parse(raw.content) ?? "";
  const { d, adapter } = await loadDraft(ctx, draftId);
  requirePerm(ctx, adapter.writePerm);
  assertEditable(d);
  const seq = await nextSeq(ctx, d.id);
  await ctx.db.insert(aiDraftVersions).values({ organizationId: ctx.organizationId, draftId: d.id, seq, origin: "human", operation: "manual_takeover", content, createdBy: ctx.userId });
  const [u] = await ctx.db.update(aiDrafts).set({ status: "manual", updatedAt: new Date() }).where(eq(aiDrafts.id, d.id)).returning();
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "ai_draft.manual_takeover", resource: "ai_draft", resourceId: d.id, metadata: { seq } });
  return buildView(ctx, u, adapter);
}

/** Rascunho manual direto (sem sugestão da IA), para quem prefere escrever desde o início com histórico de versões. */
export async function startManualDraft(ctx: TenantContext, raw: z.input<typeof createSchema> & { content?: string }) {
  const input = createSchema.parse(raw);
  const adapter = adapterFor(input.module);
  requirePerm(ctx, adapter.writePerm);
  const existing = await getDraftForSubject(ctx, input.module, input.subjectId, input.channel);
  if (existing) return takeOverManually(ctx, existing.draft.id, { content: raw.content ?? "" });
  await adapter.load(ctx, input.subjectId, input.channel); // valida acesso ao assunto
  const d = await ctx.db.transaction(async (tx) => {
    const [d] = await tx.insert(aiDrafts).values({ organizationId: ctx.organizationId, module: adapter.module, subjectType: adapter.subjectType, subjectId: input.subjectId, agentKey: adapter.agentKey, channel: input.channel ?? null, status: "manual", createdBy: ctx.userId }).returning();
    await tx.insert(aiDraftVersions).values({ organizationId: ctx.organizationId, draftId: d.id, seq: 1, origin: "human", operation: "manual_takeover", content: raw.content ?? "", createdBy: ctx.userId });
    return d;
  });
  return buildView(ctx, d, adapter);
}

/* ------------------------------------------------------------------ envio */

/** "Derivado da IA" = versão da IA ou edição ainda parecida com alguma sugestão; textos realmente escritos pelo funcionário não são. */
function isAiDerived(v: VersionRow, vs: VersionRow[]) {
  if (v.origin === "ai") return true;
  return vs.some((x) => x.origin === "ai" && similarity(x.content, v.content) >= 0.5);
}

const sendSchema = z.object({ versionId: z.string().uuid() });

/**
 * Aprovar e enviar a versão escolhida. Envio duplicado é impedido (atualização condicional do status).
 *  - Texto do funcionário → envio direto (closer:write).
 *  - Texto derivado da IA → quem tem approvals:decide envia; os demais geram pedido de aprovação com EXATAMENTE essa versão.
 */
export async function sendDraft(ctx: TenantContext, draftId: string, raw: z.input<typeof sendSchema>, opts: { forceApproval?: boolean } = {}) {
  const input = sendSchema.parse(raw);
  const { d, adapter } = await loadDraft(ctx, draftId);
  requirePerm(ctx, adapter.writePerm);
  if (adapter.sendMode !== "send") throw new HttpError(400, "Este módulo não envia mensagens: use Copiar texto.");
  if (d.status === "sent") throw new HttpError(409, "Esta resposta já foi enviada.");
  if (d.status === "pending_approval") throw new HttpError(409, "Esta resposta já está aguardando aprovação.");
  const vs = await versionsOf(ctx, d.id);
  const v = vs.find((x) => x.id === input.versionId);
  if (!v) throw new HttpError(404, "Versão não encontrada.");
  if (v.rejected) throw new HttpError(409, "Esta versão foi descartada. Recupere-a no histórico para enviá-la.");
  if (!v.content.trim()) throw new HttpError(400, "A resposta está vazia.");
  const aiDerived = isAiDerived(v, vs);
  const needsApproval = opts.forceApproval || (aiDerived && !can(ctx, "approvals:decide"));
  const lastAi = [...vs].reverse().find((x) => x.origin === "ai");
  const sentUnchanged = !!lastAi && lastAi.content === v.content;

  if (needsApproval) {
    const [locked] = await ctx.db.update(aiDrafts).set({ status: "pending_approval", updatedAt: new Date() })
      .where(and(eq(aiDrafts.id, d.id), inArray(aiDrafts.status, ["open", "manual"]))).returning();
    if (!locked) throw new HttpError(409, "Esta resposta já foi enviada ou está aguardando aprovação.");
    const [conv] = await ctx.db.select({ name: contacts.name }).from(conversations).leftJoin(contacts, eq(contacts.id, conversations.contactId)).where(eq(conversations.id, d.subjectId));
    const [ap] = await ctx.db.insert(approvalRequests).values({
      organizationId: ctx.organizationId, kind: "ai_message", title: `Resposta para ${conv?.name ?? "contato"} (versão ${v.seq})`,
      payload: { conversationId: d.subjectId, body: v.content, draftId: d.id, versionId: v.id, sources: v.sources.map((s) => s.title), simulated: v.simulated, requestedByUser: ctx.userId, aiDerived, sentUnchanged },
      requestedBy: `ai:${d.agentKey}`,
    }).returning();
    await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "ai_draft.submitted_for_approval", resource: "ai_draft", resourceId: d.id, metadata: { seq: v.seq, approvalId: ap.id } });
    return { status: "pending_approval" as const, approvalId: ap.id, delivered: false, notice: "Enviado para aprovação. Um gestor decide antes de a mensagem sair.", view: await buildView(ctx, locked, adapter) };
  }

  const prev = d.status;
  const [locked] = await ctx.db.update(aiDrafts).set({ status: "sent", sentVersionId: v.id, sentBy: ctx.userId, sentAt: new Date(), updatedAt: new Date() })
    .where(and(eq(aiDrafts.id, d.id), inArray(aiDrafts.status, ["open", "manual"]))).returning();
  if (!locked) throw new HttpError(409, "Esta resposta já foi enviada.");
  let r: Awaited<ReturnType<typeof sendReply>>;
  try {
    r = await sendReply(ctx, d.subjectId, v.content, aiDerived ? "ai" : "user");
  } catch (err) {
    await ctx.db.update(aiDrafts).set({ status: prev, sentVersionId: null, sentBy: null, sentAt: null }).where(eq(aiDrafts.id, d.id));
    throw err;
  }
  await ctx.db.update(aiDrafts).set({ sentMessageId: r.message.id }).where(eq(aiDrafts.id, d.id));
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "ai_draft.sent", resource: "ai_draft", resourceId: d.id, metadata: { seq: v.seq, messageId: r.message.id, aiDerived, sentUnchanged, delivered: r.delivered, regenerations: Math.max(0, vs.filter((x) => x.origin === "ai").length - 1) } });
  return { status: "sent" as const, approvalId: null, delivered: r.delivered, notice: r.notice, view: await buildView(ctx, { ...locked, sentMessageId: r.message.id }, adapter) };
}

/** Prospect.AI: o texto é copiado pelo funcionário (o módulo nunca envia). Registra qual versão foi usada. */
export async function markCopied(ctx: TenantContext, draftId: string, raw: z.input<typeof sendSchema>) {
  const input = sendSchema.parse(raw);
  const { d, adapter } = await loadDraft(ctx, draftId);
  requirePerm(ctx, adapter.writePerm);
  const vs = await versionsOf(ctx, d.id);
  const v = vs.find((x) => x.id === input.versionId);
  if (!v) throw new HttpError(404, "Versão não encontrada.");
  if (v.rejected) throw new HttpError(409, "Esta versão foi descartada. Recupere-a no histórico para usá-la.");
  const [u] = await ctx.db.update(aiDrafts).set({ status: "copied", sentVersionId: v.id, sentBy: ctx.userId, sentAt: new Date(), updatedAt: new Date() })
    .where(and(eq(aiDrafts.id, d.id), inArray(aiDrafts.status, ["open", "manual"]))).returning();
  if (!u) throw new HttpError(409, "Este rascunho já foi usado.");
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "ai_draft.copied", resource: "ai_draft", resourceId: d.id, metadata: { seq: v.seq } });
  return buildView(ctx, u, adapter);
}

/**
 * Chamado pelo fluxo de aprovações do Closer.AI quando o pedido veio de um rascunho.
 * Aprovar envia exatamente a versão submetida (ou a edição do aprovador, registrada como nova versão).
 * Rejeitar devolve o rascunho para o funcionário continuar; a versão rejeitada não é reenviada automaticamente.
 */
export async function finalizeDraftApproval(ctx: TenantContext, payload: { draftId: string; versionId: string; conversationId: string; aiDerived?: boolean }, approve: boolean, editedBody?: string) {
  const [d] = await ctx.db.select().from(aiDrafts).where(and(eq(aiDrafts.id, payload.draftId), eq(aiDrafts.organizationId, ctx.organizationId)));
  if (!d) throw new HttpError(404, "Rascunho da aprovação não encontrado.");
  if (!approve) {
    await ctx.db.update(aiDraftVersions).set({ rejected: true }).where(and(eq(aiDraftVersions.id, payload.versionId), eq(aiDraftVersions.draftId, d.id)));
    await ctx.db.update(aiDrafts).set({ status: "open", updatedAt: new Date() }).where(and(eq(aiDrafts.id, d.id), eq(aiDrafts.status, "pending_approval")));
    return null;
  }
  const vs = await versionsOf(ctx, d.id);
  let v = vs.find((x) => x.id === payload.versionId);
  if (!v) throw new HttpError(404, "Versão da aprovação não encontrada.");
  if (editedBody?.trim() && editedBody.trim() !== v.content) {
    const [nv] = await ctx.db.insert(aiDraftVersions).values({ organizationId: ctx.organizationId, draftId: d.id, seq: (vs[vs.length - 1]?.seq ?? 0) + 1, origin: "human", operation: "manual_edit", instruction: "Editada pelo aprovador", content: editedBody.trim(), basedOnVersionId: v.id, createdBy: ctx.userId }).returning();
    v = nv;
  }
  const [locked] = await ctx.db.update(aiDrafts).set({ status: "sent", sentVersionId: v.id, sentBy: ctx.userId, sentAt: new Date(), updatedAt: new Date() })
    .where(and(eq(aiDrafts.id, d.id), eq(aiDrafts.status, "pending_approval"))).returning();
  if (!locked) throw new HttpError(409, "Esta resposta já foi enviada.");
  const r = await sendReply(ctx, payload.conversationId, v.content, "ai");
  await ctx.db.update(aiDrafts).set({ sentMessageId: r.message.id }).where(eq(aiDrafts.id, d.id));
  const lastAi = [...vs].reverse().find((x) => x.origin === "ai");
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "ai_draft.sent", resource: "ai_draft", resourceId: d.id, metadata: { seq: v.seq, messageId: r.message.id, aiDerived: true, sentUnchanged: !!lastAi && lastAi.content === v.content, approvedBy: ctx.userId } });
  return r;
}

/** Para a conversa: de qual rascunho veio cada mensagem enviada (sugestão sem alteração × editada × escrita pela equipe). */
export async function draftOriginsForMessages(ctx: TenantContext, messageIds: string[]) {
  if (!messageIds.length) return {} as Record<string, { origin: "ai_unchanged" | "ai_edited" | "human"; seq: number }>;
  const ds = await ctx.db.select().from(aiDrafts).where(and(eq(aiDrafts.organizationId, ctx.organizationId), inArray(aiDrafts.sentMessageId, messageIds)));
  const out: Record<string, { origin: "ai_unchanged" | "ai_edited" | "human"; seq: number }> = {};
  for (const d of ds) {
    const vs = await versionsOf(ctx, d.id);
    const sent = vs.find((v) => v.id === d.sentVersionId);
    if (!sent || !d.sentMessageId) continue;
    const anyAi = vs.some((v) => v.origin === "ai");
    const unchanged = vs.some((v) => v.origin === "ai" && v.content === sent.content);
    out[d.sentMessageId] = { origin: unchanged ? "ai_unchanged" : anyAi && vs.some((v) => v.origin === "ai" && similarity(v.content, sent.content) >= 0.5) ? "ai_edited" : "human", seq: sent.seq };
  }
  return out;
}
