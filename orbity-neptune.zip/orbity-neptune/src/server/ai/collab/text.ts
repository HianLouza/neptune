/**
 * Funções PURAS de texto da colaboração humano × IA (usadas no servidor e no navegador):
 * similaridade (anti-repetição), diff por palavra (comparar versões), guarda de preços e
 * gerador determinístico de alternativas para quando não há provedor de IA real (sempre marcado como simulado).
 */

/* ------------------------------------------------------------------ similaridade */

const stripMarks = (s: string) => s.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
const norm = (s: string) => stripMarks(s.toLowerCase()).replace(/[^a-z0-9%$ ]+/g, " ").replace(/\s+/g, " ").trim();

function shingles(s: string, n = 3): Set<string> {
  const w = norm(s).split(" ").filter(Boolean);
  const out = new Set<string>();
  if (w.length < n) { if (w.length) out.add(w.join(" ")); return out; }
  for (let i = 0; i <= w.length - n; i++) out.add(w.slice(i, i + n).join(" "));
  return out;
}

/** Jaccard de trigramas de palavras: 1 = idêntico, 0 = nada em comum. */
export function similarity(a: string, b: string): number {
  const A = shingles(a), B = shingles(b);
  if (!A.size && !B.size) return 1;
  let inter = 0;
  for (const x of A) if (B.has(x)) inter++;
  return inter / (A.size + B.size - inter);
}

export const REPEAT_THRESHOLD = 0.75;

/* ------------------------------------------------------------------ diff */

export type DiffPart = { type: "same" | "added" | "removed"; text: string };

/** Diff por palavra (LCS). Suficiente para comparar versões de mensagens (até alguns milhares de palavras). */
export function wordDiff(a: string, b: string): DiffPart[] {
  const A = a.split(/(\s+)/).filter((x) => x !== ""), B = b.split(/(\s+)/).filter((x) => x !== "");
  if (A.length * B.length > 4_000_000) return [{ type: "removed", text: a }, { type: "added", text: b }];
  const m = A.length, n = B.length;
  const dp: Uint16Array[] = Array.from({ length: m + 1 }, () => new Uint16Array(n + 1));
  for (let i = m - 1; i >= 0; i--) for (let j = n - 1; j >= 0; j--) dp[i][j] = A[i] === B[j] ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1]);
  const out: DiffPart[] = [];
  const push = (type: DiffPart["type"], text: string) => { const last = out[out.length - 1]; if (last && last.type === type) last.text += text; else out.push({ type, text }); };
  let i = 0, j = 0;
  while (i < m && j < n) {
    if (A[i] === B[j]) { push("same", A[i]); i++; j++; }
    else if (dp[i + 1][j] >= dp[i][j + 1]) { push("removed", A[i]); i++; }
    else { push("added", B[j]); j++; }
  }
  while (i < m) push("removed", A[i++]);
  while (j < n) push("added", B[j++]);
  return out;
}

/* ------------------------------------------------------------------ guarda de preços e condições */

const MONEY_RE = /(R\$\s?\d[\d.,]*|US\$\s?\d[\d.,]*|\d[\d.,]*\s?(reais|d[oó]lares)|\d+(?:[.,]\d+)?\s?%|\d+\s?(dias|meses|anos|usu[aá]rios|licen[cç]as|parcelas|x\b))/gi;

/**
 * Valores (preços, percentuais, prazos, quantidades comerciais) presentes no texto gerado que NÃO aparecem nas
 * fontes autorizadas (base de conhecimento, conversa, CRM). A IA não pode inventar condições comerciais.
 */
export function unsupportedFigures(text: string, corpus: string): string[] {
  const c = norm(corpus).replace(/\s/g, "");
  const found = new Set<string>();
  for (const m of text.matchAll(MONEY_RE)) {
    const digits = m[0].replace(/[^\d]/g, "");
    if (!digits) continue;
    if (!c.includes(norm(m[0]).replace(/\s/g, "")) && !c.includes(digits)) found.add(m[0].trim());
  }
  return [...found];
}

export function figuresWarning(figs: string[]) {
  return figs.length ? `Valores sem fonte confirmada: ${figs.join(", ")}. Confira antes de enviar — a IA não pode inventar preços, prazos ou condições.` : null;
}

/* ------------------------------------------------------------------ operações */

export const OPERATIONS = [
  "initial", "regenerate", "instruct", "custom", "persuasive", "tone_formal", "tone_informal", "tone_empathetic",
  "shorten", "expand", "fix", "adapt", "negotiate", "spellcheck", "improve_selection",
] as const;
export type Operation = (typeof OPERATIONS)[number];
export type HumanOperation = "manual_edit" | "restore" | "manual_takeover";

export const OPERATION_LABEL: Record<Operation | HumanOperation, string> = {
  initial: "Sugestão inicial", regenerate: "Nova sugestão (outra abordagem)", instruct: "Pedido com instruções", custom: "Resposta personalizada",
  persuasive: "Mais persuasiva", tone_formal: "Tom mais formal", tone_informal: "Tom mais próximo", tone_empathetic: "Mais empatia",
  shorten: "Resumida", expand: "Expandida", fix: "Informações corrigidas pelas fontes", adapt: "Adaptada ao perfil do cliente",
  negotiate: "Sugestão de negociação", spellcheck: "Revisão ortográfica", improve_selection: "Trecho melhorado",
  manual_edit: "Edição manual", restore: "Versão recuperada", manual_takeover: "Resposta escrita manualmente",
};

/** O que pedir ao modelo para cada operação. */
export const OPERATION_TASK: Record<Operation, string> = {
  initial: "Escreva a melhor resposta para a última mensagem, usando só as informações autorizadas.",
  regenerate: "Escreva uma resposta com ABORDAGEM REALMENTE DIFERENTE da versão base e das descartadas: mude a estrutura, o argumento central e o próximo passo — não apenas sinônimos.",
  instruct: "Reescreva a versão base seguindo a instrução do funcionário.",
  custom: "Escreva uma resposta nova seguindo exatamente a instrução do funcionário.",
  persuasive: "Reescreva a versão base de forma mais persuasiva (benefício claro e chamada para ação), sem exagero e sem inventar fatos.",
  tone_formal: "Reescreva a versão base com linguagem mais formal e profissional.",
  tone_informal: "Reescreva a versão base com linguagem mais próxima e natural, mantendo o respeito.",
  tone_empathetic: "Reescreva a versão base demonstrando mais empatia com a situação do cliente.",
  shorten: "Resuma a versão base mantendo só o essencial.",
  expand: "Expanda a versão base com mais detalhes úteis vindos das fontes autorizadas.",
  fix: "Corrija a versão base para que todas as informações correspondam às fontes autorizadas; remova o que não tiver fonte.",
  adapt: "Adapte a versão base ao perfil do cliente (empresa, cargo, segmento, histórico) usando só dados disponíveis.",
  negotiate: "Escreva uma resposta que conduza a negociação: entenda volume/necessidade e proponha próximos passos, sem prometer descontos ou condições não autorizadas.",
  spellcheck: "Corrija ortografia, gramática e pontuação da versão base sem mudar o sentido nem o tom.",
  improve_selection: "Reescreva SOMENTE o trecho indicado, melhorando clareza e qualidade. Responda apenas com o novo trecho.",
};

/* ------------------------------------------------------------------ gerador determinístico (sem IA real) */

export type LocalContext = {
  module: string;
  customerName?: string | null;
  lastMessage?: string | null;
  knowledge?: string | null; // primeiro trecho relevante da base de conhecimento
  company?: string | null;
  segment?: string | null;
  role?: string | null;
  needs?: string | null;
  channel?: string | null;
};

export const APPROACHES = ["consultiva", "objetiva", "empatica", "proximo_passo", "beneficio", "qualificacao"] as const;
export type Approach = (typeof APPROACHES)[number];
export const APPROACH_LABEL: Record<Approach, string> = {
  consultiva: "consultiva", objetiva: "objetiva", empatica: "empática", proximo_passo: "próximo passo", beneficio: "benefício", qualificacao: "pergunta de qualificação",
};

const first = (name?: string | null) => (name ?? "").trim().split(/\s+/)[0] || "";
const sentence = (s: string) => { const t = s.trim(); return t ? (/[.!?]$/.test(t) ? t : `${t}.`) : t; };
const firstSentences = (s: string, n: number) => (s.match(/[^.!?]+[.!?]+/g) ?? [s]).slice(0, n).join(" ").trim();

function kbLine(c: LocalContext) {
  if (!c.knowledge) return "";
  // Perguntas de FAQ ("Vocês oferecem…?") são o título do trecho, não a resposta: ficam de fora.
  const answers = (c.knowledge.replace(/\s+/g, " ").match(/[^.!?]+[.!?]+/g) ?? [c.knowledge]).map((s) => s.trim()).filter((s) => !s.endsWith("?"));
  return answers.length ? sentence(firstSentences(answers.join(" "), 2)) : "";
}

/** Uma mensagem por abordagem. Nunca inventa preço, prazo ou disponibilidade: sem fonte, diz que a equipe confirma. */
export function approachText(a: Approach, c: LocalContext): string {
  const nome = first(c.customerName);
  const oi = nome ? `Olá, ${nome}!` : "Olá!";
  const kb = kbLine(c);
  const semFonte = "Vou confirmar essa informação com a equipe e te retorno em seguida.";
  if (c.module === "prospect") {
    const emp = c.company ?? "sua empresa", seg = c.segment ? ` no segmento de ${c.segment}` : "";
    const need = c.needs ? ` Muitas empresas${seg} buscam ${c.needs}.` : "";
    switch (a) {
      case "consultiva": return `${oi} Acompanho o trabalho da ${emp}${seg} e queria entender como vocês organizam hoje a prospecção e o atendimento comercial.${need} Faz sentido trocarmos ideias em uma conversa rápida?`;
      case "objetiva": return `${oi} Ajudamos equipes comerciais a priorizar leads e responder mais rápido com IA, sempre com aprovação humana. Posso te mostrar em 15 minutos como isso funcionaria na ${emp}?`;
      case "empatica": return `${oi} Sei que a rotina comercial${seg} é corrida e cheia de ferramentas soltas. Se fizer sentido para a ${emp}, posso te mostrar uma forma de centralizar leads, conversas e análises.`;
      case "proximo_passo": return `${oi} Gostaria de apresentar o ORBITY-NEPTUNE para a ${emp}. Me diga dois horários que funcionam para você nesta semana e eu confirmo a agenda.`;
      case "beneficio": return `${oi} O principal ganho para equipes como a da ${emp} é enxergar quais oportunidades merecem atenção agora, com os motivos de cada recomendação.${need} Vale uma conversa?`;
      case "qualificacao": return `${oi} Para eu entender se podemos ajudar a ${emp}: hoje vocês usam algum CRM? E qual é o maior gargalo — gerar leads, responder rápido ou fechar negócios?`;
    }
  }
  switch (a) {
    case "consultiva": return [oi, "Obrigado pela mensagem.", kb || semFonte, "Para te orientar melhor, pode me contar um pouco do seu cenário?"].filter(Boolean).join(" ");
    case "objetiva": return [nome ? `${nome},` : "", kb || semFonte, "Fico à disposição."].filter(Boolean).join(" ").replace(/^,\s*/, "");
    case "empatica": return [oi, "Entendo sua dúvida e quero te ajudar com isso.", kb || semFonte, "Se ficar qualquer ponto em aberto, me avise."].filter(Boolean).join(" ");
    case "proximo_passo": return [oi, kb || semFonte, "Se preferir, podemos conversar rapidamente: me diga um horário que funciona para você e eu confirmo com a equipe."].filter(Boolean).join(" ");
    case "beneficio": return [oi, kb ? `Resumindo o que mais importa: ${kb.charAt(0).toLowerCase()}${kb.slice(1)}` : semFonte, "Assim você consegue decidir com segurança. Quer que eu detalhe algum ponto?"].join(" ");
    case "qualificacao": return [oi, kb || "", "Para te responder com precisão, posso fazer duas perguntas rápidas? 1) Quantas pessoas usariam a solução? 2) Qual é o principal objetivo que vocês querem alcançar?"].filter(Boolean).join(" ");
  }
}

// Limites de palavra com letras acentuadas: \b do JS não reconhece "ê", então usamos \p{L} com a flag u.
const FORMAL: [RegExp, string][] = [
  [/^Ol[áa],?\s*([^!,.]+)!/iu, "Prezado(a) $1,"], [/^Ol[áa][!,]?\s*/iu, "Prezado(a), "], [/^Oi[!,]?\s*/iu, "Prezado(a), "],
  [/(?<!\p{L})vocês(?!\p{L})/giu, "os senhores"], [/(?<!\p{L})você(?!\p{L})/giu, "o(a) senhor(a)"],
  [/(?<!\p{L})te(?!\p{L})/giu, "lhe"], [/Fico à disposição\.?/iu, "Permaneço à disposição."],
];
const SPELL: [RegExp, string][] = [[/\bvc\b/gi, "você"], [/\bvcs\b/gi, "vocês"], [/\bpq\b/gi, "porque"], [/\btbm\b/gi, "também"], [/\bq\b/gi, "que"], [/\bmto\b/gi, "muito"], [/\bobg\b/gi, "obrigado"], [/\bblz\b/gi, "beleza"], [/\bnao\b/gi, "não"], [/\bentao\b/gi, "então"], [/\bvoce\b/gi, "você"]];

export function spellcheckText(s: string): string {
  let t = s;
  for (const [re, rep] of SPELL) t = t.replace(re, rep);
  t = t.replace(/[ \t]{2,}/g, " ").replace(/\s+([,.!?;:])/g, "$1").replace(/([,.!?;:])(?=[^\s\d])/g, "$1 ");
  t = t.replace(/(^|[.!?]\s+)([a-zà-ú])/g, (_m, p, ch) => p + ch.toUpperCase());
  return t.trim();
}

function removePriceSentences(s: string) {
  const parts = s.match(/[^.!?]+[.!?]*/g) ?? [s];
  const kept = parts.filter((p) => !/(R\$|pre[cç]o|valor|custa|investimento|\d+\s?%)/i.test(p));
  return (kept.join(" ").trim() || "Vou confirmar essa informação com a equipe e te retorno em seguida.").replace(/\s{2,}/g, " ");
}

/** Transformações determinísticas por operação sobre a versão base. */
export function transformText(op: Operation, base: string, c: LocalContext, instruction?: string | null): string {
  const kb = kbLine(c);
  switch (op) {
    case "shorten": return firstSentences(base, 2) || base;
    case "expand": return [base.trim(), kb && !base.includes(kb) ? `Mais um detalhe importante: ${kb}` : "", "Se quiser, posso te enviar mais informações ou marcar uma conversa com a equipe."].filter(Boolean).join(" ");
    case "tone_formal": { let t = base; for (const [re, rep] of FORMAL) t = t.replace(re, rep); return /Atenciosamente/.test(t) ? t : `${t.trim()}\n\nAtenciosamente,\nEquipe`; }
    case "tone_informal": return base.replace(/^Prezado\(a\)\s+([^,\n]+),/i, "Oi, $1!").replace(/^Prezado\(a\),?\s*/i, "Oi! ").replace(/os senhores/gi, "vocês").replace(/o\(a\) senhor\(a\)/gi, "você").replace(/\n*Atenciosamente,\s*\n?Equipe\s*$/i, "").trim();
    case "tone_empathetic": return /entendo/i.test(base) ? base : base.replace(/^(Ol[áa][^!.]*[!.]|Oi[^!.]*[!.])?\s*/i, (m) => `${m.trim()} Entendo perfeitamente a sua situação e quero te ajudar. `).trim();
    case "persuasive": return [base.trim(), "Assim você ganha tempo e decide com mais segurança.", "Posso te ajudar a dar o próximo passo ainda hoje?"].join(" ");
    case "fix": return [first(c.customerName) ? `Olá, ${first(c.customerName)}!` : "Olá!", kb || "Vou confirmar essa informação com a equipe e te retorno em seguida."].join(" ");
    case "adapt": {
      const who = [c.role, c.company].filter(Boolean).join(" da ");
      return who ? `${base.trim()} Pensando no contexto ${c.company ? `da ${c.company}` : "da sua empresa"}${c.segment ? ` (${c.segment})` : ""}, posso adaptar a proposta às necessidades da equipe.` : `${base.trim()} Se me contar um pouco mais sobre a sua empresa, adapto a proposta ao seu cenário.`;
    }
    case "negotiate": return [first(c.customerName) ? `${first(c.customerName)},` : "", "quero encontrar a melhor condição para o seu caso.", "Me conta quantas pessoas usariam e qual prazo você tem em mente?", "Com isso eu levo o seu cenário para a equipe comercial avaliar as condições possíveis."].filter(Boolean).join(" ");
    case "spellcheck": return spellcheckText(base);
    case "instruct": case "custom": return applyInstruction(base, c, instruction ?? "");
    default: return base;
  }
}

/** Interpreta instruções livres comuns de forma determinística; o que não for reconhecido gera outra abordagem. */
export function applyInstruction(base: string, c: LocalContext, instruction: string): string {
  const i = instruction.toLowerCase();
  let t = base;
  let applied = false;
  if (/(n[aã]o|sem)\s+(mencion|fal|cit)\w*\s+(o\s+|os\s+)?pre[cç]o|sem\s+pre[cç]o/.test(i)) { t = removePriceSentences(t); applied = true; }
  if (/formal/.test(i)) { t = transformText("tone_formal", t, c); applied = true; }
  if (/(informal|pr[oó]xim|descontra)/.test(i)) { t = transformText("tone_informal", t, c); applied = true; }
  if (/(objetiv|curt|resum|direto)/.test(i)) { t = transformText("shorten", t, c); applied = true; }
  if (/(empat|acolhe)/.test(i)) { t = transformText("tone_empathetic", t, c); applied = true; }
  if (/(persuas|convinc|atrativ)/.test(i)) { t = transformText("persuasive", t, c); applied = true; }
  if (/(obje[cç])/.test(i)) { t = `${t.trim()} Entendo a sua preocupação — ela é comum. Posso te mostrar como outros cenários parecidos foram resolvidos e, se fizer sentido, ajustamos a proposta ao seu caso.`; applied = true; }
  if (/(detalh|expand|mais informa)/.test(i)) { t = transformText("expand", t, c); applied = true; }
  if (!applied) {
    const next = nextApproach([detectApproach(base)].filter(Boolean) as Approach[]);
    t = approachText(next, c);
  }
  return t;
}

export function detectApproach(text: string): Approach | null {
  const t = text.toLowerCase();
  if (/duas perguntas|hoje voc[eê]s usam algum crm/.test(t)) return "qualificacao";
  if (/hor[aá]rio|agenda/.test(t)) return "proximo_passo";
  if (/resumindo o que mais importa|principal ganho/.test(t)) return "beneficio";
  if (/entendo sua d[uú]vida|sei que a rotina/.test(t)) return "empatica";
  if (/fico [àa] disposi|em 15 minutos/.test(t)) return "objetiva";
  if (/cen[aá]rio\?|trocarmos ideias/.test(t)) return "consultiva";
  return null;
}

export function nextApproach(avoid: Approach[], seed = 0): Approach {
  const free = APPROACHES.filter((a) => !avoid.includes(a));
  const pool = free.length ? free : [...APPROACHES];
  return pool[seed % pool.length];
}
