/**
 * Orquestrador de IA: aplica guardrails, limites de custo, versionamento de prompt, fallback de provedores,
 * cobrança de créditos, auditoria e histórico de execuções.
 */
import { and, eq } from "drizzle-orm";
import { aiAgents, aiExecutions, aiPromptVersions } from "../db/schema";
import { asUntrustedData, checkInput, checkOutput } from "./guardrails";
import { AIRefusalError, creditsFor, providerChain, type ChatMessage, type CompletionResult } from "./providers";
import { agentCreditsToday, consumeCredits, getWallet, PaymentRequiredError } from "../domains/billing";
import { audit } from "../audit";
import { agentBlockReason, checkAiBudgets } from "./control-plane";
import { effectiveLevel } from "./agents/catalog";
import type { TenantContext } from "../tenancy/context";

export type RunAgentInput = {
  agentKey: string;
  input: string;
  history?: ChatMessage[];
  context?: string; // dados recuperados (RAG / métricas) — tratados como não confiáveis
  promptVersion?: number; // para avaliação/comparação
  model?: string;
  preferredProvider?: string;
  chargeCredits?: boolean;
  /** Identidade apresentada ao usuário (ex.: Flávio). Acrescida ao prompt do agente; não substitui as regras dele. */
  persona?: string;
};

export type RunAgentOutput = {
  executionId: string; text: string; status: "success" | "blocked" | "fallback" | "error";
  simulated: boolean; provider: string; model: string; credits: number; latencyMs: number; warnings: string[];
};

export class AgentDisabledError extends Error { status = 409; }

type AgentRow = typeof aiAgents.$inferSelect;
type PromptRow = typeof aiPromptVersions.$inferSelect;

/**
 * Governança compartilhada (runAgent e o laço de ferramentas do Flávio): agente existe e está ativo, versão de prompt,
 * e bloqueios do AI Control Plane (kill switches, status, nível 1 "Observar"). Não cobra nem chama provedor.
 */
export async function loadAgentForRun(ctx: TenantContext, agentKey: string, promptVersion?: number): Promise<{ agent: AgentRow; prompt: PromptRow; version: number; blockedBy: string | null }> {
  const db = ctx.db;
  const [agent] = await db.select().from(aiAgents).where(and(eq(aiAgents.organizationId, ctx.organizationId), eq(aiAgents.key, agentKey)));
  if (!agent) throw Object.assign(new Error(`Agente "${agentKey}" não encontrado.`), { status: 404 });
  if (!agent.enabled) throw new AgentDisabledError(`O agente ${agent.name} está desativado.`);
  const version = promptVersion ?? agent.activeVersion;
  const [prompt] = await db.select().from(aiPromptVersions).where(and(eq(aiPromptVersions.agentId, agent.id), eq(aiPromptVersions.version, version)));
  if (!prompt) throw Object.assign(new Error("Versão de prompt não encontrada."), { status: 404 });
  // AI Control Plane: estado do agente, kill switches (toda a IA, agente, domínio) e nível "Observar".
  const blockedBy = await agentBlockReason(db, ctx.organizationId, agent)
    ?? (effectiveLevel(agent) <= 1 ? "Agente no nível 1 (Observar): só monitora, não gera respostas." : null);
  return { agent, prompt, version, blockedBy };
}

/** Limites financeiros antes de chamar um provedor: limite diário do agente (lança 402) e orçamentos mensais. */
export async function checkAgentSpend(ctx: TenantContext, agent: AgentRow, model?: string) {
  const usedToday = await agentCreditsToday(ctx.db, ctx.organizationId, agent.key);
  if (usedToday >= agent.limits.maxCreditsPerDay) throw new PaymentRequiredError(`Limite diário de créditos do agente ${agent.name} atingido (${agent.limits.maxCreditsPerDay}).`);
  return checkAiBudgets(ctx.db, ctx.organizationId, agent, model ?? agent.model);
}

/** Registra a execução (histórico + auditoria) e devolve o id. */
export async function logAgentExecution(ctx: TenantContext, agent: Pick<AgentRow, "key">, version: number, r: {
  input: string; output: string; status: string; provider?: string; model?: string; simulated?: boolean; inputTokens?: number; outputTokens?: number; credits: number; startedAt: number;
}) {
  const [row] = await ctx.db.insert(aiExecutions).values({
    organizationId: ctx.organizationId, agentKey: agent.key, provider: r.provider ?? "none", model: r.model ?? "none", promptVersion: version,
    input: r.input.slice(0, 4000), output: r.output.slice(0, 8000), status: r.status, simulated: r.simulated ?? false,
    inputTokens: r.inputTokens ?? 0, outputTokens: r.outputTokens ?? 0, credits: r.credits, latencyMs: Date.now() - r.startedAt, userId: ctx.userId,
  }).returning({ id: aiExecutions.id });
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: `ai:${agent.key}`, action: `ai.execution.${r.status}`, resource: "ai_execution", resourceId: row.id, metadata: { by: ctx.userId, provider: r.provider, credits: r.credits } });
  return row.id;
}

export async function runAgent(ctx: TenantContext, req: RunAgentInput): Promise<RunAgentOutput> {
  const db = ctx.db;
  const { agent, prompt, version, blockedBy } = await loadAgentForRun(ctx, req.agentKey, req.promptVersion);

  const started = Date.now();
  const guard = checkInput(req.input);
  const log = (r: Partial<CompletionResult> & { status: string; output: string; credits: number }) =>
    logAgentExecution(ctx, agent, version, { ...r, input: guard.sanitized, startedAt: started });

  if (blockedBy) {
    const text = `Este agente está interrompido e não pode responder agora. ${blockedBy}`;
    const id = await log({ status: "blocked", output: text, credits: 0 });
    return { executionId: id, text, status: "blocked", simulated: false, provider: "none", model: "none", credits: 0, latencyMs: Date.now() - started, warnings: [blockedBy] };
  }

  if (guard.blocked) {
    const text = "Sua solicitação contém instruções que não posso seguir por motivos de segurança. Reformule a pergunta ou fale com um administrador.";
    const id = await log({ status: "blocked", output: text, credits: 0 });
    return { executionId: id, text, status: "blocked", simulated: false, provider: "none", model: "none", credits: 0, latencyMs: Date.now() - started, warnings: guard.reasons };
  }

  // Limites financeiros: por agente/dia e orçamentos mensais (organização, agente, modelo), antes de qualquer provedor.
  const budget = await checkAgentSpend(ctx, agent, req.model ?? agent.model);

  const system = `${prompt.systemPrompt}${req.persona ? `\n\n${req.persona}` : ""}\n\nOrganização: ${ctx.organizationId}. Nunca utilize ou mencione dados de outras organizações.`;
  const contextBlock = req.context ? asUntrustedData("contexto_autorizado", req.context) : "";
  const messages: ChatMessage[] = [...(req.history ?? []).slice(-10), { role: "user", content: `${contextBlock}\n\n${guard.sanitized}`.trim() }];

  const wallet = await getWallet(db, ctx.organizationId);
  const chain = providerChain(req.preferredProvider).filter((p) => p.name === "local-heuristic" || (wallet?.balance ?? 0) > 0 || req.chargeCredits === false);
  const warnings: string[] = [...budget.warnings];
  let result: CompletionResult | null = null;
  let usedFallback = false;
  for (const p of chain) {
    try {
      result = await p.complete({ system, messages, maxTokens: agent.limits.maxTokensPerRun, model: req.model ?? agent.model, context: req.context });
      break;
    } catch (err) {
      if (err instanceof AIRefusalError) {
        const id = await log({ status: "blocked", output: err.message, credits: 0, provider: p.name });
        return { executionId: id, text: "Não posso ajudar com esse pedido. Se precisar, fale com um humano da equipe.", status: "blocked", simulated: false, provider: p.name, model: "none", credits: 0, latencyMs: Date.now() - started, warnings: [err.message] };
      }
      usedFallback = true;
      warnings.push(`Provedor ${p.name} falhou: ${(err as Error).message.slice(0, 120)}`);
    }
  }
  if (!result) {
    const id = await log({ status: "error", output: warnings.join("\n"), credits: 0 });
    return { executionId: id, text: "Não foi possível obter resposta da IA agora. Tente novamente ou fale com um humano.", status: "error", simulated: false, provider: "none", model: "none", credits: 0, latencyMs: Date.now() - started, warnings };
  }

  const out = checkOutput(result.text);
  if (!out.ok) warnings.push(...out.issues);
  const credits = req.chargeCredits === false ? 0 : creditsFor(result);
  if (credits > 0) await consumeCredits(db, ctx.organizationId, credits, "ai_execution", { agentKey: agent.key });
  if (result.simulated) warnings.push(usedFallback ? "Resposta em MODO SIMULADO (o provedor de IA real falhou)." : "Resposta em MODO SIMULADO (nenhum provedor de IA configurado).");
  const status = usedFallback ? "fallback" : "success";
  const id = await log({ ...result, status, output: out.text, credits });
  return { executionId: id, text: out.text, status, simulated: result.simulated, provider: result.provider, model: result.model, credits, latencyMs: Date.now() - started, warnings };
}
