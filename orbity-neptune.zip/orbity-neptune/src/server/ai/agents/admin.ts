/** Centro de Controle de IA — administração de agentes, versões, execuções e casos de avaliação. */
import { and, desc, eq } from "drizzle-orm";
import { z } from "zod";
import { aiAgents, aiEvalCases, aiEvalRuns, aiExecutions, aiPromptVersions } from "../../db/schema";
import { requirePerm, type TenantContext } from "../../tenancy/context";
import { audit } from "../../audit";
import { HttpError } from "../../http";
import { PROVIDERS } from "../providers";
import { effectiveLevel, levelFromLegacy } from "./catalog";

export function providerStatus() {
  return PROVIDERS.map((p) => ({ name: p.name, available: p.available(), simulated: p.name === "local-heuristic" }));
}

export async function listAgents(ctx: TenantContext) {
  requirePerm(ctx, "ai:use");
  return ctx.db.select().from(aiAgents).where(eq(aiAgents.organizationId, ctx.organizationId)).orderBy(aiAgents.name);
}

export async function getAgent(ctx: TenantContext, key: string) {
  requirePerm(ctx, "ai:use");
  const [agent] = await ctx.db.select().from(aiAgents).where(and(eq(aiAgents.organizationId, ctx.organizationId), eq(aiAgents.key, key)));
  if (!agent) throw new HttpError(404, "Agente não encontrado.");
  const versions = await ctx.db.select().from(aiPromptVersions).where(eq(aiPromptVersions.agentId, agent.id)).orderBy(desc(aiPromptVersions.version));
  const executions = await ctx.db.select().from(aiExecutions)
    .where(and(eq(aiExecutions.organizationId, ctx.organizationId), eq(aiExecutions.agentKey, key))).orderBy(desc(aiExecutions.createdAt)).limit(30);
  const cases = await ctx.db.select().from(aiEvalCases).where(and(eq(aiEvalCases.organizationId, ctx.organizationId), eq(aiEvalCases.agentKey, key))).orderBy(desc(aiEvalCases.createdAt));
  const runs = await ctx.db.select().from(aiEvalRuns).where(and(eq(aiEvalRuns.organizationId, ctx.organizationId), eq(aiEvalRuns.agentKey, key))).orderBy(desc(aiEvalRuns.createdAt)).limit(20);
  return { agent, versions, executions, cases, runs };
}

export const agentUpdateInput = z.object({
  enabled: z.boolean().optional(),
  autonomy: z.enum(["suggest", "approve", "autonomous"]).optional(),
  model: z.string().trim().min(1).max(80).optional(),
  maxTokensPerRun: z.coerce.number().int().min(100).max(64000).optional(),
  maxCreditsPerDay: z.coerce.number().int().min(0).max(1_000_000).optional(),
});

export async function updateAgent(ctx: TenantContext, key: string, raw: unknown) {
  requirePerm(ctx, "ai:manage");
  const input = agentUpdateInput.parse(raw);
  const [agent] = await ctx.db.select().from(aiAgents).where(and(eq(aiAgents.organizationId, ctx.organizationId), eq(aiAgents.key, key)));
  if (!agent) throw new HttpError(404, "Agente não encontrado.");
  const limits = {
    maxTokensPerRun: input.maxTokensPerRun ?? agent.limits.maxTokensPerRun,
    maxCreditsPerDay: input.maxCreditsPerDay ?? agent.limits.maxCreditsPerDay,
  };
  // Autonomia é governança (AI Control Plane): exige ai:govern e mantém nível e coluna legada sincronizados.
  if (input.autonomy && input.autonomy !== agent.autonomy) requirePerm(ctx, "ai:govern");
  const autonomy = input.autonomy ?? agent.autonomy;
  const [u] = await ctx.db.update(aiAgents).set({
    enabled: input.enabled ?? agent.enabled, autonomy, autonomyLevel: input.autonomy ? levelFromLegacy(autonomy) : effectiveLevel(agent),
    model: input.model ?? agent.model, limits,
  }).where(eq(aiAgents.id, agent.id)).returning();
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "ai.agent_updated", resource: "ai_agent", resourceId: agent.id, metadata: input });
  return u;
}

export async function setExecutionFeedback(ctx: TenantContext, executionId: string, value: -1 | 1) {
  requirePerm(ctx, "ai:use");
  const [e] = await ctx.db.update(aiExecutions).set({ feedback: value })
    .where(and(eq(aiExecutions.id, executionId), eq(aiExecutions.organizationId, ctx.organizationId))).returning({ id: aiExecutions.id });
  if (!e) throw new HttpError(404, "Execução não encontrada.");
  return { ok: true };
}

export const evalCaseInput = z.object({
  agentKey: z.string().min(2).max(40),
  name: z.string().trim().min(2).max(120),
  input: z.string().trim().min(2).max(4000),
  mustInclude: z.array(z.string().trim().min(1).max(200)).max(20).default([]),
  mustNotInclude: z.array(z.string().trim().min(1).max(200)).max(20).default([]),
  adversarial: z.boolean().default(false),
  locale: z.string().max(10).default("pt-BR"),
});

export async function addEvalCase(ctx: TenantContext, raw: unknown) {
  requirePerm(ctx, "ai:manage");
  const input = evalCaseInput.parse(raw);
  const [agent] = await ctx.db.select({ id: aiAgents.id }).from(aiAgents).where(and(eq(aiAgents.organizationId, ctx.organizationId), eq(aiAgents.key, input.agentKey)));
  if (!agent) throw new HttpError(404, "Agente não encontrado.");
  const [c] = await ctx.db.insert(aiEvalCases).values({ organizationId: ctx.organizationId, ...input }).returning();
  return c;
}

export async function deleteEvalCase(ctx: TenantContext, id: string) {
  requirePerm(ctx, "ai:manage");
  await ctx.db.delete(aiEvalCases).where(and(eq(aiEvalCases.id, id), eq(aiEvalCases.organizationId, ctx.organizationId)));
  return { ok: true };
}
