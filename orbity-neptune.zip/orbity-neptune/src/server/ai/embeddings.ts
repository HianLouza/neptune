/**
 * Embeddings para busca semântica (pgvector, 256 dimensões).
 * Implementação local: "hashing trick" sobre tokens e bigramas normalizados — determinística, sem custo.
 * Pode ser substituída por um provedor de embeddings mantendo a mesma interface (portabilidade).
 */
export const EMBEDDING_DIM = 256;

function normalize(t: string) {
  return t.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
}
function hash(s: string) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
  return h >>> 0;
}
const STOP = new Set("a o e de da do das dos em um uma para por com que os as no na nos nas se ao the and of to is".split(" "));

export function embed(text: string): number[] {
  const v = new Array(EMBEDDING_DIM).fill(0);
  const tokens = normalize(text).split(/[^a-z0-9]+/).filter((t) => t.length > 1 && !STOP.has(t));
  const feats = [...tokens, ...tokens.slice(1).map((t, i) => `${tokens[i]}_${t}`)];
  for (const f of feats) {
    const h = hash(f);
    v[h % EMBEDDING_DIM] += (h & 1 ? 1 : -1) * (f.includes("_") ? 0.5 : 1);
  }
  const norm = Math.sqrt(v.reduce((a, x) => a + x * x, 0)) || 1;
  return v.map((x) => x / norm);
}

export function chunkText(text: string, size = 600, overlap = 100): string[] {
  const clean = text.replace(/\s+/g, " ").trim();
  if (!clean) return [];
  const chunks: string[] = [];
  for (let i = 0; i < clean.length; i += size - overlap) {
    chunks.push(clean.slice(i, i + size));
    if (i + size >= clean.length) break;
  }
  return chunks;
}
