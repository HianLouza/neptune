/**
 * ORBITY AI CONTROL PLANE (Master Prompt 4.0 §9 e §16)
 *
 * Governança central dos agentes digitais: níveis de autonomia, política de ações, kill switches,
 * orçamentos de IA, monitoramento, inventário da força de trabalho digital e prevenção de conflitos.
 *
 * Regras invioláveis:
 *  - Ações sensíveis SEMPRE exigem aprovação humana, em qualquer nível de autonomia.
 *  - Nenhum agente amplia as próprias permissões: governança só por humanos com `ai:govern`,
 *    e um agente nunca recebe permissão que o usuário que governa não tem.
 *  - Toda alteração é auditada com antes/depois.
 *  - Kill switches globais (organizationId nulo) só podem ser criados/liberados por administradores da plataforma.
 */
import { and, desc, eq, gte, inArray, isNull, or, sql } from "drizzle-orm";
import { z } from "zod";
import type { DB } from "../../db/client";
import { aiAgents, aiBudgets, aiExecutions, approvalRequests, auditLogs, killSwitches, memberships, notifications, users, workflowRuns } from "../../db/schema";
import { requirePerm, can, type TenantContext } from "../../tenancy/context";
import { PERMISSIONS } from "../../permissions";
import { audit } from "../../audit";
import { HttpError } from "../../http";
import { AGENT_DOMAINS, effectiveLevel, legacyFromLevel } from "../agents/catalog";
import { providerStatus } from "../agents/admin";

/* ------------------------------------------------------------------ níveis e política */

export const AUTONOMY_LEVELS = [
  { level: 1, key: "observe", label: "Observar", description: "Só monitora e registra. Não gera respostas nem prepara ações." },
  { level: 2, key: "analyze", label: "Analisar", description: "Analisa e recomenda. Não prepara nem executa ações." },
  { level: 3, key: "prepare", label: "Preparar", description: "Prepara rascunhos de ações para uma pessoa revisar. Não executa." },
  { level: 4, key: "approve_execute", label: "Executar após aprovação", description: "Executa somente depois da aprovação de uma pessoa autorizada." },
  { level: 5, key: "controlled_autonomous", label: "Autonomia controlada", description: "Executa sozinho apenas ações NÃO sensíveis, dentro dos limites e políticas. Ações sensíveis continuam exigindo aprovação." },
] as const;

/** Catálogo de ações sensíveis: sempre exigem aprovação humana, em qualquer nível. */
export const SENSITIVE_AGENT_ACTIONS: Record<string, string> = {
  send_message: "Enviar mensagem a cliente ou contato",
  webhook: "Chamar webhook externo",
  external_api: "Chamar API externa",
  financial_operation: "Operação financeira (cobrança, pagamento, estorno)",
  charge: "Cobrança",
  delete_record: "Excluir registros",
  change_permissions: "Alterar permissões ou cargos",
  publish_workflow: "Publicar automação",
  export_data: "Exportar dados",
};
export const isSensitiveAction = (actionKey: string) => actionKey in SENSITIVE_AGENT_ACTIONS;

export type PolicyDecision = "deny" | "needs_approval" | "allow";
export type ActionMode = "execute" | "draft";

/**
 * Política pura (testável): decide o que um agente pode fazer com uma ação.
 *  - draft: preparar algo para revisão humana (exige nível ≥ 3; ações sensíveis também podem ser preparadas).
 *  - execute: nível 1-3 nega; 4 exige aprovação; 5 permite só ações não sensíveis. Sensível → sempre aprovação.
 */
export function policyDecision(level: number, actionKey: string, mode: ActionMode = "execute"): { decision: PolicyDecision; reason: string } {
  if (mode === "draft") {
    if (level >= 3) return { decision: "allow", reason: "Rascunho permitido: será revisado por uma pessoa." };
    return { decision: "deny", reason: `Nível ${level} (${AUTONOMY_LEVELS[level - 1]?.label ?? "?"}) não prepara ações.` };
  }
  if (level <= 3) return { decision: "deny", reason: `Nível ${level} (${AUTONOMY_LEVELS[level - 1]?.label ?? "?"}) não executa ações.` };
  if (isSensitiveAction(actionKey)) return { decision: "needs_approval", reason: `"${SENSITIVE_AGENT_ACTIONS[actionKey]}" é ação sensível: exige aprovação humana em qualquer nível.` };
  if (level === 4) return { decision: "needs_approval", reason: "Nível 4: executa somente após aprovação." };
  return { decision: "allow", reason: "Nível 5: ação não sensível dentro da autonomia controlada." };
}

type AgentLike = { key: string; domain: string; status: string; enabled: boolean; autonomyLevel: number; autonomy: string };

/** Política completa: estado do agente + kill switches + nível de autonomia. */
export async function authorizeAgentAction(ctx: TenantContext, agent: AgentLike, actionKey: string, mode: ActionMode = "execute"): Promise<{ decision: PolicyDecision; reason: string }> {
  const block = await agentBlockReason(ctx.db, ctx.organizationId, agent);
  if (block) return { decision: "deny", reason: block };
  const sw = await findActiveSwitch(ctx.db, ctx.organizationId, [{ scope: "action_category", target: actionKey }, { scope: "tool", target: actionKey }]);
  if (sw) return { decision: "deny", reason: switchMessage(sw) };
  return policyDecision(effectiveLevel(agent), actionKey, mode);
}

/* ------------------------------------------------------------------ kill switches */

export const KILL_SWITCH_SCOPES = ["all_ai", "agent", "agent_domain", "integration", "tool", "workflow", "action_category"] as const;
export type KillSwitchScope = (typeof KILL_SWITCH_SCOPES)[number];
export const SCOPE_LABELS: Record<KillSwitchScope, string> = {
  all_ai: "Toda a IA", agent: "Agente", agent_domain: "Domínio de agentes", integration: "Integração",
  tool: "Ferramenta", workflow: "Automação", action_category: "Categoria de ação",
};

type SwitchRow = typeof killSwitches.$inferSelect;
const switchMessage = (s: SwitchRow) =>
  `Interrompido por kill switch (${SCOPE_LABELS[s.scope as KillSwitchScope] ?? s.scope}${s.target !== "*" ? `: ${s.target}` : ""})${s.organizationId ? "" : " global da plataforma"}. Motivo: ${s.reason}`;

/** Procura um kill switch ativo (da organização ou global) para qualquer um dos alvos informados. */
export async function findActiveSwitch(db: DB, organizationId: string, checks: { scope: KillSwitchScope; target: string }[]): Promise<SwitchRow | null> {
  if (!checks.length) return null;
  const [row] = await db.select().from(killSwitches).where(and(
    eq(killSwitches.active, true),
    or(eq(killSwitches.organizationId, organizationId), isNull(killSwitches.organizationId)),
    or(...checks.map((c) => and(eq(killSwitches.scope, c.scope), c.scope === "all_ai" ? sql`true` : eq(killSwitches.target, c.target)))),
  )).limit(1);
  return row ?? null;
}

/** Motivo de bloqueio de um agente (estado ou kill switch), ou null se pode operar. */
export async function agentBlockReason(db: DB, organizationId: string, agent: Pick<AgentLike, "key" | "domain" | "status" | "enabled">): Promise<string | null> {
  if (!agent.enabled) return "Agente desativado.";
  if (agent.status === "paused") return "Agente pausado no AI Control Plane.";
  if (agent.status === "suspended") return "Agente suspenso no AI Control Plane.";
  if (agent.status === "retired") return "Agente aposentado (fora de operação).";
  const sw = await findActiveSwitch(db, organizationId, [
    { scope: "all_ai", target: "*" }, { scope: "agent", target: agent.key }, { scope: "agent_domain", target: agent.domain },
  ]);
  return sw ? switchMessage(sw) : null;
}

export async function workflowBlockReason(db: DB, organizationId: string, workflowId: string | null, action: string): Promise<string | null> {
  const checks: { scope: KillSwitchScope; target: string }[] = [{ scope: "action_category", target: action }, { scope: "tool", target: action }];
  if (workflowId) checks.push({ scope: "workflow", target: workflowId });
  const sw = await findActiveSwitch(db, organizationId, checks);
  return sw ? switchMessage(sw) : null;
}

export async function integrationBlockReason(db: DB, organizationId: string, provider: string, extra: { scope: KillSwitchScope; target: string }[] = []): Promise<string | null> {
  const sw = await findActiveSwitch(db, organizationId, [{ scope: "integration", target: provider }, ...extra]);
  return sw ? switchMessage(sw) : null;
}

const killSwitchInput = z.object({
  scope: z.enum(KILL_SWITCH_SCOPES),
  target: z.string().trim().max(120).optional(),
  reason: z.string().trim().min(5, "Descreva o motivo (mínimo 5 caracteres).").max(500),
  global: z.boolean().default(false),
});

export async function activateKillSwitch(ctx: TenantContext, raw: unknown) {
  requirePerm(ctx, "ai:govern");
  const input = killSwitchInput.parse(raw);
  if (input.global && !ctx.isPlatformAdmin) throw new HttpError(403, "Somente administradores da plataforma podem acionar um kill switch global.");
  const target = input.scope === "all_ai" ? "*" : (input.target ?? "").trim();
  if (!target) throw new HttpError(400, "Informe o alvo do kill switch (agente, domínio, integração, ferramenta, automação ou ação).");
  const [row] = await ctx.db.insert(killSwitches).values({
    organizationId: input.global ? null : ctx.organizationId, scope: input.scope, target, reason: input.reason, createdBy: ctx.userId,
  }).returning();
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "ai.kill_switch_activated", resource: "kill_switch", resourceId: row.id, metadata: { scope: row.scope, target, global: input.global, reason: input.reason }, ip: ctx.ip });
  await ctx.db.insert(notifications).values({ organizationId: ctx.organizationId, title: `Kill switch acionado: ${SCOPE_LABELS[input.scope]}${target !== "*" ? ` (${target})` : ""}`, body: input.reason, href: "/ai-control" });
  return row;
}

export async function releaseKillSwitch(ctx: TenantContext, id: string) {
  requirePerm(ctx, "ai:govern");
  const [row] = await ctx.db.select().from(killSwitches).where(eq(killSwitches.id, id));
  if (!row || (row.organizationId && row.organizationId !== ctx.organizationId)) throw new HttpError(404, "Kill switch não encontrado.");
  if (!row.organizationId && !ctx.isPlatformAdmin) throw new HttpError(403, "Somente administradores da plataforma podem liberar um kill switch global.");
  if (!row.active) throw new HttpError(409, "Este kill switch já foi liberado.");
  const [u] = await ctx.db.update(killSwitches).set({ active: false, releasedBy: ctx.userId, releasedAt: new Date() }).where(eq(killSwitches.id, id)).returning();
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "ai.kill_switch_released", resource: "kill_switch", resourceId: id, metadata: { scope: row.scope, target: row.target, global: !row.organizationId }, ip: ctx.ip });
  return u;
}

export async function listKillSwitches(ctx: TenantContext) {
  requirePerm(ctx, "ai:manage");
  return ctx.db.select().from(killSwitches)
    .where(or(eq(killSwitches.organizationId, ctx.organizationId), and(isNull(killSwitches.organizationId), eq(killSwitches.active, true))))
    .orderBy(desc(killSwitches.active), desc(killSwitches.createdAt)).limit(100);
}

/* ------------------------------------------------------------------ governança */

const governanceInput = z.object({
  autonomyLevel: z.coerce.number().int().min(1).max(5).optional(),
  status: z.enum(["active", "paused", "suspended", "retired"]).optional(),
  ownerUserId: z.string().uuid().nullable().optional(),
  domain: z.string().trim().min(2).max(40).optional(),
  monthlyCreditBudget: z.coerce.number().int().min(0).max(100_000_000).nullable().optional(),
  permissions: z.array(z.string()).max(40).optional(),
  tools: z.array(z.string().trim().min(2).max(60)).max(40).optional(),
});

export async function setAgentGovernance(ctx: TenantContext, key: string, raw: unknown) {
  requirePerm(ctx, "ai:govern");
  if (ctx.userId.startsWith("ai:")) throw new HttpError(403, "Agentes não podem alterar a própria governança.");
  const input = governanceInput.parse(raw);
  const [agent] = await ctx.db.select().from(aiAgents).where(and(eq(aiAgents.organizationId, ctx.organizationId), eq(aiAgents.key, key)));
  if (!agent) throw new HttpError(404, "Agente não encontrado.");

  if (input.permissions) {
    const unknown = input.permissions.filter((p) => !(PERMISSIONS as readonly string[]).includes(p));
    if (unknown.length) throw new HttpError(400, `Permissões inexistentes: ${unknown.join(", ")}.`);
    const own = ctx.permissions.includes("*") ? PERMISSIONS as readonly string[] : ctx.permissions;
    const escalation = input.permissions.filter((p) => !own.includes(p));
    if (escalation.length) throw new HttpError(403, `Um agente não pode receber permissões que você não possui: ${escalation.join(", ")}.`);
    if (input.permissions.some((p) => p === "ai:govern" || p === "admin:users" || p === "admin:settings")) throw new HttpError(403, "Agentes não podem receber permissões de governança ou administração.");
  }
  if (input.ownerUserId) {
    const [m] = await ctx.db.select({ id: memberships.id }).from(memberships).where(and(eq(memberships.organizationId, ctx.organizationId), eq(memberships.userId, input.ownerUserId)));
    if (!m) throw new HttpError(400, "O responsável precisa ser membro da organização.");
  }

  const level = input.autonomyLevel ?? effectiveLevel(agent);
  const patch = {
    autonomyLevel: level, autonomy: legacyFromLevel(level),
    status: input.status ?? agent.status,
    ownerUserId: input.ownerUserId === undefined ? agent.ownerUserId : input.ownerUserId,
    domain: input.domain ?? agent.domain,
    monthlyCreditBudget: input.monthlyCreditBudget === undefined ? agent.monthlyCreditBudget : input.monthlyCreditBudget,
    permissions: input.permissions ?? agent.permissions,
    tools: input.tools ?? agent.tools,
  };
  const before = { autonomyLevel: effectiveLevel(agent), status: agent.status, ownerUserId: agent.ownerUserId, domain: agent.domain, monthlyCreditBudget: agent.monthlyCreditBudget, permissions: agent.permissions, tools: agent.tools };
  const [u] = await ctx.db.update(aiAgents).set(patch).where(eq(aiAgents.id, agent.id)).returning();
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "ai.agent_governance_changed", resource: "ai_agent", resourceId: agent.id, metadata: { key, before, after: { ...patch, autonomy: undefined } }, ip: ctx.ip });
  return u;
}

/** Corrige agentes provisionados apenas com a coluna legada (nível divergente) — idempotente. */
export async function normalizeAgentLevels(db: DB, organizationId: string) {
  const rows = await db.select().from(aiAgents).where(eq(aiAgents.organizationId, organizationId));
  for (const a of rows) {
    const lvl = effectiveLevel(a);
    const domain = a.domain === "commercial" && AGENT_DOMAINS[a.key] ? AGENT_DOMAINS[a.key] : a.domain;
    if (lvl !== a.autonomyLevel || domain !== a.domain) await db.update(aiAgents).set({ autonomyLevel: lvl, domain }).where(eq(aiAgents.id, a.id));
  }
}

/* ------------------------------------------------------------------ orçamentos */

const monthStart = (now = new Date()) => new Date(now.getFullYear(), now.getMonth(), 1);
const monthKey = (now = new Date()) => `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;

const budgetInput = z.object({
  scope: z.enum(["organization", "agent", "model"]),
  target: z.string().trim().max(80).optional(),
  monthlyCredits: z.coerce.number().int().min(1).max(100_000_000),
  alertPct: z.coerce.number().int().min(1).max(100).default(80),
  hardStop: z.boolean().default(true),
});

export async function upsertBudget(ctx: TenantContext, raw: unknown) {
  requirePerm(ctx, "ai:govern");
  const input = budgetInput.parse(raw);
  const target = input.scope === "organization" ? "*" : (input.target ?? "").trim();
  if (!target) throw new HttpError(400, input.scope === "agent" ? "Informe a chave do agente." : "Informe o modelo (ex.: claude-opus-5-5).");
  if (input.scope === "agent") {
    const [a] = await ctx.db.select({ id: aiAgents.id }).from(aiAgents).where(and(eq(aiAgents.organizationId, ctx.organizationId), eq(aiAgents.key, target)));
    if (!a) throw new HttpError(404, "Agente não encontrado.");
  }
  const [row] = await ctx.db.insert(aiBudgets).values({ organizationId: ctx.organizationId, scope: input.scope, target, monthlyCredits: input.monthlyCredits, alertPct: input.alertPct, hardStop: input.hardStop })
    .onConflictDoUpdate({ target: [aiBudgets.organizationId, aiBudgets.scope, aiBudgets.target], set: { monthlyCredits: input.monthlyCredits, alertPct: input.alertPct, hardStop: input.hardStop } }).returning();
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "ai.budget_saved", resource: "ai_budget", resourceId: row.id, metadata: { ...input, target }, ip: ctx.ip });
  return row;
}

export async function deleteBudget(ctx: TenantContext, id: string) {
  requirePerm(ctx, "ai:govern");
  const [row] = await ctx.db.delete(aiBudgets).where(and(eq(aiBudgets.id, id), eq(aiBudgets.organizationId, ctx.organizationId))).returning();
  if (!row) throw new HttpError(404, "Orçamento não encontrado.");
  await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "ai.budget_deleted", resource: "ai_budget", resourceId: id, metadata: { scope: row.scope, target: row.target }, ip: ctx.ip });
  return { ok: true };
}

async function creditsThisMonth(db: DB, organizationId: string, filter?: { agentKey?: string; model?: string }) {
  const conds = [eq(aiExecutions.organizationId, organizationId), gte(aiExecutions.createdAt, monthStart())];
  if (filter?.agentKey) conds.push(eq(aiExecutions.agentKey, filter.agentKey));
  if (filter?.model) conds.push(eq(aiExecutions.model, filter.model));
  const [r] = await db.select({ c: sql<number>`coalesce(sum(${aiExecutions.credits}),0)::int` }).from(aiExecutions).where(and(...conds));
  return Number(r.c);
}

export async function listBudgets(ctx: TenantContext) {
  requirePerm(ctx, "ai:manage");
  const rows = await ctx.db.select().from(aiBudgets).where(eq(aiBudgets.organizationId, ctx.organizationId)).orderBy(aiBudgets.scope, aiBudgets.target);
  return Promise.all(rows.map(async (b) => {
    const used = await creditsThisMonth(ctx.db, ctx.organizationId, b.scope === "agent" ? { agentKey: b.target } : b.scope === "model" ? { model: b.target } : undefined);
    return { ...b, usedThisMonth: used, usedPct: Math.round((used / b.monthlyCredits) * 1000) / 10 };
  }));
}

export class BudgetExceededError extends Error { status = 402; }

/**
 * Checa os orçamentos aplicáveis ANTES de chamar provedores.
 * - Limite atingido + hardStop → BudgetExceededError (nada é cobrado).
 * - Limite atingido sem hardStop → segue com aviso (para orçamento de modelo, o próximo provedor da cadeia assume — ver docs).
 * - alertPct atingido → uma notificação por orçamento por mês (deduplicada via auditoria).
 */
export async function checkAiBudgets(db: DB, organizationId: string, agent: { key: string; name: string; monthlyCreditBudget: number | null }, model?: string): Promise<{ warnings: string[]; skipModel?: string }> {
  const budgets = await db.select().from(aiBudgets).where(and(eq(aiBudgets.organizationId, organizationId), or(
    eq(aiBudgets.scope, "organization"), and(eq(aiBudgets.scope, "agent"), eq(aiBudgets.target, agent.key)),
    model && model !== "auto" ? and(eq(aiBudgets.scope, "model"), eq(aiBudgets.target, model)) : sql`false`,
  )));
  const all: { id: string; label: string; monthly: number; alertPct: number; hardStop: boolean; filter?: { agentKey?: string; model?: string }; scope: string }[] = budgets.map((b) => ({
    id: b.id, label: b.scope === "organization" ? "organização" : b.scope === "agent" ? `agente ${agent.name}` : `modelo ${b.target}`,
    monthly: b.monthlyCredits, alertPct: b.alertPct, hardStop: b.hardStop, scope: b.scope,
    filter: b.scope === "agent" ? { agentKey: b.target } : b.scope === "model" ? { model: b.target } : undefined,
  }));
  if (agent.monthlyCreditBudget != null) all.push({ id: `agent:${agent.key}`, label: `agente ${agent.name} (orçamento próprio)`, monthly: agent.monthlyCreditBudget, alertPct: 80, hardStop: true, scope: "agent", filter: { agentKey: agent.key } });

  const warnings: string[] = [];
  let skipModel: string | undefined;
  for (const b of all) {
    const used = await creditsThisMonth(db, organizationId, b.filter);
    if (used >= b.monthly) {
      if (b.hardStop) throw new BudgetExceededError(`Orçamento mensal de IA da ${b.label} esgotado (${used}/${b.monthly} créditos). Ajuste no AI Control Plane.`);
      warnings.push(`Orçamento mensal da ${b.label} excedido (${used}/${b.monthly}); execução permitida porque o limite é flexível.`);
      if (b.scope === "model") skipModel = b.filter?.model;
    } else if (b.monthly > 0 && used / b.monthly * 100 >= b.alertPct) {
      await alertOnce(db, organizationId, b.id, `Orçamento de IA da ${b.label} em ${Math.round((used / b.monthly) * 100)}%`, `${used} de ${b.monthly} créditos usados neste mês.`);
    }
  }
  return { warnings, skipModel };
}

async function alertOnce(db: DB, organizationId: string, budgetId: string, title: string, body: string) {
  const key = `${budgetId}:${monthKey()}`;
  const [seen] = await db.select({ id: auditLogs.id }).from(auditLogs)
    .where(and(eq(auditLogs.organizationId, organizationId), eq(auditLogs.action, "ai.budget_alert"), eq(auditLogs.resourceId, key))).limit(1);
  if (seen) return;
  await audit(db, { organizationId, actorId: "system", action: "ai.budget_alert", resource: "ai_budget", resourceId: key, metadata: { title, body } });
  await db.insert(notifications).values({ organizationId, title, body, href: "/ai-control" });
}

/* ------------------------------------------------------------------ monitoramento e força de trabalho digital */

export async function agentMetrics(ctx: TenantContext, days = 30) {
  requirePerm(ctx, "ai:manage");
  const since = new Date(Date.now() - days * 864e5);
  const ex = aiExecutions;
  const rows = await ctx.db.select({
    agentKey: ex.agentKey,
    executions: sql<number>`count(*)::int`,
    success: sql<number>`count(*) filter (where ${ex.status} = 'success')::int`,
    fallback: sql<number>`count(*) filter (where ${ex.status} = 'fallback')::int`,
    blocked: sql<number>`count(*) filter (where ${ex.status} = 'blocked')::int`,
    errors: sql<number>`count(*) filter (where ${ex.status} = 'error')::int`,
    simulated: sql<number>`count(*) filter (where ${ex.simulated})::int`,
    avgLatencyMs: sql<number>`coalesce(avg(${ex.latencyMs}),0)::int`,
    tokens: sql<number>`coalesce(sum(${ex.inputTokens} + ${ex.outputTokens}),0)::int`,
    credits: sql<number>`coalesce(sum(${ex.credits}),0)::int`,
    positive: sql<number>`count(*) filter (where ${ex.feedback} = 1)::int`,
    negative: sql<number>`count(*) filter (where ${ex.feedback} = -1)::int`,
  }).from(ex).where(and(eq(ex.organizationId, ctx.organizationId), gte(ex.createdAt, since))).groupBy(ex.agentKey);
  // Intervenções humanas: decisões sobre pedidos de aprovação originados por agentes ("ai:<chave>").
  const human = await ctx.db.select({
    requestedBy: approvalRequests.requestedBy,
    approved: sql<number>`count(*) filter (where ${approvalRequests.status} = 'approved')::int`,
    rejected: sql<number>`count(*) filter (where ${approvalRequests.status} = 'rejected')::int`,
    pending: sql<number>`count(*) filter (where ${approvalRequests.status} = 'pending')::int`,
  }).from(approvalRequests).where(and(eq(approvalRequests.organizationId, ctx.organizationId), gte(approvalRequests.createdAt, since), sql`${approvalRequests.requestedBy} like 'ai:%'`)).groupBy(approvalRequests.requestedBy);
  const hmap = new Map(human.map((h) => [h.requestedBy.slice(3), { approved: h.approved, rejected: h.rejected, pending: h.pending }]));
  return rows.map((r) => ({
    ...r,
    successRate: r.executions ? Math.round(((r.success + r.fallback) / r.executions) * 1000) / 10 : null,
    humanInterventions: hmap.get(r.agentKey) ?? null,
  }));
}

/** Inventário da força de trabalho digital: agentes digitais, distintos de colaboradores humanos. */
export async function digitalWorkforce(ctx: TenantContext) {
  requirePerm(ctx, "ai:manage");
  await normalizeAgentLevels(ctx.db, ctx.organizationId);
  const agents = await ctx.db.select().from(aiAgents).where(eq(aiAgents.organizationId, ctx.organizationId)).orderBy(aiAgents.name);
  const metrics = new Map((await agentMetrics(ctx)).map((m) => [m.agentKey, m]));
  const ownerIds = agents.map((a) => a.ownerUserId).filter((x): x is string => !!x);
  const owners = ownerIds.length ? await ctx.db.select({ id: users.id, name: users.name }).from(users).where(inArray(users.id, ownerIds)) : [];
  const ownerMap = new Map(owners.map((o) => [o.id, o.name]));
  const providers = providerStatus();
  const activeProvider = providers.find((p) => p.available && !p.simulated)?.name ?? "local-heuristic (simulação)";
  return Promise.all(agents.map(async (a) => {
    const level = effectiveLevel(a);
    return {
      kind: "Agente digital" as const,
      id: a.id, key: a.key, name: a.name, function: a.objective, domain: a.domain,
      owner: a.ownerUserId ? { id: a.ownerUserId, name: ownerMap.get(a.ownerUserId) ?? "—" } : null,
      tools: a.tools, permissions: a.permissions, model: a.model, provider: activeProvider,
      autonomyLevel: level, autonomyLabel: AUTONOMY_LEVELS[level - 1].label,
      status: a.status, enabled: a.enabled, limits: a.limits, monthlyCreditBudget: a.monthlyCreditBudget,
      blockedBy: await agentBlockReason(ctx.db, ctx.organizationId, a),
      metrics: metrics.get(a.key) ?? null,
    };
  }));
}

/* ------------------------------------------------------------------ prevenção de conflitos */

export type Conflict = { kind: "duplicate_executions" | "excess_calls" | "overlapping_autonomy" | "workflow_loop_guard"; severity: "high" | "medium" | "low"; title: string; evidence: string; agents?: string[] };

export const EXCESS_CALLS_PER_HOUR = 120;

export async function conflictReport(ctx: TenantContext): Promise<Conflict[]> {
  requirePerm(ctx, "ai:manage");
  const out: Conflict[] = [];
  const since7 = new Date(Date.now() - 7 * 864e5);
  const org = ctx.organizationId;

  // 1) Execuções duplicadas: mesmo agente + mesma entrada em menos de 60s.
  const dup = await ctx.db.execute<{ agent_key: string; n: number }>(sql`
    select agent_key, count(*)::int as n from (
      select agent_key, created_at, lag(created_at) over (partition by agent_key, md5(input) order by created_at) as prev
      from ai_executions where organization_id = ${org} and created_at >= ${since7}
    ) t where prev is not null and created_at - prev < interval '60 seconds' group by agent_key`);
  for (const r of rowsOf<{ agent_key: string; n: number }>(dup)) out.push({ kind: "duplicate_executions", severity: r.n >= 10 ? "high" : "medium", agents: [r.agent_key], title: `Execuções duplicadas do agente ${r.agent_key}`, evidence: `${r.n} execução(ões) com a mesma entrada em menos de 60 segundos nos últimos 7 dias.` });

  // 2) Excesso de chamadas: pico por hora acima do limite.
  const peak = await ctx.db.execute<{ agent_key: string; hour: string; n: number }>(sql`
    select agent_key, to_char(date_trunc('hour', created_at), 'YYYY-MM-DD HH24:00') as hour, count(*)::int as n
    from ai_executions where organization_id = ${org} and created_at >= ${since7}
    group by agent_key, date_trunc('hour', created_at) having count(*) > ${EXCESS_CALLS_PER_HOUR} order by n desc limit 20`);
  for (const r of rowsOf<{ agent_key: string; hour: string; n: number }>(peak)) out.push({ kind: "excess_calls", severity: "medium", agents: [r.agent_key], title: `Excesso de chamadas do agente ${r.agent_key}`, evidence: `${r.n} execuções na hora ${r.hour} (limite de atenção: ${EXCESS_CALLS_PER_HOUR}/hora).` });

  // 3) Agentes com ferramentas sobrepostas e nível ≥ 4 no mesmo domínio (risco de ações concorrentes).
  const agents = await ctx.db.select().from(aiAgents).where(and(eq(aiAgents.organizationId, org), eq(aiAgents.status, "active"), eq(aiAgents.enabled, true)));
  const strong = agents.filter((a) => effectiveLevel(a) >= 4);
  for (let i = 0; i < strong.length; i++) for (let j = i + 1; j < strong.length; j++) {
    const a = strong[i], b = strong[j];
    if (a.domain !== b.domain) continue;
    const shared = a.tools.filter((t) => b.tools.includes(t));
    if (shared.length) out.push({ kind: "overlapping_autonomy", severity: "low", agents: [a.key, b.key], title: `${a.name} e ${b.name} podem agir sobre os mesmos recursos`, evidence: `Mesmo domínio (${a.domain}), ambos com nível ≥ 4 e ferramentas em comum: ${shared.join(", ")}.` });
  }

  // 4) Proteções de ciclo das automações acionadas (limite de passos ou profundidade).
  const loops = await ctx.db.select({ id: workflowRuns.id, workflowId: workflowRuns.workflowId, depth: workflowRuns.depth, error: workflowRuns.error, createdAt: workflowRuns.createdAt })
    .from(workflowRuns).where(and(eq(workflowRuns.organizationId, org), gte(workflowRuns.createdAt, new Date(Date.now() - 30 * 864e5)),
      or(sql`${workflowRuns.error} ilike '%Limite de%passos%'`, gte(workflowRuns.depth, 3)))).limit(20);
  if (loops.length) out.push({ kind: "workflow_loop_guard", severity: "high", title: "Proteção contra ciclos de automação acionada", evidence: `${loops.length} execução(ões) de automação atingiram o limite de profundidade ou de passos nos últimos 30 dias (ex.: automação ${loops[0].workflowId}).` });

  return out;
}

function rowsOf<T>(r: unknown): T[] {
  if (Array.isArray(r)) return r as T[];
  return ((r as { rows?: T[] }).rows ?? []) as T[];
}

/** Resumo para o painel. */
export async function controlPlaneOverview(ctx: TenantContext) {
  requirePerm(ctx, "ai:manage");
  const [workforce, switches, budgets, conflicts] = await Promise.all([digitalWorkforce(ctx), listKillSwitches(ctx), listBudgets(ctx), conflictReport(ctx)]);
  return { canGovern: can(ctx, "ai:govern"), isPlatformAdmin: ctx.isPlatformAdmin, levels: AUTONOMY_LEVELS, sensitiveActions: SENSITIVE_AGENT_ACTIONS, workforce, switches, budgets, conflicts };
}
