/** Constantes e rótulos do ORBITY Task Intelligence — puros (sem banco), usados pelo servidor e pela interface. */
export const PRIORITIES = ["low", "medium", "high", "urgent"] as const;
export type AlertPriority = (typeof PRIORITIES)[number];
export const PRIORITY_LABEL: Record<AlertPriority, string> = { low: "Baixa", medium: "Média", high: "Alta", urgent: "Urgente" };
export const PRIORITY_HINT: Record<AlertPriority, string> = {
  low: "Lembrete informativo", medium: "Exige atenção em breve", high: "Tarefa prioritária ou próxima do vencimento", urgent: "Crítica ou atrasada: ação imediata",
};

export const STATUSES = ["draft", "scheduled", "sent", "delivered", "read", "responded", "failed", "canceled"] as const;
export type AlertStatus = (typeof STATUSES)[number];
export const STATUS_LABEL: Record<AlertStatus, string> = {
  draft: "Rascunho", scheduled: "Agendado", sent: "Enviado", delivered: "Entregue", read: "Lido", responded: "Respondido", failed: "Falhou", canceled: "Cancelado",
};

export const CHANNELS = ["in_app", "push", "email", "whatsapp"] as const;
export type AlertChannel = (typeof CHANNELS)[number];
export const CHANNEL_LABEL: Record<AlertChannel, string> = {
  in_app: "Notificação interna / Central de Notificações", push: "Push notification", email: "E-mail", whatsapp: "WhatsApp Business",
};

export const RESPONSE_KINDS = ["ack", "working", "need_more_time", "delay_justification", "blocker", "help", "comment", "progress", "done"] as const;
export type ResponseKind = (typeof RESPONSE_KINDS)[number];
export const RESPONSE_LABEL: Record<ResponseKind, string> = {
  ack: "Recebimento confirmado", working: "Estou trabalhando nisso", need_more_time: "Solicitou mais prazo", delay_justification: "Justificou atraso",
  blocker: "Informou impedimento", help: "Pediu ajuda", comment: "Comentário", progress: "Atualizou o andamento", done: "Concluiu a tarefa",
};

export const TONES = ["formal", "direct", "cordial", "motivational", "custom"] as const;
export type Tone = (typeof TONES)[number];
export const TONE_LABEL: Record<Tone, string> = {
  formal: "Formal e corporativo", direct: "Objetivo e direto", cordial: "Cordial e colaborativo", motivational: "Motivacional", custom: "Personalizado pela organização",
};

export const MESSAGE_KINDS = [
  "friendly_reminder", "overdue_notice", "professional_chase", "high_priority", "goal_missed", "guidance", "status_request", "deadline_change",
] as const;
export type MessageKind = (typeof MESSAGE_KINDS)[number];
export const MESSAGE_KIND_LABEL: Record<MessageKind, string> = {
  friendly_reminder: "Lembrete amigável", overdue_notice: "Aviso de tarefa atrasada", professional_chase: "Cobrança profissional", high_priority: "Alerta de prioridade alta",
  goal_missed: "Lembrete de meta não atingida", guidance: "Orientação para concluir a atividade", status_request: "Solicitação de atualização", deadline_change: "Comunicação de mudança de prazo",
};


/** Tons visuais (Badge) — respeitam o design system do ORBITY-NEPTUNE. */
export const PRIORITY_TONE: Record<AlertPriority, "neutral" | "info" | "warning" | "danger"> = { low: "neutral", medium: "info", high: "warning", urgent: "danger" };
export const STATUS_TONE: Record<AlertStatus, "neutral" | "info" | "warning" | "danger" | "success" | "primary"> = {
  draft: "neutral", scheduled: "info", sent: "primary", delivered: "primary", read: "success", responded: "success", failed: "danger", canceled: "neutral",
};
