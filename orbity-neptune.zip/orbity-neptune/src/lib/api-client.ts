"use client";
/** Cliente HTTP do frontend: envelope { ok, data | error } padronizado pelo backend. */
export class ApiError extends Error {
  constructor(message: string, public status: number, public issues?: { path: string; message: string }[]) { super(message); }
}

export async function api<T = unknown>(url: string, opts: { method?: string; body?: unknown } = {}): Promise<T> {
  const res = await fetch(url, {
    method: opts.method ?? (opts.body !== undefined ? "POST" : "GET"),
    headers: opts.body !== undefined ? { "content-type": "application/json" } : undefined,
    body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
    credentials: "same-origin",
  });
  const j = await res.json().catch(() => ({ ok: false, error: "Resposta inválida do servidor." }));
  if (!res.ok || !j.ok) {
    if (res.status === 401 && typeof window !== "undefined" && !url.includes("/api/auth/")) window.location.href = "/login";
    const detail = j.issues?.length ? `: ${j.issues.map((i: { path: string; message: string }) => `${i.path} ${i.message}`).join("; ")}` : "";
    throw new ApiError((j.error ?? `Erro ${res.status}`) + detail, res.status, j.issues);
  }
  return j.data as T;
}
