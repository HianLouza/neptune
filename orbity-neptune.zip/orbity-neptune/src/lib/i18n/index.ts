/** Arquitetura de i18n: dicionários por locale; pt-BR é o padrão inicial, en/es preparados. */
import ptBR from "./messages/pt-BR.json";
import en from "./messages/en.json";

const DICTS: Record<string, Record<string, string>> = { "pt-BR": ptBR, en, es: ptBR };
export const SUPPORTED_LOCALES = ["pt-BR", "en", "es"] as const;

export function t(locale: string, key: string, vars: Record<string, string | number> = {}) {
  const dict = DICTS[locale] ?? DICTS[locale.split("-")[0]] ?? DICTS["pt-BR"];
  const raw = dict[key] ?? DICTS["pt-BR"][key] ?? key;
  return raw.replace(/\{(\w+)\}/g, (_, k) => String(vars[k] ?? `{${k}}`));
}
