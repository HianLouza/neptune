/**
 * Filtros do serviço central de métricas — compartilhados entre servidor (validação) e cliente (URL).
 * Puro: sem acesso a banco. Toda dimensão aqui existe no schema; "produto" NÃO existe (ver docs/prompt-34-35).
 */
import { z } from "zod";

export const PERIOD_PRESETS = [7, 30, 90, 180, 365] as const;
export const COMPARE_MODES = ["previous", "year", "none"] as const;
export type CompareMode = (typeof COMPARE_MODES)[number];

export const SOURCE_KEYS = ["prospect_ai", "website", "whatsapp", "referral", "import", "manual", "other"] as const;
export const SOURCE_LABELS: Record<string, string> = {
  prospect_ai: "Prospect.AI", website: "Site / Formulário", whatsapp: "WhatsApp", referral: "Indicações", import: "Importação", manual: "Manual", other: "Outros",
};

/** Dimensões de segmentação disponíveis no banco. */
export const DIMENSIONS = ["seller", "team", "campaign", "source", "stage"] as const;
export type Dimension = (typeof DIMENSIONS)[number];
export const DIMENSION_LABELS: Record<Dimension, string> = { seller: "Vendedor", team: "Equipe", campaign: "Campanha", source: "Origem", stage: "Etapa" };
/** Dimensões pedidas que não existem no schema — exibidas como indisponíveis, nunca simuladas. */
export const UNAVAILABLE_DIMENSIONS = [{ key: "product", label: "Produto", reason: "As oportunidades não têm vínculo com produtos no banco (não há itens de oportunidade)." }];

const isoDay = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Data no formato AAAA-MM-DD");
const uuid = z.string().uuid();

export const metricFiltersSchema = z.object({
  days: z.coerce.number().int().refine((d) => (PERIOD_PRESETS as readonly number[]).includes(d), "Período inválido").default(30),
  from: isoDay.optional(),
  to: isoDay.optional(),
  compare: z.enum(COMPARE_MODES).default("previous"),
  seller: uuid.optional(),
  team: uuid.optional(),
  campaign: z.union([uuid, z.literal("none")]).optional(),
  source: z.enum(SOURCE_KEYS).optional(),
  stage: uuid.optional(),
}).superRefine((f, c) => {
  if ((f.from && !f.to) || (!f.from && f.to)) c.addIssue({ code: "custom", message: "Informe início e fim do período personalizado.", path: ["from"] });
  if (f.from && f.to) {
    const a = Date.parse(f.from + "T00:00:00Z"), b = Date.parse(f.to + "T00:00:00Z");
    if (b < a) c.addIssue({ code: "custom", message: "O fim do período deve ser depois do início.", path: ["to"] });
    if ((b - a) / 864e5 > 366) c.addIssue({ code: "custom", message: "Período personalizado limitado a 366 dias.", path: ["to"] });
  }
});
export type MetricFilters = z.infer<typeof metricFiltersSchema>;

/** Nome do parâmetro na URL (em português, como o restante do app). */
export const URL_KEYS: Record<keyof MetricFilters, string> = {
  days: "periodo", from: "de", to: "ate", compare: "comparar", seller: "vendedor", team: "equipe", campaign: "campanha", source: "origem", stage: "etapa",
};

type ParamsLike = { get(name: string): string | null } | Record<string, string | string[] | undefined>;
function read(p: ParamsLike, k: string): string | undefined {
  if (typeof (p as { get?: unknown }).get === "function") return (p as { get(n: string): string | null }).get(k) ?? undefined;
  const v = (p as Record<string, string | string[] | undefined>)[k];
  return Array.isArray(v) ? v[0] : v ?? undefined;
}

/** Lê filtros da URL. Valores inválidos são descartados (nunca quebram a página). */
export function parseFilters(p: ParamsLike): MetricFilters {
  const raw: Record<string, string> = {};
  for (const [k, urlKey] of Object.entries(URL_KEYS)) {
    const v = read(p, urlKey);
    if (v != null && v !== "") raw[k] = v;
  }
  const r = metricFiltersSchema.safeParse(raw);
  if (r.success) return r.data;
  // Remove só os campos inválidos e tenta de novo.
  const bad = new Set(r.error.issues.map((i) => String(i.path[0])));
  if (bad.has("from") || bad.has("to")) { bad.add("from"); bad.add("to"); }
  for (const k of bad) delete raw[k];
  const again = metricFiltersSchema.safeParse(raw);
  return again.success ? again.data : metricFiltersSchema.parse({});
}

/** Serializa filtros para a URL (omite valores padrão). */
export function filtersToParams(f: Partial<MetricFilters>, base?: URLSearchParams): URLSearchParams {
  const p = new URLSearchParams(base);
  for (const urlKey of Object.values(URL_KEYS)) p.delete(urlKey);
  for (const [k, urlKey] of Object.entries(URL_KEYS) as [keyof MetricFilters, string][]) {
    const v = f[k];
    if (v == null || v === "") continue;
    if (k === "days" && v === 30 && !f.from) continue;
    if (k === "compare" && v === "previous") continue;
    if (k === "days" && f.from) continue;
    p.set(urlKey, String(v));
  }
  return p;
}

/** Período resolvido (fim exclusivo). Datas em UTC, como o restante do Sales Intelligence. */
export type ResolvedPeriod = { start: Date; end: Date; prevStart: Date | null; prevEnd: Date | null; days: number; label: string; compareLabel: string | null; custom: boolean };

export function resolvePeriod(f: Pick<MetricFilters, "days" | "from" | "to" | "compare">, now = new Date()): ResolvedPeriod {
  let start: Date, end: Date, label: string;
  const custom = !!(f.from && f.to);
  if (custom) {
    start = new Date(f.from + "T00:00:00Z");
    end = new Date(Date.parse(f.to + "T00:00:00Z") + 864e5);
    label = `${fmtDay(start)} a ${fmtDay(new Date(end.getTime() - 1))}`;
  } else {
    end = now;
    start = new Date(now.getTime() - f.days * 864e5);
    label = `Últimos ${f.days} dias`;
  }
  const days = Math.max(1, Math.round((end.getTime() - start.getTime()) / 864e5));
  let prevStart: Date | null = null, prevEnd: Date | null = null, compareLabel: string | null = null;
  if (f.compare === "previous") {
    prevEnd = start; prevStart = new Date(start.getTime() - (end.getTime() - start.getTime()));
    compareLabel = `Período anterior (${fmtDay(prevStart)} a ${fmtDay(new Date(prevEnd.getTime() - 1))})`;
  } else if (f.compare === "year") {
    prevStart = shiftYear(start, -1); prevEnd = shiftYear(end, -1);
    compareLabel = `Mesmo período do ano anterior (${fmtDay(prevStart)} a ${fmtDay(new Date(prevEnd.getTime() - 1))})`;
  }
  return { start, end, prevStart, prevEnd, days, label, compareLabel, custom };
}

function shiftYear(d: Date, n: number) { const x = new Date(d); x.setUTCFullYear(x.getUTCFullYear() + n); return x; }
function fmtDay(d: Date) { return d.toISOString().slice(0, 10).split("-").reverse().join("/"); }

/** Lista legível dos filtros ativos (para tela, CSV e respostas do Flávio). */
export function describeFilters(f: MetricFilters, names: Partial<Record<Dimension, Record<string, string>>> = {}): string[] {
  const out: string[] = [];
  for (const d of DIMENSIONS) {
    const v = f[d];
    if (!v) continue;
    const label = d === "source" ? SOURCE_LABELS[v] ?? v : d === "campaign" && v === "none" ? "Sem campanha" : names[d]?.[v] ?? v;
    out.push(`${DIMENSION_LABELS[d]}: ${label}`);
  }
  return out;
}
