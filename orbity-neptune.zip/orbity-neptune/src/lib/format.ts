/** Formatação localizada — locale, moeda e fuso vêm da organização/usuário (nunca constantes globais). */
export type LocaleOpts = { locale: string; currency: string; timezone?: string };

export function money(cents: number, o: LocaleOpts, compact = false) {
  return new Intl.NumberFormat(o.locale, { style: "currency", currency: o.currency, maximumFractionDigits: compact ? 1 : 0, notation: compact ? "compact" : "standard" }).format(cents / 100);
}
export function num(v: number, locale: string) { return new Intl.NumberFormat(locale).format(v); }
export function pct(v: number | null | undefined, locale: string, digits = 1) {
  return v == null ? "—" : `${new Intl.NumberFormat(locale, { maximumFractionDigits: digits, minimumFractionDigits: digits }).format(v)}%`;
}
export function date(d: Date | string | null | undefined, o: Pick<LocaleOpts, "locale" | "timezone">, withTime = false) {
  if (!d) return "—";
  return new Intl.DateTimeFormat(o.locale, { timeZone: o.timezone, day: "2-digit", month: "short", ...(withTime ? { hour: "2-digit", minute: "2-digit" } : {}) }).format(new Date(d));
}
export function relative(d: Date | string, locale: string) {
  const diff = (new Date(d).getTime() - Date.now()) / 1000;
  const rtf = new Intl.RelativeTimeFormat(locale, { numeric: "auto" });
  const abs = Math.abs(diff);
  if (abs < 60) return rtf.format(Math.round(diff), "second");
  if (abs < 3600) return rtf.format(Math.round(diff / 60), "minute");
  if (abs < 86400) return rtf.format(Math.round(diff / 3600), "hour");
  return rtf.format(Math.round(diff / 86400), "day");
}
