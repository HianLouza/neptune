"use client";
/** Gráficos do Sales Intelligence sobre o componente interativo comum (tooltip, legenda, teclado, toque, tabela). */
import { useRouter } from "next/navigation";
import { InteractiveBars } from "@/components/charts/interactive";

export function FunnelChart({ stages, locale, currency }: { stages: { id?: string; name: string; n: number; total: number }[]; locale: string; currency: string }) {
  const router = useRouter();
  const cur = new Intl.NumberFormat(locale, { style: "currency", currency, maximumFractionDigits: 0 });
  return (
    <InteractiveBars title="Funil: oportunidades por etapa (posição atual)" valueLabel="Oportunidades" color="var(--primary-2)"
      items={stages.map((s, i) => ({ key: s.id ?? String(i), label: s.name, value: s.n, extra: `Valor: ${cur.format(s.total / 100)}` }))}
      format={(v) => new Intl.NumberFormat(locale).format(v)}
      onSelect={(k) => { if (/^[0-9a-f-]{36}$/i.test(k)) router.push(`/crm?etapa=${k}`); }} />
  );
}

export function SellersChart({ sellers, locale, currency }: { sellers: { userId?: string; name: string; revenue: number; won?: number; winRate?: number | null }[]; locale: string; currency: string }) {
  const router = useRouter();
  const cur = new Intl.NumberFormat(locale, { style: "currency", currency, maximumFractionDigits: 0, notation: "compact" });
  return (
    <InteractiveBars title="Receita por vendedor" valueLabel="Receita"
      items={sellers.slice(0, 10).map((s, i) => ({ key: s.userId ?? String(i), label: s.name, value: s.revenue, extra: `${s.won ?? 0} vendas · conversão ${s.winRate == null ? "n/d" : s.winRate + "%"}` }))}
      format={(v) => cur.format(v / 100)}
      onSelect={(k) => { if (/^[0-9a-f-]{36}$/i.test(k)) router.push(`/dashboard?vendedor=${k}`); }} />
  );
}

export function OriginsChart({ buckets }: { buckets: { key?: string; label: string; count: number; pct: number }[] }) {
  const router = useRouter();
  return (
    <InteractiveBars title="Leads por origem" valueLabel="Leads" color="var(--primary-2)"
      items={buckets.map((b, i) => ({ key: b.key ?? String(i), label: b.label, value: b.count, extra: `${b.pct}% dos leads` }))}
      format={(v) => String(v)}
      onSelect={(k) => { if (k !== "other" && /^[a-z_]+$/.test(k)) router.push(`/dashboard?origem=${k}`); }} />
  );
}
