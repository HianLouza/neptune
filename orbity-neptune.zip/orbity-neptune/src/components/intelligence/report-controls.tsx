"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Download, Printer, Sparkles } from "lucide-react";
import { useAction, Feedback } from "@/components/ui/use-action";
import { Button, Select, SimBadge } from "@/components/ui";

const TYPES = [["executive", "Executivo"], ["funnel", "Funil"], ["sellers", "Vendedores"], ["origins", "Origem de leads"], ["forecast", "Previsão"]];
const PERIODS = [7, 30, 90, 180, 365];

export function ReportControls({ type, days }: { type: string; days: number }) {
  const router = useRouter();
  const go = (t: string, d: number) => router.push(`/relatorios?tipo=${t}&periodo=${d}`);
  return (
    <div className="flex flex-wrap items-center gap-2 print:hidden">
      <Select aria-label="Tipo de relatório" value={type} onChange={(e) => go(e.target.value, days)} className="w-44">{TYPES.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</Select>
      <Select aria-label="Período" value={days} onChange={(e) => go(type, Number(e.target.value))} className="w-40">{PERIODS.map((p) => <option key={p} value={p}>Últimos {p} dias</option>)}</Select>
      <a href={`/api/reports?type=${type}&days=${days}&format=csv`} className="inline-flex items-center gap-2 rounded-lg border border-line bg-surface-2 px-4 py-2 text-sm font-medium hover:border-primary-2"><Download size={16} />CSV</a>
      <Button variant="secondary" onClick={() => window.print()}><Printer size={16} />Imprimir / PDF</Button>
    </div>
  );
}

type AgentOut = { text: string; simulated: boolean; warnings: string[]; credits: number; status: string };

export function AiSummary({ type, days }: { type: string; days: number }) {
  const [out, setOut] = useState<AgentOut | null>(null);
  const { run, loading, error } = useAction();
  return (
    <div>
      <Button onClick={async () => { const r = await run<AgentOut>("/api/reports", { type, days }, { refresh: false }); if (r) setOut(r); }} disabled={loading} className="print:hidden">
        <Sparkles size={16} />{loading ? "Gerando..." : "Gerar resumo com IA"}
      </Button>
      <Feedback error={error} />
      {out && (
        <div className="mt-4 rounded-xl border border-line bg-bg-2/60 p-4">
          <div className="mb-2 flex flex-wrap items-center gap-2 text-xs text-muted">
            Resumo gerado pelo Agente de Relatórios · {out.credits} crédito(s)
            {out.simulated && <SimBadge label="IA em modo simulado" />}
          </div>
          <p className="whitespace-pre-wrap text-sm leading-relaxed">{out.text}</p>
          {out.warnings.filter((w) => !w.includes("MODO SIMULADO")).map((w) => <p key={w} className="mt-1 text-xs text-warning">{w}</p>)}
        </div>
      )}
    </div>
  );
}
