"use client";
import { useState } from "react";
import { Search } from "lucide-react";
import { useAction, Feedback } from "@/components/ui/use-action";
import { Button, Input } from "@/components/ui";

type Result = { metric: string | null; days?: number; answer: unknown; comparison?: unknown; message?: string };

const LABELS: Record<string, string> = {
  revenue: "Receita e vendas", leads_by_source: "Leads por origem", forecast: "Previsão de receita", seller_performance: "Desempenho de vendedores", funnel: "Funil",
};
const SUGGESTIONS = ["Qual a receita dos últimos 30 dias?", "Leads por origem nos últimos 7 dias", "Previsão de receita", "Ranking de vendedores", "Onde está o gargalo do funil?"];

function fmtVal(k: string, v: unknown, locale: string, currency: string): string {
  if (typeof v === "number" && /cents|revenue|Cents/i.test(k)) return new Intl.NumberFormat(locale, { style: "currency", currency, maximumFractionDigits: 0 }).format(v / 100);
  if (typeof v === "number") return new Intl.NumberFormat(locale).format(v);
  if (v == null) return "n/d";
  if (typeof v === "object") return JSON.stringify(v);
  return String(v);
}

function Render({ value, locale, currency }: { value: unknown; locale: string; currency: string }) {
  if (Array.isArray(value)) {
    if (!value.length) return <p className="text-sm text-muted">Sem dados para o período.</p>;
    const cols = Object.keys(value[0] as object).filter((c) => !["id", "userId"].includes(c));
    return (
      <div className="overflow-x-auto"><table className="w-full text-xs"><thead><tr className="text-left text-muted">{cols.map((c) => <th key={c} className="px-2 py-1">{c}</th>)}</tr></thead>
        <tbody>{value.map((row, i) => <tr key={i} className="border-t border-line">{cols.map((c) => <td key={c} className="px-2 py-1">{fmtVal(c, (row as Record<string, unknown>)[c], locale, currency)}</td>)}</tr>)}</tbody></table></div>
    );
  }
  if (value && typeof value === "object") {
    return (
      <dl className="grid grid-cols-1 gap-x-6 gap-y-1 text-sm sm:grid-cols-2">
        {Object.entries(value as Record<string, unknown>).filter(([, v]) => typeof v !== "object" || v === null).map(([k, v]) => (
          <div key={k} className="flex justify-between gap-3 border-b border-line/50 py-1"><dt className="text-muted">{k}</dt><dd className="font-medium">{fmtVal(k, v, locale, currency)}</dd></div>
        ))}
        {Object.entries(value as Record<string, unknown>).filter(([, v]) => v && typeof v === "object").map(([k, v]) => (
          <div key={k} className="sm:col-span-2"><p className="mt-2 text-xs font-semibold text-muted">{k}</p><Render value={v} locale={locale} currency={currency} /></div>
        ))}
      </dl>
    );
  }
  return <p className="text-sm">{String(value)}</p>;
}

/** Consulta em linguagem natural mapeada para métricas canônicas (sem SQL livre). */
export function NlQuery({ locale, currency }: { locale: string; currency: string }) {
  const [q, setQ] = useState("");
  const [res, setRes] = useState<Result | null>(null);
  const { run, loading, error } = useAction();
  const ask = async (text: string) => {
    if (text.trim().length < 2) return;
    setQ(text);
    const r = await run<Result>("/api/intelligence/query", { q: text }, { refresh: false });
    if (r) setRes(r);
  };
  return (
    <div>
      <form onSubmit={(e) => { e.preventDefault(); ask(q); }} className="flex gap-2">
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder='Pergunte algo como "receita dos últimos 90 dias"' aria-label="Consulta em linguagem natural" />
        <Button type="submit" disabled={loading}><Search size={16} />{loading ? "..." : "Consultar"}</Button>
      </form>
      <div className="mt-2 flex flex-wrap gap-1.5">
        {SUGGESTIONS.map((s) => <button key={s} type="button" onClick={() => ask(s)} className="rounded-full border border-line px-2.5 py-1 text-[11px] text-muted hover:border-primary-2 hover:text-fg">{s}</button>)}
      </div>
      <Feedback error={error} />
      {res && (
        <div className="mt-4 rounded-xl border border-line bg-bg-2/60 p-4">
          {res.metric ? (
            <>
              <p className="mb-3 text-xs text-muted">Métrica interpretada: <span className="font-semibold text-fg">{LABELS[res.metric] ?? res.metric}</span>{res.days ? ` · últimos ${res.days} dias` : ""}</p>
              <Render value={res.answer} locale={locale} currency={currency} />
              {res.comparison != null && <><p className="mt-3 text-xs font-semibold text-muted">Período anterior</p><Render value={res.comparison} locale={locale} currency={currency} /></>}
            </>
          ) : <p className="text-sm text-warning">{res.message}</p>}
        </div>
      )}
    </div>
  );
}
