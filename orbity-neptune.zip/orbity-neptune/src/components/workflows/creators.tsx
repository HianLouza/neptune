"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Sparkles, LayoutTemplate } from "lucide-react";
import { Badge, Button, Card, CardTitle, Textarea, cx } from "@/components/ui";
import { api } from "@/lib/api-client";
import type { TemplateInfo, Wf } from "./types";
import { STATUS_LABEL } from "./types";

function useCreate() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const create = async (body: unknown) => {
    setLoading(true); setError(null);
    try {
      const wf = await api<Wf>("/api/workflows", { body });
      router.push(`/automacoes?wf=${wf.id}`);
      router.refresh();
    } catch (e) { setError((e as Error).message); } finally { setLoading(false); }
  };
  return { create, loading, error };
}

export function TemplateGallery({ templates, labels, highlight, canWrite }: { templates: TemplateInfo[]; labels: Record<string, string>; highlight?: string; canWrite: boolean }) {
  const c = useCreate();
  return (
    <Card>
      <CardTitle sub="Crie a partir de um modelo pronto — ele entra como rascunho para você revisar antes de publicar."><span className="flex items-center gap-2"><LayoutTemplate size={16} /> Modelos prontos</span></CardTitle>
      <div className="grid gap-3 sm:grid-cols-2">
        {templates.map((t) => (
          <div key={t.key} className={cx("flex flex-col rounded-xl border p-3", highlight === t.key ? "border-primary-2 bg-primary/10" : "border-line bg-surface-2/40")}>
            <p className="text-sm font-semibold">{t.name}</p>
            <p className="mt-1 flex-1 text-xs text-muted">{t.description}</p>
            <div className="mt-2 flex items-center justify-between gap-2">
              <Badge tone="info">{labels[t.triggerEvent] ?? t.triggerEvent}</Badge>
              {canWrite && <Button size="sm" variant="secondary" disabled={c.loading} onClick={() => c.create({ templateKey: t.key })}>Usar modelo</Button>}
            </div>
          </div>
        ))}
      </div>
      {c.error && <p role="alert" className="mt-2 text-xs text-danger">{c.error}</p>}
    </Card>
  );
}

export function NLCreator({ autoFocus }: { autoFocus?: boolean }) {
  const c = useCreate();
  const [text, setText] = useState("");
  return (
    <Card glow={autoFocus}>
      <CardTitle sub="Descreva em português. Geramos um RASCUNHO determinístico — nada é publicado sem sua revisão."><span className="flex items-center gap-2"><Sparkles size={16} className="text-primary-2" /> Criar com linguagem natural</span></CardTitle>
      <form onSubmit={(e) => { e.preventDefault(); c.create({ text }); }} className="space-y-3">
        <Textarea autoFocus={autoFocus} value={text} onChange={(e) => setText(e.target.value)} placeholder="Ex.: Quando um lead for criado, criar uma tarefa, esperar 2 dias e notificar o gestor." aria-label="Descrição da automação" />
        <Button type="submit" disabled={c.loading || text.trim().length < 5}>{c.loading ? "Gerando..." : "Gerar rascunho"}</Button>
        {c.error && <p role="alert" className="text-xs text-danger">{c.error}</p>}
      </form>
    </Card>
  );
}

export function WorkflowList({ items, labels, selectedId, locale }: { items: Wf[]; labels: Record<string, string>; selectedId?: string; locale: string }) {
  return (
    <Card className="p-3">
      <p className="px-2 pb-2 text-sm font-semibold">Automações ({items.length})</p>
      {!items.length ? <p className="px-2 py-4 text-xs text-muted">Nenhuma automação. Use um modelo ou descreva uma em linguagem natural.</p> : (
        <ul className="space-y-1">
          {items.map((w) => (
            <li key={w.id}>
              <Link href={`/automacoes?wf=${w.id}`} className={cx("block rounded-lg border p-2.5", selectedId === w.id ? "border-primary-2 bg-primary/10" : "border-transparent hover:bg-surface-2")}>
                <div className="flex items-center justify-between gap-2">
                  <span className="truncate text-sm font-medium">{w.name}</span>
                  <Badge tone={w.status === "active" ? "success" : w.status === "paused" ? "warning" : "neutral"}>{STATUS_LABEL[w.status] ?? w.status}</Badge>
                </div>
                <p className="mt-0.5 text-[11px] text-muted">{labels[w.triggerEvent] ?? w.triggerEvent} · v{w.currentVersion} · {new Date(w.updatedAt).toLocaleDateString(locale)}</p>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </Card>
  );
}
