"use client";
import { useState } from "react";
import { ArrowDown, ArrowUp, Trash2, Plus, Link2, Play, Pause, Save, FlaskConical, Zap, RotateCcw } from "lucide-react";
import { Badge, Button, Card, CardTitle, Field, Input, Select, Textarea, cx } from "@/components/ui";
import { useAction, Feedback } from "@/components/ui/use-action";
import { NODE_LABEL, PARAM_LABEL, RUN_LABEL, SAMPLE_PAYLOAD, STATUS_LABEL, type ActionDef, type Definition, type WfNode, type Wf, type WfRun, type WfVersion } from "./types";

type Props = {
  workflow: Wf; versions: WfVersion[]; runs: WfRun[]; actions: ActionDef[]; labels: Record<string, string>;
  canWrite: boolean; canPublish: boolean; locale: string;
};

const newId = () => `n${Date.now().toString(36)}${Math.floor(Math.random() * 1000)}`;
const OPS = [["eq", "igual a"], ["neq", "diferente de"], ["gt", "maior que"], ["gte", "maior ou igual a"], ["lt", "menor que"], ["contains", "contém"], ["exists", "existe"]];

export function WorkflowEditor({ workflow, versions, runs, actions, labels, canWrite, canPublish, locale }: Props) {
  const current = versions.find((v) => v.version === workflow.currentVersion) ?? versions[0];
  const [name, setName] = useState(workflow.name);
  const [description, setDescription] = useState(workflow.description ?? "");
  const [trigger, setTrigger] = useState(workflow.triggerEvent);
  const [nodes, setNodes] = useState<WfNode[]>(current?.definition.nodes ?? []);
  const [loadedFrom, setLoadedFrom] = useState<number>(current?.version ?? 1);
  const [sample, setSample] = useState(JSON.stringify(SAMPLE_PAYLOAD[workflow.triggerEvent] ?? {}, null, 2));
  const [simLog, setSimLog] = useState<{ status: string; log: WfRun["log"] } | null>(null);
  const save = useAction(), status = useAction(), sim = useAction(), runA = useAction();
  const dirty = JSON.stringify(nodes) !== JSON.stringify(current?.definition.nodes ?? []) || name !== workflow.name || trigger !== workflow.triggerEvent || description !== (workflow.description ?? "");

  const upd = (i: number, patch: Partial<WfNode>) => setNodes((ns) => ns.map((n, j) => (j === i ? { ...n, ...patch } : n)));
  const updCfg = (i: number, key: string, value: unknown) => setNodes((ns) => ns.map((n, j) => (j === i ? { ...n, config: { ...n.config, [key]: value } } : n)));
  const move = (i: number, d: -1 | 1) => setNodes((ns) => { const c = [...ns]; const t = i + d; if (t < 0 || t >= c.length) return ns; [c[i], c[t]] = [c[t], c[i]]; return c; });
  const remove = (i: number) => setNodes((ns) => {
    const gone = ns[i].id;
    return ns.filter((_, j) => j !== i).map((n) => ({ ...n, next: n.next === gone ? null : n.next, nextFalse: n.nextFalse === gone ? null : n.nextFalse }));
  });
  const add = (type: WfNode["type"]) => setNodes((ns) => {
    const cfg: Record<string, unknown> = type === "action" ? { action: actions[0]?.key ?? "notify" } : type === "wait" ? { hours: 24 } : type === "condition" ? { field: "payload.amountCents", op: "gte", value: "0" } : type === "approval" ? { title: "Aprovação necessária" } : {};
    const node: WfNode = { id: newId(), type, config: cfg, next: null };
    const endIdx = ns.findIndex((n) => n.type === "end");
    if (endIdx === -1 || type === "end") return [...ns, node];
    const c = [...ns]; c.splice(endIdx, 0, node); return c;
  });
  /** Encadeia cada nó ao seguinte (ramo "falso" das condições é preservado). */
  const chain = () => setNodes((ns) => ns.map((n, i) => (n.type === "end" ? { ...n, next: null } : { ...n, next: ns[i + 1]?.id ?? null })));

  const definition = (): Definition => ({ nodes, entry: nodes[0]?.id ?? "" });
  const doSave = () => save.run(`/api/workflows/${workflow.id}`, { name, description: description || undefined, triggerEvent: trigger, definition: definition() }, { method: "PUT", success: "Nova versão salva." });
  const setStatus = (s: string, msg: string) => status.run(`/api/workflows/${workflow.id}`, { status: s }, { method: "PATCH", success: msg });
  const parseSample = () => { try { return JSON.parse(sample || "{}"); } catch { sim.setError("Payload JSON inválido."); return null; } };
  const simulate = async () => {
    const p = parseSample(); if (!p) return;
    const r = await sim.run<{ status: string; log: WfRun["log"] }>(`/api/workflows/${workflow.id}/simulate`, { payload: p }, { refresh: false });
    if (r) setSimLog(r);
  };
  const testEvent = async () => {
    const p = parseSample(); if (!p) return;
    await sim.run("/api/workflows/test-event", { type: workflow.triggerEvent, payload: p }, { success: "Evento de teste publicado. Atualize em alguns segundos para ver a execução." });
  };
  const ids = nodes.map((n) => n.id);
  const nodeOpt = (selfId: string) => [<option key="" value="">(nenhum / encerra)</option>, ...ids.filter((x) => x !== selfId).map((x) => { const n = nodes.find((y) => y.id === x)!; return <option key={x} value={x}>{x} — {NODE_LABEL[n.type]}</option>; })];

  return (
    <div className="space-y-5">
      <Card>
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h2 className="text-lg font-semibold">{workflow.name}</h2>
            <p className="text-xs text-muted">Versão publicada no motor: v{workflow.currentVersion} · editando a partir da v{loadedFrom}</p>
            <div className="mt-1 flex gap-1.5"><Badge tone={workflow.status === "active" ? "success" : workflow.status === "paused" ? "warning" : "neutral"}>{STATUS_LABEL[workflow.status] ?? workflow.status}</Badge>{dirty && <Badge tone="warning">Alterações não salvas</Badge>}</div>
          </div>
          <div className="flex flex-wrap gap-2">
            {workflow.status !== "active" && canPublish && <Button size="sm" onClick={() => setStatus("active", "Automação publicada (ativa).")} disabled={status.loading || dirty} title={dirty ? "Salve antes de publicar" : ""}><Play size={14} /> {workflow.status === "paused" ? "Reativar" : "Publicar"}</Button>}
            {workflow.status === "active" && canWrite && <Button size="sm" variant="secondary" onClick={() => setStatus("paused", "Automação pausada.")} disabled={status.loading}><Pause size={14} /> Pausar</Button>}
            {workflow.status !== "draft" && canWrite && <Button size="sm" variant="ghost" onClick={() => setStatus("draft", "Voltou para rascunho.")} disabled={status.loading}>Mover p/ rascunho</Button>}
          </div>
        </div>
        <Feedback error={status.error} message={status.message} />
      </Card>

      <Card>
        <CardTitle sub="Fluxo executado de cima para baixo seguindo o campo “próximo”. Ciclos são bloqueados; máx. 50 passos e 3 níveis de encadeamento entre automações.">Editor visual</CardTitle>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Nome"><Input value={name} onChange={(e) => setName(e.target.value)} disabled={!canWrite} /></Field>
          <Field label="Gatilho (evento)">
            <Select value={trigger} onChange={(e) => setTrigger(e.target.value)} disabled={!canWrite}>
              {Object.entries(labels).map(([k, l]) => <option key={k} value={k}>{l} ({k})</option>)}
            </Select>
          </Field>
          <div className="sm:col-span-2"><Field label="Descrição"><Input value={description} onChange={(e) => setDescription(e.target.value)} disabled={!canWrite} /></Field></div>
        </div>

        <ol className="mt-5 space-y-3">
          {nodes.map((n, i) => {
            const act = actions.find((a) => a.key === n.config.action);
            return (
              <li key={n.id} className={cx("rounded-xl border p-3", n.type === "trigger" ? "border-primary-2/60 bg-primary/10" : n.type === "end" ? "border-line bg-bg-2/60" : "border-line bg-surface-2/40")}>
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <p className="text-sm font-semibold">{i + 1}. {NODE_LABEL[n.type]} <span className="font-mono text-[11px] font-normal text-muted">{n.id}</span>{i === 0 && <Badge tone="primary" className="ml-2">entrada</Badge>}</p>
                  {canWrite && (
                    <div className="flex gap-1">
                      <Button size="sm" variant="ghost" onClick={() => move(i, -1)} disabled={i === 0} aria-label="Mover para cima"><ArrowUp size={14} /></Button>
                      <Button size="sm" variant="ghost" onClick={() => move(i, 1)} disabled={i === nodes.length - 1} aria-label="Mover para baixo"><ArrowDown size={14} /></Button>
                      <Button size="sm" variant="ghost" onClick={() => remove(i)} aria-label="Remover nó"><Trash2 size={14} /></Button>
                    </div>
                  )}
                </div>
                <fieldset disabled={!canWrite} className="mt-2 grid gap-2 sm:grid-cols-3">
                  {n.type === "trigger" && <p className="text-xs text-muted sm:col-span-3">Dispara em: <b>{labels[trigger] ?? trigger}</b></p>}
                  {n.type === "condition" && (<>
                    <Field label="Campo"><Input value={String(n.config.field ?? "")} onChange={(e) => updCfg(i, "field", e.target.value)} placeholder="payload.amountCents" /></Field>
                    <Field label="Operador"><Select value={String(n.config.op ?? "eq")} onChange={(e) => updCfg(i, "op", e.target.value)}>{OPS.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</Select></Field>
                    <Field label="Valor"><Input value={String(n.config.value ?? "")} onChange={(e) => updCfg(i, "value", e.target.value)} disabled={n.config.op === "exists"} /></Field>
                  </>)}
                  {n.type === "action" && (<>
                    <Field label="Ação"><Select value={String(n.config.action ?? "")} onChange={(e) => updCfg(i, "action", e.target.value)}>{actions.map((a) => <option key={a.key} value={a.key}>{a.label}</option>)}</Select></Field>
                    {act?.params.map((p) => (
                      <Field key={p} label={PARAM_LABEL[p] ?? p}>
                        <Input type={p === "dueInHours" ? "number" : "text"} min={0} value={String(n.config[p] ?? "")} onChange={(e) => updCfg(i, p, p === "dueInHours" ? Number(e.target.value) : e.target.value)} />
                      </Field>
                    ))}
                    <Field label="Em caso de erro"><Select value={String(n.config.onError ?? "stop")} onChange={(e) => updCfg(i, "onError", e.target.value)}><option value="stop">Interromper</option><option value="continue">Continuar</option></Select></Field>
                  </>)}
                  {n.type === "wait" && <Field label="Esperar (horas)"><Input type="number" min={0} max={8760} value={Number(n.config.hours ?? 0)} onChange={(e) => updCfg(i, "hours", Number(e.target.value))} /></Field>}
                  {n.type === "approval" && <div className="sm:col-span-2"><Field label="Título da aprovação"><Input value={String(n.config.title ?? "")} onChange={(e) => updCfg(i, "title", e.target.value)} /></Field></div>}
                  {n.type !== "end" && (
                    <Field label={n.type === "condition" ? "Próximo se VERDADEIRO" : "Próximo"}>
                      <Select value={n.next ?? ""} onChange={(e) => upd(i, { next: e.target.value || null })}>{nodeOpt(n.id)}</Select>
                    </Field>
                  )}
                  {n.type === "condition" && (
                    <Field label="Próximo se FALSO">
                      <Select value={n.nextFalse ?? ""} onChange={(e) => upd(i, { nextFalse: e.target.value || null })}>{nodeOpt(n.id)}</Select>
                    </Field>
                  )}
                </fieldset>
                {act && ["send_message", "webhook"].includes(act.key) && <p className="mt-2 text-[11px] text-warning">Ação sensível: gera um pedido de aprovação humana antes de executar.</p>}
              </li>
            );
          })}
        </ol>

        {canWrite && (
          <div className="mt-4 flex flex-wrap items-center gap-2">
            {(["condition", "action", "wait", "approval", "end"] as const).map((t) => <Button key={t} size="sm" variant="secondary" onClick={() => add(t)}><Plus size={14} /> {NODE_LABEL[t]}</Button>)}
            {!nodes.some((n) => n.type === "trigger") && <Button size="sm" variant="secondary" onClick={() => setNodes((ns) => [{ id: newId(), type: "trigger", config: {}, next: ns[0]?.id ?? null }, ...ns])}><Plus size={14} /> Gatilho</Button>}
            <Button size="sm" variant="ghost" onClick={chain}><Link2 size={14} /> Encadear em sequência</Button>
            <div className="flex-1" />
            {dirty && <Button size="sm" variant="ghost" onClick={() => { setNodes(current?.definition.nodes ?? []); setName(workflow.name); setTrigger(workflow.triggerEvent); setDescription(workflow.description ?? ""); setLoadedFrom(current?.version ?? 1); }}>Descartar</Button>}
            <Button onClick={doSave} disabled={save.loading || !dirty}><Save size={14} /> {save.loading ? "Salvando..." : `Salvar como v${workflow.currentVersion + 1}`}</Button>
          </div>
        )}
        <Feedback error={save.error} message={save.message} />
      </Card>

      <div className="grid gap-5 lg:grid-cols-2">
        <Card>
          <CardTitle sub="Simulação não tem efeitos colaterais. O evento de teste dispara automações ATIVAS de verdade.">Simular e testar</CardTitle>
          <Field label="Payload de exemplo (JSON)"><Textarea className="min-h-28 font-mono text-xs" value={sample} onChange={(e) => setSample(e.target.value)} /></Field>
          <div className="mt-3 flex flex-wrap gap-2">
            <Button size="sm" variant="secondary" onClick={simulate} disabled={sim.loading}><FlaskConical size={14} /> Simular versão atual</Button>
            {canWrite && <Button size="sm" variant="secondary" onClick={testEvent} disabled={sim.loading}><Zap size={14} /> Emitir evento de teste</Button>}
          </div>
          {dirty && <p className="mt-2 text-[11px] text-warning">A simulação usa a versão salva (v{workflow.currentVersion}), não as alterações não salvas.</p>}
          <Feedback error={sim.error} message={sim.message} />
          {simLog && (
            <div className="mt-3 rounded-lg border border-line bg-bg-2 p-3">
              <p className="mb-2 text-xs font-semibold">Resultado: {RUN_LABEL[simLog.status] ?? simLog.status}</p>
              <ol className="space-y-1 text-xs">{simLog.log.map((l, i) => <li key={i}><span className="font-mono text-muted">{l.node}</span> · <span className={l.status === "error" ? "text-danger" : l.status === "waiting" ? "text-warning" : "text-success"}>{l.status}</span> — {l.message}</li>)}</ol>
            </div>
          )}
        </Card>

        <Card>
          <CardTitle sub="Rollback: carregue uma versão anterior no editor e salve-a como nova versão.">Histórico de versões</CardTitle>
          <ul className="max-h-72 space-y-1 overflow-y-auto">
            {versions.map((v) => (
              <li key={v.id} className="flex items-center justify-between gap-2 rounded-lg px-2 py-1.5 text-sm hover:bg-surface-2">
                <span>v{v.version} {v.version === workflow.currentVersion && <Badge tone="success">atual</Badge>} <span className="text-[11px] text-muted">{new Date(v.createdAt).toLocaleString(locale, { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" })} · {v.definition.nodes.length} nós</span></span>
                {canWrite && v.version !== loadedFrom && <Button size="sm" variant="ghost" onClick={() => { setNodes(v.definition.nodes); setLoadedFrom(v.version); }}><RotateCcw size={13} /> Carregar</Button>}
              </li>
            ))}
          </ul>
        </Card>
      </div>

      <Card>
        <CardTitle sub="Uma execução por evento (idempotente). Falhas podem ser reprocessadas manualmente.">Execuções recentes ({runs.length})</CardTitle>
        {!runs.length ? <p className="text-sm text-muted">Nenhuma execução ainda. Publique a automação ou emita um evento de teste.</p> : (
          <ul className="space-y-2">
            {runs.map((r) => (
              <li key={r.id} className="rounded-lg border border-line p-2.5">
                <details>
                  <summary className="flex cursor-pointer flex-wrap items-center justify-between gap-2 text-sm">
                    <span className="flex items-center gap-2">
                      <Badge tone={r.status === "completed" ? "success" : r.status === "failed" ? "danger" : "warning"}>{RUN_LABEL[r.status] ?? r.status}</Badge>
                      v{r.version} · {new Date(r.createdAt).toLocaleString(locale, { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit", second: "2-digit" })}
                    </span>
                    {r.status === "failed" && canWrite && <Button size="sm" variant="secondary" disabled={runA.loading} onClick={(e) => { e.preventDefault(); runA.run(`/api/workflows/runs/${r.id}/reprocess`, {}, { success: "Execução reprocessada." }); }}><RotateCcw size={13} /> Reprocessar</Button>}
                  </summary>
                  <ol className="mt-2 space-y-1 text-xs">{r.log.map((l, i) => <li key={i}><span className="font-mono text-muted">{l.node}</span> · {l.status} — {l.message}</li>)}</ol>
                  {r.error && <p className="mt-1 text-xs text-danger">{r.error}</p>}
                </details>
              </li>
            ))}
          </ul>
        )}
        <Feedback error={runA.error} message={runA.message} />
      </Card>
    </div>
  );
}
