export type WfNode = {
  id: string; type: "trigger" | "condition" | "action" | "wait" | "approval" | "end";
  config: Record<string, unknown>; next?: string | null; nextFalse?: string | null;
};
export type Definition = { nodes: WfNode[]; entry: string };
export type Wf = { id: string; name: string; description: string | null; triggerEvent: string; status: string; currentVersion: number; updatedAt: string };
export type WfVersion = { id: string; version: number; definition: Definition; createdAt: string };
export type WfRun = { id: string; version: number; status: string; eventId: string | null; log: { node: string; status: string; message: string; at: string }[]; error: string | null; createdAt: string; finishedAt: string | null };
export type ActionDef = { key: string; label: string; params: string[] };
export type TemplateInfo = { key: string; name: string; description: string; triggerEvent: string };

export const NODE_LABEL: Record<WfNode["type"], string> = { trigger: "Gatilho", condition: "Condição", action: "Ação", wait: "Espera", approval: "Aprovação humana", end: "Fim" };
export const STATUS_LABEL: Record<string, string> = { draft: "Rascunho", active: "Ativa", paused: "Pausada" };
export const RUN_LABEL: Record<string, string> = { running: "Executando", waiting_approval: "Aguardando aprovação", waiting: "Aguardando", completed: "Concluída", failed: "Falhou", simulated: "Simulada" };
export const PARAM_LABEL: Record<string, string> = { title: "Título", dueInHours: "Prazo (horas)", body: "Texto", status: "Novo status", subject: "Assunto", url: "URL" };

/** Payloads de exemplo por gatilho (para simulação / evento de teste). */
export const SAMPLE_PAYLOAD: Record<string, Record<string, unknown>> = {
  "lead.created": { leadId: null, source: "website" },
  "lead.qualified": { leadId: null },
  "opportunity.created": { opportunityId: null, amountCents: 15000000 },
  "opportunity.stage_changed": { opportunityId: null },
  "opportunity.lost": { opportunityId: null, reason: "Preço" },
  "opportunity.won": { opportunityId: null, amountCents: 5000000 },
  "conversation.received": { conversationId: null, channel: "webchat", intent: "pricing" },
};
