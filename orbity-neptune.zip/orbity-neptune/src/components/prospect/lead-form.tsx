"use client";
import { useState } from "react";
import { Button, Field, Input, Select } from "@/components/ui";
import { useAction, Feedback } from "@/components/ui/use-action";

const EMPTY = { title: "", companyName: "", contactName: "", contactEmail: "", contactPhone: "", segment: "", region: "", employees: "", source: "manual" };

export function LeadForm() {
  const { run, loading, error, message } = useAction();
  const [f, setF] = useState(EMPTY);
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => setF({ ...f, [k]: e.target.value });
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const r = await run<{ score: number | null }>("/api/prospect/leads", {
      title: f.title || f.companyName || f.contactName, companyName: f.companyName || undefined, contactName: f.contactName || undefined,
      contactEmail: f.contactEmail, contactPhone: f.contactPhone || undefined, segment: f.segment || undefined, region: f.region || undefined,
      employees: f.employees ? Number(f.employees) : undefined, source: f.source,
    }, { success: "Lead criado." });
    if (r) setF(EMPTY);
  };
  return (
    <form onSubmit={submit} className="space-y-3">
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Empresa"><Input value={f.companyName} onChange={set("companyName")} /></Field>
        <Field label="Título do lead" hint="Opcional — usa o nome da empresa"><Input value={f.title} onChange={set("title")} /></Field>
        <Field label="Contato"><Input value={f.contactName} onChange={set("contactName")} /></Field>
        <Field label="E-mail"><Input type="email" value={f.contactEmail} onChange={set("contactEmail")} /></Field>
        <Field label="Telefone"><Input value={f.contactPhone} onChange={set("contactPhone")} /></Field>
        <Field label="Segmento"><Input value={f.segment} onChange={set("segment")} /></Field>
        <Field label="Região / UF"><Input value={f.region} onChange={set("region")} /></Field>
        <Field label="Colaboradores"><Input type="number" min={0} value={f.employees} onChange={set("employees")} /></Field>
        <Field label="Origem">
          <Select value={f.source} onChange={set("source")}>
            <option value="manual">Manual</option><option value="prospect_ai">Prospect.AI</option><option value="website">Site / Formulário</option>
            <option value="whatsapp">WhatsApp</option><option value="referral">Indicação</option><option value="other">Outros</option>
          </Select>
        </Field>
      </div>
      <Button type="submit" disabled={loading || !(f.title || f.companyName || f.contactName).trim()}>{loading ? "Criando..." : "Criar lead"}</Button>
      <Feedback error={error} message={message} />
    </form>
  );
}
