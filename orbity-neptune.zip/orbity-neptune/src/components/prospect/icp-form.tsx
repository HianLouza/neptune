"use client";
import { useState } from "react";
import { Button, Field, Input } from "@/components/ui";
import { useAction, Feedback } from "@/components/ui/use-action";

export type IcpValue = {
  name: string; segments: string[]; regions: string[]; minEmployees?: number; maxEmployees?: number; technologies: string[]; needs: string[];
};

const join = (a?: string[]) => (a ?? []).join(", ");
const split = (s: string) => s.split(",").map((x) => x.trim()).filter(Boolean);

/** Construtor de ICP: salvar recalcula o score de todos os leads. */
export function IcpForm({ initial, canWrite }: { initial: IcpValue | null; canWrite: boolean }) {
  const { run, loading, error, message } = useAction();
  const [f, setF] = useState({
    name: initial?.name ?? "ICP Principal", segments: join(initial?.segments), regions: join(initial?.regions),
    minEmployees: initial?.minEmployees?.toString() ?? "", maxEmployees: initial?.maxEmployees?.toString() ?? "",
    technologies: join(initial?.technologies), needs: join(initial?.needs),
  });
  const save = (e: React.FormEvent) => {
    e.preventDefault();
    run<{ rescored: number }>("/api/prospect/icp", {
      name: f.name, segments: split(f.segments), regions: split(f.regions), sizes: [],
      minEmployees: f.minEmployees ? Number(f.minEmployees) : undefined, maxEmployees: f.maxEmployees ? Number(f.maxEmployees) : undefined,
      technologies: split(f.technologies), needs: split(f.needs),
    }, { success: "ICP salvo e scores recalculados." });
  };
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement>) => setF({ ...f, [k]: e.target.value });
  return (
    <form onSubmit={save} className="space-y-3">
      <Field label="Nome do ICP"><Input required minLength={2} value={f.name} onChange={set("name")} disabled={!canWrite} /></Field>
      <Field label="Segmentos" hint="Separe por vírgula"><Input value={f.segments} onChange={set("segments")} placeholder="Tecnologia, Saúde" disabled={!canWrite} /></Field>
      <Field label="Regiões / UF" hint="Separe por vírgula"><Input value={f.regions} onChange={set("regions")} placeholder="SP, RJ, MG" disabled={!canWrite} /></Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Mín. colaboradores"><Input type="number" min={0} value={f.minEmployees} onChange={set("minEmployees")} disabled={!canWrite} /></Field>
        <Field label="Máx. colaboradores"><Input type="number" min={0} value={f.maxEmployees} onChange={set("maxEmployees")} disabled={!canWrite} /></Field>
      </div>
      <Field label="Tecnologias" hint="Ex.: HubSpot, Google Workspace"><Input value={f.technologies} onChange={set("technologies")} disabled={!canWrite} /></Field>
      <Field label="Necessidades / dores"><Input value={f.needs} onChange={set("needs")} placeholder="Aumentar conversão, Automatizar follow-up" disabled={!canWrite} /></Field>
      {canWrite && <Button type="submit" disabled={loading} className="w-full">{loading ? "Salvando e recalculando..." : "Salvar ICP e recalcular scores"}</Button>}
      <Feedback error={error} message={message} />
    </form>
  );
}
