"use client";
import { Fragment, useState } from "react";
import Link from "next/link";
import { ChevronDown, ChevronRight } from "lucide-react";
import { Badge, Button, Input, Select, Table, Td, cx } from "@/components/ui";
import { useAction, Feedback } from "@/components/ui/use-action";
import { DraftWorkspace } from "@/components/ai-collab/draft-workspace";

export type LeadRow = {
  id: string; title: string; status: string; source: string; score: number | null; createdAt: string;
  companyName: string | null; companySegment: string | null; companyRegion: string | null; contactName: string | null; contactEmail: string | null;
  scoreExplanation: { factors: { name: string; weight: number; value: number; reason: string }[]; confidence: number; model: string } | null;
};

const STATUS: Record<string, { label: string; tone: "neutral" | "info" | "success" | "danger" | "primary" }> = {
  new: { label: "Novo", tone: "neutral" }, qualifying: { label: "Em qualificação", tone: "info" }, qualified: { label: "Qualificado", tone: "success" },
  disqualified: { label: "Desqualificado", tone: "danger" }, converted: { label: "Convertido", tone: "primary" },
};
const SOURCE: Record<string, string> = { prospect_ai: "Prospect.AI", website: "Site", whatsapp: "WhatsApp", referral: "Indicação", import: "Importação", manual: "Manual", other: "Outros" };

function ScorePill({ score }: { score: number | null }) {
  if (score == null) return <Badge>sem score</Badge>;
  const tone = score >= 80 ? "success" : score >= 50 ? "warning" : "neutral";
  return <Badge tone={tone}>{score >= 80 ? "🔥 " : ""}{score}</Badge>;
}

function LeadDetail({ lead, canWrite, canConvert, currency }: { lead: LeadRow; canWrite: boolean; canConvert: boolean; currency: string }) {
  const { run, loading, error, message } = useAction();
  const [amount, setAmount] = useState("");
  const [channel, setChannel] = useState<"email" | "whatsapp" | "linkedin">("email");
  const ex = lead.scoreExplanation;
  const act = (body: Record<string, unknown>, success: string) => run(`/api/prospect/leads/${lead.id}`, body, { success });
  const done = lead.status === "converted";
  return (
    <div className="grid gap-4 p-3 lg:grid-cols-2">
      <div>
        <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted">Por que este score?</p>
        {ex ? (
          <>
            <ul className="space-y-1.5 text-sm">
              {ex.factors.map((f) => (
                <li key={f.name} className="flex items-start justify-between gap-3">
                  <span><span className="font-medium">{f.name}</span> <span className="text-muted">— {f.reason}</span></span>
                  <span className="shrink-0 text-xs text-muted">{Math.round(f.value * f.weight)}/{f.weight}</span>
                </li>
              ))}
            </ul>
            <p className="mt-2 text-xs text-muted">Confiabilidade: {Math.round(ex.confidence * 100)}% · Modelo: {ex.model}</p>
          </>
        ) : <p className="text-sm text-muted">Sem explicação. Clique em “Recalcular scores”.</p>}
      </div>
      <div className="space-y-3">
        {canWrite && !done && (
          <div className="flex flex-wrap gap-2">
            {lead.status !== "qualified" && <Button size="sm" variant="secondary" disabled={loading} onClick={() => act({ action: "qualify" }, "Lead qualificado.")}>Qualificar</Button>}
            {lead.status !== "disqualified" && <Button size="sm" variant="ghost" disabled={loading} onClick={() => act({ action: "status", status: "disqualified" }, "Lead desqualificado.")}>Desqualificar</Button>}
            {lead.status === "disqualified" && <Button size="sm" variant="ghost" disabled={loading} onClick={() => act({ action: "status", status: "new" }, "Lead reaberto.")}>Reabrir</Button>}
          </div>
        )}
        {canConvert && !done && (
          <form className="flex items-end gap-2" onSubmit={(e) => { e.preventDefault(); act({ action: "convert", amountCents: Math.round(Number(amount.replace(",", ".")) * 100) }, "Oportunidade criada no CRM."); }}>
            <label className="flex-1 text-xs text-muted">Valor estimado ({currency})
              <Input inputMode="decimal" required value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="25000" className="mt-1" />
            </label>
            <Button size="sm" type="submit" disabled={loading || !amount || isNaN(Number(amount.replace(",", ".")))}>Converter em oportunidade</Button>
          </form>
        )}
        {done && <p className="text-sm text-muted">Lead convertido. <Link href="/crm" className="text-primary-2 hover:underline">Ver no CRM</Link></p>}
        {canWrite && (
          <div className="rounded-xl border border-line p-3">
            <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted">Copiloto de abordagem</p>
            <div className="mb-2 flex items-center gap-2">
              <label htmlFor={`ch-${lead.id}`} className="text-xs text-muted">Canal</label>
              <Select id={`ch-${lead.id}`} value={channel} onChange={(e) => setChannel(e.target.value as typeof channel)} className="max-w-40">
                <option value="email">E-mail</option><option value="whatsapp">WhatsApp</option><option value="linkedin">LinkedIn</option>
              </Select>
            </div>
            <DraftWorkspace key={channel} module="prospect" subjectId={lead.id} channel={channel} canWrite={canWrite} startLabel="Gerar rascunho de abordagem" />
            <p className="mt-2 text-[11px] text-muted">O Prospect.AI nunca envia mensagens: escolha a versão, copie e envie pelo seu canal.</p>
          </div>
        )}
        <Feedback error={error} message={message} />
      </div>
    </div>
  );
}

export function LeadsTable({ rows, highlight, canWrite, canConvert, locale, currency }: { rows: LeadRow[]; highlight?: string; canWrite: boolean; canConvert: boolean; locale: string; currency: string }) {
  const [open, setOpen] = useState<string | null>(highlight ?? null);
  return (
    <Table head={["", "Lead", "Empresa / Contato", "Origem", "Status", "Score", "Criado"]}>
      {rows.map((l) => {
        const isOpen = open === l.id;
        const st = STATUS[l.status] ?? { label: l.status, tone: "neutral" as const };
        return (
          <Fragment key={l.id}>
            <tr className={cx("cursor-pointer hover:bg-surface-2/50", highlight === l.id && "bg-primary/10")} onClick={() => setOpen(isOpen ? null : l.id)}>
              <Td><button aria-label={isOpen ? "Recolher" : "Expandir"} aria-expanded={isOpen}>{isOpen ? <ChevronDown size={16} /> : <ChevronRight size={16} />}</button></Td>
              <Td className="font-medium">{l.title}</Td>
              <Td><span className="block">{l.companyName ?? "—"}</span><span className="block text-xs text-muted">{[l.contactName, l.contactEmail].filter(Boolean).join(" · ") || "sem contato"}{l.companySegment ? ` · ${l.companySegment}` : ""}</span></Td>
              <Td>{SOURCE[l.source] ?? l.source}</Td>
              <Td><Badge tone={st.tone}>{st.label}</Badge></Td>
              <Td><ScorePill score={l.score} /></Td>
              <Td className="whitespace-nowrap text-xs text-muted">{new Date(l.createdAt).toLocaleDateString(locale)}</Td>
            </tr>
            {isOpen && <tr><td colSpan={7} className="bg-bg-2/50"><LeadDetail lead={l} canWrite={canWrite} canConvert={canConvert} currency={currency} /></td></tr>}
          </Fragment>
        );
      })}
    </Table>
  );
}

export function RescoreButton() {
  const { run, loading, error, message } = useAction();
  return (
    <span className="inline-flex flex-col">
      <Button variant="secondary" disabled={loading} onClick={() => run<{ updated: number }>("/api/prospect/rescore", {}, { success: "Scores recalculados." })}>{loading ? "Recalculando..." : "Recalcular scores"}</Button>
      <Feedback error={error} message={message} />
    </span>
  );
}
