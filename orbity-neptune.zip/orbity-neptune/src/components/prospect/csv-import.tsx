"use client";
import { useState } from "react";
import { Badge, Button, Field, Input, Select, Stat } from "@/components/ui";
import { useAction, Feedback } from "@/components/ui/use-action";

type Report = {
  total: number; created: number; duplicates: number; invalid: number; dryRun: boolean;
  errors: { line: number; error: string }[]; mapping: Record<string, number>; header: string[];
};
const FIELD_LABELS: Record<string, string> = { company: "Empresa", contact: "Contato", email: "E-mail", phone: "Telefone", segment: "Segmento", region: "Região", employees: "Colaboradores" };

/** Importação CSV em 2 passos: prévia (validação/deduplicação, nada gravado) → confirmação. */
export function CsvImport() {
  const { run, loading, error, message, setError } = useAction();
  const [csv, setCsv] = useState("");
  const [fileName, setFileName] = useState("");
  const [legalBasis, setLegalBasis] = useState("legitimo_interesse");
  const [mapping, setMapping] = useState<Record<string, number> | null>(null);
  const [report, setReport] = useState<Report | null>(null);

  const onFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    setReport(null); setMapping(null);
    if (!file) return;
    if (file.size > 5_000_000) { setError("Arquivo muito grande (máx. 5 MB)."); return; }
    setFileName(file.name);
    setCsv(await file.text());
  };
  const send = async (dryRun: boolean) => {
    const r = await run<Report>("/api/prospect/import", { csv, dryRun, legalBasis, sourceName: fileName || "Importação CSV", mapping: mapping ?? undefined },
      { success: dryRun ? "Prévia gerada — revise antes de confirmar." : "Importação concluída.", refresh: !dryRun });
    if (r) { setReport(r); if (dryRun) setMapping(r.mapping); }
  };

  return (
    <div className="space-y-3">
      <Field label="Arquivo CSV" hint="Separador vírgula ou ponto e vírgula; primeira linha com cabeçalhos. Máx. 5.000 linhas.">
        <Input type="file" accept=".csv,text/csv" onChange={onFile} />
      </Field>
      <Field label="Base legal (LGPD)" hint="Registrada na linhagem dos dados importados.">
        <Select value={legalBasis} onChange={(e) => setLegalBasis(e.target.value)}>
          <option value="legitimo_interesse">Legítimo interesse</option>
          <option value="consentimento">Consentimento</option>
          <option value="execucao_contrato">Execução de contrato</option>
        </Select>
      </Field>
      {report && mapping && report.header.length > 0 && (
        <div className="rounded-xl border border-line p-3">
          <p className="mb-2 text-xs font-medium text-muted">Mapeamento de colunas (sugerido automaticamente)</p>
          <div className="grid gap-2 sm:grid-cols-2">
            {Object.keys(FIELD_LABELS).map((k) => (
              <Field key={k} label={FIELD_LABELS[k]}>
                <Select value={mapping[k] ?? ""} onChange={(e) => {
                  const m = { ...mapping };
                  if (e.target.value === "") delete m[k]; else m[k] = Number(e.target.value);
                  setMapping(m);
                }}>
                  <option value="">— ignorar —</option>
                  {report.header.map((h, i) => <option key={i} value={i}>{h || `Coluna ${i + 1}`}</option>)}
                </Select>
              </Field>
            ))}
          </div>
        </div>
      )}
      <div className="flex flex-wrap gap-2">
        <Button variant="secondary" disabled={!csv || loading} onClick={() => send(true)}>{loading ? "Processando..." : report?.dryRun ? "Gerar nova prévia" : "Pré-visualizar"}</Button>
        <Button disabled={!csv || loading || !report?.dryRun} onClick={() => send(false)}>Confirmar importação</Button>
      </div>
      <Feedback error={error} message={message} />
      {report && (
        <div className="space-y-2">
          <div className="flex items-center gap-2"><Badge tone={report.dryRun ? "warning" : "success"}>{report.dryRun ? "Prévia — nada foi gravado" : "Importado"}</Badge></div>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            <Stat label="Linhas" value={report.total} />
            <Stat label={report.dryRun ? "Serão criados" : "Criados"} value={report.created} />
            <Stat label="Duplicados" value={report.duplicates} />
            <Stat label="Inválidos" value={report.invalid} />
          </div>
          {report.errors.length > 0 && (
            <ul className="max-h-40 overflow-y-auto rounded-lg border border-line p-2 text-xs text-muted">
              {report.errors.map((e, i) => <li key={i}>Linha {e.line}: {e.error}</li>)}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}
