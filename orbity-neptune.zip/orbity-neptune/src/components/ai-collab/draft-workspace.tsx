"use client";
/**
 * Espaço de colaboração humano × IA para qualquer sugestão (Closer.AI, Prospect.AI…).
 * A IA propõe. O funcionário decide. A IA aprimora. O funcionário mantém o controle.
 */
import { useCallback, useEffect, useRef, useState } from "react";
import { Bot, Check, ClipboardCopy, History, PenLine, RefreshCw, Send, Sparkles, Trash2, Wand2, X } from "lucide-react";
import { Badge, Button, SimBadge, Textarea, cx } from "@/components/ui";
import { api } from "@/lib/api-client";
import { wordDiff } from "@/server/ai/collab/text";
import { ASSIST_OPERATIONS, DISCARD_REASON_LABEL, QUICK_INSTRUCTIONS, type DraftVersion, type DraftViewData, type SendResult } from "./types";

type Props = {
  module: "closer" | "prospect";
  subjectId: string;
  channel?: string | null;
  initial?: DraftViewData | null;    // undefined = carregar ao montar
  canWrite: boolean;
  aiEnabled?: boolean;
  channelReal?: boolean;             // false = o envio fica registrado, mas não é entregue
  locale?: string;
  onSent?: (r: SendResult) => void;
  startLabel?: string;
};
type Tab = "editor" | "assist" | "history";

const lsKey = (draftId: string) => `orbity:draft:${draftId}`;
const lsGet = (k: string) => { try { return localStorage.getItem(k); } catch { return null; } };
const lsSet = (k: string, v: string | null) => { try { if (v === null) localStorage.removeItem(k); else localStorage.setItem(k, v); } catch { /* armazenamento indisponível */ } };

export function DraftWorkspace({ module, subjectId, channel, initial, canWrite, aiEnabled = true, channelReal = false, locale = "pt-BR", onSent, startLabel }: Props) {
  const [view, setView] = useState<DraftViewData | null>(initial ?? null);
  const [loaded, setLoaded] = useState(initial !== undefined);
  const [editor, setEditor] = useState("");
  const [baseId, setBaseId] = useState<string | null>(null);
  const [tab, setTab] = useState<Tab>("editor");
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [warnings, setWarnings] = useState<string[]>([]);
  const [discardOpen, setDiscardOpen] = useState(false);
  const [reason, setReason] = useState<string | null>(null);
  const [instruction, setInstruction] = useState("");
  const [freeInstruction, setFreeInstruction] = useState("");
  const [pendingNew, setPendingNew] = useState<string | null>(null);
  const [recovered, setRecovered] = useState<string | null>(null);
  const [confirmSend, setConfirmSend] = useState(false);
  const [compare, setCompare] = useState<string[]>([]);
  const [sel, setSel] = useState<{ start: number; end: number } | null>(null);
  const ref = useRef<HTMLTextAreaElement>(null);

  const versions = view?.versions ?? [];
  const byId = (id: string | null) => versions.find((v) => v.id === id) ?? null;
  const base = byId(baseId);
  const dirty = !!view && base !== null && editor !== base.content;
  const closed = !!view && ["sent", "copied", "pending_approval"].includes(view.draft.status);
  const time = (d: string) => new Date(d).toLocaleString(locale, { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" });

  /** Aplica uma resposta do servidor sem nunca apagar texto não salvo do funcionário. */
  const apply = useCallback((v: DraftViewData, opts: { keepEditor?: boolean } = {}) => {
    setView(v);
    setWarnings(v.warnings ?? []);
    const cur = v.versions.find((x) => x.id === v.currentVersionId) ?? v.versions[v.versions.length - 1];
    if (!cur) return;
    if (opts.keepEditor) { setPendingNew(cur.id); return; }
    setEditor(cur.content); setBaseId(cur.id); setPendingNew(null);
  }, []);

  // Carregamento tardio (ex.: painel do lead) e recuperação de texto não salvo após interrupção.
  useEffect(() => {
    if (initial !== undefined) { if (initial) apply(initial); return; }
    let alive = true;
    api<DraftViewData | null>(`/api/ai-drafts?module=${module}&subjectId=${subjectId}${channel ? `&channel=${encodeURIComponent(channel)}` : ""}`).then((v) => { if (alive) { if (v) apply(v); setLoaded(true); } }).catch(() => alive && setLoaded(true));
    return () => { alive = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [module, subjectId]);
  useEffect(() => {
    if (!view) return;
    const saved = lsGet(lsKey(view.draft.id));
    const cur = byId(view.currentVersionId);
    if (saved && cur && saved !== cur.content && !versions.some((v) => v.content === saved)) setRecovered(saved);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [view?.draft.id]);
  useEffect(() => { if (view) lsSet(lsKey(view.draft.id), dirty ? editor : null); }, [editor, dirty, view]);

  const call = async <T,>(label: string, url: string, body?: unknown): Promise<T | null> => {
    setBusy(label); setError(null); setNotice(null);
    try { return await api<T>(url, { body }); }
    catch (e) { setError((e as Error).message); return null; }
    finally { setBusy(null); }
  };
  const act = (body: Record<string, unknown>, label: string) => call<DraftViewData>(label, `/api/ai-drafts/${view!.draft.id}`, body);

  /** Salva o texto do editor como versão humana (preserva o trabalho antes de qualquer geração). */
  const ensureSaved = async (): Promise<{ v: DraftViewData; id: string } | null> => {
    if (!view) return null;
    if (!dirty) return { v: view, id: baseId! };
    const r = await act({ action: "edit", content: editor, baseVersionId: baseId }, "Salvando sua edição…");
    if (!r) return null;
    const cur = r.versions.find((x) => x.id === r.currentVersionId)!;
    setView(r); setBaseId(cur.id);
    return { v: r, id: cur.id };
  };

  const start = async () => {
    const r = await call<DraftViewData>("Gerando sugestão…", "/api/ai-drafts", { module, subjectId, channel: channel ?? null });
    if (r) { apply(r); setTab("editor"); }
  };
  const startManual = async () => {
    const r = await call<DraftViewData>("Abrindo editor…", "/api/ai-drafts", { module, subjectId, channel: channel ?? null, manual: true, content: "" });
    if (r) { apply(r); setTab("editor"); setTimeout(() => ref.current?.focus(), 0); }
  };

  const generate = async (operation: string, extra: { instruction?: string; selection?: { start: number; end: number } } = {}) => {
    const wasDirty = dirty;
    const saved = await ensureSaved();
    if (!saved) return;
    const r = await act({ action: "regenerate", operation, baseVersionId: saved.id, ...extra }, "A IA está gerando uma nova versão…");
    if (!r) return;
    apply(r, { keepEditor: wasDirty && operation !== "improve_selection" });
    if (wasDirty && operation !== "improve_selection") setNotice("Nova sugestão pronta — sua edição foi preservada e salva no histórico.");
    setDiscardOpen(false); setInstruction(""); setSel(null);
  };

  const discard = async () => {
    if (!baseId) return;
    const r = await act({ action: "discard", versionId: baseId, reason }, "Descartando…");
    if (r) { setView(r); setDiscardOpen(true); setNotice("Sugestão descartada. Ela não será enviada nem repetida. Escolha como continuar."); }
  };
  const writeManually = async (prefill: boolean) => {
    const r = await act({ action: "manual", content: prefill ? editor : "" }, "Abrindo editor…");
    if (r) { apply(r); setDiscardOpen(false); setTab("editor"); setTimeout(() => ref.current?.focus(), 0); }
  };
  const saveEdit = async () => { const s = await ensureSaved(); if (s) setNotice("Edição salva como nova versão."); };
  const loadVersion = async (v: DraftVersion) => {
    if (dirty) { const s = await ensureSaved(); if (!s) return; }
    setEditor(v.content); setBaseId(v.id); setPendingNew(null); setTab("editor");
  };
  const restore = async (v: DraftVersion) => { const r = await act({ action: "restore", versionId: v.id }, "Recuperando versão…"); if (r) { apply(r); setTab("editor"); } };
  const insertAtCursor = (v: DraftVersion) => {
    const el = ref.current; const pos = el ? el.selectionStart : editor.length;
    setEditor(editor.slice(0, pos) + (pos && !/\s$/.test(editor.slice(0, pos)) ? " " : "") + v.content + editor.slice(pos));
    setTab("editor"); setNotice(`Texto da versão ${v.seq} inserido no editor. Lembre de revisar antes de enviar.`);
  };

  const send = async () => {
    const saved = await ensureSaved();
    if (!saved) return;
    if (view!.policy.mode === "copy") {
      const text = byId(saved.id)?.content ?? editor;
      try { await navigator.clipboard.writeText(text); } catch { ref.current?.select(); }
      const r = await act({ action: "copy", versionId: saved.id }, "Registrando…");
      if (r) { apply(r); setNotice("Texto copiado. Cole no seu canal para enviar — o sistema não envia esta mensagem."); }
      setConfirmSend(false);
      return;
    }
    const r = await call<SendResult>("Enviando…", `/api/ai-drafts/${view!.draft.id}`, { action: "send", versionId: saved.id });
    setConfirmSend(false);
    if (!r) return;
    apply(r.view); lsSet(lsKey(view!.draft.id), null);
    setNotice(r.notice ?? (r.status === "sent" ? "Mensagem enviada." : "Enviado para aprovação."));
    onSent?.(r);
  };

  /* ------------------------------------------------------------------ render */

  if (!loaded) return <p className="text-xs text-muted" role="status">Carregando sugestões…</p>;

  if (!view) {
    if (!canWrite) return null;
    return (
      <div className="flex flex-wrap items-center gap-2">
        <Button type="button" size="sm" variant="secondary" onClick={start} disabled={!!busy || !aiEnabled} title={aiEnabled ? "" : "IA desativada"}>
          <Sparkles size={14} /> {busy ? busy : startLabel ?? "Sugerir resposta com IA"}
        </Button>
        {module !== "closer" && <Button type="button" size="sm" variant="ghost" onClick={startManual} disabled={!!busy}>Escrever manualmente</Button>}
        {!aiEnabled && <span className="text-xs text-muted">IA desativada aqui — escreva manualmente.</span>}
        {error && <p role="alert" className="w-full text-xs text-danger">{error}</p>}
      </div>
    );
  }

  const cur = byId(view.currentVersionId);
  const shown = base ?? cur;
  const anySim = shown?.origin === "ai" && shown.simulated;
  const sentLike = view.draft.status === "sent" || view.draft.status === "copied";
  const figs = shown?.figures ?? [];

  return (
    <section aria-label="Assistente de Respostas" className="rounded-xl border border-primary-2/30 bg-primary/5">
      <header className="flex flex-wrap items-center justify-between gap-2 border-b border-line px-3 py-2">
        <div className="flex flex-wrap items-center gap-1.5">
          <Sparkles size={14} className="text-primary-2" aria-hidden />
          <span className="text-sm font-semibold">Assistente de Respostas</span>
          {shown?.origin === "ai" ? <Badge tone="primary">Sugestão da IA</Badge> : <Badge tone="info">Texto da equipe</Badge>}
          {shown?.origin === "ai" && (anySim ? <SimBadge label="Simulado (sem IA real)" /> : <Badge tone="success">IA real</Badge>)}
          {view.needsHuman && <Badge tone="warning">Base de conhecimento sem resposta — considere atendimento humano</Badge>}
          {view.draft.status === "pending_approval" && <Badge tone="warning">Aguardando aprovação</Badge>}
          {sentLike && <Badge tone="success">{view.draft.status === "sent" ? "Enviada" : "Copiada"}</Badge>}
          {view.draft.status === "manual" && <Badge tone="neutral">Você assumiu a resposta</Badge>}
        </div>
        <nav className="flex gap-1" aria-label="Seções do assistente">
          {([["editor", "Resposta", PenLine], ["assist", "Pedir à IA", Wand2], ["history", `Versões (${versions.length})`, History]] as const).map(([k, l, I]) => (
            <button key={k} type="button" onClick={() => setTab(k)} aria-pressed={tab === k}
              className={cx("flex items-center gap-1 rounded-md px-2 py-1 text-xs", tab === k ? "bg-primary/25 text-primary-2" : "text-muted hover:text-fg")}>
              <I size={12} aria-hidden /> {l}
            </button>
          ))}
        </nav>
      </header>

      <div className="space-y-3 p-3">
        {busy && <p role="status" aria-live="polite" className="flex items-center gap-2 text-xs text-primary-2"><RefreshCw size={12} className="animate-spin" aria-hidden /> {busy}</p>}
        {error && <p role="alert" className="rounded-lg border border-danger/40 bg-danger/10 px-3 py-2 text-xs text-danger">{error}</p>}
        {notice && !error && <p role="status" className="rounded-lg border border-line bg-surface-2/60 px-3 py-2 text-xs">{notice}</p>}
        {recovered && (
          <div className="flex flex-wrap items-center gap-2 rounded-lg border border-warning/40 bg-warning/10 px-3 py-2 text-xs">
            <span>Encontramos um texto não salvo desta resposta (de uma sessão interrompida).</span>
            <Button size="sm" variant="secondary" onClick={() => { setEditor(recovered); setRecovered(null); setTab("editor"); }}>Usar texto recuperado</Button>
            <Button size="sm" variant="ghost" onClick={() => { setRecovered(null); lsSet(lsKey(view.draft.id), null); }}>Descartar</Button>
          </div>
        )}
        {pendingNew && (
          <div className="flex flex-wrap items-center gap-2 rounded-lg border border-primary-2/40 bg-primary/10 px-3 py-2 text-xs">
            <span>Nova sugestão pronta (versão {byId(pendingNew)?.seq}). Sua edição continua no editor.</span>
            <Button size="sm" variant="secondary" onClick={() => { const v = byId(pendingNew); if (v) { setEditor(v.content); setBaseId(v.id); } setPendingNew(null); }}>Ver nova</Button>
            <Button size="sm" variant="ghost" onClick={() => setPendingNew(null)}>Continuar editando</Button>
          </div>
        )}

        {tab === "editor" && (
          <div className="space-y-2">
            <label htmlFor={`draft-${view.draft.id}`} className="sr-only">Texto da resposta (editável)</label>
            <textarea id={`draft-${view.draft.id}`} ref={ref} value={editor} spellCheck lang="pt-BR" disabled={closed}
              onChange={(e) => setEditor(e.target.value)} onSelect={(e) => { const t = e.currentTarget; setSel(t.selectionEnd > t.selectionStart ? { start: t.selectionStart, end: t.selectionEnd } : null); }}
              className="input min-h-32 text-sm" placeholder="Escreva ou edite a resposta…" />
            <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-muted">
              <span>
                {shown ? <>Versão {shown.seq} · {shown.operationLabel}{shown.instruction ? ` · “${shown.instruction}”` : ""}</> : null}
                {dirty && <span className="ml-1 text-warning">· edição não salva (guardada neste navegador)</span>}
              </span>
              <span>Fontes: {shown?.sources.length ? shown.sources.map((s) => s.title + (s.similarity ? ` (${Math.round(s.similarity * 100)}%)` : "")).join(", ") : "nenhuma"}</span>
            </div>
            {figs.length > 0 && <p role="alert" className="rounded-lg border border-warning/40 bg-warning/10 px-3 py-2 text-xs text-warning">Valores sem fonte confirmada: {figs.join(", ")}. A IA não pode inventar preços, prazos ou condições — confira antes de enviar.</p>}
            {warnings.filter((w) => !/simulado/.test(w) && !/Valores sem fonte/.test(w)).map((w) => <p key={w} className="text-xs text-warning">{w}</p>)}

            {!closed && view.policy.canWrite && (
              <>
                {sel && <Button size="sm" variant="ghost" onClick={() => generate("improve_selection", { selection: sel })} disabled={!!busy || !aiEnabled}><Wand2 size={13} /> Melhorar trecho selecionado</Button>}
                {!confirmSend ? (
                  <div className="flex flex-wrap gap-2">
                    <Button size="sm" onClick={() => setConfirmSend(true)} disabled={!!busy || !editor.trim() || view.policy.mode === "none"}>
                      {view.policy.mode === "copy" ? <ClipboardCopy size={14} /> : <Send size={14} />} {view.policy.mode === "copy" ? "Copiar texto" : view.policy.mode === "approval" && shown?.origin !== "human" ? "Enviar para aprovação" : "Aprovar e enviar"}
                    </Button>
                    <Button size="sm" variant="secondary" onClick={() => { ref.current?.focus(); setNotice("Edite à vontade: cada alteração salva vira uma nova versão."); }}><PenLine size={14} /> Editar antes de enviar</Button>
                    {dirty && <Button size="sm" variant="secondary" onClick={saveEdit} disabled={!!busy}><Check size={14} /> Salvar edição</Button>}
                    <Button size="sm" variant="ghost" onClick={() => setDiscardOpen((o) => !o)} aria-expanded={discardOpen}><Trash2 size={14} /> Descartar</Button>
                  </div>
                ) : (
                  <div role="group" aria-label="Confirmar envio" className="space-y-2 rounded-lg border border-line bg-surface-2/60 p-3 text-xs">
                    <p className="font-semibold">{view.policy.mode === "copy" ? "Copiar este texto?" : "Confirmar envio desta resposta?"}</p>
                    <p className="text-muted">{view.policy.reason}</p>
                    {view.policy.mode !== "copy" && !channelReal && <p className="text-warning">O canal não tem envio real: a mensagem fica registrada na conversa, mas NÃO chega ao cliente.</p>}
                    <div className="flex flex-wrap gap-2">
                      <Button size="sm" onClick={send} disabled={!!busy}>{view.policy.mode === "copy" ? "Copiar e registrar" : "Confirmar"}</Button>
                      <Button size="sm" variant="ghost" onClick={() => setConfirmSend(false)}>Voltar</Button>
                    </div>
                  </div>
                )}
                <p className="text-[11px] text-muted">{view.policy.reason}</p>
              </>
            )}

            {discardOpen && !closed && (
              <div className="space-y-3 rounded-lg border border-line bg-surface p-3" aria-label="Como continuar">
                {!byId(baseId)?.rejected ? (
                  <div className="space-y-2">
                    <p className="text-xs font-semibold">Descartar esta versão? (opcional: diga o motivo — isso não penaliza ninguém)</p>
                    <div className="flex flex-wrap gap-1.5">
                      {Object.entries(DISCARD_REASON_LABEL).map(([k, l]) => (
                        <button key={k} type="button" onClick={() => setReason(reason === k ? null : k)} aria-pressed={reason === k}
                          className={cx("rounded-full border px-2.5 py-1 text-[11px]", reason === k ? "border-primary-2 bg-primary/20 text-primary-2" : "border-line text-muted")}>{l}</button>
                      ))}
                    </div>
                    <Button size="sm" variant="danger" onClick={discard} disabled={!!busy}><X size={13} /> Descartar versão {byId(baseId)?.seq}</Button>
                  </div>
                ) : <p className="text-xs text-muted">Versão {byId(baseId)?.seq} descartada. Como quer continuar?</p>}
                <div className="grid gap-2 md:grid-cols-3">
                  <div className="rounded-lg border border-line p-2.5">
                    <p className="text-xs font-semibold">A · Gerar outra sugestão</p>
                    <p className="mb-2 text-[11px] text-muted">Nova abordagem, diferente das descartadas.</p>
                    <Button size="sm" variant="secondary" onClick={() => generate("regenerate")} disabled={!!busy || !aiEnabled}><RefreshCw size={13} /> Gerar outra</Button>
                  </div>
                  <div className="rounded-lg border border-line p-2.5">
                    <p className="text-xs font-semibold">B · Pedir com instruções</p>
                    <label htmlFor={`instr-${view.draft.id}`} className="sr-only">Instrução para a IA</label>
                    <Textarea id={`instr-${view.draft.id}`} value={instruction} onChange={(e) => setInstruction(e.target.value)} className="mt-1 min-h-16 text-xs" placeholder="Ex.: seja mais objetivo e não mencione preços" />
                    <div className="mt-1 flex flex-wrap gap-1">
                      {QUICK_INSTRUCTIONS.map((q) => <button key={q} type="button" onClick={() => setInstruction(instruction ? `${instruction}; ${q.toLowerCase()}` : q)} className="rounded-full border border-line px-2 py-0.5 text-[10px] text-muted hover:text-fg">{q}</button>)}
                    </div>
                    <Button size="sm" variant="secondary" className="mt-2" onClick={() => generate("instruct", { instruction })} disabled={!!busy || !instruction.trim() || !aiEnabled}><Bot size={13} /> Gerar com instruções</Button>
                  </div>
                  <div className="rounded-lg border border-line p-2.5">
                    <p className="text-xs font-semibold">C · Escrever manualmente</p>
                    <p className="mb-2 text-[11px] text-muted">Você assume a resposta. A IA não altera seu texto.</p>
                    <div className="flex flex-wrap gap-1.5">
                      <Button size="sm" variant="secondary" onClick={() => writeManually(false)} disabled={!!busy}><PenLine size={13} /> Do zero</Button>
                      <Button size="sm" variant="ghost" onClick={() => writeManually(true)} disabled={!!busy}>Partir deste texto</Button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {tab === "assist" && (
          <div className="space-y-3">
            {closed ? <p className="text-xs text-muted">Esta resposta já foi {view.draft.status === "pending_approval" ? "enviada para aprovação" : "usada"}. Gere uma nova sugestão para continuar.</p> : (
              <>
                <p className="text-xs text-muted">Peça quantas versões quiser. Cada pedido cria uma nova versão; seu texto nunca é apagado.</p>
                <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
                  {ASSIST_OPERATIONS.map((o) => (
                    <button key={o.op} type="button" onClick={() => generate(o.op)} disabled={!!busy || !aiEnabled}
                      className="rounded-lg border border-line p-2.5 text-left hover:border-primary-2 disabled:opacity-50">
                      <span className="block text-xs font-semibold">{o.label}</span><span className="block text-[11px] text-muted">{o.hint}</span>
                    </button>
                  ))}
                </div>
                <div className="rounded-lg border border-line p-2.5">
                  <label htmlFor={`free-${view.draft.id}`} className="text-xs font-semibold">Resposta personalizada por instrução</label>
                  <Textarea id={`free-${view.draft.id}`} value={freeInstruction} onChange={(e) => setFreeInstruction(e.target.value)} className="mt-1 min-h-16 text-xs" placeholder="Ex.: responda à objeção sobre prazo de implantação, com tom consultivo" />
                  <div className="mt-2 flex flex-wrap gap-2">
                    <Button size="sm" variant="secondary" onClick={() => generate("instruct", { instruction: freeInstruction })} disabled={!!busy || !freeInstruction.trim() || !aiEnabled}>Aplicar na versão atual</Button>
                    <Button size="sm" variant="ghost" onClick={() => generate("custom", { instruction: freeInstruction })} disabled={!!busy || !freeInstruction.trim() || !aiEnabled}>Criar resposta nova</Button>
                  </div>
                </div>
                {!aiEnabled && <p className="text-xs text-warning">A IA está desativada aqui. Você pode continuar editando manualmente.</p>}
              </>
            )}
          </div>
        )}

        {tab === "history" && (
          <div className="space-y-2">
            <p className="text-[11px] text-muted">Marque duas versões para comparar. Você pode continuar a edição de qualquer versão não enviada.</p>
            {compare.length === 2 && <DiffView a={byId(compare[0])} b={byId(compare[1])} onClose={() => setCompare([])} />}
            <ol className="max-h-80 space-y-2 overflow-y-auto">
              {[...versions].reverse().map((v) => (
                <li key={v.id} className={cx("rounded-lg border p-2.5 text-xs", v.id === baseId ? "border-primary-2" : "border-line", v.rejected && "opacity-70")}>
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <label className="flex items-center gap-1.5">
                      <input type="checkbox" checked={compare.includes(v.id)} onChange={(e) => setCompare(e.target.checked ? [...compare, v.id].slice(-2) : compare.filter((x) => x !== v.id))} aria-label={`Comparar versão ${v.seq}`} />
                      <span className="font-semibold">v{v.seq}</span>
                    </label>
                    <span className="flex flex-wrap gap-1">
                      <Badge tone={v.origin === "ai" ? "primary" : "info"}>{v.origin === "ai" ? "IA" : "Equipe"}</Badge>
                      <Badge tone="neutral">{v.operationLabel}</Badge>
                      {v.origin === "ai" && v.simulated && <Badge tone="warning">simulado</Badge>}
                      {v.rejected && <Badge tone="danger">descartada</Badge>}
                      {view.draft.sentVersionId === v.id && <Badge tone="success">{view.draft.status === "copied" ? "copiada" : "enviada"}</Badge>}
                    </span>
                  </div>
                  <p className="mt-1 text-muted">{v.createdByName} · {time(v.createdAt)}{v.instruction ? ` · “${v.instruction}”` : ""}</p>
                  <p className="mt-1 line-clamp-3 whitespace-pre-wrap">{v.content || <em className="text-muted">(vazio)</em>}</p>
                  {!closed && (
                    <div className="mt-2 flex flex-wrap gap-1.5">
                      <Button size="sm" variant="ghost" onClick={() => (v.rejected ? restore(v) : loadVersion(v))}>{v.rejected ? "Recuperar" : "Continuar editando"}</Button>
                      <Button size="sm" variant="ghost" onClick={() => insertAtCursor(v)}>Inserir no editor</Button>
                    </div>
                  )}
                </li>
              ))}
            </ol>
          </div>
        )}

        {sentLike && canWrite && (
          <Button size="sm" variant="secondary" onClick={() => { setView(null); setLoaded(true); setEditor(""); setBaseId(null); }}><Sparkles size={13} /> Nova sugestão</Button>
        )}
      </div>
    </section>
  );
}

function DiffView({ a, b, onClose }: { a: DraftVersion | null; b: DraftVersion | null; onClose: () => void }) {
  if (!a || !b) return null;
  const [older, newer] = a.seq < b.seq ? [a, b] : [b, a];
  const parts = wordDiff(older.content, newer.content);
  return (
    <div className="rounded-lg border border-line bg-surface p-3 text-xs">
      <div className="mb-2 flex items-center justify-between"><span className="font-semibold">Comparando v{older.seq} → v{newer.seq}</span><Button size="sm" variant="ghost" onClick={onClose}>Fechar</Button></div>
      <p className="whitespace-pre-wrap leading-relaxed">
        {parts.map((p, i) => p.type === "same" ? <span key={i}>{p.text}</span>
          : p.type === "added" ? <ins key={i} className="rounded bg-success/20 px-0.5 no-underline">{p.text}</ins>
          : <del key={i} className="rounded bg-danger/20 px-0.5">{p.text}</del>)}
      </p>
      <p className="mt-2 text-[11px] text-muted"><ins className="bg-success/20 no-underline">verde</ins> = acrescentado · <del className="bg-danger/20">vermelho</del> = removido</p>
    </div>
  );
}
