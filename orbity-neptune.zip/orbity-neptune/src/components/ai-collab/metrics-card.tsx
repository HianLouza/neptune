import { Badge, Card, CardTitle, Empty, Stat, Table, Td } from "@/components/ui";
import type { AiSuggestionMetrics } from "@/server/ai/collab/metrics";
import { DISCARD_REASON_LABEL } from "./types";

const AGENT_LABEL: Record<string, string> = { support_chat: "Agente de Atendimento (Closer.AI)", outreach: "Agente de Abordagem (Prospect.AI)" };
const fmt = (v: number | null, suffix = "", digits = 1) => (v == null ? "n/d" : `${v.toLocaleString("pt-BR", { maximumFractionDigits: digits })}${suffix}`);

/** Indicadores da colaboração humano × IA nas sugestões. "Aprovada" não significa "melhor". */
export function AiSuggestionMetricsCard({ m, title = "Sugestões de IA: colaboração com a equipe" }: { m: AiSuggestionMetrics; title?: string }) {
  const t = m.totals;
  return (
    <Card>
      <CardTitle sub={`Últimos ${m.days} dias · Closer.AI e Prospect.AI`}>{title}</CardTitle>
      {!t.drafts ? <Empty title="Nenhuma sugestão de IA no período">Os indicadores aparecem quando a equipe usar o Assistente de Respostas.</Empty> : (
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4 xl:grid-cols-8">
            <Stat label="Sugestões geradas" value={t.generated} hint={`${t.drafts} respostas`} />
            <Stat label="Usadas (enviadas/copiadas)" value={t.used} hint={`${t.sent} enviadas · ${t.copied} copiadas`} />
            <Stat label="Versões descartadas" value={t.discardedVersions} />
            <Stat label="Regenerações por resposta" value={fmt(t.avgRegenerations)} />
            <Stat label="Editadas antes do envio" value={fmt(t.editedPct, "%")} />
            <Stat label="Enviadas sem alteração" value={fmt(t.unchangedPct, "%")} />
            <Stat label="Escritas pela equipe" value={fmt(t.manualPct, "%")} />
            <Stat label="Tempo médio até o envio" value={t.avgMinutesToSend == null ? "n/d" : `${fmt(t.avgMinutesToSend, " min", 0)}`} hint={t.pendingApproval ? `${t.pendingApproval} aguardando aprovação` : undefined} />
          </div>
          <div className="grid gap-4 lg:grid-cols-3">
            <div>
              <p className="mb-1 text-xs font-semibold text-muted">Motivos de descarte (opcionais)</p>
              {Object.keys(m.reasons).length ? (
                <ul className="space-y-1 text-sm">{Object.entries(m.reasons).sort((a, b) => b[1] - a[1]).map(([k, v]) => <li key={k} className="flex justify-between gap-2"><span>{DISCARD_REASON_LABEL[k] ?? (k === "sem_motivo" ? "Sem motivo informado" : k)}</span><Badge>{v}</Badge></li>)}</ul>
              ) : <p className="text-xs text-muted">Nenhum descarte.</p>}
            </div>
            <div>
              <p className="mb-1 text-xs font-semibold text-muted">Por agente de IA</p>
              <Table head={["Agente", "Respostas", "Geradas", "Usadas", "Descartadas"]}>
                {m.byAgent.map((a) => <tr key={a.agentKey}><Td>{AGENT_LABEL[a.agentKey] ?? a.agentKey}</Td><Td>{a.drafts}</Td><Td>{a.generated}</Td><Td>{a.used}</Td><Td>{a.discarded}</Td></tr>)}
              </Table>
            </div>
            <div>
              <p className="mb-1 text-xs font-semibold text-muted">Associação com conversão</p>
              <p className="text-2xl font-bold">{m.conversion.ratePct == null ? "n/d" : `${fmt(m.conversion.ratePct, "%")}`}</p>
              <p className="text-xs text-muted">{m.conversion.associatedWins} de {m.conversion.sample} conversas respondidas tiveram negócio ganho em até 30 dias.</p>
              <p className="mt-1 text-[11px] text-warning">{m.conversion.note}</p>
            </div>
          </div>
          <div className="grid gap-4 lg:grid-cols-2">
            <div>
              <p className="mb-1 text-xs font-semibold text-muted">Por funcionário</p>
              <Table head={["Pessoa", "Equipe", "Respostas", "Usadas", "Regenerações"]}>
                {m.byUser.slice(0, 12).map((u) => <tr key={u.userId}><Td>{u.name}</Td><Td>{u.team ?? "—"}</Td><Td>{u.drafts}</Td><Td>{u.used}</Td><Td>{u.regenerations}</Td></tr>)}
              </Table>
            </div>
            <div>
              <p className="mb-1 text-xs font-semibold text-muted">Por equipe</p>
              <Table head={["Equipe", "Respostas", "Usadas"]}>
                {m.byTeam.map((t2) => <tr key={t2.team}><Td>{t2.team}</Td><Td>{t2.drafts}</Td><Td>{t2.used}</Td></tr>)}
              </Table>
            </div>
          </div>
          <ul className="list-disc space-y-0.5 pl-5 text-[11px] text-muted">{m.notes.map((n) => <li key={n}>{n}</li>)}</ul>
        </div>
      )}
    </Card>
  );
}
