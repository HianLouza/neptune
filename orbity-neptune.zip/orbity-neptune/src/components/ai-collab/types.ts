/** Tipos serializados (datas em ISO) do serviço de colaboração humano × IA, usados nos componentes. */
export type DraftVersion = {
  id: string; seq: number; origin: "ai" | "human"; operation: string; operationLabel: string; instruction: string | null; content: string;
  basedOnVersionId: string | null; simulated: boolean; provider: string | null; model: string | null;
  sources: { title: string; similarity?: number }[]; rejected: boolean; createdBy: string; createdByName: string; createdAt: string; figures: string[];
};
export type DraftPolicy = { mode: "send" | "approval" | "copy" | "none"; canWrite: boolean; label: string; reason: string };
export type DraftViewData = {
  draft: { id: string; module: string; subjectType: string; subjectId: string; agentKey: string; channel: string | null; status: string; createdAt: string; sentAt: string | null; sentVersionId: string | null; discardReason: string | null };
  versions: DraftVersion[]; currentVersionId: string | null; policy: DraftPolicy; regenerations: number; warnings: string[]; needsHuman: boolean;
};
export type SendResult = { status: "sent" | "pending_approval"; approvalId: string | null; delivered: boolean; notice: string | null; view: DraftViewData };

export const DISCARD_REASON_LABEL: Record<string, string> = {
  outra_abordagem: "Prefiro outra abordagem", tom: "Tom não combina", informacao_incorreta: "Informação incorreta", muito_longa: "Longa demais",
  muito_curta: "Curta demais", vou_escrever: "Vou escrever eu mesmo", outro: "Outro motivo",
};

export const QUICK_INSTRUCTIONS = [
  "Seja mais persuasivo", "Use uma linguagem mais formal", "Seja mais objetivo", "Demonstre mais empatia", "Não mencione preços",
  "Apresente outra abordagem comercial", "Responda à objeção do cliente", "Faça uma proposta mais atrativa",
];

/** Operações do "Assistente de Respostas" (§4 do prompt). */
export const ASSIST_OPERATIONS: { op: string; label: string; hint: string }[] = [
  { op: "regenerate", label: "Nova resposta", hint: "Outra sugestão com abordagem diferente" },
  { op: "persuasive", label: "Mais persuasiva", hint: "Benefício claro e chamada para ação" },
  { op: "tone_formal", label: "Tom formal", hint: "Linguagem profissional" },
  { op: "tone_informal", label: "Tom próximo", hint: "Mais natural, mantendo o respeito" },
  { op: "tone_empathetic", label: "Mais empatia", hint: "Reconhece a situação do cliente" },
  { op: "shorten", label: "Resumir", hint: "Só o essencial" },
  { op: "expand", label: "Expandir", hint: "Mais detalhes das fontes" },
  { op: "fix", label: "Corrigir informações", hint: "Alinha com a base de conhecimento" },
  { op: "adapt", label: "Adaptar ao cliente", hint: "Usa empresa, cargo e histórico" },
  { op: "negotiate", label: "Sugestão de negociação", hint: "Conduz sem prometer condições" },
  { op: "spellcheck", label: "Revisar ortografia", hint: "Corrige sem mudar o sentido" },
];
