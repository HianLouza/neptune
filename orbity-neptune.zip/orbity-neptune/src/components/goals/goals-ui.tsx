"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Check, X, RotateCcw } from "lucide-react";
import { useAction, Feedback } from "@/components/ui/use-action";
import { Button, Field, Input, Select, Textarea } from "@/components/ui";

export function TaskFilter({ mine }: { mine: boolean }) {
  const router = useRouter();
  return (
    <div className="inline-flex rounded-lg border border-line p-0.5 text-xs">
      <button onClick={() => router.push("/tarefas")} className={`rounded-md px-3 py-1 ${!mine ? "bg-surface-2 text-fg" : "text-muted"}`}>Todas</button>
      <button onClick={() => router.push("/tarefas?minhas=1")} className={`rounded-md px-3 py-1 ${mine ? "bg-surface-2 text-fg" : "text-muted"}`}>Minhas</button>
    </div>
  );
}

export function NewTaskForm({ users }: { users: { id: string; name: string }[] }) {
  const [f, setF] = useState({ title: "", description: "", priority: "medium", dueAt: "", assigneeId: "" });
  const { run, loading, error, message } = useAction();
  return (
    <form className="space-y-2" onSubmit={async (e) => {
      e.preventDefault();
      const r = await run("/api/tasks", { title: f.title, description: f.description || undefined, priority: f.priority, dueAt: f.dueAt ? new Date(f.dueAt).toISOString() : undefined, assigneeId: f.assigneeId || undefined }, { success: "Tarefa criada." });
      if (r) setF({ title: "", description: "", priority: "medium", dueAt: "", assigneeId: "" });
    }}>
      <Input required minLength={2} placeholder="Título da tarefa" value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} aria-label="Título" />
      <Textarea className="min-h-14" placeholder="Descrição (opcional)" value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} aria-label="Descrição" />
      <div className="grid gap-2 sm:grid-cols-3">
        <Select aria-label="Prioridade" value={f.priority} onChange={(e) => setF({ ...f, priority: e.target.value })}><option value="low">Baixa</option><option value="medium">Média</option><option value="high">Alta</option></Select>
        <Input aria-label="Prazo" type="datetime-local" value={f.dueAt} onChange={(e) => setF({ ...f, dueAt: e.target.value })} />
        <Select aria-label="Responsável" value={f.assigneeId} onChange={(e) => setF({ ...f, assigneeId: e.target.value })}><option value="">Eu mesmo</option>{users.map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}</Select>
      </div>
      <Button type="submit" size="sm" disabled={loading}>{loading ? "Criando..." : "Criar tarefa"}</Button>
      <Feedback error={error} message={message} />
    </form>
  );
}

export function TaskActions({ id, status }: { id: string; status: string }) {
  const { run, loading, error } = useAction();
  const set = (s: string) => run(`/api/tasks/${id}`, { status: s }, { method: "PATCH" });
  return (
    <span className="inline-flex items-center gap-1">
      {status === "open" ? (
        <>
          <button aria-label="Concluir" title="Concluir" disabled={loading} onClick={() => set("done")} className="rounded p-1 text-success hover:bg-surface-2"><Check size={16} /></button>
          <button aria-label="Cancelar" title="Cancelar" disabled={loading} onClick={() => set("canceled")} className="rounded p-1 text-muted hover:bg-surface-2 hover:text-danger"><X size={16} /></button>
        </>
      ) : <button aria-label="Reabrir" title="Reabrir" disabled={loading} onClick={() => set("open")} className="rounded p-1 text-muted hover:bg-surface-2"><RotateCcw size={14} /></button>}
      {error && <span className="text-[10px] text-danger">{error}</span>}
    </span>
  );
}

export function NewGoalForm({ users, currencySymbol }: { users: { id: string; name: string }[]; currencySymbol: string }) {
  const today = new Date();
  const first = new Date(today.getFullYear(), today.getMonth(), 1).toISOString().slice(0, 10);
  const last = new Date(today.getFullYear(), today.getMonth() + 1, 0).toISOString().slice(0, 10);
  const [f, setF] = useState({ name: "", metric: "revenue", scope: "organization", scopeId: "", target: "", start: first, end: last });
  const { run, loading, error, message } = useAction();
  return (
    <form className="space-y-2" onSubmit={async (e) => {
      e.preventDefault();
      const target = Number(f.target.replace(/\./g, "").replace(",", "."));
      const r = await run("/api/goals", {
        name: f.name, metric: f.metric, scope: f.scope, scopeId: f.scope === "organization" ? undefined : f.scopeId || undefined,
        targetValue: f.metric === "revenue" ? Math.round(target * 100) : Math.round(target),
        periodStart: new Date(f.start + "T00:00:00").toISOString(), periodEnd: new Date(f.end + "T23:59:59").toISOString(),
      }, { success: "Meta criada." });
      if (r) setF({ ...f, name: "", target: "" });
    }}>
      <Input required minLength={2} placeholder="Nome da meta" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} aria-label="Nome da meta" />
      <div className="grid gap-2 sm:grid-cols-2">
        <Select aria-label="Métrica" value={f.metric} onChange={(e) => setF({ ...f, metric: e.target.value })}><option value="revenue">Receita</option><option value="deals_won">Negócios ganhos</option></Select>
        <Select aria-label="Escopo" value={f.scope} onChange={(e) => setF({ ...f, scope: e.target.value, scopeId: "" })}><option value="organization">Organização</option><option value="user">Vendedor</option><option value="channel">Canal (origem)</option></Select>
      </div>
      {f.scope === "user" && <Select required aria-label="Vendedor" value={f.scopeId} onChange={(e) => setF({ ...f, scopeId: e.target.value })}><option value="">Selecione o vendedor</option>{users.map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}</Select>}
      {f.scope === "channel" && <Select required aria-label="Canal" value={f.scopeId} onChange={(e) => setF({ ...f, scopeId: e.target.value })}><option value="">Selecione o canal</option>{[["prospect_ai", "Prospect.AI"], ["website", "Site"], ["whatsapp", "WhatsApp"], ["referral", "Indicações"], ["import", "Importação"], ["manual", "Manual"]].map(([k, l]) => <option key={k} value={k}>{l}</option>)}</Select>}
      <Field label={f.metric === "revenue" ? `Valor-alvo (${currencySymbol})` : "Quantidade-alvo"}><Input required inputMode="decimal" value={f.target} onChange={(e) => setF({ ...f, target: e.target.value })} /></Field>
      <div className="grid grid-cols-2 gap-2">
        <Field label="Início"><Input type="date" required value={f.start} onChange={(e) => setF({ ...f, start: e.target.value })} /></Field>
        <Field label="Fim"><Input type="date" required value={f.end} onChange={(e) => setF({ ...f, end: e.target.value })} /></Field>
      </div>
      <p className="text-[11px] text-muted">Metas de leads e reuniões serão suportadas em versão futura; hoje o progresso é calculado para receita e negócios ganhos.</p>
      <Button type="submit" size="sm" disabled={loading}>{loading ? "Salvando..." : "Criar meta"}</Button>
      <Feedback error={error} message={message} />
    </form>
  );
}

export function CommissionRuleForm() {
  const [f, setF] = useState({ name: "Comissão padrão", ratePct: "5", acceleratorPct: "0" });
  const { run, loading, error, message } = useAction();
  return (
    <form className="space-y-2" onSubmit={(e) => { e.preventDefault(); run("/api/goals/commission", { name: f.name, ratePct: Number(f.ratePct.replace(",", ".")), acceleratorPct: Number(f.acceleratorPct.replace(",", ".")) }, { success: "Nova versão da regra salva e auditada." }); }}>
      <Input required minLength={2} aria-label="Nome da regra" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
      <div className="grid grid-cols-2 gap-2">
        <Field label="Taxa (%)"><Input required inputMode="decimal" value={f.ratePct} onChange={(e) => setF({ ...f, ratePct: e.target.value })} /></Field>
        <Field label="Acelerador acima da meta (p.p.)"><Input inputMode="decimal" value={f.acceleratorPct} onChange={(e) => setF({ ...f, acceleratorPct: e.target.value })} /></Field>
      </div>
      <Button type="submit" size="sm" variant="secondary" disabled={loading}>Salvar nova versão</Button>
      <Feedback error={error} message={message} />
    </form>
  );
}

export function CommissionSimulator({ rule, locale, currency }: { rule: { ratePct: number; acceleratorPct: number } | null; locale: string; currency: string }) {
  const [achieved, setAchieved] = useState("120000");
  const [target, setTarget] = useState("100000");
  const [rate, setRate] = useState(String(rule?.ratePct ?? 5));
  const [acc, setAcc] = useState(String(rule?.acceleratorPct ?? 0));
  const n = (s: string) => Number(s.replace(/\./g, "").replace(",", ".")) || 0;
  const a = n(achieved), t = n(target), r = Number(rate.replace(",", ".")) || 0, x = Number(acc.replace(",", ".")) || 0;
  // Mesma fórmula do servidor (calculateCommission): base até a meta + (taxa + acelerador) sobre o excedente.
  const commission = t > 0 ? Math.min(a, t) * (r / 100) + Math.max(0, a - t) * ((r + x) / 100) : 0;
  const fmt = new Intl.NumberFormat(locale, { style: "currency", currency, maximumFractionDigits: 2 });
  return (
    <div className="space-y-2">
      <div className="grid grid-cols-2 gap-2">
        <Field label="Realizado"><Input inputMode="decimal" value={achieved} onChange={(e) => setAchieved(e.target.value)} /></Field>
        <Field label="Meta"><Input inputMode="decimal" value={target} onChange={(e) => setTarget(e.target.value)} /></Field>
        <Field label="Taxa (%)"><Input inputMode="decimal" value={rate} onChange={(e) => setRate(e.target.value)} /></Field>
        <Field label="Acelerador (p.p.)"><Input inputMode="decimal" value={acc} onChange={(e) => setAcc(e.target.value)} /></Field>
      </div>
      <div className="rounded-xl border border-line bg-bg-2/60 p-3 text-sm">
        <p className="text-muted">Atingimento: <span className="font-semibold text-fg">{t > 0 ? Math.round((a / t) * 100) : 0}%</span></p>
        <p className="text-muted">Comissão estimada: <span className="text-lg font-bold text-fg">{fmt.format(commission)}</span></p>
        <p className="text-[11px] text-muted">Simulação — não gera pagamento nem registro.</p>
      </div>
    </div>
  );
}
