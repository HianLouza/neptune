"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Search, Upload } from "lucide-react";
import { Badge, Button, Card, CardTitle, Empty, Field, Input, Select, Textarea } from "@/components/ui";
import { useAction, Feedback } from "@/components/ui/use-action";
import { api } from "@/lib/api-client";
import type { Approval, KDoc } from "./types";

/** Fila de aprovações humanas pendentes (mensagens da IA e passos de automação). */
export function ApprovalsPanel({ items, locale, canDecide }: { items: Approval[]; locale: string; canDecide: boolean }) {
  const a = useAction();
  const [edits, setEdits] = useState<Record<string, string>>({});
  return (
    <Card>
      <CardTitle sub="Ações sensíveis da IA e de automações só executam após decisão humana.">Aprovações pendentes <Badge tone={items.length ? "warning" : "neutral"}>{items.length}</Badge></CardTitle>
      {!items.length ? <Empty title="Nenhuma aprovação pendente." /> : (
        <ul className="space-y-3">
          {items.map((it) => {
            const body = typeof it.payload.body === "string" ? it.payload.body : null;
            return (
              <li key={it.id} className="rounded-xl border border-line bg-surface-2/40 p-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <p className="text-sm font-medium">{it.title}</p>
                  <span className="text-[11px] text-muted">{new Date(it.createdAt).toLocaleString(locale, { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" })}</span>
                </div>
                <p className="text-[11px] text-muted">{it.kind === "ai_message" ? "Mensagem da IA" : it.kind === "workflow_step" ? "Passo de automação" : it.kind} · solicitado por {it.requestedBy}{it.payload.simulated ? " · IA simulada" : ""}</p>
                {body !== null && canDecide && (
                  <Textarea className="mt-2 min-h-16" value={edits[it.id] ?? body} onChange={(e) => setEdits({ ...edits, [it.id]: e.target.value })} aria-label="Texto da mensagem" />
                )}
                {body !== null && !canDecide && <p className="mt-2 whitespace-pre-wrap text-sm">{body}</p>}
                {it.kind === "workflow_step" && <pre className="mt-2 max-h-28 overflow-auto rounded-lg bg-bg-2 p-2 text-[11px] text-muted">{JSON.stringify(it.payload, null, 2)}</pre>}
                {canDecide && (
                  <div className="mt-2 flex gap-2">
                    <Button size="sm" disabled={a.loading} onClick={() => a.run(`/api/closer/approvals/${it.id}`, { approve: true, editedBody: body !== null && edits[it.id] !== undefined && edits[it.id] !== body ? edits[it.id] : undefined }, { success: "Aprovado." })}>Aprovar</Button>
                    <Button size="sm" variant="danger" disabled={a.loading} onClick={() => a.run(`/api/closer/approvals/${it.id}`, { approve: false }, { success: "Rejeitado." })}>Rejeitar</Button>
                  </div>
                )}
              </li>
            );
          })}
        </ul>
      )}
      <Feedback error={a.error} message={a.message} />
    </Card>
  );
}

/** Base de conhecimento: documentos, upload de texto e teste de busca semântica. */
export function KnowledgePanel({ docs, locale, canWrite }: { docs: KDoc[]; locale: string; canWrite: boolean }) {
  const a = useAction();
  const [f, setF] = useState({ title: "", kind: "text", content: "" });
  const [q, setQ] = useState("");
  const [results, setResults] = useState<{ title: string; content: string; similarity: number }[] | null>(null);
  const [searchErr, setSearchErr] = useState<string | null>(null);
  const [fileNote, setFileNote] = useState<string | null>(null);

  const onFile = async (file: File | undefined) => {
    setFileNote(null);
    if (!file) return;
    if (/\.pdf$/i.test(file.name)) { setFileNote("Extração de PDF pendente (dependência de biblioteca de leitura). Cole o texto manualmente por enquanto."); return; }
    if (!/\.(txt|csv|md)$/i.test(file.name)) { setFileNote("Formatos aceitos: .txt, .csv, .md."); return; }
    if (file.size > 2_000_000) { setFileNote("Arquivo maior que 2 MB."); return; }
    const content = await file.text();
    setF((cur) => ({ ...cur, content, title: cur.title || file.name.replace(/\.\w+$/, "") }));
    setFileNote(`Arquivo carregado: ${file.name} (${content.length.toLocaleString(locale)} caracteres).`);
  };
  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    const r = await a.run<{ chunks: number }>("/api/closer/knowledge", f);
    if (r) { setF({ title: "", kind: "text", content: "" }); setFileNote(null); a.setMessage(`Documento indexado em ${r.chunks} trecho(s).`); }
  };
  const search = async (e: React.FormEvent) => {
    e.preventDefault(); setSearchErr(null);
    try { setResults(await api(`/api/closer/knowledge/search?q=${encodeURIComponent(q)}`)); } catch (err) { setSearchErr((err as Error).message); }
  };

  return (
    <div className="grid gap-5 lg:grid-cols-2">
      <Card>
        <CardTitle sub="A IA só responde com base nestes documentos.">Documentos ({docs.length})</CardTitle>
        {!docs.length ? <Empty title="Nenhum documento ainda.">Adicione políticas, FAQs, preços e catálogos.</Empty> : (
          <ul className="divide-y divide-line/60">
            {docs.map((d) => (
              <li key={d.id} className="flex items-center justify-between gap-2 py-2 text-sm">
                <span className="min-w-0 truncate">{d.title}</span>
                <span className="flex shrink-0 items-center gap-2 text-[11px] text-muted"><Badge>{d.kind}</Badge>{Number(d.size).toLocaleString(locale)} car.</span>
              </li>
            ))}
          </ul>
        )}
        <form onSubmit={search} className="mt-5 space-y-2">
          <p className="text-xs font-medium text-muted">Testar busca semântica (pgvector)</p>
          <div className="flex gap-2">
            <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Ex.: vocês têm teste gratuito?" aria-label="Consulta de teste" />
            <Button type="submit" variant="secondary" disabled={q.trim().length < 2}><Search size={14} /></Button>
          </div>
          {searchErr && <p className="text-xs text-danger">{searchErr}</p>}
          {results && (results.length ? (
            <ul className="space-y-2">{results.map((r, i) => (
              <li key={i} className="rounded-lg border border-line p-2 text-xs"><p className="font-medium">{r.title} <span className="text-muted">— similaridade {Math.round(r.similarity * 100)}%</span></p><p className="mt-1 line-clamp-3 text-muted">{r.content}</p></li>
            ))}</ul>
          ) : <p className="text-xs text-muted">Nenhum trecho encontrado.</p>)}
        </form>
      </Card>
      {canWrite && (
        <Card>
          <CardTitle>Adicionar documento</CardTitle>
          <form onSubmit={save} className="space-y-3">
            <Field label="Título"><Input required minLength={2} value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} /></Field>
            <Field label="Tipo">
              <Select value={f.kind} onChange={(e) => setF({ ...f, kind: e.target.value })}>
                <option value="text">Texto</option><option value="faq">Perguntas frequentes</option><option value="pricing">Preços</option><option value="policy">Política</option><option value="catalog">Catálogo</option>
              </Select>
            </Field>
            <Field label="Arquivo (opcional)" hint=".txt, .csv ou .md — lido no navegador. PDF: extração pendente.">
              <label className="flex cursor-pointer items-center gap-2 rounded-lg border border-dashed border-line px-3 py-2 text-sm text-muted hover:border-primary-2">
                <Upload size={14} /> Escolher arquivo
                <input type="file" accept=".txt,.csv,.md,.pdf" className="sr-only" onChange={(e) => onFile(e.target.files?.[0])} />
              </label>
            </Field>
            {fileNote && <p className="text-xs text-muted">{fileNote}</p>}
            <Field label="Conteúdo"><Textarea required minLength={10} className="min-h-40" value={f.content} onChange={(e) => setF({ ...f, content: e.target.value })} /></Field>
            <Button type="submit" disabled={a.loading}>{a.loading ? "Indexando..." : "Salvar e indexar"}</Button>
            <Feedback error={a.error} message={a.message} />
          </form>
        </Card>
      )}
    </div>
  );
}

/** Simula uma mensagem recebida pelo webchat público (teste de ponta a ponta). */
export function SimulateInbound({ orgSlug }: { orgSlug: string }) {
  const router = useRouter();
  const [f, setF] = useState({ name: "", email: "", message: "" });
  const [err, setErr] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setLoading(true); setErr(null);
    try {
      const r = await api<{ conversationId: string }>("/api/webhooks/webchat", { body: { orgSlug, ...f } });
      setF({ name: "", email: "", message: "" });
      router.push(`/closer?c=${r.conversationId}`);
      router.refresh();
    } catch (er) { setErr((er as Error).message); } finally { setLoading(false); }
  };
  return (
    <Card>
      <CardTitle sub="Envia pelo mesmo endpoint público do widget de webchat do seu site.">Simular mensagem recebida (webchat)</CardTitle>
      <form onSubmit={submit} className="space-y-3">
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Nome do visitante"><Input required minLength={2} value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></Field>
          <Field label="E-mail (opcional)"><Input type="email" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></Field>
        </div>
        <Field label="Mensagem"><Textarea required value={f.message} onChange={(e) => setF({ ...f, message: e.target.value })} placeholder="Ex.: Qual o prazo de implantação?" /></Field>
        <Button type="submit" variant="secondary" disabled={loading}>{loading ? "Enviando..." : "Simular recebimento"}</Button>
        {err && <p role="alert" className="text-xs text-danger">{err}</p>}
        <p className="text-[11px] text-muted">Endpoint: <code>POST /api/webhooks/webchat</code> com orgSlug <code>{orgSlug}</code>.</p>
      </form>
    </Card>
  );
}
