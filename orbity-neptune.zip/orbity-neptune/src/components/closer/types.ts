/** Tipos serializados (datas como string ISO) enviados do servidor para os componentes do Closer.AI. */
export type ConvItem = {
  id: string; channel: string; status: string; intent: string | null; subject: string | null; aiEnabled: boolean;
  slaDueAt: string | null; lastMessageAt: string; contactName: string | null; contactEmail: string | null;
};
export type Msg = { id: string; direction: string; author: string; body: string; status: string; createdAt: string };
export type ConvDetail = ConvItem & { summary: string | null; contactPhone: string | null; messages: Msg[]; channelReal: boolean; channelConnected?: boolean; outboundImplemented?: boolean };
export type Approval = { id: string; kind: string; title: string; payload: Record<string, unknown>; requestedBy: string; createdAt: string };
export type KDoc = { id: string; title: string; kind: string; createdAt: string; size: number };

export const CHANNEL_LABEL: Record<string, string> = { whatsapp: "WhatsApp", email: "E-mail", webchat: "Webchat", instagram: "Instagram" };
export const STATUS_LABEL: Record<string, string> = { open: "Aberta", waiting: "Aguardando", handoff: "Aguardando humano", closed: "Encerrada" };
export const isSlaBreached = (c: Pick<ConvItem, "slaDueAt" | "status">) => !!c.slaDueAt && c.status !== "closed" && new Date(c.slaDueAt).getTime() < Date.now();
