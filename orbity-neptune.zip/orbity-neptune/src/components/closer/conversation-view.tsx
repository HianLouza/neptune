"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Bot, Send, FileText, UserRound, CircleX, RotateCcw } from "lucide-react";
import { Badge, Button, Card, SimBadge, Textarea, cx } from "@/components/ui";
import { useAction, Feedback } from "@/components/ui/use-action";
import { DraftWorkspace } from "@/components/ai-collab/draft-workspace";
import type { DraftViewData } from "@/components/ai-collab/types";
import { CHANNEL_LABEL, STATUS_LABEL, isSlaBreached, type ConvDetail } from "./types";

type ReplyResult = { delivered: boolean; notice: string | null };
export type MessageOrigin = { origin: "ai_unchanged" | "ai_edited" | "human"; seq: number };
const ORIGIN_LABEL: Record<MessageOrigin["origin"], string> = {
  ai_unchanged: "Sugestão da IA enviada sem alterações", ai_edited: "Sugestão da IA editada pela equipe", human: "Escrita pela equipe",
};

export function ConversationView({ conv, locale, canWrite, draft, origins = {} }: { conv: ConvDetail; locale: string; canWrite: boolean; draft?: DraftViewData | null; origins?: Record<string, MessageOrigin> }) {
  const a = useAction();
  const router = useRouter();
  const [text, setText] = useState("");
  const [notice, setNotice] = useState<string | null>(null);
  const base = `/api/closer/conversations/${conv.id}`;
  const time = (d: string) => new Date(d).toLocaleString(locale, { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" });

  const reply = async (e: React.FormEvent) => {
    e.preventDefault();
    const r = await a.run<ReplyResult>(`${base}/reply`, { body: text });
    if (r) { setText(""); setNotice(r.notice); }
  };
  const patch = (body: Record<string, unknown>, success: string) => a.run(base, body, { method: "PATCH", success });

  return (
    <Card className="flex min-h-[560px] flex-col p-0">
      <header className="flex flex-wrap items-start justify-between gap-3 border-b border-line p-4">
        <div>
          <p className="font-semibold">{conv.contactName ?? "Contato"}</p>
          <p className="text-xs text-muted">{[conv.contactEmail, conv.contactPhone].filter(Boolean).join(" · ") || "sem dados de contato"}</p>
          <div className="mt-2 flex flex-wrap gap-1.5">
            <Badge tone="info">{CHANNEL_LABEL[conv.channel] ?? conv.channel}</Badge>
            <Badge tone={conv.status === "handoff" ? "warning" : conv.status === "closed" ? "neutral" : "success"}>{STATUS_LABEL[conv.status] ?? conv.status}</Badge>
            {conv.intent && <Badge tone="primary">{conv.intent}</Badge>}
            {isSlaBreached(conv) && <Badge tone="danger">SLA vencido</Badge>}
            {!conv.channelReal && <SimBadge label={conv.channelConnected && !conv.outboundImplemented
              ? "Canal conectado, mas o envio real ainda não foi implementado — envios não são entregues"
              : "Canal sem integração real — envios não são entregues"} />}
          </div>
        </div>
        {canWrite && (
          <div className="flex flex-wrap gap-2">
            <Button size="sm" variant="secondary" onClick={() => patch({ aiEnabled: !conv.aiEnabled }, conv.aiEnabled ? "IA desativada nesta conversa." : "IA ativada nesta conversa.")} disabled={a.loading}>
              <Bot size={14} /> IA {conv.aiEnabled ? "ligada" : "desligada"}
            </Button>
            {conv.status !== "handoff" && conv.status !== "closed" && <Button size="sm" variant="secondary" onClick={() => patch({ status: "handoff" }, "Encaminhada para atendimento humano.")} disabled={a.loading}><UserRound size={14} /> Passar p/ humano</Button>}
            {conv.status !== "closed"
              ? <Button size="sm" variant="ghost" onClick={() => patch({ status: "closed" }, "Conversa encerrada.")} disabled={a.loading}><CircleX size={14} /> Encerrar</Button>
              : <Button size="sm" variant="ghost" onClick={() => patch({ status: "open" }, "Conversa reaberta.")} disabled={a.loading}><RotateCcw size={14} /> Reabrir</Button>}
          </div>
        )}
      </header>

      {conv.summary && (
        <div className="border-b border-line bg-surface-2/40 p-4 text-sm">
          <p className="mb-1 flex items-center gap-1.5 text-xs font-semibold text-muted"><FileText size={13} /> Resumo</p>
          <p className="whitespace-pre-wrap">{conv.summary}</p>
        </div>
      )}

      <div className="flex-1 space-y-3 overflow-y-auto p-4" aria-live="polite">
        {conv.messages.map((m) => (
          <div key={m.id} className={cx("max-w-[85%] rounded-xl px-3 py-2 text-sm", m.direction === "inbound" ? "bg-surface-2" : "ml-auto bg-primary/25")}>
            <p className="whitespace-pre-wrap">{m.body}</p>
            <p className="mt-1 flex flex-wrap items-center gap-1.5 text-[10px] text-muted">
              {m.direction === "inbound" ? "Cliente" : origins[m.id] ? `${ORIGIN_LABEL[origins[m.id].origin]} (v${origins[m.id].seq})` : m.author === "ai" ? "Sugestão da IA (aprovada por humano)" : "Equipe"} · {time(m.createdAt)}
              {m.status === "simulated" && <Badge tone="warning">não entregue (simulado)</Badge>}
              {m.status === "failed" && <Badge tone="danger">falhou</Badge>}
              {m.status === "blocked" && <Badge tone="danger">bloqueado (kill switch)</Badge>}
            </p>
          </div>
        ))}
        {!conv.messages.length && <p className="text-sm text-muted">Sem mensagens.</p>}
      </div>

      {canWrite && (
        <div className="border-t border-line p-4">
          <DraftWorkspace key={conv.id} module="closer" subjectId={conv.id} initial={draft ?? null} canWrite={canWrite} aiEnabled={conv.aiEnabled}
            channelReal={conv.channelReal} locale={locale} onSent={() => router.refresh()} />
        </div>
      )}

      {notice && <p role="status" className="border-t border-warning/30 bg-warning/10 px-4 py-2 text-xs text-warning">⚠ {notice}</p>}

      {canWrite && (
        <form onSubmit={reply} className="border-t border-line p-4">
          <Textarea value={text} onChange={(e) => setText(e.target.value)} placeholder="Ou escreva sua resposta diretamente (envio sem passar pela IA)..." className="min-h-20" aria-label="Resposta" />
          <div className="mt-2 flex flex-wrap items-center justify-between gap-2">
            <div className="flex flex-wrap gap-2">
              <Button type="button" size="sm" variant="secondary" onClick={() => a.run(`${base}/summary`, {}, { success: "Resumo atualizado." })} disabled={a.loading || !conv.messages.length}><FileText size={14} /> Resumir</Button>
            </div>
            <Button type="submit" size="sm" disabled={a.loading || !text.trim()}><Send size={14} /> Enviar</Button>
          </div>
          <Feedback error={a.error} message={a.message} />
        </form>
      )}
    </Card>
  );
}
