"use client";
/**
 * "Gerar alerta" — painel lateral para criar um alerta individual a partir de uma tarefa.
 * Nada é enviado sem o clique em "Confirmar". Canais indisponíveis aparecem desabilitados com o motivo real.
 */
import { useEffect, useRef, useState } from "react";
import { Bell, Clock, Save, Send, Sparkles, X } from "lucide-react";
import { api } from "@/lib/api-client";
import { useAction, Feedback } from "@/components/ui/use-action";
import { Badge, Button, Field, Input, Select, SimBadge, Textarea, cx } from "@/components/ui";
import { MESSAGE_KINDS, MESSAGE_KIND_LABEL, PRIORITIES, PRIORITY_HINT, PRIORITY_LABEL, PRIORITY_TONE, TONES, TONE_LABEL, type AlertPriority, type MessageKind } from "@/lib/task-alerts";

export type AlertTask = { id: string; title: string; description: string | null; priority: string; dueAt: string | null; assigneeId: string | null; assigneeName: string | null };
type Gen = { title: string; message: string; simulated: boolean; executionId: string | null; provider: string; credits: number; warnings: string[]; basedOn: string[] };
type Chan = { key: string; label: string; available: boolean; reason: string | null };

const fmt = (iso: string | null) => (iso ? new Date(iso).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" }) : "sem prazo");
const localInput = (d: Date) => new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16);

function defaultPriority(t: AlertTask): AlertPriority {
  const late = t.dueAt ? new Date(t.dueAt).getTime() < Date.now() : false;
  if (late) return t.priority === "high" ? "urgent" : "high";
  return t.priority === "high" ? "high" : t.priority === "low" ? "low" : "medium";
}

/** Botão da tabela de tarefas. Em telas pequenas mostra só o ícone (com tooltip e rótulo acessível). */
export function GenerateAlertButton({ task, users, senderName }: { task: AlertTask; users: { id: string; name: string }[]; senderName: string }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button type="button" aria-label={`Gerar alerta para ${task.title}`} title="Gerar alerta" onClick={() => setOpen(true)}
        className="inline-flex items-center gap-1 rounded p-1 text-primary-2 hover:bg-surface-2 xl:px-2">
        <Bell size={16} /><span className="hidden text-xs font-medium xl:inline">Gerar alerta</span>
      </button>
      {open && <AlertDrawer task={task} users={users} senderName={senderName} onClose={() => setOpen(false)} />}
    </>
  );
}

function AlertDrawer({ task, users, senderName, onClose }: { task: AlertTask; users: { id: string; name: string }[]; senderName: string; onClose: () => void }) {
  const idem = useRef(typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID() : `k-${Date.now()}-${Math.random().toString(36).slice(2)}`);
  const [recipientId, setRecipientId] = useState(task.assigneeId ?? "");
  const [title, setTitle] = useState(`Lembrete: ${task.title}`.slice(0, 140));
  const [message, setMessage] = useState("");
  const [priority, setPriority] = useState<AlertPriority>(defaultPriority(task));
  const [channels, setChannels] = useState<string[]>(["in_app"]);
  const [chan, setChan] = useState<Chan[]>([]);
  const [mode, setMode] = useState<"now" | "schedule">("now");
  const [scheduledAt, setScheduledAt] = useState(localInput(new Date(Date.now() + 3600_000)));
  const [kind, setKind] = useState<MessageKind>("friendly_reminder");
  const [tone, setTone] = useState("");
  const [instruction, setInstruction] = useState("");
  const [versions, setVersions] = useState<Gen[]>([]);
  const [origin, setOrigin] = useState<Gen | null>(null);
  const [genLoading, setGenLoading] = useState(false);
  const [genError, setGenError] = useState<string | null>(null);
  const [result, setResult] = useState<string | null>(null);
  const { run, loading, error } = useAction();

  useEffect(() => {
    api<Chan[]>("/api/task-alerts/channels").then(setChan).catch(() => setChan([{ key: "in_app", label: "Notificação interna / Central de Notificações", available: true, reason: null }]));
    const esc = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", esc);
    return () => window.removeEventListener("keydown", esc);
  }, [onClose]);

  const apply = (g: Gen) => { setTitle(g.title); setMessage(g.message); setOrigin(g); };
  async function generate() {
    setGenLoading(true); setGenError(null);
    try {
      const g = await api<Gen>("/api/task-alerts/generate", { body: { taskId: task.id, kind, tone: tone || undefined, instruction: instruction || undefined, variant: versions.length, previous: versions.map((v) => v.message) } });
      setVersions((v) => [...v, g]); apply(g);
    } catch (e) { setGenError((e as Error).message); } finally { setGenLoading(false); }
  }

  async function submit(sendMode: "now" | "schedule" | "draft") {
    const r = await run<{ notice: string; duplicate: boolean }>("/api/task-alerts", {
      taskId: task.id, recipientId: recipientId || undefined, title, message, priority, channels, sendMode,
      scheduledAt: sendMode === "schedule" ? new Date(scheduledAt).toISOString() : undefined,
      originalMessage: origin?.message, flavioExecutionId: origin?.executionId ?? undefined, simulated: origin?.simulated, idempotencyKey: idem.current,
    });
    if (r) setResult(r.notice);
  }

  const toggle = (k: string) => setChannels((c) => (c.includes(k) ? c.filter((x) => x !== k) : [...c, k]));
  const recipientName = users.find((u) => u.id === recipientId)?.name ?? task.assigneeName ?? "—";
  const ready = recipientId && title.trim().length >= 2 && message.trim().length >= 2 && channels.length > 0 && (mode === "now" || scheduledAt);

  return (
    <div className="fixed inset-0 z-40 flex justify-end bg-black/50" onClick={onClose}>
      <div role="dialog" aria-modal="true" aria-label="Gerar alerta" className="flex h-full w-full max-w-xl flex-col overflow-y-auto border-l border-line bg-surface p-5 shadow-2xl" onClick={(e) => e.stopPropagation()}>
        <div className="mb-4 flex items-start justify-between gap-3">
          <div><h2 className="text-lg font-semibold">Gerar alerta</h2><p className="text-xs text-muted">Revise tudo antes de confirmar. Nada é enviado sem a sua confirmação.</p></div>
          <button aria-label="Fechar" onClick={onClose} className="rounded p-1 text-muted hover:bg-surface-2"><X size={18} /></button>
        </div>

        {result ? (
          <div className="space-y-4">
            <div role="status" className="rounded-xl border border-line bg-bg-2/60 p-4 text-sm">{result}</div>
            <Button onClick={onClose}>Fechar</Button>
          </div>
        ) : (
          <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); void submit(mode); }}>
            <div className="rounded-xl border border-line bg-bg-2/60 p-3 text-sm">
              <p className="text-xs text-muted">Tarefa relacionada</p>
              <p className="font-medium">{task.title}</p>
              <p className="mt-1 text-xs text-muted">Prazo da tarefa: <span className="text-fg">{fmt(task.dueAt)}</span> · Remetente: <span className="text-fg">{senderName}</span></p>
            </div>

            <Field label="Responsável destinatário" hint="Preenchido com o responsável da tarefa; você pode alterar.">
              <Select value={recipientId} onChange={(e) => setRecipientId(e.target.value)} required>
                {!task.assigneeId && <option value="">Escolha o destinatário</option>}
                {users.map((u) => <option key={u.id} value={u.id}>{u.name}{u.id === task.assigneeId ? " (responsável)" : ""}</option>)}
              </Select>
            </Field>

            <fieldset className="space-y-2 rounded-xl border border-line p-3">
              <legend className="px-1 text-xs font-medium text-muted">Mensagem</legend>
              <div className="grid gap-2 sm:grid-cols-2">
                <Select aria-label="Tipo de mensagem do Flávio" value={kind} onChange={(e) => setKind(e.target.value as MessageKind)}>
                  {MESSAGE_KINDS.map((k) => <option key={k} value={k}>{MESSAGE_KIND_LABEL[k]}</option>)}
                </Select>
                <Select aria-label="Tom da mensagem" value={tone} onChange={(e) => setTone(e.target.value)}>
                  <option value="">Tom padrão da organização</option>
                  {TONES.map((t) => <option key={t} value={t}>{TONE_LABEL[t]}</option>)}
                </Select>
              </div>
              <Input aria-label="Orientação para o Flávio" placeholder="Orientação opcional (ex.: mencione o cliente, seja breve)" value={instruction} onChange={(e) => setInstruction(e.target.value)} maxLength={600} />
              <div className="flex flex-wrap items-center gap-2">
                <Button type="button" variant="secondary" size="sm" onClick={generate} disabled={genLoading}><Sparkles size={14} />{genLoading ? "Gerando..." : versions.length ? "Nova versão com Flávio" : "Gerar mensagem com Flávio"}</Button>
                {origin?.simulated && <SimBadge label="Texto simulado (sem IA real)" />}
                {versions.length > 1 && (
                  <span className="flex items-center gap-1 text-[11px] text-muted">Versões:
                    {versions.map((v, i) => <button key={i} type="button" onClick={() => apply(v)} className={cx("rounded px-1.5 py-0.5", origin === v ? "bg-primary/25 text-fg" : "hover:bg-surface-2")}>{i + 1}</button>)}
                  </span>
                )}
              </div>
              {genError && <p role="alert" className="text-xs text-danger">{genError}</p>}
              {origin?.warnings.map((w, i) => <p key={i} className="text-[11px] text-warning">{w}</p>)}
              {origin && <details className="text-[11px] text-muted"><summary className="cursor-pointer">Em que o Flávio se baseou</summary><ul className="mt-1 list-disc pl-4">{origin.basedOn.map((b, i) => <li key={i}>{b}</li>)}</ul></details>}
              <Input aria-label="Título do alerta" required minLength={2} maxLength={140} placeholder="Título do alerta" value={title} onChange={(e) => setTitle(e.target.value)} />
              <Textarea aria-label="Mensagem personalizada" required minLength={2} maxLength={2000} className="min-h-32" placeholder="Escreva a mensagem ou gere uma sugestão com o Flávio. Você pode editar livremente." value={message} onChange={(e) => setMessage(e.target.value)} />
              {origin && message.trim() !== origin.message.trim() && <p className="text-[11px] text-muted">Texto editado manualmente; a versão original do Flávio fica registrada no histórico.</p>}
            </fieldset>

            <fieldset>
              <legend className="mb-1.5 text-xs font-medium text-muted">Prioridade</legend>
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                {PRIORITIES.map((p) => (
                  <button key={p} type="button" aria-pressed={priority === p} onClick={() => setPriority(p)}
                    className={cx("rounded-lg border px-2 py-2 text-left text-xs transition", priority === p ? "border-primary-2 bg-primary/15" : "border-line hover:border-primary-2/60")}>
                    <Badge tone={PRIORITY_TONE[p]}>{PRIORITY_LABEL[p]}</Badge><span className="mt-1 block text-[10px] leading-tight text-muted">{PRIORITY_HINT[p]}</span>
                  </button>
                ))}
              </div>
            </fieldset>

            <fieldset>
              <legend className="mb-1.5 text-xs font-medium text-muted">Canais de envio</legend>
              <div className="space-y-1.5">
                {(chan.length ? chan : [{ key: "in_app", label: "Notificação interna / Central de Notificações", available: true, reason: null }]).map((c) => (
                  <label key={c.key} className={cx("flex items-start gap-2 rounded-lg border border-line p-2 text-sm", !c.available && "opacity-60")}>
                    <input type="checkbox" className="mt-1" disabled={!c.available} checked={channels.includes(c.key)} onChange={() => toggle(c.key)} />
                    <span><span className="font-medium">{c.label}</span>{!c.available && <span className="block text-[11px] text-muted">Indisponível: {c.reason}</span>}</span>
                  </label>
                ))}
              </div>
            </fieldset>

            <fieldset className="space-y-2">
              <legend className="mb-1.5 text-xs font-medium text-muted">Envio</legend>
              <div className="inline-flex rounded-lg border border-line p-0.5 text-xs">
                <button type="button" onClick={() => setMode("now")} className={cx("rounded-md px-3 py-1.5", mode === "now" ? "bg-surface-2 text-fg" : "text-muted")}>Enviar agora</button>
                <button type="button" onClick={() => setMode("schedule")} className={cx("rounded-md px-3 py-1.5", mode === "schedule" ? "bg-surface-2 text-fg" : "text-muted")}>Agendar</button>
              </div>
              {mode === "schedule" && <Field label="Data e horário de envio" hint="O alerta fica como “Agendado” (não enviado) até esse horário."><Input type="datetime-local" required value={scheduledAt} onChange={(e) => setScheduledAt(e.target.value)} /></Field>}
            </fieldset>

            <div className="rounded-xl border border-line bg-bg-2/60 p-3 text-xs text-muted">
              Resumo: <span className="text-fg">{recipientName}</span> receberá um alerta <Badge tone={PRIORITY_TONE[priority]}>{PRIORITY_LABEL[priority]}</Badge> {mode === "now" ? "agora" : `em ${fmt(new Date(scheduledAt || Date.now()).toISOString())}`}. Entrega e leitura só são registradas quando realmente acontecerem.
            </div>

            <Feedback error={error} />
            <div className="flex flex-wrap gap-2 pb-2">
              <Button type="submit" disabled={loading || !ready}>{mode === "now" ? <><Send size={14} />Confirmar e enviar agora</> : <><Clock size={14} />Confirmar agendamento</>}</Button>
              <Button type="button" variant="secondary" disabled={loading || !ready} onClick={() => void submit("draft")}><Save size={14} />Salvar rascunho</Button>
              <Button type="button" variant="ghost" onClick={onClose}>Cancelar</Button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
