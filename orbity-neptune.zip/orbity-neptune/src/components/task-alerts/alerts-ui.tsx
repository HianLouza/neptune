"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Check, Clock, HelpCircle, MessageSquare, OctagonAlert, Play, Send, TrendingUp, X } from "lucide-react";
import { api } from "@/lib/api-client";
import { useAction, Feedback } from "@/components/ui/use-action";
import { Badge, Button, Field, Input, Select, Textarea, cx } from "@/components/ui";
import { PRIORITIES, PRIORITY_LABEL, STATUSES, STATUS_LABEL, TONES, TONE_LABEL, CHANNELS, CHANNEL_LABEL, MESSAGE_KINDS, MESSAGE_KIND_LABEL } from "@/lib/task-alerts";

/* ------------------------------------------------------------------ filtros da Central */

export type FilterValues = Record<string, string | undefined>;

export function AlertFilters({ values, users, teams, tasks }: { values: FilterValues; users: { id: string; name: string }[]; teams: { id: string; name: string }[]; tasks: { id: string; title: string }[] }) {
  const router = useRouter();
  const [v, setV] = useState<FilterValues>(values);
  const set = (k: string, val: string) => setV((o) => ({ ...o, [k]: val || undefined }));
  const apply = () => {
    const q = new URLSearchParams();
    for (const [k, val] of Object.entries(v)) if (val) q.set(k, val);
    router.push(`/alertas${q.size ? `?${q}` : ""}`);
  };
  return (
    <form className="mb-4 grid gap-2 sm:grid-cols-2 lg:grid-cols-4" onSubmit={(e) => { e.preventDefault(); apply(); }} aria-label="Filtros de alertas">
      <Select aria-label="Responsável" value={v.recipientId ?? ""} onChange={(e) => set("recipientId", e.target.value)}><option value="">Todos os responsáveis</option>{users.map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}</Select>
      <Select aria-label="Equipe" value={v.teamId ?? ""} onChange={(e) => set("teamId", e.target.value)}><option value="">Todas as equipes</option>{teams.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}</Select>
      <Select aria-label="Prioridade" value={v.priority ?? ""} onChange={(e) => set("priority", e.target.value)}><option value="">Todas as prioridades</option>{PRIORITIES.map((p) => <option key={p} value={p}>{PRIORITY_LABEL[p]}</option>)}</Select>
      <Select aria-label="Status" value={v.status ?? ""} onChange={(e) => set("status", e.target.value)}><option value="">Todos os status</option>{STATUSES.map((s) => <option key={s} value={s}>{STATUS_LABEL[s]}</option>)}</Select>
      <Select aria-label="Tarefa" value={v.taskId ?? ""} onChange={(e) => set("taskId", e.target.value)}><option value="">Todas as tarefas</option>{tasks.map((t) => <option key={t.id} value={t.id}>{t.title.slice(0, 60)}</option>)}</Select>
      <Select aria-label="Canal" value={v.channel ?? ""} onChange={(e) => set("channel", e.target.value)}><option value="">Todos os canais</option>{CHANNELS.map((c) => <option key={c} value={c}>{CHANNEL_LABEL[c]}</option>)}</Select>
      <Input aria-label="De" type="date" value={v.from ?? ""} onChange={(e) => set("from", e.target.value)} />
      <Input aria-label="Até" type="date" value={v.to ?? ""} onChange={(e) => set("to", e.target.value ? `${e.target.value}T23:59:59` : "")} />
      <div className="flex gap-2 sm:col-span-2 lg:col-span-4"><Button type="submit" size="sm">Filtrar</Button><Button type="button" variant="ghost" size="sm" onClick={() => router.push("/alertas")}>Limpar</Button></div>
    </form>
  );
}

/* ------------------------------------------------------------------ ações do gestor sobre um alerta */

export function AlertRowActions({ id, status }: { id: string; status: string }) {
  const { run, loading, error } = useAction();
  if (status !== "draft" && status !== "scheduled") return null;
  return (
    <span className="inline-flex flex-wrap items-center gap-1">
      <button disabled={loading} onClick={() => run(`/api/task-alerts/${id}`, { action: "send_now" }, { method: "PATCH" })} className="rounded border border-line px-2 py-0.5 text-[11px] hover:bg-surface-2">Enviar agora</button>
      <button disabled={loading} onClick={() => run(`/api/task-alerts/${id}`, { action: "cancel" }, { method: "PATCH" })} className="rounded border border-line px-2 py-0.5 text-[11px] text-danger hover:bg-surface-2">Cancelar</button>
      {error && <span className="text-[10px] text-danger">{error}</span>}
    </span>
  );
}

/* ------------------------------------------------------------------ experiência do colaborador */

type Mode = "ack" | "working" | "progress" | "blocker" | "help" | "delay_justification" | "comment" | "extension" | "done" | null;
const MODE_TITLE: Record<Exclude<Mode, null>, string> = {
  ack: "Confirmar recebimento", working: "Estou trabalhando nisso", progress: "Atualizar andamento", blocker: "Informar impedimento", help: "Pedir ajuda",
  delay_justification: "Justificar atraso", comment: "Registrar comentário", extension: "Pedir mais prazo", done: "Marcar como concluída",
};

/** Responde a um alerta (ou atualiza a tarefa). Abrir o alerta registra a leitura (uma única vez). */
export function RespondPanel({ alertId, taskId, canComplete, dueAt, read }: { alertId?: string; taskId: string; canComplete: boolean; dueAt: string | null; read?: boolean }) {
  const [mode, setMode] = useState<Mode>(null);
  const [msg, setMsg] = useState("");
  const [pct, setPct] = useState("50");
  const [url, setUrl] = useState("");
  const [due, setDue] = useState("");
  const [blockers, setBlockers] = useState("");
  const [impact, setImpact] = useState("");
  const { run, loading, error, message, setMessage } = useAction();

  async function open(m: Mode) {
    setMode(m); setMessage(null);
    if (alertId && !read) void api(`/api/task-alerts/${alertId}`, { method: "PATCH", body: { action: "read" } }).catch(() => undefined);
  }
  async function send() {
    if (!mode) return;
    if (mode === "extension") {
      const r = await run("/api/task-extensions", { taskId, alertId, requestedDueAt: new Date(due).toISOString(), justification: msg, blockers: blockers || undefined, impact: impact || undefined }, { success: "Pedido enviado ao gestor. O prazo só muda se ele aprovar." });
      if (r) { setMode(null); setMsg(""); }
      return;
    }
    const r = await run("/api/task-alerts/respond", { alertId, taskId, kind: mode, message: msg || undefined, progressPct: mode === "progress" ? Number(pct) : undefined, evidenceUrl: url || undefined }, { success: "Resposta registrada." });
    if (r) { setMode(null); setMsg(""); setUrl(""); }
  }
  const btn = (m: Exclude<Mode, null>, icon: React.ReactNode) => (
    <button type="button" onClick={() => void open(m)} className={cx("inline-flex items-center gap-1 rounded-lg border px-2.5 py-1 text-xs hover:border-primary-2", mode === m ? "border-primary-2 bg-primary/15" : "border-line")}>{icon}{MODE_TITLE[m]}</button>
  );
  const needsMsg = mode && ["blocker", "help", "delay_justification", "comment", "extension"].includes(mode);
  return (
    <div className="mt-3 space-y-2">
      <div className="flex flex-wrap gap-1.5">
        {btn("ack", <Check size={13} />)}{btn("working", <Play size={13} />)}{btn("progress", <TrendingUp size={13} />)}{btn("blocker", <OctagonAlert size={13} />)}
        {btn("help", <HelpCircle size={13} />)}{btn("delay_justification", <MessageSquare size={13} />)}{btn("extension", <Clock size={13} />)}{btn("comment", <MessageSquare size={13} />)}
        {canComplete && btn("done", <Check size={13} />)}
      </div>
      {mode && (
        <form className="space-y-2 rounded-xl border border-line bg-bg-2/60 p-3" onSubmit={(e) => { e.preventDefault(); void send(); }}>
          <p className="text-xs font-medium">{MODE_TITLE[mode]}</p>
          {mode === "progress" && <Field label={`Andamento: ${pct}%`}><input type="range" min={0} max={100} step={5} value={pct} onChange={(e) => setPct(e.target.value)} className="w-full" /></Field>}
          {mode === "extension" && <p className="text-[11px] text-muted">Prazo atual: {dueAt ? new Date(dueAt).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" }) : "sem prazo"}</p>}
          {mode === "extension" && <Field label="Novo prazo solicitado"><Input type="datetime-local" required value={due} onChange={(e) => setDue(e.target.value)} /></Field>}
          {(needsMsg || mode === "progress" || mode === "working" || mode === "done") && (
            <Textarea aria-label={mode === "extension" ? "Justificativa" : "Mensagem"} className="min-h-16" required={!!needsMsg} minLength={needsMsg ? 5 : undefined} maxLength={2000}
              placeholder={mode === "extension" ? "Justificativa do pedido" : needsMsg ? "Descreva a situação" : "Comentário (opcional)"} value={msg} onChange={(e) => setMsg(e.target.value)} />
          )}
          {mode === "extension" && <><Input aria-label="Impedimentos identificados" placeholder="Impedimentos identificados (opcional)" value={blockers} onChange={(e) => setBlockers(e.target.value)} /><Input aria-label="Impacto esperado" placeholder="Impacto esperado no resultado/equipe (opcional)" value={impact} onChange={(e) => setImpact(e.target.value)} /></>}
          {(mode === "progress" || mode === "done" || mode === "blocker") && <Input aria-label="Link de evidência" type="url" placeholder="Link de evidência (opcional)" value={url} onChange={(e) => setUrl(e.target.value)} />}
          <div className="flex gap-2"><Button type="submit" size="sm" disabled={loading}>{loading ? "Enviando..." : "Enviar"}</Button><Button type="button" size="sm" variant="ghost" onClick={() => setMode(null)}>Cancelar</Button></div>
        </form>
      )}
      <Feedback error={error} message={message} />
    </div>
  );
}

/* ------------------------------------------------------------------ prorrogação: decisão do gestor */

export type Recommendation = { decision: string; suggestedDueAt: string | null; rationale: string; facts: string[]; inferences: string[]; recommendation: string; disclaimer: string };

export function ExtensionDecision({ id, recommendation }: { id: string; recommendation: Recommendation | null }) {
  const [counter, setCounter] = useState(recommendation?.suggestedDueAt ? new Date(new Date(recommendation.suggestedDueAt).getTime() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 16) : "");
  const [note, setNote] = useState("");
  const { run, loading, error } = useAction();
  const decide = (decision: string) => run(`/api/task-extensions/${id}`, { decision, counterDueAt: decision === "counter" ? new Date(counter).toISOString() : undefined, note: note || undefined }, { method: "PATCH" });
  const rec = recommendation?.decision;
  return (
    <div className="mt-2 space-y-2">
      {recommendation && (
        <div className="rounded-lg border border-line bg-bg-2/60 p-2.5 text-xs">
          <p className="font-medium text-fg">Flávio: {recommendation.recommendation}</p>
          <p className="mt-0.5 text-muted">{recommendation.rationale}</p>
          <details className="mt-1 text-muted"><summary className="cursor-pointer">Fatos e inferências</summary>
            <p className="mt-1 font-medium text-fg">Fatos</p><ul className="list-disc pl-4">{recommendation.facts.map((f, i) => <li key={i}>{f}</li>)}</ul>
            {recommendation.inferences.length > 0 && <><p className="mt-1 font-medium text-fg">Inferências (não são fatos)</p><ul className="list-disc pl-4">{recommendation.inferences.map((f, i) => <li key={i}>{f}</li>)}</ul></>}
            <p className="mt-1 italic">{recommendation.disclaimer}</p>
          </details>
        </div>
      )}
      <Input aria-label="Observação da decisão" placeholder="Observação para o responsável (opcional)" value={note} onChange={(e) => setNote(e.target.value)} />
      <div className="flex flex-wrap items-center gap-2">
        <Button size="sm" disabled={loading} onClick={() => decide("approve")} variant={rec === "approve" ? "primary" : "secondary"}><Check size={13} />Aprovar</Button>
        <Button size="sm" disabled={loading} onClick={() => decide("reject")} variant={rec === "reject" ? "primary" : "secondary"}><X size={13} />Rejeitar</Button>
        <Input aria-label="Outra data" type="datetime-local" className="!w-auto" value={counter} onChange={(e) => setCounter(e.target.value)} />
        <Button size="sm" disabled={loading || !counter} onClick={() => decide("counter")} variant={rec === "counter" ? "primary" : "secondary"}>Propor esta data</Button>
      </div>
      <Feedback error={error} />
    </div>
  );
}

/* ------------------------------------------------------------------ regras, escalonamento e tom (alerts:manage) */

export type RuleRow = {
  id: string; name: string; trigger: string; offsetMinutes: number; staleAfterHours: number; repeatEveryMinutes: number | null; maxReminders: number;
  allowedStartHour: number; allowedEndHour: number; alertPriority: string; active: boolean; priorities: string[];
  escalation: { enabled: boolean; maxAttempts: number; steps: { afterMinutes: number; userIds: string[] }[] };
};

export function RulesManager({ rules, users, triggers }: { rules: RuleRow[]; users: { id: string; name: string }[]; triggers: Record<string, string> }) {
  const [f, setF] = useState({ name: "", trigger: "before_due", offsetH: "24", staleH: "48", repeatH: "", max: "3", start: "8", end: "18", prio: "medium", p: ["low", "medium", "high"], esc: false, s1m: "120", s1u: "", s2m: "480", s2u: "", attempts: "2" });
  const { run, loading, error, message } = useAction();
  const nameOf = (id: string) => users.find((u) => u.id === id)?.name ?? "—";
  async function create(e: React.FormEvent) {
    e.preventDefault();
    const steps = [f.s1u ? { afterMinutes: Number(f.s1m), userIds: [f.s1u] } : null, f.s2u ? { afterMinutes: Number(f.s2m), userIds: [f.s2u] } : null].filter(Boolean);
    const r = await run("/api/task-alerts/rules", {
      name: f.name, trigger: f.trigger, offsetMinutes: Math.round(Number(f.offsetH) * 60), staleAfterHours: Number(f.staleH), repeatEveryMinutes: f.repeatH ? Math.round(Number(f.repeatH) * 60) : null,
      maxReminders: Number(f.max), allowedStartHour: Number(f.start), allowedEndHour: Number(f.end), priorities: f.p, alertPriority: f.prio, channels: ["in_app"],
      escalation: { enabled: f.esc, maxAttempts: Number(f.attempts), steps },
    }, { success: "Regra criada." });
    if (r) setF({ ...f, name: "" });
  }
  const togglePrio = (p: string) => setF((o) => ({ ...o, p: o.p.includes(p) ? o.p.filter((x) => x !== p) : [...o.p, p] }));
  return (
    <div className="space-y-4">
      {rules.length ? (
        <ul className="space-y-2">
          {rules.map((r) => (
            <li key={r.id} className="rounded-xl border border-line bg-bg-2/60 p-3 text-sm">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <p className="font-medium">{r.name} <span className="text-xs font-normal text-muted">· {triggers[r.trigger] ?? r.trigger}</span></p>
                <span className="flex items-center gap-1">
                  <Badge tone={r.active ? "success" : "neutral"}>{r.active ? "ativa" : "pausada"}</Badge>
                  <button onClick={() => run(`/api/task-alerts/rules/${r.id}`, { active: !r.active }, { method: "PATCH" })} className="rounded border border-line px-2 py-0.5 text-[11px] hover:bg-surface-2">{r.active ? "Pausar" : "Ativar"}</button>
                  <button onClick={() => run(`/api/task-alerts/rules/${r.id}`, undefined, { method: "DELETE" })} className="rounded border border-line px-2 py-0.5 text-[11px] text-danger hover:bg-surface-2">Excluir</button>
                </span>
              </div>
              <p className="mt-1 text-xs text-muted">
                {r.trigger === "before_due" && `${Math.round(r.offsetMinutes / 60)} h antes do prazo · `}{r.trigger === "overdue" && `${Math.round(r.offsetMinutes / 60)} h após vencer · `}{(r.trigger === "stale" || r.trigger === "priority_pending") && `${r.staleAfterHours} h · `}
                até {r.maxReminders} lembrete(s){r.repeatEveryMinutes ? `, a cada ${Math.round(r.repeatEveryMinutes / 60)} h` : ""} · {r.allowedStartHour}h–{r.allowedEndHour}h · prioridade {PRIORITY_LABEL[r.alertPriority as keyof typeof PRIORITY_LABEL] ?? r.alertPriority}
              </p>
              {r.escalation.enabled && <p className="mt-1 text-xs text-muted">Escalonamento (máx. {r.escalation.maxAttempts}): {r.escalation.steps.map((s, i) => `nível ${i + 1} após ${Math.round(s.afterMinutes / 60 * 10) / 10} h → ${s.userIds.map(nameOf).join(", ")}`).join(" · ")}</p>}
            </li>
          ))}
        </ul>
      ) : <p className="text-sm text-muted">Nenhuma regra configurada. Sem regras, nada é enviado automaticamente.</p>}

      <form onSubmit={create} className="space-y-3 rounded-xl border border-line p-3">
        <p className="text-sm font-medium">Nova regra</p>
        <div className="grid gap-2 sm:grid-cols-2">
          <Input aria-label="Nome da regra" required minLength={2} placeholder="Nome (ex.: Lembrete 24 h antes)" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
          <Select aria-label="Gatilho" value={f.trigger} onChange={(e) => setF({ ...f, trigger: e.target.value })}>{Object.entries(triggers).map(([k, l]) => <option key={k} value={k}>{l}</option>)}</Select>
          {(f.trigger === "before_due" || f.trigger === "overdue") && <Field label={f.trigger === "before_due" ? "Antecedência (horas)" : "Tolerância após vencer (horas)"}><Input type="number" min={0} value={f.offsetH} onChange={(e) => setF({ ...f, offsetH: e.target.value })} /></Field>}
          {(f.trigger === "stale" || f.trigger === "priority_pending") && <Field label="Considerar após (horas)"><Input type="number" min={1} value={f.staleH} onChange={(e) => setF({ ...f, staleH: e.target.value })} /></Field>}
          <Field label="Repetir a cada (horas)" hint="Vazio = não repetir"><Input type="number" min={1} value={f.repeatH} onChange={(e) => setF({ ...f, repeatH: e.target.value })} /></Field>
          <Field label="Máximo de lembretes"><Input type="number" min={1} max={10} value={f.max} onChange={(e) => setF({ ...f, max: e.target.value })} /></Field>
          <Field label="Horário permitido (início)"><Input type="number" min={0} max={23} value={f.start} onChange={(e) => setF({ ...f, start: e.target.value })} /></Field>
          <Field label="Horário permitido (fim)"><Input type="number" min={1} max={24} value={f.end} onChange={(e) => setF({ ...f, end: e.target.value })} /></Field>
          <Field label="Prioridade do alerta"><Select value={f.prio} onChange={(e) => setF({ ...f, prio: e.target.value })}>{PRIORITIES.map((p) => <option key={p} value={p}>{PRIORITY_LABEL[p]}</option>)}</Select></Field>
          <fieldset><legend className="mb-1.5 text-xs font-medium text-muted">Tarefas abrangidas</legend>
            {(["low", "medium", "high"] as const).map((p) => <label key={p} className="mr-3 inline-flex items-center gap-1 text-xs"><input type="checkbox" checked={f.p.includes(p)} onChange={() => togglePrio(p)} />{PRIORITY_LABEL[p]}</label>)}
          </fieldset>
        </div>
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={f.esc} onChange={(e) => setF({ ...f, esc: e.target.checked })} />Escalonar se não houver resposta nem atualização</label>
        {f.esc && (
          <div className="grid gap-2 rounded-lg border border-line p-2 sm:grid-cols-2">
            <Field label="Nível 1: após (minutos)"><Input type="number" min={15} value={f.s1m} onChange={(e) => setF({ ...f, s1m: e.target.value })} /></Field>
            <Field label="Nível 1: notificar (gestor)"><Select value={f.s1u} onChange={(e) => setF({ ...f, s1u: e.target.value })}><option value="">—</option>{users.map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}</Select></Field>
            <Field label="Nível 2: após (minutos)"><Input type="number" min={15} value={f.s2m} onChange={(e) => setF({ ...f, s2m: e.target.value })} /></Field>
            <Field label="Nível 2: notificar (superior)"><Select value={f.s2u} onChange={(e) => setF({ ...f, s2u: e.target.value })}><option value="">— (opcional)</option>{users.map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}</Select></Field>
            <Field label="Máximo de tentativas"><Input type="number" min={1} max={5} value={f.attempts} onChange={(e) => setF({ ...f, attempts: e.target.value })} /></Field>
            <p className="text-[11px] text-muted sm:col-span-2">Para automaticamente se a tarefa for concluída, cancelada, bloqueada com justificativa, atualizada ou se o responsável responder.</p>
          </div>
        )}
        <Button type="submit" size="sm" disabled={loading}>{loading ? "Salvando..." : "Criar regra"}</Button>
        <Feedback error={error} message={message} />
      </form>
    </div>
  );
}

export function ToneForm({ tone, customTone }: { tone: string; customTone?: string }) {
  const [t, setT] = useState(tone);
  const [c, setC] = useState(customTone ?? "");
  const { run, loading, error, message } = useAction();
  return (
    <form className="space-y-2" onSubmit={(e) => { e.preventDefault(); void run("/api/task-alerts/settings", { tone: t, customTone: c || undefined }, { method: "PUT", success: "Tom salvo." }); }}>
      <Select aria-label="Tom de comunicação" value={t} onChange={(e) => setT(e.target.value)}>{TONES.map((x) => <option key={x} value={x}>{TONE_LABEL[x]}</option>)}</Select>
      {t === "custom" && <Textarea aria-label="Descrição do tom" className="min-h-16" required placeholder="Descreva o tom da sua organização" maxLength={300} value={c} onChange={(e) => setC(e.target.value)} />}
      <p className="text-[11px] text-muted">Vale para as mensagens do Flávio e dos lembretes automáticos. Cada regra pode usar outro tom. Tipos de mensagem: {MESSAGE_KINDS.map((k) => MESSAGE_KIND_LABEL[k]).join(", ")}.</p>
      <Button type="submit" size="sm" disabled={loading}>Salvar tom</Button><Feedback error={error} message={message} />
    </form>
  );
}

export function RunAutomationButton() {
  const { run, loading, error, message } = useAction();
  return (
    <div>
      <Button size="sm" variant="secondary" disabled={loading} onClick={async () => {
        const r = await run<{ dispatched: number; created: number; escalated: number; goalNotices: number; skipped: number }>("/api/task-alerts/run", {}, { refresh: true });
        if (r) alert(`Automação executada agora: ${r.dispatched} agendado(s) enviado(s), ${r.created} lembrete(s) criado(s), ${r.escalated} escalonamento(s), ${r.goalNotices} aviso(s) de meta.`);
      }}><Send size={13} />{loading ? "Executando..." : "Executar automação agora"}</Button>
      <Feedback error={error} message={message} />
    </div>
  );
}
