"use client";
/**
 * Resumo "antes → depois" exibido antes de confirmar uma ação do Flávio.
 * Busca a prévia no servidor (só leitura); a execução continua no botão de confirmação, pelo backend.
 */
import { useEffect, useState } from "react";
import { ArrowRight, FilePlus2, Loader2, PencilLine } from "lucide-react";
import { api } from "@/lib/api-client";
import type { RecordChange } from "@/server/ai/flavio/preview";

type Preview = { title: string; kind: string; changes: RecordChange[] };

export function ChangePreview({ token, onReady }: { token: string; onReady?: (ok: boolean) => void }) {
  const [data, setData] = useState<Preview | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let alive = true;
    setData(null); setError(null);
    api<Preview>("/api/flavio/actions/preview", { body: { token } })
      .then((p) => { if (alive) { setData(p); onReady?.(true); } })
      .catch((e) => { if (alive) { setError((e as Error).message); onReady?.(false); } });
    return () => { alive = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token]);

  if (error) return <p role="alert" className="text-xs text-danger">Não consegui montar a prévia: {error}</p>;
  if (!data) return <p className="flex items-center gap-2 text-xs text-muted" role="status"><Loader2 size={13} className="animate-spin" aria-hidden />Calculando o que vai mudar…</p>;

  return (
    <div className="space-y-2" aria-label="O que vai mudar">
      {data.changes.map((c, i) => (
        <section key={i} className="rounded-lg border border-line bg-surface/60 p-2.5" aria-label={`${c.kind === "create" ? "Novo registro" : "Alteração"}: ${c.entity} ${c.label}`}>
          <p className="mb-1.5 flex flex-wrap items-center gap-1.5 text-xs">
            <span className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-semibold ${c.kind === "create" ? "bg-success/15 text-success" : "bg-warning/15 text-warning"}`}>
              {c.kind === "create" ? <FilePlus2 size={12} aria-hidden /> : <PencilLine size={12} aria-hidden />}
              {c.kind === "create" ? "Novo registro" : "Alteração"}
            </span>
            <span className="text-muted">{c.entity}{c.fields.some((f) => f.after === c.label) ? "" : ":"}</span>
            {/* O nome só aparece aqui quando não está repetido em um dos campos (evita ler o mesmo texto duas vezes). */}
            {!c.fields.some((f) => f.after === c.label) && <span className="font-medium text-fg">{c.label}</span>}
          </p>
          <table className="w-full text-[12px]">
            <caption className="sr-only">{c.kind === "create" ? `Campos do novo registro ${c.entity}` : `Valor atual e proposto de ${c.entity}`}</caption>
            <thead className="sr-only sm:not-sr-only">
              <tr className="text-left text-[10px] uppercase tracking-wide text-muted">
                <th scope="col" className="pb-1 pr-2 font-semibold">Campo</th>
                {c.kind === "update" && <th scope="col" className="pb-1 pr-2 font-semibold">Atual</th>}
                <th scope="col" className="pb-1 font-semibold">{c.kind === "update" ? "Proposto" : "Valor"}</th>
              </tr>
            </thead>
            <tbody>
              {c.fields.map((f) => (
                <tr key={f.field} className="border-t border-line/60 align-top">
                  <th scope="row" className="py-1 pr-2 text-left font-medium text-muted">{f.field}</th>
                  {c.kind === "update" && (
                    <td className="py-1 pr-2">
                      {f.comparable && f.before !== null
                        ? <span className="text-fg/80 line-through decoration-danger/60">{f.before}</span>
                        : <span className="text-muted italic">sem valor atual</span>}
                    </td>
                  )}
                  <td className="py-1">
                    <span className="inline-flex items-center gap-1 font-medium text-fg">
                      {c.kind === "update" && <ArrowRight size={12} className="text-primary-2 sm:hidden" aria-hidden />}
                      {f.after}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {c.kind === "update" && c.fields.some((f) => !f.comparable) && !c.note && (
            <p className="mt-1 text-[11px] text-muted">Sem valor atual disponível: mostrando só o valor proposto, sem comparação.</p>
          )}
          {c.note && <p className="mt-1 text-[11px] text-muted">{c.note}</p>}
        </section>
      ))}
    </div>
  );
}
