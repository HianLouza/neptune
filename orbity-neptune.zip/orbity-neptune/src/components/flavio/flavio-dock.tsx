"use client";
/**
 * Flávio — ponto de acesso persistente + painel lateral.
 * Usa só a API do backend (/api/flavio/*): nenhum provedor de IA é chamado pelo navegador.
 */
import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  X, Send, History, SquarePen, Loader2, CircleAlert, ShieldCheck, ChevronDown, ChevronRight, ArrowUpRight, ArrowDownRight,
  CheckCircle2, Database, Trash2, ArrowLeft, Lock, Cpu, Calculator,
} from "lucide-react";
import { api } from "@/lib/api-client";
import { parseFilters } from "@/lib/metrics-filters";
import { FLAVIO, moduleFor, suggestionsFor } from "@/server/ai/flavio/identity";
import type { FlavioAnswer } from "@/server/ai/flavio";
import type { ActionProposal } from "@/server/ai/flavio/actions";
import { ChangePreview } from "./change-preview";
import { cx } from "@/components/ui";

type Status = { available: boolean; canUse: boolean; mode: "ia" | "deterministico"; modeLabel: string; reason: string | null; greeting: string };
type Msg = { id: string; role: "user" | "assistant"; text: string; at: string; answer?: FlavioAnswer; error?: boolean };
type Session = { id: string; startedAt: string; endedAt: string; title: string; turns: { id: string; question: string; answer: string; at: string; mode: string }[] };
type ConfirmState = { token: string; status: "review" | "running" | "done" | "error"; message?: string; records?: { kind: string; id: string; href: string }[] };

const uid = () => Math.random().toString(36).slice(2);

export function FlavioAvatar({ size = 36 }: { size?: number }) {
  return (
    <span aria-hidden className="flex shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-primary to-navy font-bold text-white shadow-lg ring-2 ring-primary-2/40"
      style={{ width: size, height: size, fontSize: size * 0.42 }}>F</span>
  );
}

export function FlavioDock({ onOpenChange }: { onOpenChange?: (open: boolean) => void }) {
  const pathname = usePathname();
  const [open, setOpenState] = useState(false);
  const [status, setStatus] = useState<Status | null>(null);
  const [statusError, setStatusError] = useState(false);
  const [view, setView] = useState<"chat" | "history">("chat");
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [since, setSince] = useState<string | null>(null);
  const [lastIntent, setLastIntent] = useState<string | undefined>();
  /** Investigação salva (mesma base do Business Brain) à qual esta conversa pertence. */
  const [convId, setConvId] = useState<string | null>(null);
  const endRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const setOpen = useCallback((v: boolean) => { setOpenState(v); onOpenChange?.(v); }, [onOpenChange]);

  const loadStatus = useCallback(() => {
    api<Status>("/api/flavio/status").then((s) => { setStatus(s); setStatusError(false); }).catch(() => setStatusError(true));
  }, []);
  useEffect(() => { loadStatus(); }, [loadStatus]);

  const mod = moduleFor(pathname);
  const suggestions = suggestionsFor(mod.key);

  const send = useCallback(async (text: string) => {
    const q = text.trim();
    if (!q || busy) return;
    const now = new Date().toISOString();
    const conv = since ?? now;
    if (!since) setSince(now);
    setMsgs((m) => [...m, { id: uid(), role: "user", text: q, at: now }]);
    setInput(""); setBusy(true);
    try {
      const filters = parseFilters(new URLSearchParams(window.location.search));
      const a = await api<FlavioAnswer>("/api/flavio/ask", { body: { message: q, route: window.location.pathname + window.location.search, filters, conversationSince: conv, lastIntent, conversationId: convId ?? undefined } });
      if (a.intent) setLastIntent(a.intent);
      if (a.conversationId) setConvId(a.conversationId);
      setMsgs((m) => [...m, { id: uid(), role: "assistant", text: a.text, at: a.at, answer: a }]);
    } catch (e) {
      setMsgs((m) => [...m, { id: uid(), role: "assistant", text: `Não consegui responder agora: ${(e as Error).message}. Nenhuma ação foi executada.`, at: new Date().toISOString(), error: true }]);
    } finally {
      setBusy(false);
      setTimeout(() => endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" }), 60);
    }
  }, [busy, since, lastIntent, convId]);

  // Outros componentes (ex.: "Perguntar ao Flávio" num gráfico) abrem o painel com uma pergunta.
  useEffect(() => {
    const h = (e: Event) => { const d = (e as CustomEvent<{ message: string }>).detail; setOpen(true); setView("chat"); if (d?.message) send(d.message); };
    window.addEventListener("flavio:ask", h);
    return () => window.removeEventListener("flavio:ask", h);
  }, [send, setOpen]);

  useEffect(() => {
    if (!open) return;
    const t = setTimeout(() => inputRef.current?.focus(), 50);
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") setOpen(false); };
    window.addEventListener("keydown", onKey);
    return () => { clearTimeout(t); window.removeEventListener("keydown", onKey); };
  }, [open, setOpen]);

  if (status && !status.canUse) return null;

  const availability = statusError
    ? { dot: "bg-danger", text: "Indisponível (sem conexão com o servidor)" }
    : !status ? { dot: "bg-muted", text: "Verificando..." }
    : !status.available ? { dot: "bg-danger", text: status.reason ?? "Indisponível" }
    : status.mode === "ia" ? { dot: "bg-success", text: "Disponível · IA conectada" }
    : { dot: "bg-warning", text: "Disponível · modo determinístico" };

  return (
    <>
      {!open && (
        <button type="button" onClick={() => setOpen(true)} aria-label={`Abrir ${FLAVIO.name}, ${FLAVIO.title}. ${availability.text}`}
          className="fixed bottom-4 right-4 z-30 flex items-center gap-2.5 rounded-full border border-line bg-surface/95 py-1.5 pl-1.5 pr-4 shadow-2xl backdrop-blur hover:border-primary-2 print:hidden sm:bottom-6 sm:right-6">
          <span className="relative"><FlavioAvatar size={38} /><span className={cx("absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full ring-2 ring-surface", availability.dot)} /></span>
          <span className="hidden text-left leading-tight sm:block"><span className="block text-sm font-semibold">{FLAVIO.name}</span><span className="block text-[11px] text-muted">Inteligência comercial</span></span>
        </button>
      )}
      {open && (
        <aside role="dialog" aria-modal="false" aria-labelledby="flavio-title"
          className="fixed inset-y-0 right-0 z-40 flex w-full flex-col border-l border-line bg-bg/98 shadow-2xl backdrop-blur sm:w-[420px] print:hidden">
          <header className="flex items-center gap-3 border-b border-line px-4 py-3">
            <FlavioAvatar />
            <div className="min-w-0 flex-1">
              <p id="flavio-title" className="font-semibold leading-tight">{FLAVIO.name}</p>
              <p className="truncate text-[11px] text-muted">{FLAVIO.title}</p>
              <p className="flex items-center gap-1.5 text-[11px]" aria-live="polite"><i className={cx("h-2 w-2 rounded-full", availability.dot)} /><span className="truncate text-muted">{availability.text}</span></p>
            </div>
            <button type="button" onClick={() => setView(view === "history" ? "chat" : "history")} aria-pressed={view === "history"} className="rounded-lg p-2 text-muted hover:bg-surface-2 hover:text-fg" aria-label="Histórico de conversas" title="Histórico"><History size={18} /></button>
            <Link href={convId ? `/business-brain?c=${convId}` : "/business-brain"} onClick={() => setOpen(false)} className="flex h-11 w-11 items-center justify-center rounded-lg text-muted hover:bg-surface-2 hover:text-fg focus-visible:outline-2 focus-visible:outline-primary-2"
              aria-label={convId ? "Continuar esta conversa na tela completa Pergunte ao Flávio" : "Abrir a tela completa Pergunte ao Flávio"} title="Abrir a tela completa (Pergunte ao Flávio)"><ArrowUpRight size={18} /></Link>
            <button type="button" onClick={() => { setMsgs([]); setSince(null); setLastIntent(undefined); setConvId(null); setView("chat"); }} className="rounded-lg p-2 text-muted hover:bg-surface-2 hover:text-fg" aria-label="Nova conversa" title="Nova conversa"><SquarePen size={18} /></button>
            <button type="button" onClick={() => setOpen(false)} className="rounded-lg p-2 text-muted hover:bg-surface-2 hover:text-fg" aria-label={`Fechar ${FLAVIO.name}`}><X size={18} /></button>
          </header>

          {view === "history" ? <HistoryView onBack={() => setView("chat")} /> : (
            <>
              <div className="flex-1 space-y-4 overflow-y-auto px-4 py-4" aria-live="polite" aria-busy={busy}>
                <p className="text-[11px] text-muted">Contexto: <span className="text-fg">{mod.label}</span>. Uso só dados que seu perfil pode ver. Nada é criado ou alterado sem a sua confirmação.</p>
                {!msgs.length && (
                  <div className="space-y-3">
                    <div className="rounded-xl border border-line bg-surface/70 p-3 text-sm leading-relaxed">{status?.greeting ?? FLAVIO.greeting}</div>
                    {status && status.mode === "deterministico" && status.available && (
                      <p className="flex gap-2 rounded-lg border border-warning/40 bg-warning/10 p-2.5 text-[11px] text-warning"><Calculator size={14} className="shrink-0" aria-hidden />Nenhum provedor de IA configurado: respondo com análises calculadas diretamente das métricas, sem texto gerado por modelo.</p>
                    )}
                  </div>
                )}
                {msgs.map((m) => m.role === "user"
                  ? <div key={m.id} className="ml-8 rounded-xl bg-primary/20 px-3 py-2 text-sm">{m.text}</div>
                  : <AssistantMessage key={m.id} m={m} onAsk={send} />)}
                {busy && <p className="flex items-center gap-2 text-xs text-muted"><Loader2 size={14} className="animate-spin" aria-hidden />{FLAVIO.name} está analisando os dados...</p>}
                <div ref={endRef} />
              </div>
              <div className="border-t border-line p-3">
                <div className="mb-2 flex gap-1.5 overflow-x-auto pb-1" role="list" aria-label="Perguntas sugeridas">
                  {suggestions.map((s) => <button key={s} role="listitem" type="button" disabled={busy || !status?.available} onClick={() => send(s)} className="shrink-0 rounded-full border border-line px-2.5 py-1 text-[11px] text-muted hover:border-primary-2 hover:text-fg disabled:opacity-50">{s}</button>)}
                </div>
                <form onSubmit={(e) => { e.preventDefault(); send(input); }} className="flex items-end gap-2 rounded-xl border border-line bg-bg-2/60 p-1.5 pl-3">
                  <label htmlFor="flavio-input" className="sr-only">Pergunta para o {FLAVIO.name}</label>
                  <textarea id="flavio-input" ref={inputRef} rows={1} maxLength={2000} value={input} disabled={!status?.available}
                    onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(input); } }}
                    placeholder={status?.available === false ? "Flávio indisponível" : `Pergunte ao ${FLAVIO.name}...`} className="max-h-32 min-h-9 flex-1 resize-none bg-transparent py-2 text-sm outline-none placeholder:text-muted" />
                  <button type="submit" disabled={busy || !input.trim() || !status?.available} className="rounded-lg bg-gradient-to-r from-primary to-navy p-2 text-white disabled:opacity-50" aria-label="Enviar"><Send size={16} /></button>
                </form>
              </div>
            </>
          )}
        </aside>
      )}
    </>
  );
}

function ModeBadge({ a }: { a: FlavioAnswer }) {
  if (a.mode === "ia") return <span className="inline-flex items-center gap-1 rounded-full border border-line px-2 py-0.5 text-[10px] text-muted"><Cpu size={11} aria-hidden />Texto gerado por IA ({a.model}) · números do sistema · confira</span>;
  if (a.mode === "deterministico") return <span className="inline-flex items-center gap-1 rounded-full border border-line px-2 py-0.5 text-[10px] text-muted"><Calculator size={11} aria-hidden />Calculado das métricas, sem modelo de IA</span>;
  if (a.mode === "bloqueado") return <span className="inline-flex items-center gap-1 rounded-full border border-danger/50 px-2 py-0.5 text-[10px] text-danger"><ShieldCheck size={11} aria-hidden />Bloqueado por segurança</span>;
  return <span className="inline-flex items-center gap-1 rounded-full border border-danger/50 px-2 py-0.5 text-[10px] text-danger"><CircleAlert size={11} aria-hidden />Indisponível</span>;
}

function AssistantMessage({ m, onAsk }: { m: Msg; onAsk: (q: string) => void }) {
  const a = m.answer;
  const an = a?.analysis;
  const [showEv, setShowEv] = useState(false);
  const [showData, setShowData] = useState(false);
  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2"><FlavioAvatar size={22} /><span className="text-xs font-semibold">{FLAVIO.name}</span>{a && <ModeBadge a={a} />}</div>
      <div className={cx("rounded-xl border p-3 text-sm leading-relaxed", m.error ? "border-danger/50 bg-danger/10 text-danger" : "border-line bg-surface/70")}>
        <p className="whitespace-pre-wrap">{m.text}</p>
      </div>
      {an && an.indicators.length > 0 && (
        <dl className="grid grid-cols-2 gap-2">
          {an.indicators.slice(0, 6).map((i) => (
            <div key={i.label} className="rounded-lg border border-line bg-bg-2/60 p-2">
              <dt className="text-[10px] text-muted">{i.label}</dt>
              <dd className="text-sm font-semibold">{i.value}</dd>
              {i.detail && <dd className={cx("flex items-center gap-0.5 text-[10px]", i.trend === "up" ? "text-success" : i.trend === "down" ? "text-danger" : "text-muted")}>{i.trend === "up" ? <ArrowUpRight size={11} aria-hidden /> : i.trend === "down" ? <ArrowDownRight size={11} aria-hidden /> : null}{i.detail}</dd>}
            </div>
          ))}
        </dl>
      )}
      {an?.proposals.map((p) => <ProposalCard key={p.token} p={p} />)}
      {an && an.evidence.length > 0 && (
        <div>
          <button type="button" onClick={() => setShowEv(!showEv)} aria-expanded={showEv} className="flex items-center gap-1 text-[11px] text-primary-2 hover:underline">{showEv ? <ChevronDown size={13} /> : <ChevronRight size={13} />}Evidências ({an.evidence.length})</button>
          {showEv && (
            <ul className="mt-1 space-y-1">
              {an.evidence.map((e, i) => (
                <li key={i} className="rounded-lg border border-line/70 px-2.5 py-1.5 text-[11px]">
                  {e.href ? <Link href={e.href} className="font-medium hover:text-primary-2 hover:underline">{e.label}</Link> : <span className="font-medium">{e.label}</span>}
                  <span className="block text-muted">{e.detail}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
      {an && (
        <div>
          <button type="button" onClick={() => setShowData(!showData)} aria-expanded={showData} className="flex items-center gap-1 text-[11px] text-muted hover:text-fg"><Database size={12} aria-hidden />Dados usados nesta resposta</button>
          {showData && (
            <div className="mt-1 space-y-1 rounded-lg border border-line/70 p-2.5 text-[11px] text-muted">
              <p><span className="text-fg">Análise:</span> {an.title}</p>
              {an.period && <p><span className="text-fg">Período:</span> {an.period}</p>}
              <p><span className="text-fg">Filtros:</span> {an.filters.length ? an.filters.join(", ") : "nenhum"}</p>
              <p><span className="text-fg">Fontes:</span> {an.sources.join("; ") || "nenhuma"}</p>
              {an.criteria.length > 0 && <div><span className="text-fg">Critérios:</span><ul className="list-disc pl-4">{an.criteria.map((c) => <li key={c}>{c}</li>)}</ul></div>}
              <p><span className="text-fg">Tela:</span> {a?.screen.module}</p>
              <p>Hipóteses aparecem marcadas como tal; os números vêm do serviço central de métricas.</p>
            </div>
          )}
        </div>
      )}
      {an && an.links.length > 0 && <div className="flex flex-wrap gap-2">{an.links.map((l) => <Link key={l.href} href={l.href} className="text-[11px] text-primary-2 hover:underline">{l.label}</Link>)}</div>}
      {an?.permissionNotes.map((n) => <p key={n} className="flex gap-1.5 text-[11px] text-warning"><Lock size={12} className="mt-0.5 shrink-0" aria-hidden />{n}</p>)}
      {a?.warnings.map((w) => <p key={w} className="flex gap-1.5 text-[11px] text-warning"><CircleAlert size={12} className="mt-0.5 shrink-0" aria-hidden />{w}</p>)}
      {a && a.suggestions.length > 0 && a.mode !== "bloqueado" && (
        <div className="flex flex-wrap gap-1">{a.suggestions.slice(0, 3).filter((s) => s !== m.text).map((s) => <button key={s} type="button" onClick={() => onAsk(s)} className="rounded-full border border-line px-2 py-0.5 text-[10px] text-muted hover:border-primary-2 hover:text-fg">{s}</button>)}</div>
      )}
    </div>
  );
}

function ProposalCard({ p }: { p: ActionProposal }) {
  const [st, setSt] = useState<ConfirmState | null>(null);
  const [previewOk, setPreviewOk] = useState(false);
  const confirm = async () => {
    setSt({ token: p.token, status: "running" });
    try {
      const r = await api<{ message: string; records: { kind: string; id: string; href: string }[] }>("/api/flavio/actions/confirm", { body: { token: p.token } });
      setSt({ token: p.token, status: "done", message: r.message, records: r.records });
    } catch (e) { setSt({ token: p.token, status: "error", message: (e as Error).message }); }
  };
  return (
    <div className="rounded-xl border border-primary-2/50 bg-primary/10 p-3 text-sm">
      <p className="font-semibold">{p.title}</p>
      <p className="text-xs text-muted">{p.summary}</p>
      {!st && (
        <div className="mt-2 flex flex-wrap items-center gap-2">
          <button type="button" disabled={!p.allowed} onClick={() => setSt({ token: p.token, status: "review" })} aria-label={`Revisar e confirmar: ${p.title}`}
            className="min-h-11 rounded-lg bg-gradient-to-r from-primary to-navy px-4 text-sm font-medium text-white focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary-2 disabled:opacity-50">Revisar e confirmar</button>
          {!p.allowed && <span className="flex items-center gap-1 text-[11px] text-warning"><Lock size={12} aria-hidden />Exige permissão {p.permission}</span>}
          <span className="text-[10px] text-muted">Válida até {new Date(p.expiresAt).toLocaleTimeString()}</span>
        </div>
      )}
      {st?.status === "review" && (
        <div className="mt-2 space-y-2 rounded-lg border border-line bg-bg-2/80 p-2.5" role="group" aria-label="Confirmação da ação">
          <p className="text-xs font-medium">Confira o que vai mudar antes de confirmar:</p>
          <ChangePreview token={p.token} onReady={setPreviewOk} />
          <p className="text-[11px] text-muted">Nada muda até você confirmar. O registro fica na auditoria em seu nome.</p>
          <div className="flex flex-wrap gap-2">
            <button type="button" onClick={confirm} disabled={!previewOk} aria-label={`Confirmar e executar: ${p.title}`}
              className="min-h-11 rounded-lg bg-gradient-to-r from-primary to-navy px-4 text-sm font-medium text-white focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary-2 disabled:opacity-50">Confirmar e executar</button>
            <button type="button" onClick={() => { setSt(null); setPreviewOk(false); }} aria-label={`Cancelar: ${p.title}`}
              className="min-h-11 rounded-lg border border-line px-4 text-sm focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary-2">Cancelar</button>
          </div>
        </div>
      )}
      {st?.status === "running" && <p className="mt-2 flex items-center gap-2 text-xs text-muted"><Loader2 size={13} className="animate-spin" aria-hidden />Executando...</p>}
      {st?.status === "done" && (
        <div className="mt-2 text-xs text-success" role="status">
          <p className="flex items-center gap-1.5"><CheckCircle2 size={14} aria-hidden />{st.message}</p>
          {st.records?.[0] && <Link href={st.records[0].href} className="text-primary-2 hover:underline">Abrir</Link>}
        </div>
      )}
      {st?.status === "error" && <p role="alert" className="mt-2 text-xs text-danger">Não executado: {st.message}</p>}
    </div>
  );
}

function HistoryView({ onBack }: { onBack: () => void }) {
  const [sessions, setSessions] = useState<Session[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [openId, setOpenId] = useState<string | null>(null);
  const [confirmErase, setConfirmErase] = useState(false);
  const load = () => api<Session[]>("/api/flavio/history").then(setSessions).catch((e) => setError((e as Error).message));
  useEffect(() => { load(); }, []);
  const erase = async (range?: { from: string; to: string }) => {
    try { await api("/api/flavio/history", { method: "DELETE", body: range ?? {} }); setConfirmErase(false); load(); } catch (e) { setError((e as Error).message); }
  };
  const s = sessions?.find((x) => x.id === openId);
  return (
    <div className="flex-1 overflow-y-auto px-4 py-4">
      <button type="button" onClick={s ? () => setOpenId(null) : onBack} className="mb-3 flex items-center gap-1 text-xs text-muted hover:text-fg"><ArrowLeft size={14} aria-hidden />{s ? "Voltar ao histórico" : "Voltar à conversa"}</button>
      {error && <p role="alert" className="text-sm text-danger">{error}</p>}
      {!sessions && !error && <p className="flex items-center gap-2 text-xs text-muted"><Loader2 size={14} className="animate-spin" aria-hidden />Carregando...</p>}
      {s ? (
        <div className="space-y-3">
          <p className="text-[11px] text-muted">{new Date(s.startedAt).toLocaleString()} · respostas guardadas como texto. Para números atualizados, pergunte de novo.</p>
          {s.turns.map((t) => (
            <div key={t.id} className="space-y-1">
              <p className="ml-8 rounded-xl bg-primary/20 px-3 py-2 text-sm">{t.question}</p>
              <p className="whitespace-pre-wrap rounded-xl border border-line bg-surface/70 p-3 text-sm">{t.answer}</p>
              <p className="text-[10px] text-muted">{new Date(t.at).toLocaleString()} · {t.mode === "ia" ? "texto gerado por IA" : t.mode === "bloqueado" ? "bloqueado" : "calculado das métricas"}</p>
            </div>
          ))}
          <button type="button" onClick={() => erase({ from: s.startedAt, to: s.endedAt })} className="flex items-center gap-1.5 text-xs text-danger hover:underline"><Trash2 size={13} aria-hidden />Apagar o conteúdo desta conversa</button>
        </div>
      ) : sessions && (
        <>
          {!sessions.length && <p className="text-sm text-muted">Nenhuma conversa ainda.</p>}
          <ul className="space-y-2">
            {sessions.map((x) => (
              <li key={x.id}>
                <button type="button" onClick={() => setOpenId(x.id)} className="w-full rounded-xl border border-line bg-surface/60 p-3 text-left hover:border-primary-2">
                  <span className="block truncate text-sm">{x.title}</span>
                  <span className="block text-[11px] text-muted">{new Date(x.startedAt).toLocaleString()} · {x.turns.length} pergunta(s)</span>
                </button>
              </li>
            ))}
          </ul>
          {sessions.length > 0 && (
            <div className="mt-4 border-t border-line pt-3 text-xs">
              {!confirmErase ? <button type="button" onClick={() => setConfirmErase(true)} className="flex items-center gap-1.5 text-danger hover:underline"><Trash2 size={13} aria-hidden />Apagar todo o meu histórico</button> : (
                <div className="space-y-2 rounded-lg border border-danger/50 p-2.5">
                  <p>O texto de todas as suas conversas com o {FLAVIO.name} será apagado e não poderá ser recuperado. O registro de uso (data, créditos) continua na auditoria.</p>
                  <div className="flex gap-2"><button type="button" onClick={() => erase()} className="rounded-lg bg-danger px-3 py-1.5 text-white">Apagar</button><button type="button" onClick={() => setConfirmErase(false)} className="rounded-lg border border-line px-3 py-1.5">Cancelar</button></div>
                </div>
              )}
            </div>
          )}
        </>
      )}
    </div>
  );
}
