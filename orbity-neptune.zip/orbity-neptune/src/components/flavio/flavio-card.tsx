"use client";
/** Cartão do Flávio no dashboard (substitui o antigo "ORBITY AI"): atalhos que abrem o painel lateral com a pergunta. */
import Link from "next/link";
import { BarChart3, Target, Network, FileText, Hourglass, ListChecks } from "lucide-react";
import { FLAVIO } from "@/server/ai/flavio/identity";
import { FlavioAvatar } from "./flavio-dock";

const ask = (message: string) => window.dispatchEvent(new CustomEvent("flavio:ask", { detail: { message } }));

export function FlavioCard() {
  const actions = [
    { icon: BarChart3, label: "Analisar performance do período", q: "Analise a performance comercial do período e aponte os principais gargalos." },
    { icon: ListChecks, label: "Prioridades da semana", q: "Quais ações devemos priorizar nesta semana?" },
    { icon: Hourglass, label: "Oportunidades paradas", q: "Quais oportunidades estão paradas?" },
    { icon: Target, label: "Leads com maior potencial", q: "Quais leads possuem maior potencial?" },
  ];
  return (
    <section className="card glow flex flex-col p-5" aria-label={`${FLAVIO.name}, ${FLAVIO.title}`}>
      <div className="flex items-center gap-3">
        <FlavioAvatar size={52} />
        <div>
          <p className="text-lg font-semibold">{FLAVIO.name}</p>
          <p className="text-sm text-muted">{FLAVIO.title}</p>
        </div>
      </div>
      <p className="mt-3 text-sm text-muted">Pergunte sobre os indicadores desta tela. Respondo com os dados da sua organização, mostro período, critérios e evidências, e só executo algo depois da sua confirmação.</p>
      <div className="mt-4 space-y-2">
        {actions.map((a) => (
          <button key={a.label} type="button" onClick={() => ask(a.q)} className="flex w-full items-center gap-3 rounded-xl border border-line bg-surface-2/60 px-4 py-2.5 text-left text-sm hover:border-primary-2">
            <a.icon size={18} className="text-primary-2" aria-hidden />{a.label}
          </button>
        ))}
        <Link href="/automacoes?novo=ia" className="flex w-full items-center gap-3 rounded-xl border border-line bg-surface-2/60 px-4 py-2.5 text-sm hover:border-primary-2"><Network size={18} className="text-primary-2" aria-hidden />Criar automação</Link>
        <Link href="/relatorios" className="flex w-full items-center gap-3 rounded-xl border border-line bg-surface-2/60 px-4 py-2.5 text-sm hover:border-primary-2"><FileText size={18} className="text-primary-2" aria-hidden />Gerar relatório</Link>
      </div>
    </section>
  );
}
