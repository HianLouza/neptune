"use client";
import { useRouter, useSearchParams } from "next/navigation";
import { ChevronDown } from "lucide-react";

export function PeriodSelect({ value }: { value: number }) {
  const router = useRouter();
  const sp = useSearchParams();
  return (
    <label className="relative flex items-center gap-2 rounded-xl border border-line bg-surface/70 px-4 py-2.5 text-sm">
      <span className="text-muted">Período:</span>
      <select value={value} onChange={(e) => { const p = new URLSearchParams(sp); p.set("periodo", e.target.value); router.push(`?${p}`); }}
        className="appearance-none bg-transparent pr-6 font-medium outline-none" aria-label="Período">
        <option value={7}>Últimos 7 dias</option><option value={30}>Últimos 30 dias</option><option value={90}>Últimos 90 dias</option>
      </select>
      <ChevronDown size={16} className="pointer-events-none absolute right-3 text-muted" />
    </label>
  );
}
