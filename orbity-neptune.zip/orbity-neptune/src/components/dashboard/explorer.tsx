"use client";
/**
 * Dashboard interativo: filtros globais (URL), cards com drill-down, série temporal com comparação, segmentação com
 * filtro cruzado, exportação CSV e atualização periódica. Todos os números vêm de /api/metrics (serviço central).
 */
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import {
  Target, Users, Trophy, Database, TrendingUp, Receipt, ArrowUp, ArrowDown, Minus, RefreshCw, Download, X, FilterX,
  CircleAlert, Loader2, ExternalLink, Info, Sparkles,
} from "lucide-react";
import type { DashboardBundle } from "@/server/domains/metrics";
import {
  COMPARE_MODES, DIMENSIONS, DIMENSION_LABELS, PERIOD_PRESETS, SOURCE_LABELS, UNAVAILABLE_DIMENSIONS, filtersToParams, type Dimension, type MetricFilters,
} from "@/lib/metrics-filters";
import { InteractiveBars, InteractiveTimeSeries, type SeriesDef } from "@/components/charts/interactive";
import { api } from "@/lib/api-client";
import { cx } from "@/components/ui";

type Perms = { crm: boolean; prospect: boolean; exportData: boolean; ai: boolean };
type DrillMetric = "leads" | "opportunities" | "won" | "lost" | "closed" | "revenue" | "open_pipeline";
type DrillRow = { id: string; entity: "lead" | "opportunity"; title: string; companyName: string | null; ownerName: string | null; status: string; stageName: string | null; source: string | null; campaignName: string | null; score: number | null; amountCents: number | null; createdAt: string; closedAt: string | null; href: string };
type DrillResult = { entity: "lead" | "opportunity"; total: number; totalAmountCents: number | null; rows: DrillRow[]; truncated: boolean; definition: { label: string; formula: string }; range: { start: string; end: string }; notApplicable?: string };
type DrillState = { metric: DrillMetric; title: string; window?: "current" | "previous"; pointStart?: string; pointEnd?: string; extra?: Partial<MetricFilters> };

const COMPARE_LABEL: Record<string, string> = { previous: "Período anterior", year: "Mesmo período do ano anterior", none: "Sem comparação" };
const STATUS_LABEL: Record<string, string> = { open: "Aberta", won: "Ganha", lost: "Perdida", new: "Novo", qualifying: "Em qualificação", qualified: "Qualificado", disqualified: "Desqualificado", converted: "Convertido" };
const REFRESH_MS = 60_000;

function useFormat(locale: string, currency: string) {
  return useMemo(() => {
    const cur = new Intl.NumberFormat(locale, { style: "currency", currency, maximumFractionDigits: 0 });
    const curC = new Intl.NumberFormat(locale, { style: "currency", currency, notation: "compact", maximumFractionDigits: 1 });
    const n = new Intl.NumberFormat(locale);
    const d = new Intl.DateTimeFormat(locale, { day: "2-digit", month: "short", timeZone: "UTC" });
    return {
      money: (c: number | null) => (c == null ? "n/d" : cur.format(c / 100)), moneyC: (c: number) => curC.format(c / 100), num: (v: number | null) => (v == null ? "n/a" : n.format(v)),
      pct: (v: number | null) => (v == null ? "n/d" : `${String(v).replace(".", ",")}%`), day: (iso: string) => d.format(new Date(iso)).replace(".", ""),
      dateTime: (iso: string) => new Date(iso).toLocaleString(locale, { dateStyle: "short", timeStyle: "short" }),
    };
  }, [locale, currency]);
}

function Delta({ v, suffix = "%" }: { v: number | null | undefined; suffix?: string }) {
  if (v == null) return <span className="text-xs text-muted">sem base de comparação</span>;
  const Icon = v > 0 ? ArrowUp : v < 0 ? ArrowDown : Minus;
  return <span className={cx("flex items-center gap-1 text-sm font-semibold", v > 0 ? "text-success" : v < 0 ? "text-danger" : "text-muted")}><Icon size={14} aria-hidden />{v > 0 ? "+" : ""}{String(v).replace(".", ",")}{suffix}</span>;
}

export function DashboardExplorer({ initial, initialFilters, perms, locale, currency }: { initial: DashboardBundle; initialFilters: MetricFilters; perms: Perms; locale: string; currency: string }) {
  const fmt = useFormat(locale, currency);
  const [filters, setFilters] = useState<MetricFilters>(initialFilters);
  const [data, setData] = useState<DashboardBundle>(initial);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [updatedAt, setUpdatedAt] = useState(initial.meta.generatedAt);
  const [auto, setAuto] = useState(true);
  const [dim, setDim] = useState<Dimension>("source");
  const [chartMetric, setChartMetric] = useState<"revenue" | "won" | "leads" | "conversion">("revenue");
  const [drill, setDrill] = useState<DrillState | null>(null);
  const reqId = useRef(0);

  const qs = useMemo(() => filtersToParams(filters).toString(), [filters]);

  const load = useCallback(async (f: MetricFilters, silent = false) => {
    const id = ++reqId.current;
    if (!silent) setLoading(true);
    try {
      const r = await api<DashboardBundle>(`/api/metrics/dashboard?${filtersToParams(f).toString()}`);
      if (id !== reqId.current) return;
      setData(r); setError(null); setUpdatedAt(r.meta.generatedAt);
    } catch (e) {
      if (id === reqId.current) setError((e as Error).message);
    } finally {
      if (id === reqId.current) setLoading(false);
    }
  }, []);

  // Filtros vivem na URL (compartilháveis e lidos pelo Flávio). replaceState evita recarregar a página inteira.
  const apply = (patch: Partial<MetricFilters>) => {
    const next = { ...filters, ...patch } as MetricFilters;
    for (const k of Object.keys(patch) as (keyof MetricFilters)[]) if (patch[k] === undefined || patch[k] === "") delete next[k];
    setFilters(next);
    const p = filtersToParams(next, new URLSearchParams(window.location.search));
    window.history.replaceState(null, "", `${window.location.pathname}${p.toString() ? "?" + p : ""}`);
    load(next);
  };

  // Atualização periódica enquanto a aba está visível + ao voltar para a aba.
  useEffect(() => {
    if (!auto) return;
    const tick = () => { if (document.visibilityState === "visible") load(filters, true); };
    const t = setInterval(tick, REFRESH_MS);
    document.addEventListener("visibilitychange", tick);
    return () => { clearInterval(t); document.removeEventListener("visibilitychange", tick); };
  }, [auto, filters, load]);

  const toggleFilter = (d: Dimension, key: string) => {
    const value = key === "__none__" ? (d === "campaign" ? "none" : undefined) : key;
    if (value === undefined) return;
    apply({ [d]: filters[d] === value ? undefined : value } as Partial<MetricFilters>);
  };

  const c = data.current, p = data.previous, dl = data.delta;
  const cards: { label: string; value: string; delta: React.ReactNode; prev?: string; icon: typeof Target; tone: string; metric: DrillMetric; def: string; allowed: boolean }[] = [
    { label: "Leads gerados", value: fmt.num(c.leads), delta: <Delta v={dl?.leads} />, prev: p ? fmt.num(p.leads) : undefined, icon: Target, tone: "from-primary to-navy", metric: "leads", def: data.definitions.leads.formula, allowed: perms.crm || perms.prospect },
    { label: "Oportunidades", value: fmt.num(c.opportunities), delta: <Delta v={dl?.opportunities} />, prev: p ? fmt.num(p.opportunities) : undefined, icon: Users, tone: "from-blue-600 to-indigo-500", metric: "opportunities", def: data.definitions.opportunities.formula, allowed: perms.crm },
    { label: "Vendas realizadas", value: fmt.num(c.won), delta: <Delta v={dl?.won} />, prev: p ? fmt.num(p.won) : undefined, icon: Trophy, tone: "from-emerald-600 to-teal-500", metric: "won", def: data.definitions.won.formula, allowed: perms.crm },
    { label: "Receita", value: fmt.money(c.revenueCents), delta: <Delta v={dl?.revenue} />, prev: p ? fmt.money(p.revenueCents) : undefined, icon: Database, tone: "from-amber-500 to-orange-500", metric: "revenue", def: data.definitions.revenue.formula, allowed: perms.crm },
    { label: "Taxa de conversão", value: fmt.pct(c.conversionRate), delta: <Delta v={dl?.conversionPp} suffix=" p.p." />, prev: p ? fmt.pct(p.conversionRate) : undefined, icon: TrendingUp, tone: "from-navy to-primary", metric: "closed", def: data.definitions.conversion.formula, allowed: perms.crm },
    { label: "Ticket médio", value: fmt.money(c.avgTicketCents), delta: <Delta v={dl?.avgTicket} />, prev: p ? fmt.money(p.avgTicketCents) : undefined, icon: Receipt, tone: "from-sky-600 to-cyan-500", metric: "won", def: data.definitions.avg_ticket.formula, allowed: perms.crm },
  ];

  const pts = data.series.points;
  const timeSeries: SeriesDef[] = [
    { key: "revenue", label: "Receita", color: "var(--primary)", kind: "area", format: (v) => fmt.moneyC(v) },
    ...(data.meta.comparison ? [{ key: "prevRevenue", label: "Receita (comparação)", color: "#94a3b8", kind: "line" as const, dashed: true, format: (v: number) => fmt.moneyC(v) }] : []),
    ...(c.leads != null ? [{ key: "leads", label: "Leads", color: "var(--primary-2)", kind: "line" as const, axis: "right" as const, format: (v: number) => fmt.num(v) }] : []),
    { key: "won", label: "Vendas", color: "#22c55e", kind: "bar", axis: "right", format: (v) => fmt.num(v), defaultHidden: true },
  ];
  const timePoints = pts.map((x) => ({
    label: fmt.day(x.start),
    range: data.series.bucketDays === 1 ? fmt.day(x.start) : `${fmt.day(x.start)} a ${fmt.day(new Date(Date.parse(x.end) - 1).toISOString())}`,
    values: { revenue: x.revenueCents, prevRevenue: x.prev?.revenueCents ?? null, leads: x.leads, won: x.won },
  }));

  const b = data.breakdowns[dim];
  const metricOf = (r: (typeof b.rows)[number]) => (chartMetric === "revenue" ? r.revenueCents : chartMetric === "won" ? r.won : chartMetric === "leads" ? r.leads ?? 0 : r.conversionRate ?? 0);
  const compareOf = (r: (typeof b.rows)[number]) => (chartMetric === "revenue" ? r.prevRevenueCents : chartMetric === "won" ? r.prevWon : null);
  const metricFmt = (v: number) => (chartMetric === "revenue" ? fmt.moneyC(v) : chartMetric === "conversion" ? fmt.pct(v) : fmt.num(v));
  const selectedKey = (() => { const v = filters[dim]; return v === "none" ? "__none__" : v ?? null; })();
  const optionName = (d: Dimension, id: string) => {
    const o = data.options;
    const list = d === "seller" ? o.sellers : d === "team" ? o.teams : d === "campaign" ? o.campaigns : d === "stage" ? o.stages : o.sources;
    return id === "none" ? "Sem campanha" : list.find((x) => x.id === id)?.name ?? (d === "source" ? SOURCE_LABELS[id] : id);
  };
  const activeChips = DIMENSIONS.filter((d) => filters[d]).map((d) => ({ d, label: `${DIMENSION_LABELS[d]}: ${optionName(d, filters[d]!)}` }));

  const exportHref = (tipo: string, extra = "") => `/api/metrics/export?tipo=${tipo}${qs ? "&" + qs : ""}${extra}`;
  const askFlavio = (q: string) => window.dispatchEvent(new CustomEvent("flavio:ask", { detail: { message: q } }));

  return (
    <div className="space-y-5">
      {/* --------- filtros globais --------- */}
      <section className="card p-4" aria-label="Filtros globais do dashboard">
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-5 2xl:grid-cols-9">
          <FilterSelect label="Período" value={filters.from ? "custom" : String(filters.days)} onChange={(v) => v === "custom"
            ? apply({ from: new Date(Date.now() - 30 * 864e5).toISOString().slice(0, 10), to: new Date().toISOString().slice(0, 10) })
            : apply({ days: Number(v) as MetricFilters["days"], from: undefined, to: undefined })}
            options={[...PERIOD_PRESETS.map((d) => ({ id: String(d), name: `Últimos ${d} dias` })), { id: "custom", name: "Personalizado" }]} />
          <FilterSelect label="Comparar com" value={filters.compare} onChange={(v) => apply({ compare: v as MetricFilters["compare"] })} options={COMPARE_MODES.map((m) => ({ id: m, name: COMPARE_LABEL[m] }))} />
          <FilterSelect label="Vendedor" value={filters.seller ?? ""} onChange={(v) => apply({ seller: v || undefined })} options={data.options.sellers} all="Todos" />
          <FilterSelect label="Equipe" value={filters.team ?? ""} onChange={(v) => apply({ team: v || undefined })} options={data.options.teams} all={data.options.teams.length ? "Todas" : "Nenhuma equipe"} />
          <FilterSelect label="Campanha" value={filters.campaign ?? ""} onChange={(v) => apply({ campaign: (v || undefined) as MetricFilters["campaign"] })} options={[{ id: "none", name: "Sem campanha" }, ...data.options.campaigns]} all="Todas" />
          <FilterSelect label="Origem" value={filters.source ?? ""} onChange={(v) => apply({ source: (v || undefined) as MetricFilters["source"] })} options={data.options.sources} all="Todas" />
          <FilterSelect label="Etapa" value={filters.stage ?? ""} onChange={(v) => apply({ stage: v || undefined })} options={data.options.stages} all="Todas" />
          {UNAVAILABLE_DIMENSIONS.map((u) => (
            <label key={u.key} className="flex flex-col gap-1 text-[11px] text-muted" title={u.reason}>
              <span className="flex items-center gap-1">{u.label}<Info size={11} aria-hidden /></span>
              <select disabled className="input py-1.5 text-xs opacity-60" aria-describedby={`na-${u.key}`}><option>Indisponível</option></select>
              <span id={`na-${u.key}`} className="sr-only">{u.reason}</span>
            </label>
          ))}
          <div className="flex items-end gap-2">
            <button type="button" onClick={() => load(filters)} className="flex h-[34px] flex-1 items-center justify-center gap-1.5 rounded-lg border border-line px-3 text-xs hover:border-primary-2" aria-label="Atualizar dados agora">
              <RefreshCw size={14} className={loading ? "animate-spin" : ""} aria-hidden />Atualizar
            </button>
          </div>
        </div>
        {filters.from && (
          <div className="mt-2 flex flex-wrap items-end gap-2">
            <label className="flex flex-col gap-1 text-[11px] text-muted">Início<input type="date" className="input py-1.5 text-xs" value={filters.from} max={filters.to} onChange={(e) => e.target.value && apply({ from: e.target.value })} /></label>
            <label className="flex flex-col gap-1 text-[11px] text-muted">Fim<input type="date" className="input py-1.5 text-xs" value={filters.to} min={filters.from} onChange={(e) => e.target.value && apply({ to: e.target.value })} /></label>
          </div>
        )}
        <div className="mt-3 flex flex-wrap items-center gap-2 text-xs">
          <span className="text-muted">{data.meta.period.label}{data.meta.comparison ? ` · comparação: ${data.meta.comparison.label}` : ""}</span>
          {activeChips.map((ch) => (
            <button key={ch.d} type="button" onClick={() => apply({ [ch.d]: undefined } as Partial<MetricFilters>)} className="flex items-center gap-1 rounded-full border border-primary-2/60 bg-primary/15 px-2.5 py-0.5" aria-label={`Remover filtro ${ch.label}`}>
              {ch.label}<X size={12} aria-hidden />
            </button>
          ))}
          {activeChips.length > 0 && <button type="button" onClick={() => apply({ seller: undefined, team: undefined, campaign: undefined, source: undefined, stage: undefined })} className="flex items-center gap-1 text-muted hover:text-fg"><FilterX size={13} aria-hidden />Limpar filtros</button>}
          <span className="ml-auto flex flex-wrap items-center gap-3 text-muted">
            <label className="flex items-center gap-1.5"><input type="checkbox" checked={auto} onChange={(e) => setAuto(e.target.checked)} />Atualizar a cada minuto</label>
            <span aria-live="polite">Atualizado {fmt.dateTime(updatedAt)}</span>
            <ExportMenu items={[{ label: "Resumo (CSV)", href: exportHref("resumo") }, { label: "Série temporal (CSV)", href: exportHref("serie") }, { label: `Segmentação por ${DIMENSION_LABELS[dim].toLowerCase()} (CSV)`, href: exportHref("segmentacao", `&dimensao=${dim}`) }]} />
          </span>
        </div>
        {data.meta.notApplicable.map((n) => <p key={n} className="mt-2 text-xs text-warning">{n}</p>)}
      </section>

      {error && (
        <div role="alert" className="flex items-center gap-3 rounded-xl border border-danger/50 bg-danger/10 p-3 text-sm text-danger">
          <CircleAlert size={18} aria-hidden />Não foi possível atualizar os indicadores: {error}. Os números abaixo são da última atualização bem-sucedida.
          <button type="button" onClick={() => load(filters)} className="ml-auto rounded-lg border border-danger/50 px-3 py-1 text-xs">Tentar de novo</button>
        </div>
      )}

      {/* --------- cards --------- */}
      <div className={cx("grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 min-[1760px]:grid-cols-6 transition-opacity", loading && "opacity-60")} aria-busy={loading}>
        {cards.map((k) => (
          <button key={k.label} type="button" disabled={!k.allowed} onClick={() => setDrill({ metric: k.metric, title: k.label })}
            title={`${k.def}${k.allowed ? " — clique para ver os registros" : " — seu perfil não pode abrir os registros"}`}
            className="card group flex gap-4 p-4 text-left transition-colors hover:border-primary-2 disabled:cursor-default disabled:hover:border-line">
            <span className={cx("flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br text-white shadow-lg", k.tone)}><k.icon size={24} aria-hidden /></span>
            <span className="min-w-0">
              <span className="block text-sm text-fg/80">{k.label}</span>
              <span className="block truncate text-2xl font-bold">{k.value}</span>
              <span className="mt-1 flex flex-wrap items-center gap-x-2">{k.delta}{k.prev && <span className="text-[11px] text-muted">antes: {k.prev}</span>}</span>
            </span>
          </button>
        ))}
      </div>

      {/* --------- gráficos --------- */}
      <div className="grid gap-5 xl:grid-cols-5">
        <section className="card min-w-0 p-5 xl:col-span-3" aria-labelledby="perf-title">
          <div className="mb-3 flex flex-wrap items-start justify-between gap-2">
            <div>
              <h2 id="perf-title" className="text-lg font-semibold">Performance de vendas</h2>
              <p className="text-xs text-muted">Receita e leads por {data.series.bucketDays === 1 ? "dia" : "semana"} (UTC){data.meta.comparison ? "; linha tracejada = comparação" : ""}.</p>
            </div>
            {perms.ai && <button type="button" onClick={() => askFlavio("Explique o gráfico de performance de vendas e o que mudou em relação ao período anterior")} className="flex items-center gap-1.5 rounded-lg border border-line px-2.5 py-1 text-[11px] text-muted hover:border-primary-2 hover:text-fg"><Sparkles size={13} aria-hidden />Perguntar ao Flávio</button>}
          </div>
          {pts.every((x) => !x.revenueCents && !x.leads && !x.won && !(x.prev?.revenueCents)) ? (
            <EmptyChart text="Nenhuma venda ou lead no período e filtros selecionados." />
          ) : (
            <InteractiveTimeSeries title="Performance de vendas" points={timePoints} series={timeSeries}
              onOpen={perms.crm ? (i) => setDrill({ metric: "won", title: `Vendas em ${timePoints[i].range}`, pointStart: pts[i].start, pointEnd: pts[i].end }) : undefined}
              openLabel="Abrir vendas deste período" />
          )}
        </section>

        <section className="card min-w-0 p-5 xl:col-span-2" aria-labelledby="seg-title">
          <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
            <h2 id="seg-title" className="text-lg font-semibold">Segmentação</h2>
            <select aria-label="Indicador da segmentação" className="input w-auto py-1 text-xs" value={chartMetric} onChange={(e) => setChartMetric(e.target.value as typeof chartMetric)}>
              <option value="revenue">Receita</option><option value="won">Vendas</option><option value="leads">Leads</option><option value="conversion">Conversão</option>
            </select>
          </div>
          <div role="tablist" aria-label="Dimensão" className="mb-3 flex flex-wrap gap-1">
            {DIMENSIONS.map((d) => (
              <button key={d} role="tab" type="button" aria-selected={dim === d} onClick={() => setDim(d)}
                className={cx("rounded-lg px-2.5 py-1 text-xs", dim === d ? "bg-primary/25 text-fg" : "text-muted hover:text-fg")}>{DIMENSION_LABELS[d]}</button>
            ))}
          </div>
          <p className="mb-2 text-[11px] text-muted">{b.note}</p>
          <InteractiveBars title={`${b.label}: ${chartMetric}`} valueLabel={{ revenue: "Receita", won: "Vendas", leads: "Leads", conversion: "Conversão" }[chartMetric]}
            items={b.rows.filter((r) => metricOf(r) || compareOf(r)).map((r) => ({ key: r.key, label: r.label, value: metricOf(r), compare: compareOf(r), extra: `${r.won} vendas · ${fmt.money(r.revenueCents)} · conversão ${fmt.pct(r.conversionRate)}` }))}
            format={metricFmt} selectedKey={selectedKey} onSelect={(k) => toggleFilter(dim, k)}
            onOpen={perms.crm ? (k) => setDrill({ metric: "won", title: `Vendas — ${b.rows.find((r) => r.key === k)?.label}`, extra: k === "__none__" ? (dim === "campaign" ? { campaign: "none" } : {}) : { [dim]: k } }) : undefined} />
        </section>
      </div>

      {/* --------- tabela da segmentação (filtro cruzado) --------- */}
      <section className="card min-w-0 p-5" aria-labelledby="tab-title">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <h2 id="tab-title" className="text-lg font-semibold">Detalhamento por {DIMENSION_LABELS[dim].toLowerCase()}</h2>
          <a href={exportHref("segmentacao", `&dimensao=${dim}`)} className="flex items-center gap-1.5 rounded-lg border border-line px-3 py-1.5 text-xs hover:border-primary-2"><Download size={14} aria-hidden />Exportar CSV</a>
        </div>
        {b.rows.length ? (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[640px] text-sm">
              <caption className="sr-only">Indicadores por {DIMENSION_LABELS[dim]}. Clique numa linha para filtrar todo o dashboard.</caption>
              <thead><tr className="text-left text-xs text-muted">
                {[DIMENSION_LABELS[dim], "Leads", "Oportunidades", "Vendas", "Perdidas", "Receita", "Conversão", "Participação", data.meta.comparison ? "Receita (comp.)" : null].filter(Boolean).map((h) => <th key={h} scope="col" className="px-3 py-2 font-medium">{h}</th>)}
              </tr></thead>
              <tbody>
                {b.rows.map((r) => {
                  const sel = selectedKey === r.key;
                  return (
                    <tr key={r.key} className={cx("border-t border-line", sel && "bg-primary/10")}>
                      <th scope="row" className="px-3 py-2 text-left font-normal">
                        <button type="button" onClick={() => toggleFilter(dim, r.key)} disabled={r.key === "__none__" && dim !== "campaign"} aria-pressed={sel} className="text-left hover:text-primary-2 hover:underline disabled:no-underline disabled:hover:text-fg">{r.label}</button>
                      </th>
                      <td className="px-3 py-2">{fmt.num(r.leads)}</td><td className="px-3 py-2">{fmt.num(r.opportunities)}</td><td className="px-3 py-2">{fmt.num(r.won)}</td><td className="px-3 py-2">{fmt.num(r.lost)}</td>
                      <td className="px-3 py-2 font-medium">{fmt.money(r.revenueCents)}</td>
                      <td className="px-3 py-2">{fmt.pct(r.conversionRate)}{r.won + r.lost > 0 && r.won + r.lost < 5 && <span className="text-muted" title="Menos de 5 negócios fechados"> *</span>}</td>
                      <td className="px-3 py-2">{fmt.pct(r.revenueSharePct)}</td>
                      {data.meta.comparison && <td className="px-3 py-2 text-muted">{fmt.money(r.prevRevenueCents)}</td>}
                    </tr>
                  );
                })}
              </tbody>
            </table>
            <p className="mt-2 text-[11px] text-muted">* menos de 5 negócios fechados: conversão pouco confiável. Clique no nome para aplicar ou remover o filtro em todo o dashboard.</p>
          </div>
        ) : <EmptyChart text="Sem dados para esta dimensão com os filtros atuais." />}
        <p className="mt-3 text-[11px] text-muted">
          Pipeline aberto (posição atual): <span className="font-medium text-fg">{fmt.money(data.pipeline.valueCents)}</span> em {fmt.num(data.pipeline.openDeals)} oportunidades
          {perms.crm && <> · <button type="button" onClick={() => setDrill({ metric: "open_pipeline", title: "Pipeline aberto" })} className="text-primary-2 hover:underline">ver registros</button></>}
        </p>
      </section>

      {drill && <DrillDrawer state={drill} filters={filters} perms={perms} fmt={fmt} hasComparison={!!data.meta.comparison} onClose={() => setDrill(null)} />}
    </div>
  );
}

function FilterSelect({ label, value, onChange, options, all }: { label: string; value: string; onChange: (v: string) => void; options: { id: string; name: string }[]; all?: string }) {
  return (
    <label className="flex min-w-0 flex-col gap-1 text-[11px] text-muted">
      {label}
      <select className="input py-1.5 text-xs" value={value} onChange={(e) => onChange(e.target.value)}>
        {all && <option value="">{all}</option>}
        {options.map((o) => <option key={o.id} value={o.id}>{o.name}</option>)}
      </select>
    </label>
  );
}

function ExportMenu({ items }: { items: { label: string; href: string }[] }) {
  const [open, setOpen] = useState(false);
  return (
    <span className="relative">
      <button type="button" onClick={() => setOpen(!open)} aria-expanded={open} className="flex items-center gap-1.5 rounded-lg border border-line px-2.5 py-1 hover:border-primary-2 hover:text-fg"><Download size={13} aria-hidden />Exportar</button>
      {open && (
        <span className="card absolute right-0 z-30 mt-1 flex w-60 flex-col p-1 shadow-2xl" onMouseLeave={() => setOpen(false)}>
          {items.map((i) => <a key={i.href} href={i.href} onClick={() => setOpen(false)} className="rounded-lg px-3 py-2 text-left text-xs text-fg hover:bg-surface-2">{i.label}</a>)}
          <span className="px-3 pb-1 pt-1 text-[10px] text-muted">Exporta exatamente o resultado filtrado da tela. A exportação é registrada na auditoria.</span>
        </span>
      )}
    </span>
  );
}

function EmptyChart({ text }: { text: string }) {
  return <div className="flex h-48 flex-col items-center justify-center gap-2 rounded-xl border border-dashed border-line text-center text-sm text-muted"><Info size={18} aria-hidden />{text}</div>;
}

/* ------------------------------------------------------------------ drill-down */

function DrillDrawer({ state, filters, perms, fmt, hasComparison, onClose }: {
  state: DrillState; filters: MetricFilters; perms: Perms; fmt: ReturnType<typeof useFormat>; hasComparison: boolean; onClose: () => void;
}) {
  const [win, setWin] = useState<"current" | "previous">(state.window ?? "current");
  const [res, setRes] = useState<DrillResult | null>(null);
  const [rows, setRows] = useState<DrillRow[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const panel = useRef<HTMLDivElement>(null);
  const f = { ...filters, ...state.extra };
  const params = (offset: number) => {
    const p = filtersToParams(f);
    p.set("metrica", state.metric); p.set("janela", win); p.set("limite", "50"); p.set("deslocamento", String(offset));
    if (state.pointStart && state.pointEnd && win === "current") { p.set("inicio", state.pointStart); p.set("fim", state.pointEnd); }
    return p;
  };
  const fetchPage = async (offset: number) => {
    setLoading(true);
    try {
      const r = await api<DrillResult>(`/api/metrics/drilldown?${params(offset)}`);
      setRes(r); setRows((old) => (offset ? [...old, ...r.rows] : r.rows)); setError(null);
    } catch (e) { setError((e as Error).message); } finally { setLoading(false); }
  };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => { fetchPage(0); }, [win]);
  useEffect(() => {
    panel.current?.focus();
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  const exportUrl = (() => { const p = params(0); p.delete("limite"); p.delete("deslocamento"); return `/api/metrics/export?tipo=registros&${p}`; })();

  return (
    <div className="fixed inset-0 z-40 flex justify-end bg-black/50" onClick={onClose}>
      <div ref={panel} tabIndex={-1} role="dialog" aria-modal="true" aria-labelledby="drill-title" onClick={(e) => e.stopPropagation()}
        className="flex h-full w-full max-w-2xl flex-col border-l border-line bg-bg shadow-2xl outline-none">
        <div className="flex items-start justify-between gap-3 border-b border-line p-4">
          <div className="min-w-0">
            <h2 id="drill-title" className="text-lg font-semibold">{state.title}</h2>
            {res && <p className="text-xs text-muted">{res.definition.label}: {res.definition.formula}</p>}
            {res && <p className="text-xs text-muted">Intervalo: {fmt.dateTime(res.range.start)} a {fmt.dateTime(res.range.end)} (fim exclusivo)</p>}
          </div>
          <button type="button" onClick={onClose} className="rounded-lg p-2 text-muted hover:bg-surface-2 hover:text-fg" aria-label="Fechar registros"><X size={18} /></button>
        </div>
        <div className="flex flex-wrap items-center gap-2 border-b border-line px-4 py-2 text-xs">
          {hasComparison && state.metric !== "open_pipeline" && (
            <span role="tablist" aria-label="Janela" className="flex gap-1">
              {(["current", "previous"] as const).map((w) => <button key={w} role="tab" type="button" aria-selected={win === w} onClick={() => setWin(w)} className={cx("rounded-lg px-2.5 py-1", win === w ? "bg-primary/25" : "text-muted hover:text-fg")}>{w === "current" ? "Período atual" : "Comparação"}</button>)}
            </span>
          )}
          {res && <span className="text-muted">{fmt.num(res.total)} registro(s){res.totalAmountCents != null ? ` · ${fmt.money(res.totalAmountCents)}` : ""}</span>}
          {perms.exportData && res && res.total > 0 && <a href={exportUrl} className="ml-auto flex items-center gap-1.5 rounded-lg border border-line px-2.5 py-1 hover:border-primary-2"><Download size={13} aria-hidden />Exportar registros (CSV)</a>}
        </div>
        <div className="flex-1 overflow-y-auto p-4" aria-busy={loading}>
          {error && <p role="alert" className="rounded-lg border border-danger/50 bg-danger/10 p-3 text-sm text-danger">{error}</p>}
          {res?.notApplicable && <p className="text-sm text-warning">{res.notApplicable}</p>}
          {!error && !loading && res && !rows.length && !res.notApplicable && <p className="py-10 text-center text-sm text-muted">Nenhum registro compõe este indicador com os filtros atuais.</p>}
          {rows.length > 0 && (
            <ul className="space-y-2">
              {rows.map((r) => (
                <li key={r.id}>
                  <Link href={r.href} className="flex items-start justify-between gap-3 rounded-xl border border-line bg-surface/60 p-3 hover:border-primary-2">
                    <span className="min-w-0">
                      <span className="block truncate text-sm font-medium">{r.companyName ?? r.title}</span>
                      <span className="block text-[11px] text-muted">
                        {[r.entity === "lead" ? "Lead" : "Oportunidade", STATUS_LABEL[r.status] ?? r.status, r.stageName, r.source, r.campaignName, r.ownerName ? `resp. ${r.ownerName}` : "sem responsável", r.score != null ? `score ${r.score}` : null].filter(Boolean).join(" · ")}
                      </span>
                      <span className="block text-[11px] text-muted">Criado {fmt.dateTime(r.createdAt)}{r.closedAt ? ` · fechado ${fmt.dateTime(r.closedAt)}` : ""}</span>
                    </span>
                    <span className="flex shrink-0 items-center gap-2 text-sm font-semibold">{r.amountCents != null && fmt.money(r.amountCents)}<ExternalLink size={14} className="text-muted" aria-hidden /></span>
                  </Link>
                </li>
              ))}
            </ul>
          )}
          {loading && <p className="flex items-center justify-center gap-2 py-6 text-sm text-muted"><Loader2 size={16} className="animate-spin" aria-hidden />Carregando registros...</p>}
          {res?.truncated && !loading && <button type="button" onClick={() => fetchPage(rows.length)} className="mt-3 w-full rounded-lg border border-line py-2 text-sm hover:border-primary-2">Carregar mais</button>}
        </div>
      </div>
    </div>
  );
}
