import { Bell, House, Target, Zap, ChartColumn, Users, Network, Bot, SquareCheck, BarChart3, Puzzle, CreditCard, Headset, Settings, LifeBuoy, Gauge, Landmark, FlaskConical, ShieldCheck, Brain } from "lucide-react";
import type { LucideIcon } from "lucide-react";

export const NAV_ICONS: Record<string, LucideIcon> = {
  home: House, target: Target, zap: Zap, chart: ChartColumn, users: Users, workflow: Network, bot: Bot, check: SquareCheck,
  bars: BarChart3, puzzle: Puzzle, card: CreditCard, headset: Headset, gear: Settings, support: LifeBuoy,
  gauge: Gauge, landmark: Landmark, flask: FlaskConical, shield: ShieldCheck, brain: Brain, bell: Bell,
};
