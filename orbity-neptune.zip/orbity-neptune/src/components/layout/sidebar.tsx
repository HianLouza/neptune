"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Infinity as InfinityIcon, X } from "lucide-react";
import { visibleNavGroups } from "./nav";
import { NAV_ICONS } from "./icons";
import { Logo } from "./logo";
import { cx } from "../ui";

export type SidebarProps = {
  labels: Record<string, string>;
  permissions: string[];
  isPlatformAdmin: boolean;
  plan: { name: string; usagePct: number; used: number; allowance: number; locale: string } | null;
  open: boolean;
  onClose: () => void;
};

export function Sidebar({ labels, permissions, isPlatformAdmin, plan, open, onClose }: SidebarProps) {
  const pathname = usePathname();
  const groups = visibleNavGroups(permissions, isPlatformAdmin);
  return (
    <>
      {open && <div className="fixed inset-0 z-30 bg-black/50 lg:hidden" onClick={onClose} aria-hidden />}
      <aside className={cx(
        "fixed inset-y-0 left-0 z-40 flex w-64 flex-col border-r border-line bg-bg/95 backdrop-blur transition-transform lg:sticky lg:top-0 lg:h-screen lg:translate-x-0",
        open ? "translate-x-0" : "-translate-x-full",
      )}>
        <div className="flex items-center justify-between px-5 py-4">
          <Link href="/dashboard" aria-label="Início: painel de vendas" className="rounded-lg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary-2"><Logo /></Link>
          <button className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg hover:bg-surface-2 focus-visible:outline-2 focus-visible:outline-primary-2 lg:hidden"
            onClick={onClose} aria-label="Fechar menu"><X size={20} aria-hidden /></button>
        </div>
        <nav className="flex-1 space-y-4 overflow-y-auto px-3 pb-2" aria-label="Navegação principal">
          {groups.map((g) => {
            const headingId = `nav-group-${g.key}`;
            return (
              <div key={g.key} role="group" aria-labelledby={headingId}>
                <p id={headingId} className="px-3 pb-1 text-[11px] font-semibold uppercase tracking-[0.12em] text-muted">{labels[g.labelKey] ?? g.key}</p>
                <ul className="space-y-0.5">
                  {g.items.map((n) => {
                    const Icon = NAV_ICONS[n.icon];
                    const active = pathname === n.href || pathname.startsWith(n.href + "/");
                    return (
                      <li key={n.href}>
                        <Link href={n.href} onClick={onClose} aria-current={active ? "page" : undefined}
                          className={cx("flex min-h-11 items-center gap-3 rounded-xl px-3 py-2 text-[15px] transition focus-visible:outline-2 focus-visible:outline-offset-[-2px] focus-visible:outline-primary-2",
                            active ? "bg-gradient-to-r from-primary to-navy font-semibold text-white shadow-lg shadow-primary/30" : "text-fg/85 hover:bg-surface-2 hover:text-fg")}>
                          <Icon size={20} strokeWidth={1.8} aria-hidden />
                          <span className="leading-tight">{labels[n.key] ?? n.key}</span>
                        </Link>
                      </li>
                    );
                  })}
                </ul>
              </div>
            );
          })}
        </nav>
        {plan && (
          <div className="m-3 rounded-xl border border-line bg-surface/70 p-4">
            <div className="flex items-center justify-between">
              <p className="font-semibold text-primary-2">Plano {plan.name}</p>
              <span className="rounded-md bg-primary/25 p-1 text-primary-2"><InfinityIcon size={16} /></span>
            </div>
            <div className="mt-3 h-2 overflow-hidden rounded-full bg-surface-2">
              <div className="h-full rounded-full bg-gradient-to-r from-primary to-primary-2" style={{ width: `${plan.usagePct}%` }} />
            </div>
            <p className="mt-2 text-xs text-muted">
              Uso de IA: {plan.usagePct}% ({plan.used.toLocaleString(plan.locale)}/{plan.allowance.toLocaleString(plan.locale)})
            </p>
            <Link href="/billing" className="mt-3 block rounded-lg border border-line bg-surface-2 py-2 text-center text-sm font-medium hover:border-primary-2">Gerenciar plano</Link>
          </div>
        )}
      </aside>
    </>
  );
}
