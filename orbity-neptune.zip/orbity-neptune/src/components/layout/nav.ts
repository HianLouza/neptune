/**
 * Navegação da plataforma, agrupada por função (o que a pessoa quer fazer), não por nome de produto.
 * Rotas (href), chaves de texto (key) e permissões (perm/platformOnly) são as mesmas de antes:
 * só o agrupamento e os textos exibidos mudaram.
 */
export type NavItem = { href: string; key: string; icon: string; perm?: string; platformOnly?: boolean };
export type NavGroup = { key: string; labelKey: string; items: NavItem[] };

export const NAV_GROUPS: NavGroup[] = [
  {
    key: "sell", labelKey: "nav.group.sell", items: [
      { href: "/dashboard", key: "nav.dashboard", icon: "home" },
      { href: "/prospect", key: "nav.prospect", icon: "target", perm: "prospect:read" },
      { href: "/closer", key: "nav.closer", icon: "zap", perm: "closer:read" },
      { href: "/crm", key: "nav.crm", icon: "users", perm: "crm:read" },
      { href: "/tarefas", key: "nav.tasks", icon: "check", perm: "goals:read" },
      { href: "/alertas", key: "nav.alerts", icon: "bell", perm: "goals:read" },
    ],
  },
  {
    key: "analyze", labelKey: "nav.group.analyze", items: [
      { href: "/command-center", key: "nav.command", icon: "gauge", perm: "intelligence:read" },
      { href: "/business-brain", key: "nav.brain", icon: "brain", perm: "ai:use" },
      { href: "/intelligence", key: "nav.intelligence", icon: "chart", perm: "intelligence:read" },
      { href: "/simulador", key: "nav.simulator", icon: "flask", perm: "strategy:read" },
      { href: "/relatorios", key: "nav.reports", icon: "bars", perm: "intelligence:read" },
      { href: "/financeiro", key: "nav.finance", icon: "landmark", perm: "finance:read" },
    ],
  },
  {
    key: "automate", labelKey: "nav.group.automate", items: [
      { href: "/automacoes", key: "nav.automations", icon: "workflow", perm: "automations:read" },
      { href: "/agentes", key: "nav.agents", icon: "bot", perm: "ai:use" },
    ],
  },
  {
    key: "account", labelKey: "nav.group.account", items: [
      { href: "/integracoes", key: "nav.integrations", icon: "puzzle", perm: "integrations:read" },
      { href: "/billing", key: "nav.billing", icon: "card", perm: "billing:read" },
      { href: "/configuracoes", key: "nav.settings", icon: "gear" },
    ],
  },
  {
    key: "admin", labelKey: "nav.group.admin", items: [
      { href: "/admin", key: "nav.admin", icon: "gear", perm: "admin:users" },
      { href: "/ai-control", key: "nav.aicontrol", icon: "shield", perm: "ai:manage" },
      { href: "/customer-success", key: "nav.cs", icon: "headset", platformOnly: true },
    ],
  },
];

/** Lista plana (busca global, rótulos): mesma ordem dos grupos. */
export const NAV: NavItem[] = NAV_GROUPS.flatMap((g) => g.items);

/** Chaves de texto usadas pela navegação (itens + títulos de seção). */
export const NAV_LABEL_KEYS: string[] = [...NAV.map((n) => n.key), ...NAV_GROUPS.map((g) => g.labelKey)];

export function canSeeNavItem(item: NavItem, permissions: readonly string[], isPlatformAdmin: boolean) {
  if (item.platformOnly) return isPlatformAdmin;
  return !item.perm || permissions.includes("*") || permissions.includes(item.perm);
}

/** Grupos visíveis para o perfil: itens sem permissão somem e grupos que ficaram vazios também. */
export function visibleNavGroups(permissions: readonly string[], isPlatformAdmin: boolean): NavGroup[] {
  return NAV_GROUPS
    .map((g) => ({ ...g, items: g.items.filter((i) => canSeeNavItem(i, permissions, isPlatformAdmin)) }))
    .filter((g) => g.items.length > 0);
}
