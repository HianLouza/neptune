"use client";
import { useEffect, useRef, useState, type ReactNode } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { Bell, CircleHelp, Grip, Search, Menu, Sun, Moon, ChevronDown, LogOut, Settings, LifeBuoy, ShieldCheck, TriangleAlert } from "lucide-react";
import { FlavioDock } from "@/components/flavio/flavio-dock";
import { Sidebar, type SidebarProps } from "./sidebar";
import { api } from "@/lib/api-client";
import { NAV } from "./nav";

type Notif = { id: string; title: string; body: string | null; href: string | null; readAt: string | null; createdAt: string };
type Props = Omit<SidebarProps, "open" | "onClose"> & {
  children: ReactNode;
  user: { name: string; initials: string; role: string };
  org: { name: string; isDemo: boolean };
  unread: number;
  demoBanner: string;
  searchPlaceholder: string;
  theme: string;
};

export function AppShell(p: Props) {
  const [open, setOpen] = useState(false);
  const [palette, setPalette] = useState(false);
  const [theme, setTheme] = useState(p.theme);
  const [flavioOpen, setFlavioOpen] = useState(false);
  const pathname = usePathname();

  // Tela inicial = última tela acessada: registra a rota atual.
  useEffect(() => {
    const t = setTimeout(() => { api("/api/preferences", { body: { lastRoute: pathname } }).catch(() => {}); }, 400);
    return () => clearTimeout(t);
  }, [pathname]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") { e.preventDefault(); setPalette(true); } };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const toggleTheme = () => {
    const next = theme === "dark" ? "light" : "dark";
    setTheme(next);
    document.documentElement.dataset.theme = next;
    api("/api/preferences", { body: { theme: next } }).catch(() => {});
  };

  return (
    <div className="flex min-h-screen">
      <Sidebar labels={p.labels} permissions={p.permissions} isPlatformAdmin={p.isPlatformAdmin} plan={p.plan} open={open} onClose={() => setOpen(false)} />
      <div className={`flex min-w-0 flex-1 flex-col transition-[margin] duration-200 ${flavioOpen ? "xl:mr-[420px]" : ""}`}>
        {p.org.isDemo && <div className="flex items-center justify-center gap-1.5 bg-warning/15 px-4 py-1.5 text-center text-xs font-medium text-warning"><TriangleAlert size={13} aria-hidden />{p.demoBanner}</div>}
        <header className="sticky top-0 z-20 flex items-center gap-3 border-b border-line bg-bg/80 px-4 py-3 backdrop-blur lg:px-8">
          <button className="-ml-2.5 flex h-11 w-11 shrink-0 items-center justify-center rounded-lg hover:bg-surface-2 focus-visible:outline-2 focus-visible:outline-primary-2 lg:hidden" onClick={() => setOpen(true)} aria-label="Abrir menu" aria-expanded={open}><Menu aria-hidden /></button>
          <button onClick={() => setPalette(true)} className="flex w-full min-w-0 max-w-xl items-center gap-3 rounded-xl border border-line bg-surface/70 px-3 py-2.5 text-left text-sm text-muted hover:border-primary-2 sm:px-4" aria-label={p.searchPlaceholder}>
            <Search size={18} />
            <span className="hidden flex-1 truncate sm:block">{p.searchPlaceholder}</span>
            <kbd className="hidden rounded-md border border-line bg-surface-2 px-1.5 py-0.5 text-[11px] sm:block">Ctrl K</kbd>
          </button>
          <div className="ml-auto flex shrink-0 items-center gap-0.5 sm:gap-2">
            <Notifications unread={p.unread} />
            <button onClick={toggleTheme} className="rounded-lg p-2 text-muted hover:bg-surface-2 hover:text-fg" aria-label="Alternar tema">{theme === "dark" ? <Sun size={20} /> : <Moon size={20} />}</button>
            <Link href="/suporte" className="hidden rounded-lg p-2 text-muted hover:bg-surface-2 hover:text-fg sm:block" aria-label="Ajuda"><CircleHelp size={20} /></Link>
            <AppsMenu />
            <UserMenu user={p.user} org={p.org} isPlatformAdmin={p.isPlatformAdmin} />
          </div>
        </header>
        <main className="flex-1 px-4 py-6 lg:px-8">{p.children}</main>
      </div>
      {palette && <CommandPalette onClose={() => setPalette(false)} labels={p.labels} />}
      {/* Flávio: ponto de acesso persistente; no desktop largo o painel empurra o conteúdo em vez de cobri-lo. */}
      <FlavioDock onOpenChange={setFlavioOpen} />
    </div>
  );
}

function useClickOutside(onOut: () => void) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const h = (e: MouseEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) onOut(); };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, [onOut]);
  return ref;
}

function Notifications({ unread }: { unread: number }) {
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState<Notif[] | null>(null);
  const [count, setCount] = useState(unread);
  const ref = useClickOutside(() => setOpen(false));
  const load = async () => {
    setOpen((o) => !o);
    const data = await api<Notif[]>("/api/notifications").catch(() => []);
    setItems(data);
  };
  const readAll = async () => { await api("/api/notifications", { body: { readAll: true } }); setCount(0); setItems((i) => i?.map((n) => ({ ...n, readAt: new Date().toISOString() })) ?? null); };
  return (
    <div className="relative" ref={ref}>
      <button onClick={load} className="relative rounded-lg p-2 text-muted hover:bg-surface-2 hover:text-fg" aria-label={`Notificações (${count} não lidas)`}>
        <Bell size={20} />
        {count > 0 && <span className="absolute right-1.5 top-1.5 h-2.5 w-2.5 rounded-full bg-primary-2 ring-2 ring-bg" />}
      </button>
      {open && (
        <div className="card absolute right-0 mt-2 w-80 p-2 shadow-2xl">
          <div className="flex items-center justify-between px-2 py-1">
            <p className="text-sm font-semibold">Notificações</p>
            <button onClick={readAll} className="text-xs text-primary-2 hover:underline">Marcar todas como lidas</button>
          </div>
          <div className="max-h-80 overflow-y-auto">
            {!items ? <p className="p-3 text-xs text-muted">Carregando...</p> : !items.length ? <p className="p-3 text-xs text-muted">Nenhuma notificação.</p> :
              items.map((n) => (
                <Link key={n.id} href={n.href ?? "#"} onClick={() => setOpen(false)} className={`block rounded-lg px-3 py-2 hover:bg-surface-2 ${n.readAt ? "opacity-60" : ""}`}>
                  <p className="text-sm">{n.title}</p>
                  {n.body && <p className="text-xs text-muted">{n.body}</p>}
                </Link>
              ))}
          </div>
        </div>
      )}
    </div>
  );
}

function AppsMenu() {
  const [open, setOpen] = useState(false);
  const ref = useClickOutside(() => setOpen(false));
  const apps = [["Prospect.AI", "/prospect"], ["Closer.AI", "/closer"], ["Sales Intelligence", "/intelligence"], ["CRM", "/crm"], ["Automações", "/automacoes"], ["IA & Agentes", "/agentes"]];
  return (
    <div className="relative hidden sm:block" ref={ref}>
      <button onClick={() => setOpen(!open)} className="rounded-lg p-2 text-muted hover:bg-surface-2 hover:text-fg" aria-label="Aplicativos"><Grip size={20} /></button>
      {open && (
        <div className="card absolute right-0 mt-2 grid w-64 grid-cols-2 gap-1 p-2 shadow-2xl">
          {apps.map(([l, h]) => <Link key={h} href={h} onClick={() => setOpen(false)} className="rounded-lg px-3 py-3 text-center text-xs hover:bg-surface-2">{l}</Link>)}
        </div>
      )}
    </div>
  );
}

function UserMenu({ user, org, isPlatformAdmin }: { user: Props["user"]; org: Props["org"]; isPlatformAdmin: boolean }) {
  const [open, setOpen] = useState(false);
  const ref = useClickOutside(() => setOpen(false));
  const router = useRouter();
  const logout = async () => { await api("/api/auth/logout", { body: {} }).catch(() => {}); router.push("/login"); };
  return (
    <div className="relative" ref={ref}>
      <button onClick={() => setOpen(!open)} className="flex items-center gap-3 rounded-xl border border-line bg-surface/70 py-1.5 pl-1.5 pr-3 hover:border-primary-2">
        <span className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-primary to-navy text-sm font-bold text-white">{user.initials}</span>
        <span className="hidden text-left leading-tight md:block">
          <span className="block text-sm font-semibold">{org.name}</span>
          <span className="block text-xs text-muted">{user.role}</span>
        </span>
        <ChevronDown size={16} className="text-muted" />
      </button>
      {open && (
        <div className="card absolute right-0 mt-2 w-60 p-2 shadow-2xl">
          <p className="px-3 py-2 text-sm font-medium">{user.name}</p>
          <Link href="/configuracoes" onClick={() => setOpen(false)} className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm hover:bg-surface-2"><Settings size={16} /> Perfil e segurança</Link>
          <Link href="/suporte" onClick={() => setOpen(false)} className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm hover:bg-surface-2"><LifeBuoy size={16} /> Suporte</Link>
          {isPlatformAdmin && <Link href="/admin/plataforma" onClick={() => setOpen(false)} className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm hover:bg-surface-2"><ShieldCheck size={16} /> Painel global</Link>}
          <button onClick={logout} className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm text-danger hover:bg-surface-2"><LogOut size={16} /> Sair</button>
        </div>
      )}
    </div>
  );
}

type SearchHit = { id: string; label: string; kind: string; href: string };
function CommandPalette({ onClose, labels }: { onClose: () => void; labels: Record<string, string> }) {
  const [q, setQ] = useState("");
  const [hits, setHits] = useState<SearchHit[]>([]);
  const [idx, setIdx] = useState(0);
  const router = useRouter();
  const pages: SearchHit[] = [...NAV.map((n) => ({ id: n.href, label: labels[n.key], kind: "Página", href: n.href })), { id: "/suporte", label: "Suporte", kind: "Página", href: "/suporte" }];
  useEffect(() => {
    if (q.trim().length < 2) { setHits([]); return; }
    const t = setTimeout(() => { api<SearchHit[]>(`/api/search?q=${encodeURIComponent(q)}`).then(setHits).catch(() => setHits([])); }, 200);
    return () => clearTimeout(t);
  }, [q]);
  const list = [...pages.filter((p) => p.label.toLowerCase().includes(q.toLowerCase())), ...hits].slice(0, 12);
  const go = (h: SearchHit) => { onClose(); router.push(h.href); };
  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center bg-black/60 p-4 pt-[12vh]" onClick={onClose}>
      <div className="card w-full max-w-xl p-2 shadow-2xl" onClick={(e) => e.stopPropagation()} role="dialog" aria-label="Busca global">
        <input autoFocus value={q} onChange={(e) => { setQ(e.target.value); setIdx(0); }} placeholder="Buscar páginas, leads, empresas, negócios..." className="input border-0 bg-transparent text-base"
          onKeyDown={(e) => {
            if (e.key === "Escape") onClose();
            if (e.key === "ArrowDown") setIdx((i) => Math.min(i + 1, list.length - 1));
            if (e.key === "ArrowUp") setIdx((i) => Math.max(i - 1, 0));
            if (e.key === "Enter" && list[idx]) go(list[idx]);
          }} />
        <div className="max-h-96 overflow-y-auto border-t border-line pt-1">
          {list.map((h, i) => (
            <button key={h.kind + h.id} onClick={() => go(h)} className={`flex w-full items-center justify-between rounded-lg px-3 py-2 text-left text-sm ${i === idx ? "bg-surface-2" : ""}`}>
              <span>{h.label}</span><span className="text-xs text-muted">{h.kind}</span>
            </button>
          ))}
          {!list.length && <p className="p-3 text-xs text-muted">Nada encontrado.</p>}
        </div>
      </div>
    </div>
  );
}
