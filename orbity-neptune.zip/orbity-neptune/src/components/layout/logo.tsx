/** Marca ORBITY-NEPTUNE: planeta com órbita (SVG original). */
export function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex items-center gap-3">
      <svg width="40" height="40" viewBox="0 0 48 48" aria-hidden>
        <defs>
          <linearGradient id="lg-planet" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="var(--primary-2)" /><stop offset="1" stopColor="var(--primary)" /></linearGradient>
          <linearGradient id="lg-ring" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stopColor="var(--primary-2)" /><stop offset="1" stopColor="var(--primary)" /></linearGradient>
        </defs>
        <circle cx="24" cy="24" r="11" fill="url(#lg-planet)" />
        <ellipse cx="24" cy="24" rx="21" ry="8" fill="none" stroke="url(#lg-ring)" strokeWidth="2.5" transform="rotate(-25 24 24)" />
        <circle cx="41" cy="15" r="2.2" fill="var(--text)" />
      </svg>
      {!compact && (
        <div className="leading-tight">
          <p className="text-[17px] font-extrabold tracking-wide text-fg">ORBITY-NEPTUNE<sup className="ml-0.5 text-[8px]">™</sup></p>
          <p className="text-[11px] text-muted">Plataforma de Vendas com IA</p>
        </div>
      )}
    </div>
  );
}
