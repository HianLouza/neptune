export const AUTONOMY_LABEL: Record<string, string> = {
  suggest: "Somente sugere",
  approve: "Executa após aprovação",
  autonomous: "Autônomo (ações não sensíveis)",
};
