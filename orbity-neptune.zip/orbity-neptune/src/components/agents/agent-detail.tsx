"use client";
import { useState } from "react";
import { ThumbsDown, ThumbsUp, Trash2 } from "lucide-react";
import { useAction, Feedback } from "@/components/ui/use-action";
import { Badge, Button, Field, Input, Select, SimBadge, Textarea } from "@/components/ui";

type Agent = { key: string; model: string; autonomy: string; enabled: boolean; limits: { maxTokensPerRun: number; maxCreditsPerDay: number } };

export function AgentSettingsForm({ agent, canManage, canGovern = false }: { agent: Agent; canManage: boolean; canGovern?: boolean }) {
  const [f, setF] = useState({ model: agent.model, autonomy: agent.autonomy, maxTokensPerRun: agent.limits.maxTokensPerRun, maxCreditsPerDay: agent.limits.maxCreditsPerDay });
  const { run, loading, error, message } = useAction();
  return (
    <form onSubmit={(e) => { e.preventDefault(); run(`/api/ai/agents/${agent.key}`, f, { method: "PATCH", success: "Configurações salvas e auditadas." }); }} className="space-y-3">
      <Field label="Modelo" hint='"auto" usa o modelo padrão do provedor configurado.'><Input disabled={!canManage} value={f.model} onChange={(e) => setF({ ...f, model: e.target.value })} /></Field>
      <Field label="Autonomia" hint={canGovern ? "Ações sensíveis sempre exigem aprovação humana, em qualquer nível. Os 5 níveis completos ficam no AI Control Plane." : "Somente administradores (ai:govern) alteram a autonomia, no AI Control Plane."}>
        <Select disabled={!canGovern} value={f.autonomy} onChange={(e) => setF({ ...f, autonomy: e.target.value })}>
          <option value="suggest">Somente sugere</option><option value="approve">Executa após aprovação</option><option value="autonomous">Autônomo (ações não sensíveis)</option>
        </Select>
      </Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Máx. tokens por execução"><Input type="number" min={100} max={64000} disabled={!canManage} value={f.maxTokensPerRun} onChange={(e) => setF({ ...f, maxTokensPerRun: Number(e.target.value) })} /></Field>
        <Field label="Máx. créditos por dia"><Input type="number" min={0} disabled={!canManage} value={f.maxCreditsPerDay} onChange={(e) => setF({ ...f, maxCreditsPerDay: Number(e.target.value) })} /></Field>
      </div>
      {canManage ? <Button type="submit" disabled={loading}>{loading ? "Salvando..." : "Salvar configurações"}</Button> : <p className="text-xs text-muted">Somente administradores (ai:manage) podem alterar.</p>}
      <Feedback error={error} message={message} />
    </form>
  );
}

type Version = { id: string; version: number; systemPrompt: string; status: string; evalScore: number | null; createdAt: Date | string };

export function VersionsPanel({ agentKey, versions, activeVersion, canManage, threshold }: { agentKey: string; versions: Version[]; activeVersion: number; canManage: boolean; threshold: number }) {
  const [prompt, setPrompt] = useState(versions.find((v) => v.version === activeVersion)?.systemPrompt ?? "");
  const [open, setOpen] = useState<number | null>(null);
  const { run, loading, error, message } = useAction();
  return (
    <div className="space-y-4">
      <div className="space-y-2">
        {versions.map((v) => (
          <div key={v.id} className="rounded-xl border border-line bg-bg-2/60 p-3">
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-semibold">v{v.version}</span>
              {v.version === activeVersion && <Badge tone="success">ativa</Badge>}
              <Badge tone={v.status === "approved" ? "primary" : v.status === "draft" ? "warning" : "neutral"}>{v.status === "approved" ? "aprovada" : v.status === "draft" ? "rascunho" : v.status}</Badge>
              <span className="text-xs text-muted">avaliação: {v.evalScore == null ? "não avaliada" : `${Math.round(v.evalScore * 100)}%`}</span>
              <div className="ml-auto flex flex-wrap gap-1.5">
                <Button size="sm" variant="ghost" onClick={() => setOpen(open === v.version ? null : v.version)}>{open === v.version ? "Ocultar" : "Ver prompt"}</Button>
                {canManage && <Button size="sm" variant="secondary" disabled={loading} onClick={() => run(`/api/ai/agents/${agentKey}/evaluate`, { version: v.version }, { success: `Avaliação da v${v.version} concluída.` })}>Avaliar</Button>}
                {canManage && v.version !== activeVersion && (
                  <Button size="sm" disabled={loading} onClick={() => run(`/api/ai/agents/${agentKey}/activate`, { version: v.version }, { success: v.version < activeVersion ? `Rollback para v${v.version} concluído.` : `v${v.version} ativada.` })}>
                    {v.version < activeVersion ? "Rollback" : "Ativar"}
                  </Button>
                )}
              </div>
            </div>
            {open === v.version && <pre className="mt-2 max-h-60 overflow-auto whitespace-pre-wrap rounded-lg bg-bg p-3 text-xs text-muted">{v.systemPrompt}</pre>}
          </div>
        ))}
      </div>
      {canManage && (
        <form onSubmit={(e) => { e.preventDefault(); run(`/api/ai/agents/${agentKey}/versions`, { systemPrompt: prompt }, { success: "Nova versão criada como rascunho. Avalie antes de ativar." }); }} className="space-y-2">
          <Field label="Nova versão do prompt" hint={`A ativação exige avaliação com pelo menos ${Math.round(threshold * 100)}% de acerto (governança).`}>
            <Textarea className="min-h-40 font-mono text-xs" value={prompt} onChange={(e) => setPrompt(e.target.value)} />
          </Field>
          <Button type="submit" variant="secondary" disabled={loading || prompt.trim().length < 20}>Criar nova versão</Button>
        </form>
      )}
      <Feedback error={error} message={message} />
    </div>
  );
}

type RunOut = { executionId: string; text: string; status: string; simulated: boolean; provider: string; model: string; credits: number; latencyMs: number; warnings: string[] };

export function Playground({ agentKey, versions, enabled }: { agentKey: string; versions: number[]; enabled: boolean }) {
  const [input, setInput] = useState("");
  const [context, setContext] = useState("");
  const [version, setVersion] = useState<string>("");
  const [out, setOut] = useState<RunOut | null>(null);
  const { run, loading, error } = useAction();
  return (
    <div className="space-y-3">
      <Field label="Entrada"><Textarea value={input} onChange={(e) => setInput(e.target.value)} placeholder="Ex.: Qual o prazo de implantação?" /></Field>
      <Field label="Contexto (opcional)" hint="Tratado como dado não confiável — nunca como instrução."><Textarea className="min-h-16" value={context} onChange={(e) => setContext(e.target.value)} /></Field>
      <div className="flex flex-wrap items-end gap-2">
        <Field label="Versão do prompt"><Select value={version} onChange={(e) => setVersion(e.target.value)} className="w-40"><option value="">Ativa</option>{versions.map((v) => <option key={v} value={v}>v{v}</option>)}</Select></Field>
        <Button disabled={loading || !input.trim() || !enabled} onClick={async () => {
          const r = await run<RunOut>(`/api/ai/agents/${agentKey}/test`, { input, context: context || undefined, promptVersion: version ? Number(version) : undefined });
          if (r) setOut(r);
        }}>{loading ? "Executando..." : "Executar teste"}</Button>
        {!enabled && <span className="text-xs text-warning">Agente desativado.</span>}
      </div>
      <Feedback error={error} />
      {out && (
        <div className="rounded-xl border border-line bg-bg-2/60 p-4">
          <div className="mb-2 flex flex-wrap items-center gap-2 text-xs text-muted">
            <Badge tone={out.status === "success" ? "success" : out.status === "blocked" ? "danger" : "warning"}>{out.status}</Badge>
            {out.provider} · {out.model} · {out.credits} crédito(s) · {out.latencyMs} ms
            {out.simulated && <SimBadge />}
          </div>
          <p className="whitespace-pre-wrap text-sm">{out.text}</p>
          {out.warnings.map((w) => <p key={w} className="mt-1 text-xs text-warning">{w}</p>)}
          <div className="mt-2"><FeedbackButtons executionId={out.executionId} value={null} /></div>
        </div>
      )}
    </div>
  );
}

export function FeedbackButtons({ executionId, value }: { executionId: string; value: number | null }) {
  const [v, setV] = useState(value);
  const { run, loading, error } = useAction();
  const send = async (n: 1 | -1) => { const r = await run(`/api/ai/executions/${executionId}/feedback`, { value: n }); if (r) setV(n); };
  return (
    <span className="inline-flex items-center gap-1">
      <button aria-label="Resposta útil" disabled={loading} onClick={() => send(1)} className={`rounded p-1 ${v === 1 ? "text-success" : "text-muted hover:text-fg"}`}><ThumbsUp size={14} /></button>
      <button aria-label="Resposta ruim" disabled={loading} onClick={() => send(-1)} className={`rounded p-1 ${v === -1 ? "text-danger" : "text-muted hover:text-fg"}`}><ThumbsDown size={14} /></button>
      {error && <span className="text-[10px] text-danger">{error}</span>}
    </span>
  );
}

type Case = { id: string; name: string; input: string; mustInclude: string[]; mustNotInclude: string[]; adversarial: boolean };

export function EvalCases({ agentKey, cases, canManage }: { agentKey: string; cases: Case[]; canManage: boolean }) {
  const [f, setF] = useState({ name: "", input: "", mustInclude: "", mustNotInclude: "", adversarial: false });
  const { run, loading, error, message } = useAction();
  const list = (s: string) => s.split(",").map((x) => x.trim()).filter(Boolean);
  return (
    <div className="space-y-4">
      {cases.length ? (
        <ul className="space-y-2">
          {cases.map((c) => (
            <li key={c.id} className="rounded-xl border border-line bg-bg-2/60 p-3 text-sm">
              <div className="flex items-start justify-between gap-2">
                <p className="font-medium">{c.name} {c.adversarial && <Badge tone="danger">adversarial</Badge>}</p>
                {canManage && <button aria-label="Remover caso" disabled={loading} onClick={() => run("/api/ai/eval-cases", { id: c.id }, { method: "DELETE" })} className="text-muted hover:text-danger"><Trash2 size={14} /></button>}
              </div>
              <p className="mt-1 text-xs text-muted">Entrada: {c.input}</p>
              {(c.mustInclude.length > 0 || c.mustNotInclude.length > 0) && (
                <p className="mt-1 text-xs text-muted">Deve conter: {c.mustInclude.join(", ") || "—"} · Não pode conter: {c.mustNotInclude.join(", ") || "—"}</p>
              )}
            </li>
          ))}
        </ul>
      ) : <p className="text-sm text-muted">Nenhum caso cadastrado. Ao executar a primeira avaliação, casos padrão (incl. adversariais) são criados para o agente de atendimento.</p>}
      {canManage && (
        <form onSubmit={async (e) => {
          e.preventDefault();
          const r = await run("/api/ai/eval-cases", { agentKey, name: f.name, input: f.input, mustInclude: list(f.mustInclude), mustNotInclude: list(f.mustNotInclude), adversarial: f.adversarial }, { success: "Caso adicionado." });
          if (r) setF({ name: "", input: "", mustInclude: "", mustNotInclude: "", adversarial: false });
        }} className="space-y-2 rounded-xl border border-dashed border-line p-3">
          <p className="text-xs font-semibold text-muted">Adicionar caso de avaliação</p>
          <Input required placeholder="Nome do caso" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
          <Textarea required className="min-h-16" placeholder="Entrada enviada ao agente" value={f.input} onChange={(e) => setF({ ...f, input: e.target.value })} />
          <div className="grid gap-2 sm:grid-cols-2">
            <Input placeholder="Deve conter (vírgulas)" value={f.mustInclude} onChange={(e) => setF({ ...f, mustInclude: e.target.value })} />
            <Input placeholder="Não pode conter (vírgulas)" value={f.mustNotInclude} onChange={(e) => setF({ ...f, mustNotInclude: e.target.value })} />
          </div>
          <label className="flex items-center gap-2 text-xs text-muted"><input type="checkbox" checked={f.adversarial} onChange={(e) => setF({ ...f, adversarial: e.target.checked })} /> Teste adversarial (espera bloqueio ou resposta segura)</label>
          <Button size="sm" type="submit" disabled={loading}>Adicionar</Button>
        </form>
      )}
      <Feedback error={error} message={message} />
    </div>
  );
}
