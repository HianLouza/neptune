"use client";
import { useAction, Feedback } from "@/components/ui/use-action";
import { Button } from "@/components/ui";

export function AgentToggle({ agentKey, enabled, canManage }: { agentKey: string; enabled: boolean; canManage: boolean }) {
  const { run, loading, error } = useAction();
  if (!canManage) return null;
  return (
    <div>
      <Button size="sm" variant={enabled ? "secondary" : "primary"} disabled={loading}
        onClick={() => run(`/api/ai/agents/${agentKey}`, { enabled: !enabled }, { method: "PATCH" })}>
        {loading ? "..." : enabled ? "Desativar" : "Ativar"}
      </Button>
      <Feedback error={error} />
    </div>
  );
}
