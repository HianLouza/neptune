"use client";
import { useRouter } from "next/navigation";
import { useState, useCallback } from "react";
import { api } from "@/lib/api-client";

/** Executa uma chamada de API, controla loading/erro e atualiza os dados do servidor (router.refresh). */
export function useAction() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const run = useCallback(async <T,>(url: string, body?: unknown, opts: { method?: string; success?: string; refresh?: boolean } = {}): Promise<T | null> => {
    setLoading(true); setError(null); setMessage(null);
    try {
      const data = await api<T>(url, { method: opts.method, body });
      if (opts.success) setMessage(opts.success);
      if (opts.refresh !== false) router.refresh();
      return data;
    } catch (e) {
      setError((e as Error).message);
      return null;
    } finally { setLoading(false); }
  }, [router]);
  return { run, loading, error, message, setError, setMessage };
}

export function Feedback({ error, message }: { error?: string | null; message?: string | null }) {
  if (!error && !message) return null;
  return <p role={error ? "alert" : "status"} className={`mt-2 text-xs ${error ? "text-danger" : "text-success"}`}>{error ?? message}</p>;
}
