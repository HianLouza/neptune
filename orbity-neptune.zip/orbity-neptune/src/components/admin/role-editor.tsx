"use client";
import { useState } from "react";
import { Button, Input } from "@/components/ui";
import { useAction, Feedback } from "@/components/ui/use-action";

const MODULE_LABELS: Record<string, string> = { crm: "CRM", prospect: "Prospect.AI", closer: "Closer.AI", intelligence: "Sales Intelligence", automations: "Automações", ai: "IA", approvals: "Aprovações", goals: "Metas", integrations: "Integrações", billing: "Billing", admin: "Administração", audit: "Auditoria", export: "Exportação", support: "Suporte" };

/** Matriz de permissões (módulo × ação) para cargos personalizados. Cargos do sistema são somente leitura. */
export function RoleEditor({ all, role }: { all: readonly string[]; role?: { id: string; name: string; permissions: string[]; isSystem: boolean } }) {
  const [name, setName] = useState(role?.name ?? "");
  const [perms, setPerms] = useState<Set<string>>(new Set(role?.permissions ?? []));
  const { run, loading, error, message } = useAction();
  const readOnly = role?.isSystem;
  const modules = [...new Set(all.map((p) => p.split(":")[0]))];
  const toggle = (p: string) => { const n = new Set(perms); if (n.has(p)) n.delete(p); else n.add(p); setPerms(n); };
  return (
    <div className="space-y-3">
      {!readOnly && <Input placeholder="Nome do cargo" value={name} onChange={(e) => setName(e.target.value)} />}
      <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
        {modules.map((m) => (
          <div key={m} className="rounded-lg border border-line p-2">
            <p className="mb-1 text-xs font-semibold">{MODULE_LABELS[m] ?? m}</p>
            {all.filter((p) => p.startsWith(m + ":")).map((p) => (
              <label key={p} className="flex items-center gap-2 text-xs text-muted">
                <input type="checkbox" disabled={readOnly} checked={perms.has(p) || perms.has("*")} onChange={() => toggle(p)} />{p.split(":")[1]}
              </label>
            ))}
          </div>
        ))}
      </div>
      {readOnly ? <p className="text-xs text-muted">Cargo do sistema — somente leitura.</p> : (
        <>
          <Button size="sm" disabled={loading || name.trim().length < 2} onClick={() => run("/api/admin", { action: "save_role", roleId: role?.id, name, permissions: [...perms] }, { success: "Cargo salvo." })}>
            {loading ? "Salvando..." : role ? "Salvar cargo" : "Criar cargo"}
          </Button>
          <Feedback error={error} message={message} />
        </>
      )}
    </div>
  );
}
