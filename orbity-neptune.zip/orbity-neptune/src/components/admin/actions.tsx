"use client";
import { useState, type ReactNode } from "react";
import { Button, Field, Input, Select, Textarea } from "@/components/ui";
import { useAction, Feedback } from "@/components/ui/use-action";

/** Botão que dispara uma ação de API (com confirmação opcional) e atualiza a página. */
export function ActionButton({ url, body, label, confirm, variant = "secondary", size = "sm", success, method }: {
  url: string; body?: unknown; label: ReactNode; confirm?: string; variant?: "primary" | "secondary" | "ghost" | "danger"; size?: "sm" | "md"; success?: string; method?: string;
}) {
  const { run, loading, error, message } = useAction();
  return (
    <span className="inline-flex flex-col">
      <Button type="button" variant={variant} size={size} disabled={loading}
        onClick={() => { if (confirm && !window.confirm(confirm)) return; run(url, body ?? {}, { success, method }); }}>
        {loading ? "..." : label}
      </Button>
      <Feedback error={error} message={message} />
    </span>
  );
}

export type FieldSpec = {
  name: string; label: string; type?: "text" | "number" | "email" | "password" | "select" | "textarea" | "checkbox" | "date";
  options?: { value: string; label: string }[]; defaultValue?: string | number | boolean; placeholder?: string; hint?: string; required?: boolean;
  /** "list" = separa por vírgula em array */ transform?: "list" | "number" | "cents";
};

/** Formulário genérico que envia { ...extra, ...campos } para uma rota de API. */
export function FieldsForm({ url, fields, extra, submitLabel = "Salvar", success = "Salvo.", onDone, nestUnder, nestExtra, shape, columns = 1, reset = false }: {
  url: string; fields: FieldSpec[]; extra?: Record<string, unknown>; submitLabel?: string; success?: string;
  onDone?: (data: unknown) => void; columns?: 1 | 2 | 3; reset?: boolean;
  /** Envia { ...extra, [nestUnder]: { ...nestExtra, ...campos } } (props serializáveis — podem vir de Server Components). */
  nestUnder?: string; nestExtra?: Record<string, unknown>;
  /** Agrupa campos: payload[key] = campos listados (ou com o prefixo, removido). */
  shape?: { key: string; fields?: string[]; prefix?: string }[];
}) {
  const init = () => Object.fromEntries(fields.map((f) => [f.name, f.defaultValue ?? (f.type === "checkbox" ? false : "")]));
  const [v, setV] = useState<Record<string, string | number | boolean>>(init);
  const { run, loading, error, message } = useAction();
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const body: Record<string, unknown> = {};
    for (const f of fields) {
      const raw = v[f.name];
      if (f.transform === "list") body[f.name] = String(raw ?? "").split(",").map((x) => x.trim()).filter(Boolean);
      else if (f.transform === "number" || f.type === "number") body[f.name] = raw === "" ? undefined : Number(raw);
      else if (f.transform === "cents") body[f.name] = Math.round(Number(String(raw).replace(",", ".")) * 100);
      else body[f.name] = raw === "" ? undefined : raw;
    }
    let payload: Record<string, unknown>;
    if (nestUnder) payload = { ...extra, [nestUnder]: { ...nestExtra, ...body } };
    else if (shape) {
      payload = { ...extra };
      for (const g of shape) {
        payload[g.key] = Object.fromEntries(Object.entries(body)
          .filter(([k]) => (g.fields ? g.fields.includes(k) : g.prefix ? k.startsWith(g.prefix) : false))
          .map(([k, val]) => [g.prefix ? k.slice(g.prefix.length) : k, val]));
      }
    } else payload = { ...extra, ...body };
    const data = await run(url, payload, { success });
    if (data !== null) { onDone?.(data); if (reset) setV(init()); }
  };
  const grid = columns === 3 ? "sm:grid-cols-3" : columns === 2 ? "sm:grid-cols-2" : "";
  return (
    <form onSubmit={submit} className="space-y-3">
      <div className={`grid gap-3 ${grid}`}>
        {fields.map((f) => (
          f.type === "checkbox" ? (
            <label key={f.name} className="flex items-center gap-2 text-sm"><input type="checkbox" checked={!!v[f.name]} onChange={(e) => setV({ ...v, [f.name]: e.target.checked })} />{f.label}</label>
          ) : (
            <Field key={f.name} label={f.label} hint={f.hint}>
              {f.type === "select" ? (
                <Select value={String(v[f.name])} onChange={(e) => setV({ ...v, [f.name]: e.target.value })} required={f.required}>
                  {f.options?.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                </Select>
              ) : f.type === "textarea" ? (
                <Textarea value={String(v[f.name])} placeholder={f.placeholder} required={f.required} onChange={(e) => setV({ ...v, [f.name]: e.target.value })} />
              ) : (
                <Input type={f.type ?? "text"} step={f.type === "number" ? "any" : undefined} value={String(v[f.name])} placeholder={f.placeholder} required={f.required} onChange={(e) => setV({ ...v, [f.name]: e.target.value })} />
              )}
            </Field>
          )
        ))}
      </div>
      <Button type="submit" size="sm" disabled={loading}>{loading ? "Enviando..." : submitLabel}</Button>
      <Feedback error={error} message={message} />
    </form>
  );
}

/** Seletor que dispara ação ao mudar (ex.: cargo do usuário). */
export function ActionSelect({ url, value, options, bodyBase, valueKey, numeric, label }: { url: string; value: string; options: { value: string; label: string }[]; bodyBase: Record<string, unknown>; valueKey: string; numeric?: boolean; label: string }) {
  const { run, loading, error } = useAction();
  return (
    <span className="inline-flex flex-col">
      <select aria-label={label} className="input py-1 text-xs" value={value} disabled={loading} onChange={(e) => { if (e.target.value) run(url, { ...bodyBase, [valueKey]: numeric ? Number(e.target.value) : e.target.value }); }}>
        {options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
      </select>
      <Feedback error={error} />
    </span>
  );
}

/** Seção recolhível para formulários secundários. */
export function Collapsible({ label, children, defaultOpen = false }: { label: string; children: ReactNode; defaultOpen?: boolean }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div>
      <Button type="button" size="sm" variant="secondary" onClick={() => setOpen(!open)}>{open ? "Fechar" : label}</Button>
      {open && <div className="mt-3 rounded-xl border border-line bg-bg-2/50 p-4">{children}</div>}
    </div>
  );
}
