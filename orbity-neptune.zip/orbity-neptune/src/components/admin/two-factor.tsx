"use client";
import { useState } from "react";
import { Button, Field, Input, Badge } from "@/components/ui";
import { useAction, Feedback } from "@/components/ui/use-action";

/** Configuração de 2FA (TOTP — aplicativo autenticador). */
export function TwoFactor({ enabled }: { enabled: boolean }) {
  const [setup, setSetup] = useState<{ secret: string; otpauth: string } | null>(null);
  const [code, setCode] = useState("");
  const { run, loading, error, message } = useAction();
  if (enabled) return (
    <div className="space-y-3">
      <p className="text-sm"><Badge tone="success">2FA ativo</Badge> Sua conta exige código do aplicativo autenticador no login.</p>
      <div className="flex flex-wrap items-end gap-2">
        <Field label="Código atual para desativar"><Input inputMode="numeric" maxLength={6} value={code} onChange={(e) => setCode(e.target.value)} /></Field>
        <Button size="sm" variant="danger" disabled={loading || code.length !== 6} onClick={async () => { if (await run("/api/auth/2fa", { action: "disable", code }, { success: "2FA desativado." })) setCode(""); }}>Desativar 2FA</Button>
      </div>
      <Feedback error={error} message={message} />
    </div>
  );
  return (
    <div className="space-y-3">
      <p className="text-sm text-muted">Proteja sua conta com um aplicativo autenticador (Google Authenticator, Authy, 1Password, Microsoft Authenticator).</p>
      {!setup ? (
        <Button size="sm" disabled={loading} onClick={async () => { const r = await run<{ secret: string; otpauth: string }>("/api/auth/2fa", { action: "setup" }, { refresh: false }); if (r) setSetup(r); }}>Configurar 2FA</Button>
      ) : (
        <div className="space-y-3 rounded-lg border border-line p-3 text-sm">
          <p>1. No aplicativo, adicione uma conta manualmente com a chave:</p>
          <code className="block break-all rounded bg-bg-2 p-2 text-xs">{setup.secret}</code>
          <p className="text-xs text-muted">Ou use o URI: <span className="break-all">{setup.otpauth}</span></p>
          <p>2. Digite o código de 6 dígitos gerado:</p>
          <div className="flex flex-wrap items-end gap-2">
            <Input inputMode="numeric" maxLength={6} className="max-w-40" value={code} onChange={(e) => setCode(e.target.value)} aria-label="Código" />
            <Button size="sm" disabled={loading || code.length !== 6} onClick={async () => { if (await run("/api/auth/2fa", { action: "enable", code }, { success: "2FA ativado." })) { setSetup(null); setCode(""); } }}>Ativar</Button>
          </div>
        </div>
      )}
      <Feedback error={error} message={message} />
    </div>
  );
}

/** Seleção de tema persistida nas preferências do usuário. */
export function ThemePicker({ current }: { current: string }) {
  const [theme, setTheme] = useState(current);
  const { run } = useAction();
  const pick = async (t: "dark" | "light") => { setTheme(t); document.documentElement.dataset.theme = t; await run("/api/preferences", { theme: t }, { refresh: false }); };
  return (
    <div className="flex gap-2">
      {(["dark", "light"] as const).map((t) => <Button key={t} size="sm" variant={theme === t ? "primary" : "secondary"} onClick={() => pick(t)}>{t === "dark" ? "Escuro" : "Claro"}</Button>)}
    </div>
  );
}
