"use client";
import { useState } from "react";
import { Button, Field, Input } from "@/components/ui";
import { useAction, Feedback } from "@/components/ui/use-action";

type Subject = { name: string; email: string | null; phone: string | null; legalBasis: string | null; consentStatus: string; conversations: number };

/** Direitos do titular (LGPD): localizar dados e anonimizar mediante confirmação explícita. */
export function LgpdTool() {
  const [email, setEmail] = useState("");
  const [subject, setSubject] = useState<Subject | null>(null);
  const [confirm, setConfirm] = useState("");
  const lookup = useAction();
  const erase = useAction();
  return (
    <div className="space-y-3">
      <form className="flex flex-wrap items-end gap-2" onSubmit={async (e) => { e.preventDefault(); setSubject(null); setSubject(await lookup.run<Subject>("/api/admin", { action: "lgpd_lookup", email }, { refresh: false })); }}>
        <div className="min-w-60 flex-1"><Field label="E-mail do titular"><Input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} /></Field></div>
        <Button size="sm" type="submit" disabled={lookup.loading}>Localizar</Button>
      </form>
      <Feedback error={lookup.error} />
      {subject && (
        <div className="rounded-lg border border-line p-3 text-sm">
          <p><strong>{subject.name}</strong> · {subject.email} · {subject.phone ?? "sem telefone"}</p>
          <p className="text-xs text-muted">Base legal: {subject.legalBasis ?? "—"} · Consentimento: {subject.consentStatus} · Conversas: {subject.conversations}</p>
          <p className="mt-3 text-xs text-danger">A anonimização remove nome, e-mail, telefone e o conteúdo das mensagens. Esta ação é irreversível e será auditada.</p>
          <div className="mt-2 flex flex-wrap items-end gap-2">
            <Field label='Digite "EXCLUIR" para confirmar'><Input value={confirm} onChange={(e) => setConfirm(e.target.value)} /></Field>
            <Button size="sm" variant="danger" disabled={confirm !== "EXCLUIR" || erase.loading}
              onClick={async () => { const r = await erase.run("/api/admin", { action: "lgpd_erase", email, confirm }, { success: "Titular anonimizado." }); if (r) { setSubject(null); setConfirm(""); } }}>
              Anonimizar dados
            </Button>
          </div>
        </div>
      )}
      <Feedback error={erase.error} message={erase.message} />
    </div>
  );
}

export function CopyField({ value }: { value: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <div className="flex gap-2">
      <Input readOnly value={value} />
      <Button size="sm" variant="secondary" type="button" onClick={async () => { await navigator.clipboard.writeText(value); setCopied(true); setTimeout(() => setCopied(false), 1500); }}>{copied ? "Copiado" : "Copiar"}</Button>
    </div>
  );
}
