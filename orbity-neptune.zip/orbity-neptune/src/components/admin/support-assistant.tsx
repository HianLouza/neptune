"use client";
import { useState } from "react";
import { Button, Input, SimBadge } from "@/components/ui";
import { api } from "@/lib/api-client";

type Out = { text: string; simulated: boolean; suggestTicket: boolean };

/** Assistente de suporte: responde com base na ajuda da plataforma e oferece abrir chamado quando não resolve. */
export function SupportAssistant() {
  const [q, setQ] = useState("");
  const [out, setOut] = useState<Out | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const ask = async (e: React.FormEvent) => {
    e.preventDefault(); setLoading(true); setErr(null);
    try { setOut(await api<Out>("/api/support/ai", { body: { message: q } })); } catch (x) { setErr((x as Error).message); } finally { setLoading(false); }
  };
  return (
    <div className="space-y-3">
      <form onSubmit={ask} className="flex gap-2">
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Ex.: Como conecto o WhatsApp?" minLength={2} required />
        <Button type="submit" size="sm" disabled={loading}>{loading ? "..." : "Perguntar"}</Button>
      </form>
      {err && <p className="text-xs text-danger">{err}</p>}
      {out && (
        <div className="rounded-lg border border-line bg-bg-2/60 p-3 text-sm">
          <p className="whitespace-pre-wrap">{out.text}</p>
          {out.simulated && <div className="mt-2"><SimBadge label="IA em modo simulado" /></div>}
          {out.suggestTicket && <p className="mt-2 text-xs text-warning">Não resolveu? Abra um chamado ao lado — nossa equipe humana responde dentro do SLA.</p>}
        </div>
      )}
    </div>
  );
}
