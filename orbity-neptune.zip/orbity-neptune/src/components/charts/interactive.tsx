"use client";
/**
 * Gráficos interativos acessíveis (Recharts 3).
 * - Tooltip com valores exatos, período do ponto, comparação e variação.
 * - Legenda interativa (botões com aria-pressed) para ligar/desligar séries.
 * - Ponto ativo destacado; navegação por teclado (setas, Home/End, Enter abre os registros, Esc limpa).
 * - Toque: tocar seleciona o ponto e mostra o painel de detalhe com o botão de abrir registros.
 * - Alternativa em tabela para leitores de tela e para quem prefere números.
 */
import { useId, useMemo, useState, type KeyboardEvent, type ReactNode } from "react";
import {
  Area, Bar, BarChart, CartesianGrid, Cell, ComposedChart, Line, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from "recharts";
import { Table2, ChartColumn, MousePointerClick } from "lucide-react";

export type SeriesDef = {
  key: string; label: string; color: string; kind: "area" | "line" | "bar"; axis?: "left" | "right"; dashed?: boolean;
  format: (v: number) => string; defaultHidden?: boolean;
};

const tooltipBox = "rounded-xl border border-line bg-surface px-3 py-2 text-xs shadow-2xl";

function Legend({ series, hidden, toggle }: { series: SeriesDef[]; hidden: Set<string>; toggle: (k: string) => void }) {
  return (
    <div className="flex flex-wrap gap-1.5" role="group" aria-label="Séries do gráfico (clique para mostrar ou ocultar)">
      {series.map((s) => {
        const on = !hidden.has(s.key);
        return (
          <button key={s.key} type="button" aria-pressed={on} onClick={() => toggle(s.key)}
            className={`flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] transition-colors ${on ? "border-line bg-surface-2/70 text-fg" : "border-dashed border-line text-muted line-through"}`}>
            <i className="h-2.5 w-2.5 rounded-full" style={{ background: s.color, opacity: on ? 1 : 0.35, outline: s.dashed ? "1px dashed var(--muted)" : undefined }} />
            {s.label}
          </button>
        );
      })}
    </div>
  );
}

function ViewToggle({ table, setTable }: { table: boolean; setTable: (v: boolean) => void }) {
  return (
    <button type="button" onClick={() => setTable(!table)} aria-pressed={table}
      className="flex items-center gap-1.5 rounded-lg border border-line px-2.5 py-1 text-[11px] text-muted hover:border-primary-2 hover:text-fg">
      {table ? <ChartColumn size={13} /> : <Table2 size={13} />}{table ? "Ver gráfico" : "Ver tabela"}
    </button>
  );
}

/* ------------------------------------------------------------------ série temporal */

export type TimePoint = { label: string; range: string; values: Record<string, number | null> };

export function InteractiveTimeSeries({
  title, points, series, onOpen, openLabel = "Abrir registros deste período", height = 240, footer,
}: {
  title: string; points: TimePoint[]; series: SeriesDef[];
  onOpen?: (index: number) => void; openLabel?: string; height?: number; footer?: ReactNode;
}) {
  const [hidden, setHidden] = useState<Set<string>>(() => new Set(series.filter((s) => s.defaultHidden).map((s) => s.key)));
  const [active, setActive] = useState<number | null>(null);
  const [table, setTable] = useState(false);
  const descId = useId();
  const visible = series.filter((s) => !hidden.has(s.key));
  const data = useMemo(() => points.map((p, i) => ({ i, label: p.label, ...p.values })), [points]);
  const toggle = (k: string) => setHidden((h) => { const n = new Set(h); if (n.has(k)) n.delete(k); else if (series.length - n.size > 1) n.add(k); return n; });
  const hasRight = visible.some((s) => s.axis === "right");

  const onKey = (e: KeyboardEvent<HTMLDivElement>) => {
    if (!points.length) return;
    const cur = active ?? -1;
    if (e.key === "ArrowRight") { e.preventDefault(); setActive(Math.min(points.length - 1, cur + 1)); }
    else if (e.key === "ArrowLeft") { e.preventDefault(); setActive(cur <= 0 ? 0 : cur - 1); }
    else if (e.key === "Home") { e.preventDefault(); setActive(0); }
    else if (e.key === "End") { e.preventDefault(); setActive(points.length - 1); }
    else if ((e.key === "Enter" || e.key === " ") && active != null && onOpen) { e.preventDefault(); onOpen(active); }
    else if (e.key === "Escape") setActive(null);
  };

  const ap = active != null ? points[active] : null;
  const summary = `${title}. ${points.length} pontos. Use as setas para percorrer${onOpen ? " e Enter para abrir os registros" : ""}.`;

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <Legend series={series} hidden={hidden} toggle={toggle} />
        <ViewToggle table={table} setTable={setTable} />
      </div>
      {table ? (
        <DataTable caption={title} head={["Período", ...visible.map((s) => s.label)]}
          rows={points.map((p, i) => ({ key: String(i), cells: [p.range, ...visible.map((s) => (p.values[s.key] == null ? "n/a" : s.format(p.values[s.key]!)))], onOpen: onOpen ? () => onOpen(i) : undefined }))} />
      ) : (
        <div tabIndex={0} role="group" aria-roledescription="gráfico interativo" aria-label={summary} aria-describedby={descId} onKeyDown={onKey}
          className="rounded-xl outline-offset-4" style={{ height, touchAction: "pan-y" }}>
          <ResponsiveContainer>
            <ComposedChart data={data} margin={{ top: 8, right: hasRight ? 4 : 8, left: -6, bottom: 0 }} accessibilityLayer={false}
              onClick={(st) => { const i = Number(st?.activeTooltipIndex); if (Number.isFinite(i)) { if (active === i && onOpen) onOpen(i); else setActive(i); } }}
              onMouseMove={(st) => { const i = Number(st?.activeTooltipIndex); if (Number.isFinite(i)) setActive(i); }}>
              <defs>
                {visible.filter((s) => s.kind === "area").map((s) => (
                  <linearGradient key={s.key} id={`g-${descId}-${s.key}`.replace(/:/g, "")} x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={s.color} stopOpacity={0.45} /><stop offset="100%" stopColor={s.color} stopOpacity={0.02} />
                  </linearGradient>
                ))}
              </defs>
              <CartesianGrid stroke="var(--border)" strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="label" tick={{ fill: "var(--muted)", fontSize: 11 }} axisLine={false} tickLine={false} interval="preserveStartEnd" minTickGap={18} />
              <YAxis yAxisId="left" tick={{ fill: "var(--muted)", fontSize: 11 }} axisLine={false} tickLine={false} width={56}
                tickFormatter={(v) => (visible.find((s) => (s.axis ?? "left") === "left")?.format(Number(v)) ?? String(v))} />
              <YAxis yAxisId="right" orientation="right" hide={!hasRight} tick={{ fill: "var(--muted)", fontSize: 11 }} axisLine={false} tickLine={false} width={36} allowDecimals={false} />
              {active != null && data[active] && <ReferenceLine yAxisId="left" x={data[active].label} stroke="var(--primary-2)" strokeDasharray="4 3" />}
              <Tooltip cursor={{ stroke: "var(--primary-2)", strokeOpacity: 0.4 }} content={({ active: on, label, payload }) => {
                if (!on || !payload?.length) return null;
                const i = (payload[0].payload as { i: number }).i;
                const p = points[i];
                return (
                  <div className={tooltipBox}>
                    <p className="mb-1 font-semibold text-fg">{p?.range ?? label}</p>
                    {visible.map((s) => <p key={s.key} className="flex items-center justify-between gap-4"><span className="flex items-center gap-1.5 text-muted"><i className="h-2 w-2 rounded-full" style={{ background: s.color }} />{s.label}</span><span className="font-medium text-fg">{p.values[s.key] == null ? "n/a" : s.format(p.values[s.key]!)}</span></p>)}
                    {onOpen && <p className="mt-1 text-[10px] text-muted">Clique de novo ou Enter para abrir os registros</p>}
                  </div>
                );
              }} />
              {visible.map((s) => {
                const common = { key: s.key, yAxisId: s.axis ?? "left", dataKey: s.key, name: s.label, isAnimationActive: true, animationDuration: 450 };
                if (s.kind === "bar") return <Bar {...common} fill={s.color} fillOpacity={0.55} radius={[4, 4, 0, 0]} maxBarSize={18} />;
                if (s.kind === "area") return <Area {...common} type="monotone" stroke={s.color} strokeWidth={2.25} fill={`url(#${`g-${descId}-${s.key}`.replace(/:/g, "")})`} dot={false} activeDot={{ r: 5, strokeWidth: 2, stroke: "var(--bg)" }} />;
                return <Line {...common} type="monotone" stroke={s.color} strokeWidth={2} strokeDasharray={s.dashed ? "5 4" : undefined} dot={false} activeDot={{ r: 4 }} />;
              })}
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      )}
      <p id={descId} className="sr-only">Tabela alternativa disponível pelo botão Ver tabela.</p>
      <div aria-live="polite" className="min-h-[2.25rem] rounded-lg border border-line/60 bg-bg-2/50 px-3 py-1.5 text-xs">
        {ap ? (
          <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
            <span className="font-semibold">{ap.range}</span>
            {visible.map((s) => <span key={s.key} className="text-muted">{s.label}: <span className="font-medium text-fg">{ap.values[s.key] == null ? "n/a" : s.format(ap.values[s.key]!)}</span></span>)}
            {onOpen && <button type="button" onClick={() => onOpen(active!)} className="ml-auto flex items-center gap-1 text-primary-2 hover:underline"><MousePointerClick size={13} />{openLabel}</button>}
          </div>
        ) : <span className="text-muted">Passe o mouse, toque ou use as setas do teclado sobre o gráfico para ver os valores de cada período.</span>}
      </div>
      {footer}
    </div>
  );
}

/* ------------------------------------------------------------------ barras por categoria */

export type BarItem = { key: string; label: string; value: number; compare?: number | null; extra?: string };

export function InteractiveBars({
  title, items, format, color = "var(--primary-2)", compareColor = "#64748b", selectedKey, onSelect, onOpen, valueLabel, compareLabel = "Comparação", height = 240,
}: {
  title: string; items: BarItem[]; format: (v: number) => string; color?: string; compareColor?: string;
  selectedKey?: string | null; onSelect?: (key: string) => void; onOpen?: (key: string) => void; valueLabel: string; compareLabel?: string; height?: number;
}) {
  const hasCompare = items.some((x) => x.compare != null);
  const series: SeriesDef[] = [
    { key: "value", label: valueLabel, color, kind: "bar", format },
    ...(hasCompare ? [{ key: "compare", label: compareLabel, color: compareColor, kind: "bar" as const, format }] : []),
  ];
  const [hidden, setHidden] = useState<Set<string>>(new Set());
  const [active, setActive] = useState<number | null>(null);
  const [table, setTable] = useState(false);
  const toggle = (k: string) => setHidden((h) => { const n = new Set(h); if (n.has(k)) n.delete(k); else if (series.length - n.size > 1) n.add(k); return n; });
  const data = items.slice(0, 12).map((x, i) => ({ i, name: x.label.length > 16 ? x.label.slice(0, 15) + "..." : x.label, value: x.value, compare: x.compare ?? null }));
  const onKey = (e: KeyboardEvent<HTMLDivElement>) => {
    if (!data.length) return;
    const cur = active ?? -1;
    if (e.key === "ArrowRight" || e.key === "ArrowDown") { e.preventDefault(); setActive(Math.min(data.length - 1, cur + 1)); }
    else if (e.key === "ArrowLeft" || e.key === "ArrowUp") { e.preventDefault(); setActive(cur <= 0 ? 0 : cur - 1); }
    else if (e.key === "Enter" && active != null && onSelect) { e.preventDefault(); onSelect(items[active].key); }
    else if (e.key === "Escape") setActive(null);
  };
  const ai = active != null ? items[active] : null;

  if (!items.length) return <p className="py-10 text-center text-sm text-muted">Sem dados para os filtros selecionados.</p>;
  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <Legend series={series} hidden={hidden} toggle={toggle} />
        <ViewToggle table={table} setTable={setTable} />
      </div>
      {table ? (
        <DataTable caption={title} head={["Categoria", valueLabel, ...(hasCompare ? [compareLabel] : []), "Detalhe"]}
          rows={items.map((x) => ({ key: x.key, cells: [x.label, format(x.value), ...(hasCompare ? [x.compare == null ? "n/a" : format(x.compare)] : []), x.extra ?? ""], onOpen: onSelect ? () => onSelect(x.key) : undefined, openLabel: "Filtrar" }))} />
      ) : (
        <div tabIndex={0} role="group" aria-roledescription="gráfico interativo" onKeyDown={onKey}
          aria-label={`${title}. ${items.length} categorias. Use as setas para percorrer e Enter para filtrar o dashboard pela categoria.`}
          className="rounded-xl outline-offset-4" style={{ height, touchAction: "pan-y" }}>
          <ResponsiveContainer>
            <BarChart data={data} margin={{ left: -8, right: 8, top: 8 }} accessibilityLayer={false}
              onClick={(st) => { const i = Number(st?.activeTooltipIndex); if (Number.isFinite(i)) { if (active === i && onSelect) onSelect(items[i].key); else setActive(i); } }}
              onMouseMove={(st) => { const i = Number(st?.activeTooltipIndex); if (Number.isFinite(i)) setActive(i); }}>
              <CartesianGrid stroke="var(--border)" strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="name" tick={{ fill: "var(--muted)", fontSize: 10 }} axisLine={false} tickLine={false} interval={0} angle={data.length > 5 ? -25 : 0} textAnchor={data.length > 5 ? "end" : "middle"} height={data.length > 5 ? 52 : 28} />
              <YAxis tick={{ fill: "var(--muted)", fontSize: 11 }} axisLine={false} tickLine={false} width={56} tickFormatter={(v) => format(Number(v))} />
              <Tooltip cursor={{ fill: "var(--surface-2)", fillOpacity: 0.5 }} content={({ active: on, payload }) => {
                if (!on || !payload?.length) return null;
                const it = items[(payload[0].payload as { i: number }).i];
                return (
                  <div className={tooltipBox}>
                    <p className="mb-1 font-semibold text-fg">{it.label}</p>
                    <p className="text-muted">{valueLabel}: <span className="font-medium text-fg">{format(it.value)}</span></p>
                    {it.compare != null && <p className="text-muted">{compareLabel}: <span className="font-medium text-fg">{format(it.compare)}</span></p>}
                    {it.extra && <p className="text-muted">{it.extra}</p>}
                    {onSelect && <p className="mt-1 text-[10px] text-muted">Clique de novo ou Enter para filtrar o dashboard</p>}
                  </div>
                );
              }} />
              {!hidden.has("value") && (
                <Bar dataKey="value" name={valueLabel} radius={[6, 6, 0, 0]} isAnimationActive animationDuration={450} maxBarSize={36}>
                  {data.map((d, i) => <Cell key={d.i} fill={color} fillOpacity={selectedKey && items[i].key !== selectedKey ? 0.3 : active === i ? 1 : 0.8} stroke={active === i || items[i].key === selectedKey ? "var(--text)" : "none"} strokeWidth={1.5} cursor="pointer" />)}
                </Bar>
              )}
              {hasCompare && !hidden.has("compare") && <Bar dataKey="compare" name={compareLabel} fill={compareColor} fillOpacity={0.5} radius={[6, 6, 0, 0]} isAnimationActive animationDuration={450} maxBarSize={36} />}
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}
      <div aria-live="polite" className="min-h-[2.25rem] rounded-lg border border-line/60 bg-bg-2/50 px-3 py-1.5 text-xs">
        {ai ? (
          <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
            <span className="font-semibold">{ai.label}</span>
            <span className="text-muted">{valueLabel}: <span className="font-medium text-fg">{format(ai.value)}</span></span>
            {ai.compare != null && <span className="text-muted">{compareLabel}: <span className="font-medium text-fg">{format(ai.compare)}</span></span>}
            <span className="ml-auto flex gap-3">
              {onSelect && <button type="button" onClick={() => onSelect(ai.key)} className="text-primary-2 hover:underline">{selectedKey === ai.key ? "Remover filtro" : "Filtrar por esta categoria"}</button>}
              {onOpen && <button type="button" onClick={() => onOpen(ai.key)} className="text-primary-2 hover:underline">Abrir registros</button>}
            </span>
          </div>
        ) : <span className="text-muted">Toque ou passe o mouse numa barra; clique de novo para filtrar todo o dashboard.</span>}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ tabela acessível */

export function DataTable({ caption, head, rows }: { caption: string; head: string[]; rows: { key: string; cells: ReactNode[]; onOpen?: () => void; openLabel?: string }[] }) {
  return (
    <div className="max-h-72 overflow-auto rounded-xl border border-line">
      <table className="w-full text-xs">
        <caption className="sr-only">{caption}</caption>
        <thead className="sticky top-0 bg-surface"><tr>{head.map((h) => <th key={h} scope="col" className="px-3 py-2 text-left font-medium text-muted">{h}</th>)}{rows.some((r) => r.onOpen) && <th scope="col" className="px-3 py-2"><span className="sr-only">Ações</span></th>}</tr></thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.key} className="border-t border-line">
              {r.cells.map((c, i) => i === 0 ? <th key={i} scope="row" className="px-3 py-1.5 text-left font-normal">{c}</th> : <td key={i} className="px-3 py-1.5">{c}</td>)}
              {r.onOpen && <td className="px-3 py-1.5 text-right"><button type="button" onClick={r.onOpen} className="text-primary-2 hover:underline">{r.openLabel ?? "Abrir"}</button></td>}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
