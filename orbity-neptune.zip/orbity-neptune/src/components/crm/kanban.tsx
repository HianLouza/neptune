"use client";
import { useState } from "react";
import Link from "next/link";
import { Button, Input, Select, cx } from "@/components/ui";
import { useAction, Feedback } from "@/components/ui/use-action";

export type Stage = { id: string; name: string; kind: string; color: string; probability: number };
export type Column = { stage: Stage; count: number; totalCents: number; items: { id: string; title: string; amountCents: number; companyName: string | null; lastActivityAt: string; ownerName: string | null }[] };

const HEAD: Record<string, string> = {
  violet: "from-primary/80", blue: "from-blue-600/80", amber: "from-amber-600/80", fuchsia: "from-navy/80",
  emerald: "from-emerald-600/80", green: "from-green-600/80", red: "from-red-600/80",
};

/** Movimentação: seleciona a etapa destino; "Perdido" exige motivo. */
function MoveControl({ oppId, current, stages, canWrite }: { oppId: string; current: string; stages: Stage[]; canWrite: boolean }) {
  const { run, loading, error } = useAction();
  const [target, setTarget] = useState("");
  const [reason, setReason] = useState("");
  if (!canWrite) return null;
  const stage = stages.find((s) => s.id === target);
  const submit = () => run(`/api/crm/opportunities/${oppId}`, { action: "move", stageId: target, lostReason: stage?.kind === "lost" ? reason : undefined }, { success: "Movida." }).then((r) => { if (r) { setTarget(""); setReason(""); } });
  return (
    <div className="mt-2 space-y-1.5" onClick={(e) => e.stopPropagation()}>
      <Select aria-label="Mover para etapa" value={target} onChange={(e) => setTarget(e.target.value)} className="py-1 text-xs">
        <option value="">Mover para…</option>
        {stages.filter((s) => s.id !== current).map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
      </Select>
      {stage?.kind === "lost" && <Input value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Motivo da perda (obrigatório)" className="py-1 text-xs" />}
      {target && <Button size="sm" className="w-full" disabled={loading || (stage?.kind === "lost" && reason.trim().length < 2)} onClick={submit}>{loading ? "Movendo..." : "Confirmar"}</Button>}
      <Feedback error={error} />
    </div>
  );
}

export function Kanban({ columns, stages, canWrite, locale, currency, staleDays }: { columns: Column[]; stages: Stage[]; canWrite: boolean; locale: string; currency: string; staleDays: number }) {
  const fmt = new Intl.NumberFormat(locale, { style: "currency", currency, maximumFractionDigits: 0 });
  const limit = Date.now() - staleDays * 864e5;
  return (
    <div className="flex gap-3 overflow-x-auto pb-2">
      {columns.map((col) => (
        <div key={col.stage.id} className="w-64 shrink-0 overflow-hidden rounded-xl border border-line bg-bg-2/60">
          <div className={cx("bg-gradient-to-b to-transparent px-3 py-2.5", HEAD[col.stage.color] ?? HEAD.violet)}>
            <div className="flex items-center justify-between"><p className="text-sm font-semibold text-white">{col.stage.name}</p><span className="text-xs text-white/80">{col.stage.probability}%</span></div>
            <p className="text-xs text-white/80">{col.count.toLocaleString(locale)} · {fmt.format(col.totalCents / 100)}</p>
          </div>
          <div className="max-h-[65vh] space-y-2 overflow-y-auto p-2">
            {col.items.map((it) => {
              const stale = new Date(it.lastActivityAt).getTime() < limit && col.stage.kind === "open";
              return (
                <div key={it.id} className="rounded-lg border border-line bg-surface/80 p-2.5">
                  <Link href={`/crm/oportunidade/${it.id}`} className="block hover:text-primary-2">
                    <p className="truncate text-sm font-medium">{it.companyName ?? it.title}</p>
                    <p className="text-xs text-muted">{fmt.format(it.amountCents / 100)}{it.ownerName ? ` · ${it.ownerName.split(" ")[0]}` : ""}</p>
                    {stale && <p className="mt-1 text-[11px] text-warning">⚠ Sem atividade há +{staleDays} dias</p>}
                  </Link>
                  <MoveControl oppId={it.id} current={col.stage.id} stages={stages} canWrite={canWrite} />
                </div>
              );
            })}
            {col.count > col.items.length && <Link href={`/crm?etapa=${col.stage.id}`} className="block px-1 text-xs text-muted hover:text-fg">+ {(col.count - col.items.length).toLocaleString(locale)} mais (ver etapa)</Link>}
            {!col.count && <p className="p-2 text-xs text-muted">Nenhuma oportunidade.</p>}
          </div>
        </div>
      ))}
    </div>
  );
}
