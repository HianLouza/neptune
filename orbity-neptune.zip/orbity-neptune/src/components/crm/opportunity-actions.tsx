"use client";
import { useState } from "react";
import { Button, Field, Input, Select, Textarea, cx } from "@/components/ui";
import { useAction, Feedback } from "@/components/ui/use-action";
import { toCents } from "./forms";

type Stage = { id: string; name: string; kind: string };
type Tab = "atividade" | "tarefa" | "reuniao" | "proposta" | "etapa";

export function OpportunityActions({ oppId, stages, currentStageId, members, defaultAmount, currency, title }: {
  oppId: string; stages: Stage[]; currentStageId: string; members: { id: string; name: string }[]; defaultAmount: number; currency: string; title: string;
}) {
  const [tab, setTab] = useState<Tab>("atividade");
  const { run, loading, error, message } = useAction();
  const url = `/api/crm/opportunities/${oppId}`;

  const [act, setAct] = useState({ type: "note", subject: "", body: "" });
  const [task, setTask] = useState({ title: "", priority: "medium", dueAt: "", assigneeId: "" });
  const [meet, setMeet] = useState({ title: `Reunião — ${title}`.slice(0, 200), startsAt: "" });
  const [prop, setProp] = useState({ title: `Proposta — ${title}`.slice(0, 200), amount: String(defaultAmount / 100) });
  const [move, setMove] = useState({ stageId: "", lostReason: "" });
  const target = stages.find((s) => s.id === move.stageId);

  const tabs: [Tab, string][] = [["atividade", "Registrar atividade"], ["tarefa", "Criar tarefa"], ["reuniao", "Agendar reunião"], ["proposta", "Enviar proposta"], ["etapa", "Mover etapa"]];

  return (
    <div>
      <div className="mb-4 flex flex-wrap gap-1" role="tablist">
        {tabs.map(([k, l]) => (
          <button key={k} role="tab" aria-selected={tab === k} onClick={() => setTab(k)}
            className={cx("rounded-lg px-3 py-1.5 text-xs", tab === k ? "bg-primary/25 font-semibold text-primary-2" : "text-muted hover:bg-surface-2 hover:text-fg")}>{l}</button>
        ))}
      </div>

      {tab === "atividade" && (
        <form className="space-y-3" onSubmit={async (e) => { e.preventDefault(); if (await run(url, { action: "activity", ...act }, { success: "Atividade registrada." })) setAct({ type: "note", subject: "", body: "" }); }}>
          <div className="grid gap-3 sm:grid-cols-[180px_1fr]">
            <Field label="Tipo">
              <Select value={act.type} onChange={(e) => setAct({ ...act, type: e.target.value })}>
                <option value="note">Nota</option><option value="call">Ligação</option><option value="email">E-mail</option>
                <option value="meeting">Reunião</option><option value="whatsapp">WhatsApp</option><option value="follow_up">Follow-up</option>
              </Select>
            </Field>
            <Field label="Assunto"><Input required minLength={2} value={act.subject} onChange={(e) => setAct({ ...act, subject: e.target.value })} /></Field>
          </div>
          <Field label="Detalhes"><Textarea value={act.body} onChange={(e) => setAct({ ...act, body: e.target.value })} /></Field>
          <Button type="submit" disabled={loading || act.subject.trim().length < 2}>Registrar</Button>
        </form>
      )}

      {tab === "tarefa" && (
        <form className="space-y-3" onSubmit={async (e) => {
          e.preventDefault();
          if (await run(url, { action: "task", title: task.title, priority: task.priority, dueAt: task.dueAt ? new Date(task.dueAt).toISOString() : undefined, assigneeId: task.assigneeId || undefined }, { success: "Tarefa criada." }))
            setTask({ title: "", priority: "medium", dueAt: "", assigneeId: "" });
        }}>
          <Field label="Tarefa"><Input required minLength={2} value={task.title} onChange={(e) => setTask({ ...task, title: e.target.value })} /></Field>
          <div className="grid gap-3 sm:grid-cols-3">
            <Field label="Prioridade"><Select value={task.priority} onChange={(e) => setTask({ ...task, priority: e.target.value })}><option value="low">Baixa</option><option value="medium">Média</option><option value="high">Alta</option></Select></Field>
            <Field label="Prazo"><Input type="datetime-local" value={task.dueAt} onChange={(e) => setTask({ ...task, dueAt: e.target.value })} /></Field>
            <Field label="Responsável"><Select value={task.assigneeId} onChange={(e) => setTask({ ...task, assigneeId: e.target.value })}><option value="">Eu</option>{members.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}</Select></Field>
          </div>
          <Button type="submit" disabled={loading || task.title.trim().length < 2}>Criar tarefa</Button>
        </form>
      )}

      {tab === "reuniao" && (
        <form className="space-y-3" onSubmit={async (e) => { e.preventDefault(); if (await run(url, { action: "meeting", title: meet.title, startsAt: new Date(meet.startsAt).toISOString() }, { success: "Reunião registrada na agenda do ORBITY." })) setMeet({ ...meet, startsAt: "" }); }}>
          <Field label="Título"><Input required minLength={2} value={meet.title} onChange={(e) => setMeet({ ...meet, title: e.target.value })} /></Field>
          <Field label="Data e hora" hint="Convites externos dependem da integração Google/Microsoft conectada."><Input type="datetime-local" required value={meet.startsAt} onChange={(e) => setMeet({ ...meet, startsAt: e.target.value })} /></Field>
          <Button type="submit" disabled={loading || !meet.startsAt}>Agendar</Button>
        </form>
      )}

      {tab === "proposta" && (
        <form className="space-y-3" onSubmit={(e) => { e.preventDefault(); run(url, { action: "proposal", title: prop.title, amountCents: toCents(prop.amount) }, { success: "Proposta registrada como enviada." }); }}>
          <Field label="Título"><Input required minLength={2} value={prop.title} onChange={(e) => setProp({ ...prop, title: e.target.value })} /></Field>
          <Field label={`Valor (${currency})`} hint="Registra a proposta e dispara o evento “Proposta enviada”. O envio do documento ao cliente é feito por você."><Input inputMode="decimal" required value={prop.amount} onChange={(e) => setProp({ ...prop, amount: e.target.value })} /></Field>
          <Button type="submit" disabled={loading || isNaN(toCents(prop.amount))}>Registrar proposta enviada</Button>
        </form>
      )}

      {tab === "etapa" && (
        <form className="space-y-3" onSubmit={async (e) => { e.preventDefault(); if (await run(url, { action: "move", stageId: move.stageId, lostReason: target?.kind === "lost" ? move.lostReason : undefined }, { success: "Etapa atualizada." })) setMove({ stageId: "", lostReason: "" }); }}>
          <Field label="Nova etapa">
            <Select required value={move.stageId} onChange={(e) => setMove({ ...move, stageId: e.target.value })}>
              <option value="">Selecione…</option>
              {stages.filter((s) => s.id !== currentStageId).map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
            </Select>
          </Field>
          {target?.kind === "lost" && <Field label="Motivo da perda (obrigatório)"><Input required minLength={2} value={move.lostReason} onChange={(e) => setMove({ ...move, lostReason: e.target.value })} placeholder="Preço, concorrente, sem orçamento..." /></Field>}
          <Button type="submit" variant={target?.kind === "lost" ? "danger" : "primary"} disabled={loading || !move.stageId || (target?.kind === "lost" && move.lostReason.trim().length < 2)}>Mover</Button>
        </form>
      )}
      <Feedback error={error} message={message} />
    </div>
  );
}
