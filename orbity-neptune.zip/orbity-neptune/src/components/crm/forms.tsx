"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button, Field, Input, Select } from "@/components/ui";
import { useAction, Feedback } from "@/components/ui/use-action";
import { api } from "@/lib/api-client";

// "1.500,50" (pt-BR) ou "1500.50" → centavos.
export const toCents = (v: string) => Math.round(Number(v.includes(",") ? v.replace(/\./g, "").replace(",", ".") : v) * 100);
const validMoney = (v: string) => v.trim() !== "" && !isNaN(toCents(v)) && toCents(v) >= 0;

/** Nova oportunidade: cria/deduplica a empresa e abre o negócio na etapa escolhida. */
export function OpportunityForm({ stages, currency }: { stages: { id: string; name: string }[]; currency: string }) {
  const router = useRouter();
  const [f, setF] = useState({ title: "", companyName: "", amount: "", stageId: stages[0]?.id ?? "", expectedCloseDate: "" });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => setF({ ...f, [k]: e.target.value });
  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setLoading(true); setError(null); setMessage(null);
    try {
      let companyId: string | undefined;
      if (f.companyName.trim()) companyId = (await api<{ company: { id: string } }>("/api/crm/companies", { body: { name: f.companyName.trim() } })).company.id;
      const o = await api<{ id: string }>("/api/crm/opportunities", { body: {
        title: f.title.trim() || f.companyName.trim(), amountCents: toCents(f.amount), stageId: f.stageId || undefined, companyId,
        expectedCloseDate: f.expectedCloseDate || undefined,
      } });
      setMessage("Oportunidade criada.");
      setF({ ...f, title: "", companyName: "", amount: "", expectedCloseDate: "" });
      router.push(`/crm/oportunidade/${o.id}`);
    } catch (err) { setError((err as Error).message); } finally { setLoading(false); }
  };
  return (
    <form onSubmit={submit} className="space-y-3">
      <Field label="Empresa"><Input value={f.companyName} onChange={set("companyName")} placeholder="Empresa (criada se não existir)" /></Field>
      <Field label="Título do negócio"><Input value={f.title} onChange={set("title")} placeholder="Opcional — usa o nome da empresa" /></Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label={`Valor (${currency})`}><Input inputMode="decimal" required value={f.amount} onChange={set("amount")} placeholder="50000" /></Field>
        <Field label="Previsão de fechamento"><Input type="date" value={f.expectedCloseDate} onChange={set("expectedCloseDate")} /></Field>
      </div>
      <Field label="Etapa"><Select value={f.stageId} onChange={set("stageId")}>{stages.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</Select></Field>
      <Button type="submit" disabled={loading || !validMoney(f.amount) || (f.title + f.companyName).trim().length < 2}>{loading ? "Criando..." : "Criar oportunidade"}</Button>
      <Feedback error={error} message={message} />
    </form>
  );
}

export function CompanyForm() {
  const { run, loading, error, message } = useAction();
  const [f, setF] = useState({ name: "", domain: "", segment: "", region: "", employees: "" });
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement>) => setF({ ...f, [k]: e.target.value });
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const r = await run<{ duplicate: boolean }>("/api/crm/companies", { name: f.name, domain: f.domain || null, segment: f.segment || null, region: f.region || null, employees: f.employees ? Number(f.employees) : null });
    if (r) { setF({ name: "", domain: "", segment: "", region: "", employees: "" }); }
    if (r?.duplicate) alert("Empresa já existia (mesmo nome ou domínio) — nenhum duplicado foi criado.");
  };
  return (
    <form onSubmit={submit} className="space-y-3">
      <Field label="Nome"><Input required minLength={2} value={f.name} onChange={set("name")} /></Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Domínio"><Input value={f.domain} onChange={set("domain")} placeholder="empresa.com.br" /></Field>
        <Field label="Colaboradores"><Input type="number" min={0} value={f.employees} onChange={set("employees")} /></Field>
        <Field label="Segmento"><Input value={f.segment} onChange={set("segment")} /></Field>
        <Field label="Região / UF"><Input value={f.region} onChange={set("region")} /></Field>
      </div>
      <Button type="submit" disabled={loading}>{loading ? "Salvando..." : "Adicionar empresa"}</Button>
      <Feedback error={error} message={message} />
    </form>
  );
}

export function ContactForm({ companies }: { companies: { id: string; name: string }[] }) {
  const { run, loading, error, message } = useAction();
  const [f, setF] = useState({ name: "", email: "", phone: "", jobTitle: "", companyId: "", legalBasis: "legitimo_interesse" });
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => setF({ ...f, [k]: e.target.value });
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const r = await run<{ duplicate: boolean }>("/api/crm/contacts", { ...f, companyId: f.companyId || null, phone: f.phone || null, jobTitle: f.jobTitle || null });
    if (r) setF({ name: "", email: "", phone: "", jobTitle: "", companyId: "", legalBasis: "legitimo_interesse" });
    if (r?.duplicate) alert("Já existe um contato com este e-mail — nenhum duplicado foi criado.");
  };
  return (
    <form onSubmit={submit} className="space-y-3">
      <Field label="Nome"><Input required minLength={2} value={f.name} onChange={set("name")} /></Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="E-mail"><Input type="email" value={f.email} onChange={set("email")} /></Field>
        <Field label="Telefone"><Input value={f.phone} onChange={set("phone")} /></Field>
        <Field label="Cargo"><Input value={f.jobTitle} onChange={set("jobTitle")} /></Field>
        <Field label="Empresa">
          <Select value={f.companyId} onChange={set("companyId")}><option value="">— nenhuma —</option>{companies.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</Select>
        </Field>
      </div>
      <Field label="Base legal (LGPD)">
        <Select value={f.legalBasis} onChange={set("legalBasis")}>
          <option value="legitimo_interesse">Legítimo interesse</option><option value="consentimento">Consentimento</option><option value="execucao_contrato">Execução de contrato</option>
        </Select>
      </Field>
      <Button type="submit" disabled={loading}>{loading ? "Salvando..." : "Adicionar contato"}</Button>
      <Feedback error={error} message={message} />
    </form>
  );
}
