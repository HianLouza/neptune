import { NextResponse, type NextRequest } from "next/server";

const PUBLIC = ["/login", "/cadastro", "/api/auth", "/api/health", "/api/webhooks", "/manifest.webmanifest", "/icons", "/sw.js"];

/** Barreira leve: sem cookie de sessão → login. A validação real da sessão ocorre no servidor (getContext). */
export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;
  if (PUBLIC.some((p) => pathname.startsWith(p)) || pathname.startsWith("/_next")) return NextResponse.next();
  if (!req.cookies.get("on_session")) {
    if (pathname.startsWith("/api/")) return NextResponse.json({ ok: false, error: "Não autenticado." }, { status: 401 });
    const url = req.nextUrl.clone();
    url.pathname = "/login";
    return NextResponse.redirect(url);
  }
  return NextResponse.next();
}
export const config = { matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"] };
