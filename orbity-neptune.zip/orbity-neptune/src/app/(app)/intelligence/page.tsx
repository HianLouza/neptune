import { requirePageContext } from "@/server/auth/next";
import { dashboardKpis, funnelAnalysis, leadOrigins, recommendations, revenueForecast, sellerPerformance } from "@/server/domains/intelligence";
import { Badge, Card, CardTitle, Empty, PageHeader, Stat, Table, Td } from "@/components/ui";
import { PeriodSelect } from "@/components/dashboard/period-select";
import { FunnelChart, OriginsChart, SellersChart } from "@/components/intelligence/charts";
import { NlQuery } from "@/components/intelligence/nl-query";
import { money, num, pct } from "@/lib/format";
import { aiSuggestionMetrics } from "@/server/ai/collab/metrics";
import { AiSuggestionMetricsCard } from "@/components/ai-collab/metrics-card";

export const metadata = { title: "Indicadores" };

const PRIORITY_TONE = { alta: "danger", "média": "warning", baixa: "info" } as const;

function deltaText(v: number | null, suffix = "%") {
  if (v == null) return "sem base de comparação";
  return `${v >= 0 ? "+" : ""}${String(v).replace(".", ",")}${suffix} vs. período anterior`;
}

export default async function IntelligencePage({ searchParams }: { searchParams: Promise<{ periodo?: string }> }) {
  const ctx = await requirePageContext("intelligence:read");
  const sp = await searchParams;
  const days = [7, 30, 90].includes(Number(sp.periodo)) ? Number(sp.periodo) : 30;
  const o = { locale: ctx.locale, currency: ctx.currency };
  const [kpis, funnel, sellers, origins, forecast, recs] = await Promise.all([
    dashboardKpis(ctx, days), funnelAnalysis(ctx), sellerPerformance(ctx, days), leadOrigins(ctx, days), revenueForecast(ctx), recommendations(ctx),
  ]);
  const open = funnel.filter((f) => f.kind === "open");
  const closedSample = kpis.current.won + (kpis.current.conversionRate ? Math.round(kpis.current.won / (kpis.current.conversionRate / 100)) - kpis.current.won : 0);

  return (
    <div className="mx-auto max-w-[1600px] space-y-5">
      <PageHeader title="Indicadores" subtitle="Sales Intelligence: análise de funil, vendedores, canais, previsão e recomendações com evidências." actions={<PeriodSelect value={days} />} />

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-5">
        <Stat label="Leads" value={num(kpis.current.leads, o.locale)} hint={deltaText(kpis.delta.leads)} />
        <Stat label="Oportunidades criadas" value={num(kpis.current.opportunities, o.locale)} hint={deltaText(kpis.delta.opportunities)} />
        <Stat label="Vendas" value={num(kpis.current.won, o.locale)} hint={deltaText(kpis.delta.won)} />
        <Stat label="Receita" value={money(kpis.current.revenueCents, o)} hint={deltaText(kpis.delta.revenue)} />
        <Stat label="Conversão (ganhas/fechadas)" value={pct(kpis.current.conversionRate, o.locale)} hint={kpis.current.conversionRate == null ? "Nenhum negócio fechado no período" : closedSample < 20 ? "Amostra pequena: interpretar com cautela" : deltaText(kpis.delta.conversionPp, " p.p.")} />
      </div>

      <Card>
        <CardTitle sub="Perguntas são mapeadas para métricas com definição canônica — nenhuma consulta livre ao banco é gerada por IA.">Pergunte aos seus dados</CardTitle>
        <NlQuery locale={o.locale} currency={o.currency} />
      </Card>

      <div className="grid gap-5 lg:grid-cols-2">
        <Card>
          <CardTitle sub="Posição atual de todas as oportunidades">Análise de funil</CardTitle>
          {funnel.some((f) => f.n > 0) ? (
            <>
              <FunnelChart stages={funnel} locale={o.locale} currency={o.currency} />
              <Table head={["Etapa", "Oportunidades", "Valor", "Passagem"]}>
                {funnel.map((s) => {
                  const i = open.findIndex((x) => x.id === s.id);
                  const conv = i > 0 && open[i - 1].n ? Math.round((s.n / open[i - 1].n) * 100) : null;
                  return (
                    <tr key={s.id}>
                      <Td>{s.name} {s.kind !== "open" && <Badge tone={s.kind === "won" ? "success" : "danger"}>{s.kind === "won" ? "ganho" : "perdido"}</Badge>}</Td>
                      <Td>{num(s.n, o.locale)}</Td>
                      <Td>{money(s.total, o)}</Td>
                      <Td>{conv == null ? "—" : <span className={conv < 35 ? "text-danger" : ""}>{conv}%</span>}</Td>
                    </tr>
                  );
                })}
              </Table>
            </>
          ) : <Empty title="Sem oportunidades no funil">Crie oportunidades no CRM para ver a análise.</Empty>}
        </Card>

        <Card>
          <CardTitle sub="Cenários ponderados pela probabilidade de cada etapa">Previsão de receita</CardTitle>
          <div className="grid grid-cols-3 gap-3">
            <Stat label="Pessimista" value={money(forecast.scenarios.pessimistic, o)} />
            <Stat label="Base" value={money(forecast.scenarios.base, o)} />
            <Stat label="Otimista" value={money(forecast.scenarios.optimistic, o)} />
          </div>
          <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
            <p className="text-muted">Pipeline aberto: <span className="font-medium text-fg">{money(forecast.pipelineTotalCents, o)}</span></p>
            <p className="text-muted">Negócios abertos: <span className="font-medium text-fg">{num(forecast.openDeals, o.locale)}</span></p>
            <p className="text-muted">Taxa de ganho (90d): <span className="font-medium text-fg">{forecast.historicalWinRate == null ? "n/d" : pct(forecast.historicalWinRate * 100, o.locale)}</span></p>
            <p className="text-muted">Incerteza: <span className="font-medium text-fg">±{forecast.uncertaintyPct}%</span> (amostra {forecast.sampleSize})</p>
          </div>
          <div className="mt-4">
            <p className="text-xs font-semibold text-muted">Premissas</p>
            <ul className="mt-1 list-disc space-y-1 pl-5 text-xs text-muted">{forecast.assumptions.map((a) => <li key={a}>{a}</li>)}</ul>
            {forecast.limitations.length > 0 && <div className="mt-3 rounded-lg border border-warning/40 bg-warning/10 p-3 text-xs text-warning">{forecast.limitations.join(" ")}</div>}
          </div>
        </Card>
      </div>

      <Card>
        <CardTitle sub="Cada recomendação traz problema, evidência, impacto, prioridade, ação e indicador de acompanhamento">Recomendações</CardTitle>
        {recs.length ? (
          <div className="grid gap-3 md:grid-cols-2">
            {recs.map((r) => (
              <div key={r.problem} className="rounded-xl border border-line bg-bg-2/60 p-4">
                <div className="flex items-start justify-between gap-2"><p className="font-semibold">{r.problem}</p><Badge tone={PRIORITY_TONE[r.priority]}>prioridade {r.priority}</Badge></div>
                <dl className="mt-2 space-y-1 text-xs">
                  <div><dt className="inline text-muted">Evidência: </dt><dd className="inline">{r.evidence}</dd></div>
                  <div><dt className="inline text-muted">Impacto estimado: </dt><dd className="inline">{r.impact}</dd></div>
                  <div><dt className="inline text-muted">Ação: </dt><dd className="inline">{r.action}</dd></div>
                  <div><dt className="inline text-muted">Indicador: </dt><dd className="inline">{r.indicator}</dd></div>
                </dl>
              </div>
            ))}
          </div>
        ) : <Empty title="Nenhum gargalo detectado pelas regras atuais">As regras avaliam passagem entre etapas, oportunidades paradas, leads sem score e conversas em handoff.</Empty>}
      </Card>

      <div className="grid gap-5 lg:grid-cols-2">
        <Card>
          <CardTitle sub={`Últimos ${days} dias`}>Desempenho de vendedores</CardTitle>
          {sellers.length ? (
            <>
              <SellersChart sellers={sellers} locale={o.locale} currency={o.currency} />
              <Table head={["#", "Vendedor", "Ganhas", "Perdidas", "Abertas", "Receita", "Conversão"]}>
                {sellers.map((s, i) => (
                  <tr key={s.userId}>
                    <Td>{i + 1}</Td><Td>{s.name}</Td><Td>{s.won}</Td><Td>{s.lost}</Td><Td>{s.open}</Td><Td>{money(s.revenue, o)}</Td>
                    <Td>{s.winRate == null ? "n/d" : <span title={s.won + s.lost < 5 ? "Menos de 5 negócios fechados: pouco confiável" : undefined}>{s.winRate}%{s.won + s.lost < 5 ? " *" : ""}</span>}</Td>
                  </tr>
                ))}
              </Table>
              <p className="mt-2 text-[11px] text-muted">* menos de 5 negócios fechados — taxa pouco confiável.</p>
            </>
          ) : <Empty title="Sem oportunidades atribuídas a vendedores" />}
        </Card>
        <Card>
          <CardTitle sub={`Últimos ${days} dias · ${num(origins.total, o.locale)} leads`}>Análise por canal / origem</CardTitle>
          {origins.total ? <OriginsChart buckets={origins.buckets} /> : <Empty title="Nenhum lead no período" />}
          <Table head={["Origem", "Leads", "%"]}>
            {origins.buckets.map((b) => <tr key={b.key}><Td>{b.label}</Td><Td>{num(b.count, o.locale)}</Td><Td>{b.pct}%</Td></tr>)}
          </Table>
        </Card>
      </div>
      <AiSuggestionMetricsCard m={await aiSuggestionMetrics(ctx, days)} title="Respostas com IA no atendimento e na prospecção" />
    </div>
  );
}
