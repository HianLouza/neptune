import { eq } from "drizzle-orm";
import { requirePageContext, getSessionToken } from "@/server/auth/next";
import { users, userPreferences, sessions } from "@/server/db/schema";
import { listMySessions } from "@/server/domains/admin";
import { sha256 } from "@/server/auth/crypto";
import { Badge, Card, CardTitle, PageHeader, Table, Td } from "@/components/ui";
import { ActionButton, FieldsForm } from "@/components/admin/actions";
import { TwoFactor, ThemePicker } from "@/components/admin/two-factor";
import { date } from "@/lib/format";

export const metadata = { title: "Configurações" };

export default async function ConfiguracoesPage() {
  const ctx = await requirePageContext();
  const o = { locale: ctx.locale, timezone: ctx.timezone };
  const token = await getSessionToken();
  const [[u], [pref], mySessions, [current]] = await Promise.all([
    ctx.db.select().from(users).where(eq(users.id, ctx.userId)),
    ctx.db.select().from(userPreferences).where(eq(userPreferences.userId, ctx.userId)),
    listMySessions(ctx),
    token ? ctx.db.select({ id: sessions.id }).from(sessions).where(eq(sessions.tokenHash, sha256(token))) : Promise.resolve([]),
  ]);

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      <PageHeader title="Configurações" subtitle="Perfil, segurança, sessões e preferências." />
      <Card>
        <CardTitle sub={u.email}>Perfil</CardTitle>
        <FieldsForm url="/api/me" extra={{ action: "profile" }} columns={2} success="Perfil atualizado."
          fields={[
            { name: "name", label: "Nome", defaultValue: u.name, required: true },
            { name: "jobTitle", label: "Cargo/função", defaultValue: u.jobTitle ?? "" },
            { name: "locale", label: "Idioma", type: "select", defaultValue: u.locale, options: [{ value: "pt-BR", label: "Português (Brasil)" }, { value: "en", label: "English" }, { value: "es", label: "Español" }] },
            { name: "timezone", label: "Fuso horário (vazio = da organização)", defaultValue: u.timezone ?? "", placeholder: "America/Sao_Paulo" },
          ]} />
      </Card>
      <div className="grid gap-6 md:grid-cols-2">
        <Card><CardTitle>Verificação em duas etapas</CardTitle><TwoFactor enabled={u.totpEnabled} /></Card>
        <Card><CardTitle>Tema</CardTitle><ThemePicker current={pref?.theme ?? "dark"} /></Card>
      </div>
      <Card>
        <CardTitle sub="Encerre sessões que você não reconhece.">Sessões ativas</CardTitle>
        <Table head={["Dispositivo", "IP", "Início", "Expira", ""]}>
          {mySessions.map((s) => (
            <tr key={s.id}>
              <Td className="max-w-xs truncate text-xs">{s.userAgent ?? "Desconhecido"} {current?.id === s.id && <Badge tone="success">Esta sessão</Badge>}</Td>
              <Td className="text-xs">{s.ip ?? "—"}</Td><Td className="text-xs">{date(s.createdAt, o, true)}</Td><Td className="text-xs">{date(s.expiresAt, o)}</Td>
              <Td>{current?.id !== s.id && <ActionButton url="/api/me" body={{ action: "revoke_session", sessionId: s.id }} label="Encerrar" variant="ghost" success="Sessão encerrada." />}</Td>
            </tr>
          ))}
        </Table>
      </Card>
    </div>
  );
}
