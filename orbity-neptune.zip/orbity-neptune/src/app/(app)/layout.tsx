import { and, count, eq, isNull, or } from "drizzle-orm";
import { requirePageContext } from "@/server/auth/next";
import { notifications, organizations, users, userPreferences } from "@/server/db/schema";
import { getSubscription, getWallet } from "@/server/domains/billing";
import { kickOutbox } from "@/server/events/handlers";
import { AppShell } from "@/components/layout/app-shell";
import { NAV_LABEL_KEYS } from "@/components/layout/nav";
import { t } from "@/lib/i18n";
import { redirect } from "next/navigation";

export const dynamic = "force-dynamic";

const ROLE_LABEL: Record<string, string> = { admin: "Admin", manager: "Gestor", member: "Colaborador" };

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const ctx = await requirePageContext();
  const db = ctx.db;
  const [[user], [org], [pref], sub, wallet, [unread]] = await Promise.all([
    db.select().from(users).where(eq(users.id, ctx.userId)),
    db.select().from(organizations).where(eq(organizations.id, ctx.organizationId)),
    db.select().from(userPreferences).where(eq(userPreferences.userId, ctx.userId)),
    getSubscription(db, ctx.organizationId),
    getWallet(db, ctx.organizationId),
    db.select({ n: count() }).from(notifications).where(and(eq(notifications.organizationId, ctx.organizationId), isNull(notifications.readAt), or(isNull(notifications.userId), eq(notifications.userId, ctx.userId)))),
  ]);
  if (!org.onboardingCompleted) redirect("/onboarding");
  kickOutbox(db); // processa eventos pendentes (o worker garante processamento contínuo)

  const labels = Object.fromEntries(NAV_LABEL_KEYS.map((k) => [k, t(ctx.locale, k)]));
  const allowance = wallet?.monthlyAllowance ?? 0, used = wallet?.usedThisPeriod ?? 0;
  const initials = user.name.split(" ").map((p) => p[0]).slice(0, 2).join("").toUpperCase();
  return (
    <AppShell
      labels={labels} permissions={ctx.permissions} isPlatformAdmin={ctx.isPlatformAdmin}
      plan={sub ? { name: sub.plan.name, used, allowance, usagePct: allowance ? Math.min(100, Math.round((used / allowance) * 100)) : 0, locale: ctx.locale } : null}
      user={{ name: user.name, initials, role: ROLE_LABEL[ctx.roleKey] ?? ctx.roleKey }}
      org={{ name: org.name, isDemo: org.isDemo }} unread={Number(unread.n)}
      demoBanner={t(ctx.locale, "demo.banner")} searchPlaceholder={t(ctx.locale, "search.placeholder")} theme={pref?.theme ?? "dark"}
    >
      {children}
    </AppShell>
  );
}
