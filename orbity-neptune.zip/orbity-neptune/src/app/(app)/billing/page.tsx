import { asc, desc, eq } from "drizzle-orm";
import { requirePageContext } from "@/server/auth/next";
import { creditTransactions, invoices, plans, integrations } from "@/server/db/schema";
import { forecastSpend, getLimit, getSubscription, getWallet, usageThisPeriod, OVERAGE_CENTS_PER_CREDIT } from "@/server/domains/billing";
import { Badge, Card, CardTitle, Empty, PageHeader, Progress, Stat, Table, Td } from "@/components/ui";
import { ActionButton, FieldsForm } from "@/components/admin/actions";
import { date, money, num } from "@/lib/format";
import { and, inArray } from "drizzle-orm";

export const metadata = { title: "Billing & Planos" };

const SUB_STATUS: Record<string, { label: string; tone: "success" | "warning" | "danger" | "info" | "neutral" }> = {
  trialing: { label: "Em teste", tone: "info" }, active: { label: "Ativa", tone: "success" }, past_due: { label: "Pagamento pendente", tone: "warning" },
  suspended: { label: "Suspensa", tone: "danger" }, canceled: { label: "Cancelada", tone: "neutral" },
};
const LIMIT_LABELS: Record<string, string> = { users: "Usuários", leads_per_month: "Leads/mês", messages_per_month: "Mensagens/mês", agents: "Agentes de IA", automations: "Automações", integrations: "Integrações", storage_mb: "Armazenamento (MB)" };
const FEATURE_LABELS: Record<string, string> = { prospect: "Prospect.AI", closer: "Closer.AI", intelligence: "Sales Intelligence", crm: "CRM central", automations: "Workflow Engine", ai_agents: "Agentes de IA", ai_eval: "AI Evaluation Center", goals: "Metas e comissões", integrations_advanced: "Integrações avançadas", experiments: "Experimentos", data_export: "Exportação de dados", sso: "SSO", custom_roles: "Cargos personalizados" };
const USAGE = [["leads", "leads_per_month", "Leads"], ["messages", "messages_per_month", "Mensagens"], ["ai_credits", null, "Créditos de IA"]] as const;

export default async function BillingPage() {
  const ctx = await requirePageContext("billing:read");
  const canManage = ctx.permissions.includes("*") || ctx.permissions.includes("billing:manage");
  const o = { locale: ctx.locale, currency: ctx.currency, timezone: ctx.timezone };
  const [sub, wallet, allPlans, txs, invs, forecast, payProviders] = await Promise.all([
    getSubscription(ctx.db, ctx.organizationId), getWallet(ctx.db, ctx.organizationId),
    ctx.db.select().from(plans).where(eq(plans.active, true)).orderBy(asc(plans.includedCredits)),
    ctx.db.select().from(creditTransactions).where(eq(creditTransactions.organizationId, ctx.organizationId)).orderBy(desc(creditTransactions.createdAt)).limit(15),
    ctx.db.select().from(invoices).where(eq(invoices.organizationId, ctx.organizationId)).orderBy(desc(invoices.createdAt)).limit(20),
    forecastSpend(ctx.db, ctx.organizationId),
    ctx.db.select().from(integrations).where(and(eq(integrations.organizationId, ctx.organizationId), inArray(integrations.provider, ["stripe", "mercadopago", "asaas"]))),
  ]);
  const usage = await Promise.all(USAGE.map(async ([metric, limitKey, label]) => ({
    label, used: await usageThisPeriod(ctx.db, ctx.organizationId, metric), limit: limitKey ? await getLimit(ctx.db, ctx.organizationId, limitKey) : wallet?.monthlyAllowance ?? null,
  })));
  const realPayment = payProviders.some((p) => p.status === "connected");
  const st = sub ? SUB_STATUS[sub.sub.status] ?? SUB_STATUS.active : null;
  const price = (c: number | null) => (c == null ? "A definir — validação comercial pendente" : `${money(c, o)}/mês`);

  return (
    <div className="mx-auto max-w-7xl space-y-6">
      <PageHeader title="Billing & Planos" subtitle="Assinatura, créditos de IA unificados, consumo, excedentes autorizados e faturas." />

      {!realPayment && (
        <div className="rounded-xl border border-warning/40 bg-warning/10 p-4 text-sm text-warning">
          Nenhum provedor de pagamento (Stripe, Mercado Pago ou Asaas) está conectado. Faturas são geradas para conferência, mas <strong>nenhuma cobrança real é realizada</strong> até que um provedor seja configurado em Integrações.
        </div>
      )}

      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-1">
          <CardTitle>Assinatura atual</CardTitle>
          {sub && st ? (
            <div className="space-y-2 text-sm">
              <p className="text-2xl font-bold">{sub.plan.name}</p>
              <Badge tone={st.tone}>{st.label}</Badge>
              <p className="text-muted">Preço: {price(sub.plan.monthlyPriceCents == null ? null : Number(sub.plan.monthlyPriceCents))}</p>
              {sub.sub.trialEndsAt && sub.sub.status === "trialing" && <p className="text-muted">Teste termina em {date(sub.sub.trialEndsAt, o)}</p>}
              <p className="text-muted">Período: {date(sub.sub.currentPeriodStart, o)} – {date(sub.sub.currentPeriodEnd, o)}</p>
              <p className="text-muted">Ciclo: {sub.sub.billingCycle === "annual" ? "Anual" : "Mensal"} · Provedor: {sub.sub.provider}</p>
            </div>
          ) : <Empty title="Sem assinatura." />}
        </Card>
        <Card className="lg:col-span-2">
          <CardTitle sub="Carteira unificada usada por todos os agentes e módulos.">Créditos de IA</CardTitle>
          {wallet ? (
            <div className="grid gap-3 sm:grid-cols-3">
              <Stat label="Saldo" value={num(wallet.balance, o.locale)} />
              <Stat label="Franquia mensal" value={num(wallet.monthlyAllowance, o.locale)} />
              <Stat label="Usado no período" value={num(wallet.usedThisPeriod, o.locale)} hint={wallet.monthlyAllowance ? `${Math.round((wallet.usedThisPeriod / wallet.monthlyAllowance) * 100)}% da franquia` : undefined} />
            </div>
          ) : <Empty title="Carteira não encontrada." />}
        </Card>
      </div>

      <Card>
        <CardTitle>Consumo do período</CardTitle>
        <div className="grid gap-4 md:grid-cols-3">
          {usage.map((u) => {
            const p = u.limit ? Math.round((u.used / u.limit) * 100) : 0;
            return (
              <div key={u.label}>
                <div className="mb-1 flex justify-between text-sm"><span>{u.label}</span><span className="text-muted">{num(u.used, o.locale)} / {u.limit == null ? "ilimitado" : num(u.limit, o.locale)}</span></div>
                <Progress value={p} tone={p >= 100 ? "danger" : p >= 80 ? "warning" : "primary"} />
              </div>
            );
          })}
        </div>
      </Card>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardTitle sub="Apresentado antes de qualquer cobrança.">Previsão de gastos e excedentes</CardTitle>
          {forecast ? (
            <div className="space-y-3 text-sm">
              <div className="grid grid-cols-2 gap-3">
                <Stat label="Consumo projetado" value={`${num(forecast.projectedUse, o.locale)} créditos`} />
                <Stat label="Excedente projetado" value={money(forecast.projectedOverageCents, o)} hint={`${num(forecast.projectedOverageCredits, o.locale)} créditos × ${OVERAGE_CENTS_PER_CREDIT} centavos`} />
              </div>
              <p>Excedentes: {forecast.overageAuthorized ? <Badge tone="success">Autorizados até {money(forecast.overageCapCents, o)}</Badge> : <Badge tone="neutral">Não autorizados — uso é bloqueado ao zerar o saldo</Badge>}</p>
              <ul className="list-disc space-y-1 pl-5 text-xs text-muted">{forecast.assumptions.map((a) => <li key={a}>{a}</li>)}</ul>
              {canManage && (
                <FieldsForm url="/api/billing" extra={{ action: "overage" }} columns={2} submitLabel="Salvar autorização"
                  success="Autorização atualizada e registrada em auditoria."
                  fields={[
                    { name: "authorized", label: "Autorizo cobrança automática de excedentes conforme contrato", type: "checkbox", defaultValue: forecast.overageAuthorized },
                    { name: "capCents", label: `Teto mensal (${o.currency})`, type: "number", transform: "cents", defaultValue: forecast.overageCapCents / 100 },
                  ]} />
              )}
            </div>
          ) : <Empty title="Sem dados de consumo." />}
        </Card>
        <Card>
          <CardTitle>Histórico de créditos</CardTitle>
          {txs.length ? (
            <Table head={["Data", "Motivo", "Agente", "Créditos"]}>
              {txs.map((t) => <tr key={t.id}><Td className="text-xs">{date(t.createdAt, o, true)}</Td><Td className="text-xs">{t.reason === "overage" ? "Excedente" : t.reason}</Td><Td className="text-xs">{t.agentKey ?? "—"}</Td><Td className={t.amount < 0 ? "text-danger" : "text-success"}>{t.amount > 0 ? "+" : ""}{num(t.amount, o.locale)}</Td></tr>)}
            </Table>
          ) : <Empty title="Nenhuma movimentação ainda." />}
        </Card>
      </div>

      <Card>
        <CardTitle sub="Preços finais ainda não definidos: dependem da validação comercial (pilotos e testes de preço).">Planos</CardTitle>
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {allPlans.map((p) => {
            const current = sub?.plan.key === p.key;
            return (
              <div key={p.id} className={`flex flex-col rounded-xl border p-4 ${current ? "border-primary-2 bg-primary/10" : "border-line bg-bg-2/50"}`}>
                <div className="flex items-center justify-between"><p className="text-lg font-bold">{p.name}</p>{current && <Badge tone="primary">Atual</Badge>}</div>
                <p className="mt-1 text-xs text-muted">{price(p.monthlyPriceCents == null ? null : Number(p.monthlyPriceCents))}</p>
                <p className="text-xs text-muted">Desconto anual: {p.annualDiscountPct}% · Teste: {p.trialDays} dias</p>
                <p className="mt-2 text-sm">{num(p.includedCredits, o.locale)} créditos de IA/mês</p>
                <ul className="mt-2 space-y-0.5 text-xs text-muted">
                  {Object.entries(p.limits).map(([k, v]) => <li key={k}>{LIMIT_LABELS[k] ?? k}: {v < 0 ? "ilimitado" : num(v, o.locale)}</li>)}
                </ul>
                <div className="mt-2 flex flex-wrap gap-1">{p.features.map((f) => <Badge key={f}>{FEATURE_LABELS[f] ?? f}</Badge>)}</div>
                <div className="mt-auto pt-4">
                  {canManage && !current && <ActionButton url="/api/billing" body={{ action: "change_plan", planKey: p.key }} label={`Mudar para ${p.name}`} confirm={`Confirmar mudança para o plano ${p.name}? Limites e franquia de créditos serão ajustados.`} success="Plano alterado." />}
                </div>
              </div>
            );
          })}
        </div>
      </Card>

      <Card>
        <CardTitle action={canManage ? <ActionButton url="/api/billing" body={{ action: "invoice" }} label="Gerar fatura do período" success="Fatura gerada." /> : undefined}>Faturas</CardTitle>
        {invs.length ? (
          <Table head={["Número", "Emissão", "Vencimento", "Itens", "Valor", "Status"]}>
            {invs.map((i) => (
              <tr key={i.id}>
                <Td>{i.number}</Td><Td className="text-xs">{date(i.createdAt, o)}</Td><Td className="text-xs">{date(i.dueAt, o)}</Td>
                <Td className="text-xs">{i.lines.length ? i.lines.map((l) => l.description).join("; ") : "Sem itens cobráveis (preço do plano a definir)"}</Td>
                <Td>{money(Number(i.amountCents), { locale: o.locale, currency: i.currency })}</Td>
                <Td><Badge tone={i.status === "paid" ? "success" : i.status === "open" ? "warning" : "neutral"}>{{ paid: "Paga", open: "Em aberto", draft: "Rascunho", void: "Anulada", uncollectible: "Incobrável" }[i.status] ?? i.status}</Badge></Td>
              </tr>
            ))}
          </Table>
        ) : <Empty title="Nenhuma fatura gerada." />}
      </Card>
    </div>
  );
}
