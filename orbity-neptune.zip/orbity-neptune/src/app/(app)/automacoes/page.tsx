import { requirePageContext } from "@/server/auth/next";
import { ACTION_CATALOG, listWorkflows, workflowDetail } from "@/server/workflows/engine";
import { TEMPLATES } from "@/server/workflows/templates";
import { EVENT_LABELS } from "@/server/events";
import { Card, Empty, PageHeader } from "@/components/ui";
import { NLCreator, TemplateGallery, WorkflowList } from "@/components/workflows/creators";
import { WorkflowEditor } from "@/components/workflows/editor";
import type { Wf, WfRun, WfVersion } from "@/components/workflows/types";

export const metadata = { title: "Automações" };

const ser = <T,>(v: unknown) => JSON.parse(JSON.stringify(v)) as T;

/** Gatilhos disponíveis para automações (exclui eventos internos de billing/aprovação). */
const TRIGGER_KEYS = ["lead.created", "lead.qualified", "opportunity.created", "opportunity.stage_changed", "opportunity.won", "opportunity.lost",
  "conversation.received", "message.replied", "meeting.scheduled", "proposal.sent", "payment.confirmed", "limit.reached"];

export default async function AutomacoesPage({ searchParams }: { searchParams: Promise<{ wf?: string; novo?: string; modelo?: string }> }) {
  const ctx = await requirePageContext("automations:read");
  const sp = await searchParams;
  const can = (p: string) => ctx.permissions.includes("*") || ctx.permissions.includes(p);
  const canWrite = can("automations:write");
  const labels = Object.fromEntries(TRIGGER_KEYS.map((k) => [k, EVENT_LABELS[k] ?? k]));

  const items = ser<Wf[]>(await listWorkflows(ctx));
  let detail: { workflow: Wf; versions: WfVersion[]; runs: WfRun[] } | null = null;
  let notFound = false;
  if (sp.wf && /^[0-9a-f-]{36}$/i.test(sp.wf)) {
    try { detail = ser(await workflowDetail(ctx, sp.wf)); } catch { notFound = true; }
  }
  const templates = TEMPLATES.map(({ key, name, description, triggerEvent }) => ({ key, name, description, triggerEvent }));

  return (
    <div className="mx-auto max-w-[1600px]">
      <PageHeader title="Automações" subtitle="Workflow Engine: gatilhos, condições, ramificações, esperas, aprovações humanas, versionamento e simulação." />
      <div className="grid gap-5 lg:grid-cols-[320px_1fr]">
        <div className="space-y-4">
          <WorkflowList items={items} labels={labels} selectedId={detail?.workflow.id} locale={ctx.locale} />
        </div>
        <div className="min-w-0 space-y-5">
          {detail ? (
            <WorkflowEditor key={detail.workflow.id + ":" + detail.workflow.currentVersion} workflow={detail.workflow} versions={detail.versions} runs={detail.runs}
              actions={ACTION_CATALOG} labels={labels} canWrite={canWrite} canPublish={can("automations:publish")} locale={ctx.locale} />
          ) : (
            <>
              {notFound && <Card><Empty title="Automação não encontrada." /></Card>}
              {canWrite && <NLCreator autoFocus={sp.novo === "ia"} />}
              <TemplateGallery templates={templates} labels={labels} highlight={sp.modelo} canWrite={canWrite} />
              {!canWrite && <p className="text-xs text-muted">Seu perfil pode visualizar automações, mas não criar ou editar.</p>}
            </>
          )}
          {detail && canWrite && (
            <details className="card p-4">
              <summary className="cursor-pointer text-sm font-semibold">Criar outra automação</summary>
              <div className="mt-4 space-y-5">
                <NLCreator />
                <TemplateGallery templates={templates} labels={labels} canWrite={canWrite} />
              </div>
            </details>
          )}
        </div>
      </div>
    </div>
  );
}
