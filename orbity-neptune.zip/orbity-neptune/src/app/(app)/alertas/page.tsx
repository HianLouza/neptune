import Link from "next/link";
import { and, desc, eq } from "drizzle-orm";
import { requirePageContext } from "@/server/auth/next";
import { teams, tasks, memberships, users } from "@/server/db/schema";
import {
  alertCenterMetrics, executionIntelligence, filtersSchema, getAlertDetail, getTone, listAlerts, listExtensions, listMyAlerts, listRules, taskHistory, TRIGGER_LABEL,
  CHANNEL_LABEL, PRIORITY_LABEL, PRIORITY_TONE, RESPONSE_LABEL, STATUS_LABEL, STATUS_TONE, type AlertChannel, type AlertPriority, type AlertStatus, type ResponseKind,
} from "@/server/domains/task-alerts";
import { Badge, Card, CardTitle, Empty, PageHeader, Stat, Table, Td } from "@/components/ui";
import { AlertFilters, AlertRowActions, ExtensionDecision, RespondPanel, RulesManager, RunAutomationButton, ToneForm, type Recommendation, type RuleRow } from "@/components/task-alerts/alerts-ui";
import { date, num } from "@/lib/format";

export const metadata = { title: "Central de Alertas" };

const FILTER_KEYS = ["recipientId", "teamId", "priority", "status", "taskId", "channel", "kind", "from", "to"] as const;
const EVENT_LABEL: Record<string, string> = {
  created: "Alerta criado", scheduled: "Agendado", sent: "Enviado", delivered: "Entregue", read: "Lido pelo destinatário", failed: "Falha no envio", canceled: "Cancelado",
  responded: "Resposta do colaborador", escalated: "Escalonado", extension_requested: "Prorrogação solicitada", extension_decided: "Prorrogação decidida",
};
const KIND_LABEL: Record<string, string> = { manual: "Manual", automation: "Automático", escalation: "Escalonado" };
const EXT_LABEL: Record<string, [string, "warning" | "success" | "danger" | "info"]> = { pending: ["pendente", "warning"], approved: ["aprovada", "success"], rejected: ["rejeitada", "danger"], countered: ["data alterada pelo gestor", "info"] };

type SP = Record<string, string | undefined>;

export default async function AlertasPage({ searchParams }: { searchParams: Promise<SP> }) {
  const ctx = await requirePageContext("goals:read");
  const can = (p: string) => ctx.permissions.includes("*") || ctx.permissions.includes(p);
  const manager = can("alerts:send"), admin = can("alerts:manage");
  const sp = await searchParams;
  const o = { locale: ctx.locale, currency: ctx.currency, timezone: ctx.timezone };
  const dt = (d: Date | string | null | undefined) => (d ? date(d, o, true) : "—");
  const orgUsers = await ctx.db.select({ id: users.id, name: users.name }).from(memberships).innerJoin(users, eq(users.id, memberships.userId))
    .where(and(eq(memberships.organizationId, ctx.organizationId), eq(memberships.status, "active"))).orderBy(users.name);
  const nameOf = (id: string | null) => orgUsers.find((u) => u.id === id)?.name ?? (id ? "—" : "Automação");

  const filters = Object.fromEntries(FILTER_KEYS.map((k) => [k, sp[k]]).filter(([, v]) => v)) as SP;
  const parsed = filtersSchema.safeParse(filters);
  const [mine, allExt, central, metrics, rules, tone, intel, teamRows, taskRows] = await Promise.all([
    listMyAlerts(ctx), listExtensions(ctx),
    manager ? listAlerts(ctx, parsed.success ? filters : {}) : Promise.resolve([]),
    manager ? alertCenterMetrics(ctx) : Promise.resolve(null),
    admin ? listRules(ctx) : Promise.resolve([]),
    manager ? getTone(ctx) : Promise.resolve(null),
    manager ? executionIntelligence(ctx, 90) : Promise.resolve(null),
    manager ? ctx.db.select({ id: teams.id, name: teams.name }).from(teams).where(eq(teams.organizationId, ctx.organizationId)).orderBy(teams.name) : Promise.resolve([]),
    manager ? ctx.db.select({ id: tasks.id, title: tasks.title }).from(tasks).where(eq(tasks.organizationId, ctx.organizationId)).orderBy(desc(tasks.createdAt)).limit(150) : Promise.resolve([]),
  ]);
  const myExt = allExt.filter((e) => e.r.requesterId === ctx.userId);
  const pendingExt = allExt.filter((e) => e.r.status === "pending" && e.r.requesterId !== ctx.userId);

  // Detalhe: ?alerta=ID (alerta e histórico da tarefa) ou ?tarefa=ID (histórico da tarefa).
  const detail = sp.alerta ? await getAlertDetail(ctx, sp.alerta).catch(() => null)
    : sp.tarefa ? await taskHistory(ctx, sp.tarefa).then((h) => ({ alert: null, ...h })).catch(() => null) : null;

  const chips = (a: { channels: string[]; channelResults: Record<string, { status: string; error?: string }> }) => (
    <span className="flex flex-wrap gap-1">{a.channels.map((c) => {
      const r = a.channelResults[c];
      return <Badge key={c} tone={r?.status === "failed" ? "danger" : r?.status === "delivered" ? "success" : r ? "primary" : "neutral"}>{CHANNEL_LABEL[c as AlertChannel]?.split(" /")[0] ?? c}{r ? ` · ${r.status === "delivered" ? "entregue" : r.status === "failed" ? "falhou" : "enviado"}` : ""}</Badge>;
    })}</span>
  );

  return (
    <div className="mx-auto max-w-[1500px] space-y-5">
      <PageHeader title="Central de Alertas" subtitle="Comunicação individual, rastreável e contextualizada sobre tarefas e metas. Envio, entrega e leitura são sempre registrados separadamente." />

      {/* ---- Detalhe / histórico ---- */}
      {detail && (
        <Card glow>
          <div id="detalhe" />
          <CardTitle sub={<>Tarefa: <Link className="text-primary-2 underline" href={`/tarefas#t-${detail.task.id}`}>{detail.task.title}</Link> · prazo {dt(detail.task.dueAt)} · {detail.task.status === "open" ? "aberta" : detail.task.status === "done" ? "concluída" : "cancelada"}{detail.task.blockedReason ? ` · bloqueada: ${detail.task.blockedReason}` : ""}</>}
            action={<Link href="/alertas" className="text-xs text-muted hover:text-fg">Fechar</Link>}>{detail.alert ? `Alerta: ${detail.alert.title}` : "Histórico da tarefa"}</CardTitle>
          {detail.alert && (
            <div className="mb-4 space-y-2 rounded-xl border border-line bg-bg-2/60 p-3 text-sm">
              <div className="flex flex-wrap items-center gap-2"><Badge tone={PRIORITY_TONE[detail.alert.priority as AlertPriority]}>{PRIORITY_LABEL[detail.alert.priority as AlertPriority]}</Badge><Badge tone={STATUS_TONE[detail.alert.status as AlertStatus]}>{STATUS_LABEL[detail.alert.status as AlertStatus]}</Badge>{chips(detail.alert)}
                {detail.alert.simulated && <Badge tone="warning">texto simulado</Badge>}</div>
              <p className="text-xs text-muted">De {nameOf(detail.alert.senderId)} para {nameOf(detail.alert.recipientId)} · {KIND_LABEL[detail.alert.kind]}{detail.alert.escalationLevel ? ` (nível ${detail.alert.escalationLevel})` : ""}</p>
              <p className="whitespace-pre-wrap">{detail.alert.message}</p>
              {detail.alert.originalMessage && detail.alert.originalMessage !== detail.alert.message && <details className="text-xs text-muted"><summary className="cursor-pointer">Sugestão original do Flávio (antes da edição)</summary><p className="mt-1 whitespace-pre-wrap">{detail.alert.originalMessage}</p></details>}
              {detail.alert.failureReason && <p className="text-xs text-danger">Motivo: {detail.alert.failureReason}</p>}
              {detail.alert.recipientId === ctx.userId && ["sent", "delivered", "read", "responded"].includes(detail.alert.status) && (
                <RespondPanel alertId={detail.alert.id} taskId={detail.task.id} canComplete={can("crm:write")} dueAt={detail.task.dueAt?.toISOString() ?? null} read={!!detail.alert.readAt} />
              )}
            </div>
          )}
          <div className="grid gap-5 lg:grid-cols-2">
            <div>
              <p className="mb-2 text-xs font-medium text-muted">Linha do tempo (mais recente primeiro)</p>
              {detail.events.length ? (
                <ol className="space-y-2 border-l border-line pl-4">
                  {detail.events.map((e) => {
                    const d = e.data as Record<string, unknown>;
                    return (
                      <li key={e.id} className="relative text-sm"><span className="absolute -left-[21px] top-1.5 h-2 w-2 rounded-full bg-primary-2" />
                        <p className="font-medium">{EVENT_LABEL[e.type] ?? e.type}{e.channel ? ` · ${CHANNEL_LABEL[e.channel as AlertChannel]?.split(" /")[0] ?? e.channel}` : ""}</p>
                        <p className="text-[11px] text-muted">{dt(e.createdAt)} · {e.actorId === "system" ? "sistema" : nameOf(e.actorId)}</p>
                        {e.type === "responded" && <p className="text-xs text-muted">{RESPONSE_LABEL[d.kind as ResponseKind] ?? String(d.kind)}{d.message ? `: ${d.message}` : ""}{d.progressPct != null ? ` (${d.progressPct}%)` : ""}</p>}
                        {e.type === "failed" && !!d.error && <p className="text-xs text-danger">{String(d.error)}</p>}
                        {e.type === "canceled" && !!d.reason && <p className="text-xs text-muted">{String(d.reason)}</p>}
                        {e.type === "escalated" && <p className="text-xs text-muted">Nível {String(d.level)} → {nameOf(String(d.toUserId))}</p>}
                        {e.type === "extension_requested" && <p className="text-xs text-muted">Novo prazo pedido: {dt(String(d.requestedDueAt))} — {String(d.justification ?? "")}</p>}
                        {e.type === "extension_decided" && <p className="text-xs text-muted">{String(d.decision)}{d.newDueAt ? ` · novo prazo ${dt(String(d.newDueAt))}` : " · prazo mantido"}{d.note ? ` — ${d.note}` : ""}</p>}
                      </li>
                    );
                  })}
                </ol>
              ) : <p className="text-xs text-muted">Sem eventos visíveis para o seu acesso.</p>}
            </div>
            <div>
              <p className="mb-2 text-xs font-medium text-muted">Alertas desta tarefa ({detail.alerts.length})</p>
              <ul className="space-y-1.5 text-sm">
                {detail.alerts.map((a) => <li key={a.id} className="flex flex-wrap items-center gap-2"><Link className="text-primary-2 underline" href={`/alertas?alerta=${a.id}#detalhe`}>{a.title}</Link><Badge tone={STATUS_TONE[a.status as AlertStatus]}>{STATUS_LABEL[a.status as AlertStatus]}</Badge><span className="text-[11px] text-muted">{dt(a.createdAt)}</span></li>)}
                {!detail.alerts.length && <li className="text-xs text-muted">Nenhum alerta.</li>}
              </ul>
              {detail.extensions.length > 0 && <><p className="mb-2 mt-4 text-xs font-medium text-muted">Solicitações de prorrogação</p>
                <ul className="space-y-1.5 text-sm">{detail.extensions.map((x) => <li key={x.id}><Badge tone={EXT_LABEL[x.status]?.[1] ?? "neutral"}>{EXT_LABEL[x.status]?.[0] ?? x.status}</Badge> <span className="text-xs text-muted">pediu {dt(x.requestedDueAt)}: {x.justification}</span></li>)}</ul></>}
            </div>
          </div>
        </Card>
      )}

      {/* ---- Meus alertas (colaborador) ---- */}
      <Card>
        <CardTitle sub="Alertas que você recebeu. Abrir um alerta registra a leitura; você pode responder, justificar, pedir ajuda ou mais prazo.">Meus alertas</CardTitle>
        {mine.length ? (
          <ul className="space-y-3">
            {mine.map(({ a, taskTitle, taskStatus, taskDueAt }) => (
              <li key={a.id} className={`rounded-xl border p-3 ${a.readAt || a.respondedAt ? "border-line" : "border-primary-2/50 bg-primary/5"}`}>
                <div className="flex flex-wrap items-center gap-2">
                  <Badge tone={PRIORITY_TONE[a.priority as AlertPriority]}>{PRIORITY_LABEL[a.priority as AlertPriority]}</Badge>
                  <Badge tone={STATUS_TONE[a.status as AlertStatus]}>{STATUS_LABEL[a.status as AlertStatus]}</Badge>
                  {a.kind === "escalation" && <Badge tone="warning">escalonamento</Badge>}
                  <span className="font-medium">{a.title}</span>
                </div>
                <p className="mt-1 text-xs text-muted">De {nameOf(a.senderId)} · {dt(a.sentAt)} · Tarefa: <Link className="text-primary-2 underline" href={`/tarefas#t-${a.taskId}`}>{taskTitle}</Link> · prazo {dt(taskDueAt)}</p>
                <p className="mt-2 whitespace-pre-wrap text-sm">{a.message}</p>
                {taskStatus === "open" ? <RespondPanel alertId={a.id} taskId={a.taskId} canComplete={can("crm:write") && a.kind !== "escalation"} dueAt={taskDueAt?.toISOString() ?? null} read={!!a.readAt} /> : <p className="mt-2 text-xs text-muted">Tarefa já encerrada.</p>}
              </li>
            ))}
          </ul>
        ) : <Empty title="Nenhum alerta recebido">Quando um gestor ou uma regra enviar um alerta sobre suas responsabilidades, ele aparece aqui e na Central de Notificações.</Empty>}
        {myExt.length > 0 && (
          <div className="mt-4 border-t border-line pt-3"><p className="mb-2 text-xs font-medium text-muted">Minhas solicitações de prorrogação</p>
            <ul className="space-y-1 text-sm">{myExt.map((e) => <li key={e.r.id}><Badge tone={EXT_LABEL[e.r.status]?.[1] ?? "neutral"}>{EXT_LABEL[e.r.status]?.[0]}</Badge> {e.taskTitle} · pediu {dt(e.r.requestedDueAt)}{e.r.decisionNote ? ` — ${e.r.decisionNote}` : ""}{e.r.decidedDueAt ? ` · prazo definido: ${dt(e.r.decidedDueAt)}` : ""}</li>)}</ul></div>
        )}
      </Card>

      {manager && metrics && (
        <>
          <section aria-label="Indicadores">
            <div className="grid grid-cols-2 gap-3 md:grid-cols-4 xl:grid-cols-5">
              <Stat label="Alertas enviados" value={num(metrics.total, o.locale)} hint="Com envio efetivamente realizado" />
              <Stat label="Aguardando leitura" value={num(metrics.pendingRead, o.locale)} hint="Enviados/entregues, ainda não abertos" />
              <Stat label="Agendados" value={num(metrics.scheduled, o.locale)} hint={`${metrics.drafts} rascunho(s)`} />
              <Stat label="Lidos" value={num(metrics.read, o.locale)} hint="Abertos pelo destinatário" />
              <Stat label="Sem resposta" value={num(metrics.unanswered, o.locale)} hint="Enviados sem resposta do responsável" />
              <Stat label="Tarefas atrasadas" value={num(metrics.overdueTasks, o.locale)} />
              <Stat label="Pedidos de prorrogação" value={num(metrics.pendingExtensions, o.locale)} hint="Aguardando decisão" />
              <Stat label="Tarefas críticas" value={num(metrics.criticalTasks, o.locale)} hint={`Prioridade alta vencida ou a vencer em 48 h · ${metrics.unassignedCritical} sem responsável`} />
              <Stat label="Escalonados" value={num(metrics.escalated, o.locale)} />
              <Stat label="Falhas de entrega" value={num(metrics.failed, o.locale)} hint={metrics.failed ? "Veja o motivo em cada alerta" : "Nenhuma"} />
            </div>
          </section>

          <Card>
            <CardTitle sub={`${central.length} alerta(s) · abra um alerta para ver o histórico completo e ir direto à tarefa`}>Alertas</CardTitle>
            <AlertFilters values={filters} users={orgUsers} teams={teamRows} tasks={taskRows} />
            {central.length ? (
              <Table head={["Prioridade", "Alerta / tarefa", "Destinatário", "Canais", "Status e etapas", "Origem", ""]}>
                {central.map(({ a, taskTitle, recipient }) => (
                  <tr key={a.id}>
                    <Td><Badge tone={PRIORITY_TONE[a.priority as AlertPriority]}>{PRIORITY_LABEL[a.priority as AlertPriority]}</Badge></Td>
                    <Td><Link className="font-medium text-primary-2 hover:underline" href={`/alertas?alerta=${a.id}#detalhe`}>{a.title}</Link><span className="block text-xs text-muted">Tarefa: <Link className="underline" href={`/tarefas#t-${a.taskId}`}>{taskTitle}</Link></span></Td>
                    <Td>{recipient}</Td>
                    <Td>{chips(a)}</Td>
                    <Td>
                      <Badge tone={STATUS_TONE[a.status as AlertStatus]}>{STATUS_LABEL[a.status as AlertStatus]}</Badge>
                      <span className="mt-1 block text-[11px] leading-4 text-muted">
                        {a.scheduledAt && a.status === "scheduled" && <>agendado p/ {dt(a.scheduledAt)}<br /></>}
                        {a.sentAt && <>enviado {dt(a.sentAt)}<br /></>}{a.deliveredAt && <>entregue {dt(a.deliveredAt)}<br /></>}{a.readAt && <>lido {dt(a.readAt)}<br /></>}{a.respondedAt && <>respondido {dt(a.respondedAt)}</>}
                        {a.failureReason && <span className="text-danger">{a.failureReason}</span>}
                      </span>
                    </Td>
                    <Td><span className="text-xs">{KIND_LABEL[a.kind]}{a.escalationLevel ? ` ${a.escalationLevel}` : ""}</span>{a.messageOrigin !== "manual" && <span className="block text-[11px] text-muted">{a.messageOrigin === "flavio" ? "Flávio" : "Flávio + edição"}{a.simulated ? " (simulado)" : ""}</span>}</Td>
                    <Td><AlertRowActions id={a.id} status={a.status} /></Td>
                  </tr>
                ))}
              </Table>
            ) : <Empty title="Nenhum alerta com estes filtros">Gere um alerta no botão “Gerar alerta” da tabela em <Link className="underline" href="/tarefas">Tarefas &amp; Metas</Link>.</Empty>}
          </Card>

          <Card>
            <div id="prorrogacoes" />
            <CardTitle sub="O Flávio recomenda com fatos e inferências separados; a decisão é sempre sua. Nada muda de prazo sozinho.">Solicitações de prorrogação</CardTitle>
            {pendingExt.length ? (
              <ul className="space-y-4">
                {pendingExt.map(({ r, taskTitle, taskPriority, requester }) => (
                  <li key={r.id} className="rounded-xl border border-line p-3 text-sm">
                    <p className="font-medium">{taskTitle} <span className="text-xs font-normal text-muted">· prioridade {taskPriority} · {requester}</span></p>
                    <p className="text-xs text-muted">Prazo atual {dt(r.currentDueAt)} → solicitado {dt(r.requestedDueAt)}</p>
                    <p className="mt-1">{r.justification}</p>
                    {(r.blockers || r.impact) && <p className="text-xs text-muted">{r.blockers && <>Impedimentos: {r.blockers}. </>}{r.impact && <>Impacto: {r.impact}.</>}</p>}
                    <ExtensionDecision id={r.id} recommendation={(r.recommendation as Recommendation | null) ?? null} />
                  </li>
                ))}
              </ul>
            ) : <Empty title="Nenhuma solicitação pendente" />}
          </Card>

          {intel && (
            <Card>
              <CardTitle sub={`Últimos ${intel.period.days} dias · fatos, inferências, estimativas e recomendações ficam separados`}>Inteligência de execução (Flávio)</CardTitle>
              <div className="grid gap-5 lg:grid-cols-2">
                <div>
                  <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted">Fatos</p>
                  <div className="grid grid-cols-2 gap-2">
                    <Stat label="Tarefas abertas" value={num(intel.facts.openTasks, o.locale)} /><Stat label="Atrasadas" value={num(intel.facts.overdueTasks, o.locale)} />
                    <Stat label="Bloqueadas (declarado)" value={num(intel.facts.blockedTasks, o.locale)} /><Stat label="Sem atualização há 7 dias" value={num(intel.facts.tasksWithoutUpdate7d, o.locale)} />
                  </div>
                  <ul className="mt-3 space-y-1 text-xs text-muted">
                    {Object.entries(intel.facts.overdueByTeam).map(([team, n]) => <li key={team}>Atrasadas — {team}: <span className="text-fg">{n}</span></li>)}
                    {Object.entries(intel.facts.responsesByKind).map(([k, n]) => <li key={k}>{RESPONSE_LABEL[k as ResponseKind] ?? k}: <span className="text-fg">{n}</span></li>)}
                    <li>Do 1º alerta à conclusão: {intel.facts.hoursFromFirstAlertToCompletion.n ? `média ${intel.facts.hoursFromFirstAlertToCompletion.average} h (mediana ${intel.facts.hoursFromFirstAlertToCompletion.median} h, ${intel.facts.hoursFromFirstAlertToCompletion.n} tarefas)` : "amostra insuficiente"}</li>
                    {intel.facts.workloadSignals.map((w, i) => <li key={i}>Carga: {w.name} ({w.team}) tem {w.openTasks} tarefas abertas (mediana {w.teamMedian}) — sinal de distribuição, não de desempenho</li>)}
                  </ul>
                </div>
                <div className="space-y-4">
                  <div><p className="mb-1 text-xs font-semibold uppercase tracking-wide text-muted">Inferências (hipóteses)</p>{intel.inferences.length ? <ul className="list-disc space-y-1 pl-4 text-sm">{intel.inferences.map((t, i) => <li key={i}>{t}</li>)}</ul> : <p className="text-xs text-muted">Sem inferências com os dados atuais.</p>}</div>
                  <div><p className="mb-1 text-xs font-semibold uppercase tracking-wide text-muted">Recomendações</p>{intel.recommendations.length ? <ul className="list-disc space-y-1 pl-4 text-sm">{intel.recommendations.map((t, i) => <li key={i}>{t}</li>)}</ul> : <p className="text-xs text-muted">Nenhuma no momento.</p>}</div>
                  <div className="rounded-lg border border-line bg-bg-2/60 p-2.5"><p className="mb-1 text-xs font-semibold text-muted">Ressalvas</p><ul className="list-disc space-y-0.5 pl-4 text-[11px] text-muted">{intel.caveats.map((t, i) => <li key={i}>{t}</li>)}</ul></div>
                </div>
              </div>
            </Card>
          )}
        </>
      )}

      {admin && (
        <div className="grid gap-5 lg:grid-cols-[1fr_380px]">
          <Card>
            <CardTitle sub="Sem regras, nada é enviado automaticamente. Lembretes respeitam horário, limite e intervalo mínimo; o escalonamento para sozinho quando há resposta ou atualização." action={<RunAutomationButton />}>Automação e escalonamento</CardTitle>
            <RulesManager rules={rules as unknown as RuleRow[]} users={orgUsers} triggers={TRIGGER_LABEL} />
          </Card>
          <Card><CardTitle sub="Estilo das mensagens geradas pelo Flávio e dos lembretes automáticos">Modo de comunicação</CardTitle>{tone && <ToneForm tone={tone.tone} customTone={tone.customTone} />}</Card>
        </div>
      )}
    </div>
  );
}
