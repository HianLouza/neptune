import { requirePageContext } from "@/server/auth/next";
import { buildReport, reportQuery } from "@/server/domains/reporting";
import { METRIC_CATALOG } from "@/server/domains/data-intelligence";
import { Card, CardTitle, Empty, PageHeader, Table, Td, Badge } from "@/components/ui";
import { AiSummary, ReportControls } from "@/components/intelligence/report-controls";
import { date } from "@/lib/format";

export const metadata = { title: "Relatórios" };

export default async function RelatoriosPage({ searchParams }: { searchParams: Promise<{ tipo?: string; periodo?: string }> }) {
  const ctx = await requirePageContext("intelligence:read");
  const sp = await searchParams;
  const parsed = reportQuery.safeParse({ type: sp.tipo, days: sp.periodo });
  const q = parsed.success ? parsed.data : { type: "executive" as const, days: 30 };
  const report = await buildReport(ctx, q.type, q.days);
  const canAi = ctx.permissions.includes("*") || ctx.permissions.includes("ai:use");

  return (
    <div className="mx-auto max-w-[1400px] space-y-5">
      <PageHeader title="Relatórios" subtitle="Relatórios gerenciais com métricas de definição canônica. Exporte em CSV ou imprima/salve em PDF." actions={<ReportControls type={q.type} days={q.days} />} />

      <Card className="print:border-0 print:bg-white print:text-black print:shadow-none">
        <CardTitle sub={`Gerado em ${date(report.generatedAt, { locale: ctx.locale, timezone: ctx.timezone }, true)} · ORBITY-NEPTUNE`}>{report.title}</CardTitle>
        {report.rows.length ? (
          <Table head={report.columns}>
            {report.rows.map((r, i) => <tr key={i}>{r.map((c, j) => <Td key={j}>{c}</Td>)}</tr>)}
          </Table>
        ) : <Empty title="Sem dados para este relatório no período selecionado" />}
        {report.notes.length > 0 && (
          <div className="mt-4">
            <p className="text-xs font-semibold text-muted">Observações</p>
            <ul className="mt-1 list-disc space-y-1 pl-5 text-xs text-muted">{report.notes.map((n) => <li key={n}>{n}</li>)}</ul>
          </div>
        )}
        {canAi && <div className="mt-5 border-t border-line pt-4"><AiSummary type={q.type} days={q.days} /></div>}
      </Card>

      <Card className="print:hidden">
        <CardTitle sub="Definições consistentes usadas por todos os módulos (Data Intelligence)">Catálogo de métricas</CardTitle>
        <Table head={["ID", "Métrica", "Descrição", "Fórmula", "Fonte", "Dimensões", "Periodicidade", "Responsável"]}>
          {METRIC_CATALOG.map((m) => (
            <tr key={m.key}>
              <Td><code className="text-xs">{m.key}</code></Td>
              <Td className="font-medium">{m.name}</Td>
              <Td className="max-w-xs text-xs text-muted">{m.description}</Td>
              <Td><code className="text-[11px]">{m.formula}</code></Td>
              <Td>{m.source}</Td>
              <Td><div className="flex flex-wrap gap-1">{m.dimensions.map((d) => <Badge key={d}>{d}</Badge>)}</div></Td>
              <Td>{m.periodicity}</Td>
              <Td>{m.owner}</Td>
            </tr>
          ))}
        </Table>
      </Card>
    </div>
  );
}
