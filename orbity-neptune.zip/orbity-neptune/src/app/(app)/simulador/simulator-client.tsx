"use client";
import { useMemo, useState } from "react";
import { Badge, Button, Card, CardTitle, Empty, Field, Input, Select, Table, Td, cx } from "@/components/ui";
import { Feedback, useAction } from "@/components/ui/use-action";
import { simulate, type Baseline, type SimulationResult, type Variables, type MonthSummary } from "@/server/domains/strategy/model";
import type { Evidence } from "@/server/db/schema";

type Saved = {
  id: string; name: string; kind: string; status: string; createdBy: string; createdByName: string; approvedByName: string | null;
  createdAt: string; approvedAt: string | null; results: SimulationResult & { revenueSource?: string }; variables: Record<string, number>;
};

const KINDS: [string, string][] = [
  ["price", "Preço"], ["cost", "Custos"], ["hiring", "Contratação"], ["volume", "Volume"], ["conversion", "Conversão"],
  ["marketing", "Marketing"], ["churn", "Perda de clientes"], ["reorganization", "Reorganização (análise)"], ["custom", "Personalizado"],
];
const STATUS: Record<string, [string, "neutral" | "warning" | "success" | "danger"]> = {
  draft: ["Rascunho", "neutral"], submitted: ["Aguardando aprovação", "warning"], approved: ["Aprovado", "success"], rejected: ["Rejeitado", "danger"],
};

type Form = {
  priceChangePct: number; elasticity: number; volumeChangePct: number; conversionChangePct: number; variableCostChangePct: number;
  fixedCostChangePct: number; newHires: number; costPerHire: string; marketing: string; leadsPerThousand: string; churnChangePct: number;
  uncertaintyPct: number; initialCash: string; fixedOverride: string; variableOverride: string;
};
const EMPTY: Form = {
  priceChangePct: 0, elasticity: -0.5, volumeChangePct: 0, conversionChangePct: 0, variableCostChangePct: 0, fixedCostChangePct: 0,
  newHires: 0, costPerHire: "", marketing: "", leadsPerThousand: "", churnChangePct: 0, uncertaintyPct: 10, initialCash: "", fixedOverride: "", variableOverride: "",
};
const toCents = (reais: string) => (reais.trim() === "" ? null : Math.round(Number(reais.replace(",", ".")) * 100));

function toVariables(f: Form): Partial<Variables> {
  return {
    priceChangePct: f.priceChangePct, elasticity: f.elasticity, volumeChangePct: f.volumeChangePct, conversionChangePct: f.conversionChangePct,
    variableCostChangePct: f.variableCostChangePct, fixedCostChangePct: f.fixedCostChangePct, newHires: f.newHires,
    monthlyCostPerHireCents: toCents(f.costPerHire), marketingSpendCents: toCents(f.marketing) ?? 0,
    leadsPerThousand: f.leadsPerThousand.trim() === "" ? null : Number(f.leadsPerThousand), churnChangePct: f.churnChangePct,
    uncertaintyPct: f.uncertaintyPct, initialCashCents: toCents(f.initialCash),
    fixedCostsCentsOverride: toCents(f.fixedOverride), variableCostsCentsOverride: toCents(f.variableOverride),
  };
}

export function SimulatorClient({ baseline, evidence, financeConnected, saved, me, canWrite, canApprove, locale, currency }: {
  baseline: Baseline; evidence: Evidence; financeConnected: boolean; saved: Saved[]; me: string; canWrite: boolean; canApprove: boolean; locale: string; currency: string;
}) {
  const [f, setF] = useState<Form>(EMPTY);
  const set = <K extends keyof Form>(k: K, v: Form[K]) => setF((p) => ({ ...p, [k]: v }));
  const money = (c: number | null | undefined) => (c == null ? "—" : new Intl.NumberFormat(locale, { style: "currency", currency, maximumFractionDigits: 0 }).format(c / 100));
  const signed = (c: number) => `${c > 0 ? "+" : ""}${money(c)}`;

  const sim = useMemo(() => {
    try { return { ok: true as const, r: simulate(baseline, toVariables(f)) }; }
    catch (e) { return { ok: false as const, error: (e as Error).message }; }
  }, [baseline, f]);

  const presets: [string, Partial<Form>][] = [
    ["E se eu aumentar o preço em 10%?", { priceChangePct: 10 }],
    ["Reduzir custos fixos em 10%", { fixedCostChangePct: -10 }],
    ["Contratar 3 pessoas", { newHires: 3 }],
    ["Investir R$ 10 mil em marketing", { marketing: "10000" }],
    ["Perder 5% dos clientes", { churnChangePct: 5 }],
    ["Reduzir a equipe em 2 pessoas (análise)", { newHires: -2 }],
  ];
  const confidence = evidence.confidence >= 0.75 ? "alta" : evidence.confidence >= 0.5 ? "média" : evidence.confidence > 0 ? "baixa" : "insuficiente";

  return (
    <div className="space-y-4">
      <Card>
        <CardTitle sub={`Fonte da receita: ${baseline.revenueSource === "finance" ? "Financeiro (recebimentos)" : "CRM (oportunidades ganhas)"} · confiança ${confidence}`}>Base atual (mês típico)</CardTitle>
        <div className="grid grid-cols-2 gap-3 text-sm md:grid-cols-4 xl:grid-cols-7">
          <Kpi label="Receita/mês" value={money(baseline.revenueCents)} />
          <Kpi label="Leads/mês" value={baseline.leadsPerMonth.toLocaleString(locale)} />
          <Kpi label="Vendas/mês" value={baseline.dealsPerMonth.toLocaleString(locale)} />
          <Kpi label="Conversão lead→venda" value={`${(baseline.conversionRate * 100).toLocaleString(locale, { maximumFractionDigits: 1 })}%`} />
          <Kpi label="Ticket médio" value={money(baseline.avgTicketCents)} />
          <Kpi label="Custos variáveis/mês" value={baseline.variableCostsCents == null ? "Informe abaixo" : money(baseline.variableCostsCents)} />
          <Kpi label="Custos fixos/mês" value={baseline.fixedCostsCents == null ? "Informe abaixo" : money(baseline.fixedCostsCents)} />
        </div>
        {!financeConnected && (
          <p className="mt-3 text-xs text-warning">Sem lançamentos financeiros: informe custos fixos e variáveis mensais para simular. O simulador não estima despesas por conta própria.</p>
        )}
      </Card>

      <div className="grid gap-4 xl:grid-cols-[minmax(0,1fr)_minmax(0,1.5fr)]">
        <Card>
          <CardTitle sub="Altere as variáveis: o resultado é recalculado na hora.">Construtor de simulação</CardTitle>
          <div className="mb-3 flex flex-wrap gap-2">
            {presets.map(([label, p]) => (
              <button key={label} onClick={() => setF({ ...EMPTY, ...p, fixedOverride: f.fixedOverride, variableOverride: f.variableOverride, costPerHire: f.costPerHire, leadsPerThousand: f.leadsPerThousand })}
                className="rounded-full border border-line px-3 py-1 text-xs hover:border-primary-2">{label}</button>
            ))}
            <button onClick={() => setF({ ...EMPTY, fixedOverride: f.fixedOverride, variableOverride: f.variableOverride })} className="rounded-full border border-line px-3 py-1 text-xs text-muted hover:text-fg">Limpar</button>
          </div>
          <div className="space-y-3">
            <Slider id="price" label="Preço" value={f.priceChangePct} min={-50} max={50} onChange={(v) => set("priceChangePct", v)} />
            <Slider id="volume" label="Volume de vendas" value={f.volumeChangePct} min={-50} max={100} onChange={(v) => set("volumeChangePct", v)} />
            <Slider id="conversion" label="Conversão" value={f.conversionChangePct} min={-50} max={100} onChange={(v) => set("conversionChangePct", v)} />
            <Slider id="varcost" label="Custos variáveis" value={f.variableCostChangePct} min={-50} max={50} onChange={(v) => set("variableCostChangePct", v)} />
            <Slider id="fixcost" label="Custos fixos" value={f.fixedCostChangePct} min={-50} max={50} onChange={(v) => set("fixedCostChangePct", v)} />
            <Slider id="churn" label="Perda de clientes" value={f.churnChangePct} min={-20} max={30} onChange={(v) => set("churnChangePct", v)} />
            <div className="grid grid-cols-2 gap-3">
              <Field label="Contratações (negativo = redução)"><Input type="number" value={f.newHires} onChange={(e) => set("newHires", Number(e.target.value))} aria-label="Contratações" /></Field>
              <Field label="Custo mensal por pessoa (R$)"><Input inputMode="decimal" value={f.costPerHire} onChange={(e) => set("costPerHire", e.target.value)} aria-label="Custo mensal por pessoa" /></Field>
              <Field label="Marketing extra/mês (R$)"><Input inputMode="decimal" value={f.marketing} onChange={(e) => set("marketing", e.target.value)} aria-label="Marketing extra por mês" /></Field>
              <Field label="Leads a cada R$ 1.000" hint="Do seu histórico de campanhas"><Input inputMode="decimal" value={f.leadsPerThousand} onChange={(e) => set("leadsPerThousand", e.target.value)} aria-label="Leads a cada mil reais" /></Field>
              <Field label="Elasticidade-preço" hint="Premissa: -0,5 = +1% de preço, -0,5% de volume"><Input type="number" step="0.1" max={0} min={-5} value={f.elasticity} onChange={(e) => set("elasticity", Number(e.target.value))} aria-label="Elasticidade" /></Field>
              <Field label="Incerteza (± % volume)"><Input type="number" min={0} max={80} value={f.uncertaintyPct} onChange={(e) => set("uncertaintyPct", Number(e.target.value))} aria-label="Incerteza" /></Field>
              <Field label="Saldo de caixa inicial (R$)" hint="Opcional"><Input inputMode="decimal" value={f.initialCash} onChange={(e) => set("initialCash", e.target.value)} aria-label="Saldo de caixa inicial" /></Field>
            </div>
            <details open={baseline.fixedCostsCents == null} className="rounded-xl border border-line p-3">
              <summary className="cursor-pointer text-sm font-medium">Custos da base {baseline.fixedCostsCents == null && <Badge tone="warning">obrigatório</Badge>}</summary>
              <div className="mt-3 grid grid-cols-2 gap-3">
                <Field label="Custos fixos mensais (R$)"><Input inputMode="decimal" value={f.fixedOverride} placeholder={baseline.fixedCostsCents == null ? "Informe" : String(baseline.fixedCostsCents / 100)} onChange={(e) => set("fixedOverride", e.target.value)} aria-label="Custos fixos mensais" /></Field>
                <Field label="Custos variáveis mensais (R$)"><Input inputMode="decimal" value={f.variableOverride} placeholder={baseline.variableCostsCents == null ? "Informe" : String(baseline.variableCostsCents / 100)} onChange={(e) => set("variableOverride", e.target.value)} aria-label="Custos variáveis mensais" /></Field>
              </div>
            </details>
          </div>
        </Card>

        <div className="space-y-4">
          {!sim.ok ? (
            <Card><Empty title="Faltam dados para simular">{sim.error}</Empty></Card>
          ) : (
            <Results r={sim.r} money={money} signed={signed} />
          )}
        </div>
      </div>

      <div className="grid gap-4 xl:grid-cols-2">
        <Card>
          <CardTitle sub="De onde vêm os números e o que foi assumido.">Premissas e fontes</CardTitle>
          <ul className="space-y-1 text-sm">
            {evidence.facts.map((x, i) => <li key={i}><b>{x.label}:</b> {x.source}{x.period ? ` · ${x.period}` : ""}</li>)}
          </ul>
          <p className="mt-3 text-xs font-semibold uppercase text-muted">Cálculos</p>
          <ul className="list-disc pl-5 text-xs text-muted">{evidence.calculations.map((x, i) => <li key={i}>{x}</li>)}</ul>
          <p className="mt-3 text-xs font-semibold uppercase text-muted">Premissas desta simulação</p>
          <ul className="list-disc pl-5 text-xs text-muted">{(sim.ok ? sim.r.assumptions : evidence.assumptions).map((x, i) => <li key={i}>{x}</li>)}</ul>
          {evidence.missingData.length > 0 && <><p className="mt-3 text-xs font-semibold uppercase text-warning">Dados ausentes</p><ul className="list-disc pl-5 text-xs text-warning">{evidence.missingData.map((x, i) => <li key={i}>{x}</li>)}</ul></>}
          <p className="mt-3 text-xs font-semibold uppercase text-muted">Limitações</p>
          <ul className="list-disc pl-5 text-xs text-muted">{evidence.limitations.map((x, i) => <li key={i}>{x}</li>)}</ul>
        </Card>
        <SaveAndHistory saved={saved} me={me} canWrite={canWrite} canApprove={canApprove} variables={toVariables(f)} simOk={sim.ok} money={money} signed={signed} locale={locale} />
      </div>
    </div>
  );
}

function Kpi({ label, value }: { label: string; value: string }) {
  return <div className="rounded-xl border border-line bg-bg-2/60 p-3"><p className="text-xs text-muted">{label}</p><p className="mt-1 font-semibold tabular-nums">{value}</p></div>;
}

function Slider({ id, label, value, min, max, onChange }: { id: string; label: string; value: number; min: number; max: number; onChange: (v: number) => void }) {
  return (
    <div className="grid grid-cols-[9rem_minmax(0,1fr)_4.5rem] items-center gap-3 text-sm">
      <label htmlFor={`sl-${id}`}>{label}</label>
      <input id={`sl-${id}`} type="range" min={min} max={max} step={1} value={value} onChange={(e) => onChange(Number(e.target.value))} className="accent-[var(--primary-2)]" />
      <Input type="number" value={value} min={min * 4} max={max * 4} onChange={(e) => onChange(Number(e.target.value))} aria-label={`${label} (%)`} className="py-1 text-right" />
    </div>
  );
}

function ScenarioCard({ title, s, highlight, money }: { title: string; s: MonthSummary; highlight?: boolean; money: (c: number | null) => string }) {
  return (
    <div className={cx("rounded-xl border p-3 text-sm", highlight ? "border-primary-2 bg-primary/10" : "border-line bg-bg-2/60")}>
      <p className="text-xs font-semibold uppercase text-muted">{title}</p>
      <p className={cx("mt-1 text-lg font-bold tabular-nums", s.resultCents < 0 ? "text-danger" : "")}>{money(s.resultCents)}</p>
      <p className="text-xs text-muted">resultado/mês</p>
      <dl className="mt-2 grid grid-cols-2 gap-x-2 text-xs tabular-nums">
        <dt className="text-muted">Receita</dt><dd className="text-right">{money(s.revenueCents)}</dd>
        <dt className="text-muted">Custos var.</dt><dd className="text-right">{money(s.variableCostsCents)}</dd>
        <dt className="text-muted">Custos fixos</dt><dd className="text-right">{money(s.fixedCostsCents)}</dd>
        <dt className="text-muted">Margem</dt><dd className="text-right">{s.marginPct == null ? "—" : `${s.marginPct}%`}</dd>
        <dt className="text-muted">Equilíbrio</dt><dd className="text-right">{money(s.breakEvenRevenueCents)}</dd>
      </dl>
    </div>
  );
}

function Results({ r, money, signed }: { r: SimulationResult; money: (c: number | null) => string; signed: (c: number) => string }) {
  const maxAbs = Math.max(1, ...r.projection.map((p) => Math.abs(p.cumulativeCashCents)));
  return (
    <>
      <Card>
        <CardTitle sub={`Impacto no resultado mensal: ${signed(r.delta.resultCents)}${r.delta.marginPp != null ? ` · margem ${r.delta.marginPp > 0 ? "+" : ""}${r.delta.marginPp} p.p.` : ""}`}>Resultado</CardTitle>
        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
          <ScenarioCard title="Hoje" s={r.current} money={money} />
          <ScenarioCard title="Pessimista" s={r.scenarios.pessimista} money={money} />
          <ScenarioCard title="Base (sua simulação)" s={r.scenarios.base} money={money} highlight />
          <ScenarioCard title="Otimista" s={r.scenarios.otimista} money={money} />
        </div>
        {r.notes.map((n, i) => <p key={i} className="mt-3 rounded-lg border border-warning/30 bg-warning/10 px-3 py-2 text-xs text-warning">{n}</p>)}
        <p className="mt-3 text-xs text-muted">Projeção de análise. Não é previsão garantida nem substitui análise contábil ou fiscal.</p>
      </Card>
      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardTitle sub="Variação acumulada de caixa no cenário base">Projeção de 12 meses</CardTitle>
          <div className="flex h-36 items-end gap-1" role="img" aria-label="Caixa acumulado por mês">
            {r.projection.map((p) => (
              <div key={p.month} className="flex flex-1 flex-col items-center justify-end gap-1" title={`Mês ${p.month}: ${money(p.cumulativeCashCents)}`}>
                <div className={cx("w-full rounded-t", p.cumulativeCashCents >= 0 ? "bg-primary-2/70" : "bg-danger/70")} style={{ height: `${Math.max(2, (Math.abs(p.cumulativeCashCents) / maxAbs) * 100)}%` }} />
                <span className="text-[10px] text-muted">{p.month}</span>
              </div>
            ))}
          </div>
          <p className="mt-2 text-xs text-muted">Mês 12: {money(r.projection[11].cumulativeCashCents)}</p>
        </Card>
        <Card>
          <CardTitle sub="Efeito isolado de cada variável no resultado mensal">Sensibilidade</CardTitle>
          <Table head={["Variável", "Mudança", "Resultado"]}>
            {r.sensitivity.map((s) => (
              <tr key={s.variable} className="border-t border-line"><Td>{s.label}</Td><Td>{s.change}</Td><Td className="tabular-nums">{signed(s.resultDeltaCents)}</Td></tr>
            ))}
          </Table>
          {r.contributions.length > 0 && (
            <>
              <p className="mt-3 text-xs font-semibold uppercase text-muted">Contribuição das suas mudanças</p>
              <ul className="text-xs">{r.contributions.map((c) => <li key={c.variable} className="flex justify-between"><span>{c.label}</span><span className="tabular-nums">{signed(c.resultDeltaCents)}</span></li>)}</ul>
            </>
          )}
        </Card>
      </div>
    </>
  );
}

function SaveAndHistory({ saved, me, canWrite, canApprove, variables, simOk, money, signed, locale }: {
  saved: Saved[]; me: string; canWrite: boolean; canApprove: boolean; variables: Partial<Variables>; simOk: boolean;
  money: (c: number | null) => string; signed: (c: number) => string; locale: string;
}) {
  const { run, loading, error, message } = useAction();
  const [name, setName] = useState("");
  const [kind, setKind] = useState("custom");
  const [compare, setCompare] = useState<string[]>([]);
  const toggle = (id: string) => setCompare((c) => (c.includes(id) ? c.filter((x) => x !== id) : [...c, id].slice(-3)));
  const chosen = saved.filter((s) => compare.includes(s.id));

  return (
    <Card>
      <CardTitle sub="Cenários salvos guardam premissas, responsável e aprovação.">Cenários</CardTitle>
      {canWrite ? (
        <div className="flex flex-wrap items-end gap-2">
          <Field label="Nome do cenário"><Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Ex.: Reajuste de 10% em janeiro" aria-label="Nome do cenário" /></Field>
          <Field label="Tipo"><Select value={kind} onChange={(e) => setKind(e.target.value)} aria-label="Tipo do cenário">{KINDS.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</Select></Field>
          <Button onClick={async () => { if (await run("/api/strategy/scenarios", { name, kind, variables }, { success: "Cenário salvo." })) setName(""); }} disabled={loading || !simOk || name.trim().length < 3}>Salvar cenário</Button>
        </div>
      ) : <p className="text-xs text-muted">Você pode simular, mas salvar cenários exige permissão de estratégia.</p>}
      <Feedback error={error} message={message} />

      {saved.length === 0 ? <div className="mt-3"><Empty title="Nenhum cenário salvo">Salve uma simulação para compará-la e enviá-la para aprovação.</Empty></div> : (
        <ul className="mt-3 space-y-2">
          {saved.map((s) => {
            const [label, tone] = STATUS[s.status] ?? [s.status, "neutral"];
            const base = s.results.scenarios.base;
            return (
              <li key={s.id} className="rounded-xl border border-line bg-bg-2/60 p-3 text-sm">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <label className="flex items-center gap-2">
                    <input type="checkbox" checked={compare.includes(s.id)} onChange={() => toggle(s.id)} aria-label={`Comparar ${s.name}`} />
                    <span className="font-medium">{s.name}</span>
                  </label>
                  <Badge tone={tone}>{label}</Badge>
                </div>
                <p className="mt-1 text-xs text-muted">
                  {KINDS.find(([k]) => k === s.kind)?.[1] ?? s.kind} · por {s.createdByName} em {new Date(s.createdAt).toLocaleDateString(locale)}
                  {s.approvedByName ? ` · ${s.status === "approved" ? "aprovado" : "decidido"} por ${s.approvedByName}` : ""}
                </p>
                <p className="text-xs">Resultado/mês: {money(base.resultCents)} ({signed(s.results.delta.resultCents)} vs. base)</p>
                <div className="mt-2 flex flex-wrap gap-2">
                  {canWrite && (s.status === "draft" || s.status === "rejected") && (
                    <Button size="sm" variant="secondary" disabled={loading} onClick={() => run(`/api/strategy/scenarios/${s.id}`, { action: "submit" }, { method: "PATCH", success: "Enviado para aprovação." })}>Enviar para aprovação</Button>
                  )}
                  {s.status === "submitted" && canApprove && s.createdBy !== me && (
                    <>
                      <Button size="sm" disabled={loading} onClick={() => run(`/api/strategy/scenarios/${s.id}`, { action: "approve" }, { method: "PATCH", success: "Cenário aprovado." })}>Aprovar</Button>
                      <Button size="sm" variant="ghost" disabled={loading} onClick={() => run(`/api/strategy/scenarios/${s.id}`, { action: "reject" }, { method: "PATCH", success: "Cenário rejeitado." })}>Rejeitar</Button>
                    </>
                  )}
                  {s.status === "submitted" && s.createdBy === me && <span className="text-xs text-muted">Aguardando outra pessoa aprovar (quem cria não aprova).</span>}
                </div>
              </li>
            );
          })}
        </ul>
      )}

      {chosen.length >= 2 && (
        <div className="mt-4 overflow-x-auto">
          <p className="mb-2 text-xs font-semibold uppercase text-muted">Comparação</p>
          <Table head={["", ...chosen.map((c) => c.name)]}>
            {([["Receita/mês", (s: Saved) => money(s.results.scenarios.base.revenueCents)], ["Resultado/mês", (s: Saved) => money(s.results.scenarios.base.resultCents)],
              ["Margem", (s: Saved) => (s.results.scenarios.base.marginPct == null ? "—" : `${s.results.scenarios.base.marginPct}%`)],
              ["Equilíbrio", (s: Saved) => money(s.results.scenarios.base.breakEvenRevenueCents)], ["Caixa em 12 meses", (s: Saved) => money(s.results.projection[11]?.cumulativeCashCents ?? null)],
              ["Status", (s: Saved) => STATUS[s.status]?.[0] ?? s.status]] as [string, (s: Saved) => string][]).map(([label, fn]) => (
              <tr key={label} className="border-t border-line"><Td className="text-muted">{label}</Td>{chosen.map((c) => <Td key={c.id} className="tabular-nums">{fn(c)}</Td>)}</tr>
            ))}
          </Table>
        </div>
      )}
    </Card>
  );
}
