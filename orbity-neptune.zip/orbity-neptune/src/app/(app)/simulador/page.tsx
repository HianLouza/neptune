import { requirePageContext } from "@/server/auth/next";
import { buildBaseline, listScenarios } from "@/server/domains/strategy";
import { can } from "@/server/tenancy/context";
import { PageHeader } from "@/components/ui";
import { SimulatorClient } from "./simulator-client";

export const metadata = { title: "Simulador Estratégico" };

export default async function SimuladorPage() {
  const ctx = await requirePageContext("strategy:read");
  const [{ baseline, evidence, financeConnected }, saved] = await Promise.all([buildBaseline(ctx), listScenarios(ctx)]);
  return (
    <div className="mx-auto max-w-[1500px] space-y-5">
      <PageHeader
        title="Simulador Estratégico"
        subtitle="Teste decisões antes de tomá-las: preço, custos, contratações, marketing e perda de clientes, sobre a base real da sua empresa."
      />
      <SimulatorClient
        baseline={baseline}
        evidence={evidence}
        financeConnected={financeConnected}
        saved={JSON.parse(JSON.stringify(saved))}
        me={ctx.userId}
        canWrite={can(ctx, "strategy:write")}
        canApprove={can(ctx, "approvals:decide")}
        locale={ctx.locale}
        currency={ctx.currency}
      />
    </div>
  );
}
