import Link from "next/link";
import { requirePageContext } from "@/server/auth/next";
import { kanban, listCompanies, listContacts, getCompany, getContact, staleCount, STALE_DAYS } from "@/server/domains/crm/queries";
import { Badge, Card, CardTitle, Empty, Input, PageHeader, Table, Td, Button, cx } from "@/components/ui";
import { Kanban, type Column } from "@/components/crm/kanban";
import { OpportunityForm, CompanyForm, ContactForm } from "@/components/crm/forms";
import { num } from "@/lib/format";

export const metadata = { title: "CRM" };

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const LEGAL: Record<string, string> = { legitimo_interesse: "Legítimo interesse", consentimento: "Consentimento", execucao_contrato: "Execução de contrato" };

type SP = { aba?: string; etapa?: string; filtro?: string; empresa?: string; contato?: string; q?: string };

export default async function CrmPage({ searchParams }: { searchParams: Promise<SP> }) {
  const ctx = await requirePageContext("crm:read");
  const sp = await searchParams;
  const canWrite = ctx.permissions.includes("*") || ctx.permissions.includes("crm:write");
  const empresa = sp.empresa && UUID.test(sp.empresa) ? sp.empresa : undefined;
  const contato = sp.contato && UUID.test(sp.contato) ? sp.contato : undefined;
  const tab = empresa ? "empresas" : contato ? "contatos" : ["empresas", "contatos"].includes(sp.aba ?? "") ? sp.aba! : "pipeline";
  const etapa = sp.etapa && UUID.test(sp.etapa) ? sp.etapa : undefined;
  const stale = sp.filtro === "paradas";
  const q = sp.q?.trim().slice(0, 80) || undefined;

  const tabs = [{ key: "pipeline", label: "Pipeline" }, { key: "empresas", label: "Empresas" }, { key: "contatos", label: "Contatos" }];
  const tabLink = (k: string) => (k === "pipeline" ? "/crm" : `/crm?aba=${k}`);

  return (
    <div className="mx-auto max-w-[1600px]">
      <PageHeader title="CRM" subtitle="Cadastro central compartilhado: empresas, contatos, oportunidades e funil." />
      <nav className="mb-5 flex gap-1 border-b border-line" aria-label="Seções do CRM">
        {tabs.map((t) => (
          <Link key={t.key} href={tabLink(t.key)} className={cx("-mb-px border-b-2 px-4 py-2 text-sm", tab === t.key ? "border-primary-2 font-semibold text-fg" : "border-transparent text-muted hover:text-fg")}>{t.label}</Link>
        ))}
      </nav>
      {tab === "pipeline" && <PipelineView ctx={ctx} canWrite={canWrite} etapa={etapa} stale={stale} q={q} />}
      {tab === "empresas" && <CompaniesView ctx={ctx} canWrite={canWrite} q={q} highlight={empresa} />}
      {tab === "contatos" && <ContactsView ctx={ctx} canWrite={canWrite} q={q} highlight={contato} />}
    </div>
  );
}

type Ctx = Awaited<ReturnType<typeof requirePageContext>>;

async function PipelineView({ ctx, canWrite, etapa, stale, q }: { ctx: Ctx; canWrite: boolean; etapa?: string; stale: boolean; q?: string }) {
  const [board, staleN] = await Promise.all([kanban(ctx, { stageId: etapa, stale, q, perStage: etapa ? 100 : 20 }), staleCount(ctx)]);
  const columns: Column[] = board.columns.map((c) => ({ ...c, items: c.items.map((i) => ({ ...i, lastActivityAt: i.lastActivityAt.toISOString() })) }));
  const openStages = board.stages.filter((s) => s.kind === "open");
  const filterStage = etapa ? board.stages.find((s) => s.id === etapa) : null;
  return (
    <div className="grid gap-5 2xl:grid-cols-[1fr_340px]">
      <Card className="min-w-0">
        <CardTitle sub={`${num(columns.reduce((a, c) => a + c.count, 0), ctx.locale)} oportunidades${filterStage ? ` em ${filterStage.name}` : ""}${stale ? ` sem atividade há +${STALE_DAYS} dias` : ""}`}>Funil de vendas</CardTitle>
        <form action="/crm" className="mb-4 flex flex-wrap items-center gap-2">
          <Input name="q" defaultValue={q ?? ""} placeholder="Buscar negócio ou empresa" className="max-w-xs" />
          {etapa && <input type="hidden" name="etapa" value={etapa} />}
          {stale && <input type="hidden" name="filtro" value="paradas" />}
          <Button type="submit" variant="secondary">Buscar</Button>
          <Link href={stale ? "/crm" : "/crm?filtro=paradas"} className={cx("inline-flex items-center rounded-lg border px-3 py-2 text-sm", stale ? "border-warning bg-warning/15 text-warning" : "border-line text-muted hover:text-fg")}>
            ⚠ Paradas há +{STALE_DAYS} dias ({num(staleN, ctx.locale)})
          </Link>
          {(etapa || stale || q) && <Link href="/crm" className="px-2 text-sm text-muted hover:text-fg">Limpar filtros</Link>}
        </form>
        {columns.length ? <Kanban columns={columns} stages={board.stages} canWrite={canWrite} locale={ctx.locale} currency={ctx.currency} staleDays={STALE_DAYS} />
          : <Empty title="Etapa não encontrada" />}
      </Card>
      {canWrite && (
        <Card className="self-start">
          <CardTitle>Nova oportunidade</CardTitle>
          <OpportunityForm stages={openStages.map((s) => ({ id: s.id, name: s.name }))} currency={ctx.currency} />
        </Card>
      )}
    </div>
  );
}

async function CompaniesView({ ctx, canWrite, q, highlight }: { ctx: Ctx; canWrite: boolean; q?: string; highlight?: string }) {
  const [list, selected] = await Promise.all([listCompanies(ctx, q, 100), highlight ? getCompany(ctx, highlight) : null]);
  const rows = selected && !list.some((c) => c.id === selected.id)
    ? [{ ...selected, contacts: 0, openDeals: 0 }, ...list] : list;
  return (
    <div className="grid gap-5 xl:grid-cols-[1fr_360px]">
      <Card className="min-w-0">
        <CardTitle sub="Deduplicadas por nome normalizado e domínio">Empresas</CardTitle>
        <form action="/crm" className="mb-4 flex gap-2"><input type="hidden" name="aba" value="empresas" /><Input name="q" defaultValue={q ?? ""} placeholder="Buscar empresa ou domínio" className="max-w-xs" /><Button type="submit" variant="secondary">Buscar</Button></form>
        {rows.length ? (
          <Table head={["Empresa", "Segmento", "Região", "Colaboradores", "Contatos", "Negócios abertos", "Origem"]}>
            {rows.map((c) => (
              <tr key={c.id} className={cx(highlight === c.id && "bg-primary/10")}>
                <Td className="font-medium">{c.name}{c.domain && <span className="block text-xs text-muted">{c.domain}</span>}</Td>
                <Td>{c.segment ?? "—"}</Td><Td>{c.region ?? "—"}</Td><Td>{c.employees ?? "—"}</Td>
                <Td>{c.contacts}</Td><Td>{c.openDeals}</Td><Td className="text-xs text-muted">{c.source ?? "—"}</Td>
              </tr>
            ))}
          </Table>
        ) : <Empty title="Nenhuma empresa encontrada" />}
      </Card>
      {canWrite && <Card className="self-start"><CardTitle>Nova empresa</CardTitle><CompanyForm /></Card>}
    </div>
  );
}

async function ContactsView({ ctx, canWrite, q, highlight }: { ctx: Ctx; canWrite: boolean; q?: string; highlight?: string }) {
  const [list, selected, companies] = await Promise.all([listContacts(ctx, q, 100), highlight ? getContact(ctx, highlight) : null, listCompanies(ctx, undefined, 200)]);
  const rows = selected && !list.some((c) => c.id === selected.c.id)
    ? [{ id: selected.c.id, name: selected.c.name, email: selected.c.email, phone: selected.c.phone, jobTitle: selected.c.jobTitle, consentStatus: selected.c.consentStatus, legalBasis: selected.c.legalBasis, companyName: selected.companyName, companyId: selected.c.companyId }, ...list]
    : list;
  return (
    <div className="grid gap-5 xl:grid-cols-[1fr_360px]">
      <Card className="min-w-0">
        <CardTitle sub="Deduplicados por e-mail · base legal LGPD registrada">Contatos</CardTitle>
        <form action="/crm" className="mb-4 flex gap-2"><input type="hidden" name="aba" value="contatos" /><Input name="q" defaultValue={q ?? ""} placeholder="Buscar nome ou e-mail" className="max-w-xs" /><Button type="submit" variant="secondary">Buscar</Button></form>
        {rows.length ? (
          <Table head={["Nome", "Empresa", "E-mail / Telefone", "Cargo", "Base legal", "Consentimento"]}>
            {rows.map((c) => (
              <tr key={c.id} className={cx(highlight === c.id && "bg-primary/10")}>
                <Td className="font-medium">{c.name}</Td>
                <Td>{c.companyId ? <Link href={`/crm?empresa=${c.companyId}`} className="hover:text-primary-2">{c.companyName}</Link> : "—"}</Td>
                <Td><span className="block">{c.email ?? "—"}</span><span className="block text-xs text-muted">{c.phone ?? ""}</span></Td>
                <Td>{c.jobTitle ?? "—"}</Td>
                <Td className="text-xs">{LEGAL[c.legalBasis ?? ""] ?? c.legalBasis ?? "—"}</Td>
                <Td><Badge tone={c.consentStatus === "granted" ? "success" : c.consentStatus === "denied" ? "danger" : "neutral"}>{c.consentStatus === "granted" ? "Concedido" : c.consentStatus === "denied" ? "Negado" : "Desconhecido"}</Badge></Td>
              </tr>
            ))}
          </Table>
        ) : <Empty title="Nenhum contato encontrado" />}
      </Card>
      {canWrite && <Card className="self-start"><CardTitle>Novo contato</CardTitle><ContactForm companies={companies.map((c) => ({ id: c.id, name: c.name }))} /></Card>}
    </div>
  );
}
