import Link from "next/link";
import { notFound } from "next/navigation";
import { and, desc, eq } from "drizzle-orm";
import { ArrowLeft } from "lucide-react";
import { requirePageContext } from "@/server/auth/next";
import { opportunityDetail, getDefaultPipeline } from "@/server/domains/crm";
import { orgMembers } from "@/server/domains/crm/queries";
import { meetings, tasks, users } from "@/server/db/schema";
import { Badge, Card, CardTitle, Empty, PageHeader, Stat } from "@/components/ui";
import { OpportunityActions } from "@/components/crm/opportunity-actions";
import { date, money } from "@/lib/format";

export const metadata = { title: "Oportunidade" };

const ACT_LABEL: Record<string, string> = { call: "Ligação", email: "E-mail", meeting: "Reunião", note: "Nota", whatsapp: "WhatsApp", follow_up: "Follow-up", stage_change: "Mudança de etapa" };
const PROP_LABEL: Record<string, string> = { draft: "Rascunho", sent: "Enviada", accepted: "Aceita", rejected: "Recusada" };

export default async function OpportunityPage({ params }: { params: Promise<{ id: string }> }) {
  const ctx = await requirePageContext("crm:read");
  const { id } = await params;
  if (!/^[0-9a-f-]{36}$/i.test(id)) notFound();
  const detail = await opportunityDetail(ctx, id).catch(() => null);
  if (!detail) notFound();
  const canWrite = ctx.permissions.includes("*") || ctx.permissions.includes("crm:write");
  const o = { locale: ctx.locale, currency: ctx.currency, timezone: ctx.timezone };
  const { opp, company, contact, stage } = detail;

  const [{ stages }, members, oppTasks, oppMeetings, [owner]] = await Promise.all([
    getDefaultPipeline(ctx),
    orgMembers(ctx),
    ctx.db.select({ t: tasks, assignee: users.name }).from(tasks).leftJoin(users, eq(users.id, tasks.assigneeId))
      .where(and(eq(tasks.organizationId, ctx.organizationId), eq(tasks.opportunityId, id))).orderBy(desc(tasks.createdAt)).limit(20),
    ctx.db.select().from(meetings).where(and(eq(meetings.organizationId, ctx.organizationId), eq(meetings.opportunityId, id))).orderBy(desc(meetings.startsAt)).limit(10),
    opp.ownerId ? ctx.db.select({ name: users.name }).from(users).where(eq(users.id, opp.ownerId)) : Promise.resolve([] as { name: string }[]),
  ]);
  const statusTone = opp.status === "won" ? "success" : opp.status === "lost" ? "danger" : "info";
  const statusLabel = opp.status === "won" ? "Ganha" : opp.status === "lost" ? "Perdida" : "Aberta";
  const idle = Math.floor((Date.now() - opp.lastActivityAt.getTime()) / 864e5);

  return (
    <div className="mx-auto max-w-[1300px]">
      <Link href="/crm" className="mb-3 inline-flex items-center gap-1 text-sm text-muted hover:text-fg"><ArrowLeft size={14} /> Voltar ao funil</Link>
      <PageHeader title={opp.title} subtitle={[company?.name, contact?.name].filter(Boolean).join(" · ") || "Sem empresa vinculada"}
        actions={<><Badge tone={statusTone}>{statusLabel}</Badge><Badge tone="primary">{stage.name}</Badge></>} />

      <div className="mb-5 grid grid-cols-2 gap-3 md:grid-cols-4">
        <Stat label="Valor" value={money(Number(opp.amountCents), o)} />
        <Stat label="Probabilidade da etapa" value={`${stage.probability}%`} hint={`Valor ponderado: ${money(Number(opp.amountCents) * stage.probability / 100, o)}`} />
        <Stat label="Previsão de fechamento" value={opp.expectedCloseDate ? date(opp.expectedCloseDate, o) : "—"} />
        <Stat label="Última atividade" value={idle === 0 ? "Hoje" : `${idle} dia(s)`} hint={idle > 5 && opp.status === "open" ? "⚠ Risco: sem atividade há mais de 5 dias" : undefined} />
      </div>

      <div className="grid gap-5 lg:grid-cols-[1fr_340px]">
        <div className="space-y-5 min-w-0">
          {canWrite && (
            <Card>
              <CardTitle>Ações</CardTitle>
              <OpportunityActions oppId={opp.id} stages={stages.map((s) => ({ id: s.id, name: s.name, kind: s.kind }))} currentStageId={opp.stageId}
                members={members} defaultAmount={Number(opp.amountCents)} currency={ctx.currency} title={opp.title} />
            </Card>
          )}
          <Card>
            <CardTitle sub="Histórico de atividades e mudanças de etapa">Linha do tempo</CardTitle>
            {detail.activities.length ? (
              <ol className="space-y-3 border-l border-line pl-4">
                {detail.activities.map(({ a, userName }) => (
                  <li key={a.id} className="relative">
                    <span className="absolute -left-[21px] top-1.5 h-2.5 w-2.5 rounded-full bg-primary-2" />
                    <p className="text-sm"><Badge className="mr-2">{ACT_LABEL[a.type] ?? a.type}</Badge>{a.subject}</p>
                    {a.body && <p className="mt-1 whitespace-pre-wrap text-xs text-muted">{a.body}</p>}
                    <p className="mt-0.5 text-[11px] text-muted">{date(a.occurredAt, o, true)}{userName ? ` · ${userName}` : ""}</p>
                  </li>
                ))}
              </ol>
            ) : <Empty title="Nenhuma atividade registrada" />}
          </Card>
        </div>

        <div className="space-y-5">
          <Card>
            <CardTitle>Detalhes</CardTitle>
            <dl className="space-y-2 text-sm">
              <div><dt className="text-xs text-muted">Empresa</dt><dd>{company ? <Link href={`/crm?empresa=${company.id}`} className="hover:text-primary-2">{company.name}</Link> : "—"}{company?.segment ? <span className="text-muted"> · {company.segment}</span> : null}</dd></div>
              <div><dt className="text-xs text-muted">Contato</dt><dd>{contact ? <Link href={`/crm?contato=${contact.id}`} className="hover:text-primary-2">{contact.name}</Link> : "—"}{contact?.email ? <span className="block text-xs text-muted">{contact.email}</span> : null}</dd></div>
              <div><dt className="text-xs text-muted">Responsável</dt><dd>{owner?.name ?? "—"}</dd></div>
              <div><dt className="text-xs text-muted">Origem</dt><dd>{opp.source ?? "—"}</dd></div>
              {opp.lostReason && <div><dt className="text-xs text-muted">Motivo da perda</dt><dd className="text-danger">{opp.lostReason}</dd></div>}
              <div><dt className="text-xs text-muted">Criada em</dt><dd>{date(opp.createdAt, o, true)}</dd></div>
            </dl>
          </Card>
          <Card>
            <CardTitle>Propostas</CardTitle>
            {detail.proposals.length ? (
              <ul className="space-y-2 text-sm">{detail.proposals.map((p) => (
                <li key={p.id} className="flex items-center justify-between gap-2"><span className="min-w-0 truncate">{p.title}<span className="block text-xs text-muted">{money(Number(p.amountCents), o)}</span></span><Badge>{PROP_LABEL[p.status] ?? p.status}</Badge></li>
              ))}</ul>
            ) : <p className="text-sm text-muted">Nenhuma proposta.</p>}
          </Card>
          <Card>
            <CardTitle>Tarefas</CardTitle>
            {oppTasks.length ? (
              <ul className="space-y-2 text-sm">{oppTasks.map(({ t, assignee }) => (
                <li key={t.id} className="flex items-start justify-between gap-2"><span className={t.status === "done" ? "text-muted line-through" : ""}>{t.title}<span className="block text-xs text-muted">{assignee ?? "—"}{t.dueAt ? ` · ${date(t.dueAt, o, true)}` : ""}</span></span><Badge tone={t.priority === "high" ? "danger" : "neutral"}>{t.priority === "high" ? "Alta" : t.priority === "low" ? "Baixa" : "Média"}</Badge></li>
              ))}</ul>
            ) : <p className="text-sm text-muted">Nenhuma tarefa.</p>}
          </Card>
          <Card>
            <CardTitle>Reuniões</CardTitle>
            {oppMeetings.length ? (
              <ul className="space-y-2 text-sm">{oppMeetings.map((m) => <li key={m.id}>{m.title}<span className="block text-xs text-muted">{date(m.startsAt, o, true)}</span></li>)}</ul>
            ) : <p className="text-sm text-muted">Nenhuma reunião agendada.</p>}
          </Card>
        </div>
      </div>
    </div>
  );
}
