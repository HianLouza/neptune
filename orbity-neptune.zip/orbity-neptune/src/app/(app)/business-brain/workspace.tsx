"use client";
/**
 * Business Brain — ambiente de investigação do Flávio.
 * O empresário pergunta. Flávio investiga. Business Brain analisa. ORBITY conecta. O empresário decide.
 * Só fala com o backend (/api/brain/*, /api/flavio/actions/confirm); nenhum provedor de IA é chamado pelo navegador.
 */
import { useCallback, useEffect, useRef, useState } from "react";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import {
  AlertTriangle, BellRing, Bot, CheckCircle2, ChevronDown, ChevronRight, CircleDashed, Download, Loader2, Lock, Plus, Send, Settings2, ShieldAlert, Trash2,
} from "lucide-react";
import { api } from "@/lib/api-client";
import { Badge, Button, Card, Select, Textarea, cx } from "@/components/ui";
import { FlavioAvatar } from "@/components/flavio/flavio-dock";
import type { Investigation, AnswerSection, Recommendation } from "@/server/ai/flavio/investigate";
import type { ActionProposal } from "@/server/ai/flavio/actions";
import { ChangePreview } from "@/components/flavio/change-preview";
import type { ProactiveItem, AlertPrefs } from "@/server/ai/flavio/alerts";
import type { Chart, SourceInfo } from "@/server/ai/flavio/tools";

type Status = { available: boolean; mode: "ia" | "deterministico"; modeLabel: string; reason: string | null; greeting: string };
type InvListItem = { id: string; title: string; surface: string; updatedAt: string; messages: number; topic: string | null };
type StoredMessage = { id: string; role: "user" | "assistant"; content: string; payload: unknown; createdAt: string };
type StoredInvestigation = { id: string; title: string; surface: string; messages: StoredMessage[] };
type Turn = { id: string; role: "user" | "assistant"; text: string; inv?: Investigation; legacy?: { mode?: string; intentLabel?: string | null; sources?: string[] }; error?: boolean };

const STEP_LABELS = ["Interpretar a pergunta", "Definir indicadores e fontes", "Consultar os módulos autorizados", "Verificar qualidade dos dados", "Comparar períodos",
  "Identificar padrões e anomalias", "Formular hipóteses", "Validar com evidências", "Elaborar recomendações", "Conclusões e limitações"];
const NATURE_TONE: Record<string, "info" | "warning" | "primary" | "success" | "neutral"> = { fato: "info", "inferência": "warning", estimativa: "primary", "hipótese": "neutral", "recomendação": "success" };
const DATA_TONE: Record<string, "success" | "warning" | "danger" | "neutral"> = { real: "success", incompleto: "warning", sem_permissao: "danger", indisponivel: "neutral", erro: "danger" };
const DATA_LABEL: Record<string, string> = { real: "dado real", incompleto: "incompleto", sem_permissao: "sem permissão", indisponivel: "indisponível", erro: "erro na consulta" };
const uid = () => Math.random().toString(36).slice(2);

function turnsFrom(inv: StoredInvestigation | null): Turn[] {
  if (!inv) return [];
  return inv.messages.map((m) => {
    const p = (m.payload ?? null) as ({ kind?: string } & Record<string, unknown>) | null;
    if (m.role === "assistant" && p?.kind === "investigation") return { id: m.id, role: "assistant", text: m.content, inv: p as unknown as Investigation };
    if (m.role === "assistant") return { id: m.id, role: "assistant", text: m.content, legacy: { mode: p?.mode as string | undefined, intentLabel: (p?.intentLabel as string | null) ?? null, sources: (p?.sources as string[]) ?? [] } };
    return { id: m.id, role: "user", text: m.content };
  });
}

export function BrainWorkspace(props: {
  status: Status; investigations: InvListItem[]; initial: StoredInvestigation | null; initialQuestion: string | null; suggestions: string[];
  proactive: ProactiveItem[]; prefs: AlertPrefs; alertDomains: { key: string; label: string }[]; modules: { label: string; module: string; allowed: boolean }[];
}) {
  const [list, setList] = useState(props.investigations);
  const [convId, setConvId] = useState<string | null>(props.initial?.id ?? null);
  const [turns, setTurns] = useState<Turn[]>(turnsFrom(props.initial));
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [panel, setPanel] = useState<"none" | "alerts" | "modules">("none");
  const endRef = useRef<HTMLDivElement>(null);
  const asked = useRef(false);

  const refreshList = useCallback(() => api<InvListItem[]>("/api/brain/investigations").then(setList).catch(() => undefined), []);

  const ask = useCallback(async (q: string) => {
    const question = q.trim();
    if (question.length < 2 || busy) return;
    setError(null); setBusy(true); setInput("");
    setTurns((t) => [...t, { id: uid(), role: "user", text: question }]);
    setTimeout(() => endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" }), 50);
    try {
      const inv = await api<Investigation>("/api/brain/investigate", { body: { question, conversationId: convId ?? undefined, surface: "brain" } });
      setConvId(inv.conversationId);
      setTurns((t) => [...t, { id: inv.messageId ?? uid(), role: "assistant", text: inv.executiveAnswer, inv }]);
      if (inv.conversationId) window.history.replaceState(null, "", `/business-brain?c=${inv.conversationId}`);
      refreshList();
    } catch (e) {
      setTurns((t) => [...t, { id: uid(), role: "assistant", text: `Não consegui investigar agora: ${(e as Error).message}. Nada foi alterado; sua pergunta pode ser enviada de novo.`, error: true }]);
      setInput(question);
    } finally {
      setBusy(false);
      setTimeout(() => endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" }), 80);
    }
  }, [busy, convId, refreshList]);

  useEffect(() => { if (props.initialQuestion && !asked.current) { asked.current = true; ask(props.initialQuestion); } }, [props.initialQuestion, ask]);

  const open = async (id: string) => {
    setError(null);
    try {
      const inv = await api<StoredInvestigation>(`/api/brain/investigations/${id}`);
      setConvId(inv.id); setTurns(turnsFrom(inv));
      window.history.replaceState(null, "", `/business-brain?c=${inv.id}`);
    } catch (e) { setError((e as Error).message); }
  };
  const fresh = () => { setConvId(null); setTurns([]); setError(null); window.history.replaceState(null, "", "/business-brain"); };

  return (
    <div className="grid gap-4 lg:grid-cols-[260px_minmax(0,1fr)]">
      <History list={list} current={convId} onOpen={open} onNew={fresh} onChanged={(deletedId) => { refreshList(); if (!deletedId || deletedId === convId) fresh(); }} />

      <div className="min-w-0 space-y-4">
        <Card className="p-4">
          <div className="flex flex-wrap items-center gap-3">
            <FlavioAvatar size={40} />
            <div className="min-w-0 flex-1">
              <p className="font-semibold leading-tight">Flávio · Pergunte ao Flávio</p>
              <p className="text-xs text-muted">{props.status.available ? props.status.modeLabel : props.status.reason}</p>
            </div>
            <Badge tone={props.status.mode === "ia" ? "primary" : "neutral"}>{props.status.mode === "ia" ? "IA conectada" : "Sem modelo de IA · respostas calculadas dos dados"}</Badge>
            <Button size="sm" variant="secondary" onClick={() => setPanel(panel === "alerts" ? "none" : "alerts")} aria-expanded={panel === "alerts"}><BellRing size={14} className="mr-1 inline" />Alertas</Button>
            <Button size="sm" variant="secondary" onClick={() => setPanel(panel === "modules" ? "none" : "modules")} aria-expanded={panel === "modules"}><Settings2 size={14} className="mr-1 inline" />Fontes</Button>
          </div>
          {panel === "alerts" && <AlertSettings prefs={props.prefs} domains={props.alertDomains} />}
          {panel === "modules" && <Modules modules={props.modules} />}
        </Card>

        {!turns.length && props.proactive.length > 0 && <Proactive items={props.proactive} onAsk={ask} />}

        <section aria-label="Conversa" aria-live="polite" className="space-y-4">
          {!turns.length && (
            <Card className="p-5">
              <p className="text-sm">{props.status.greeting}</p>
              <p className="mt-1 text-xs text-muted">Pergunte qualquer coisa sobre a empresa. As sugestões abaixo são só atalhos.</p>
            </Card>
          )}
          {turns.map((t) => t.role === "user"
            ? <div key={t.id} className="ml-auto max-w-[85%] rounded-2xl rounded-br-md bg-primary/20 px-4 py-2.5 text-sm">{t.text}</div>
            : <AssistantTurn key={t.id} turn={t} onAsk={ask} />)}
          {busy && <Running />}
          <div ref={endRef} />
        </section>

        <Card className="sticky bottom-2 p-3">
          <form onSubmit={(e) => { e.preventDefault(); ask(input); }} className="flex items-end gap-2">
            <Textarea value={input} onChange={(e) => setInput(e.target.value)} placeholder={convId ? "Continue a investigação (ex.: Qual vendedor foi mais afetado? O que podemos fazer?)" : "Ex.: Por que minha receita caiu?"}
              aria-label="Pergunta ao Flávio" maxLength={2000} rows={2} className="min-h-0 flex-1 resize-none"
              onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); ask(input); } }} disabled={!props.status.available} />
            <Button type="submit" disabled={busy || input.trim().length < 2 || !props.status.available} aria-label="Investigar">{busy ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}</Button>
          </form>
          <div className="mt-2 flex gap-1.5 overflow-x-auto pb-1" role="list" aria-label="Perguntas sugeridas">
            {props.suggestions.map((s) => <button key={s} type="button" role="listitem" disabled={busy} onClick={() => ask(s)} className="shrink-0 rounded-full border border-line px-2.5 py-1 text-[11px] text-muted hover:border-primary-2 hover:text-fg disabled:opacity-50">{s}</button>)}
          </div>
          {error && <p className="mt-2 text-xs text-danger" role="alert">{error}</p>}
        </Card>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ histórico */

function History({ list, current, onOpen, onNew, onChanged }: { list: InvListItem[]; current: string | null; onOpen: (id: string) => void; onNew: () => void; onChanged: (deletedId?: string) => void }) {
  const [confirm, setConfirm] = useState<string | "all" | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const remove = async (id: string | "all") => {
    try { await api(id === "all" ? "/api/brain/investigations" : `/api/brain/investigations/${id}`, { method: "DELETE" }); setConfirm(null); onChanged(id === "all" ? undefined : id); }
    catch (e) { setErr((e as Error).message); }
  };
  return (
    <Card className="h-fit p-3 lg:sticky lg:top-2">
      <Button className="w-full" onClick={onNew}><Plus size={14} className="mr-1 inline" />Nova investigação</Button>
      <p className="mt-3 mb-1 text-[11px] font-semibold uppercase tracking-wide text-muted">Investigações salvas</p>
      {!list.length && <p className="text-xs text-muted">Nenhuma ainda. Suas conversas com o Flávio aparecem aqui, inclusive as do painel lateral.</p>}
      <ul className="max-h-[50vh] space-y-1 overflow-y-auto">
        {list.map((c) => (
          <li key={c.id} className={cx("group rounded-lg border px-2 py-1.5", c.id === current ? "border-primary-2 bg-primary/10" : "border-transparent hover:bg-surface-2")}>
            <button type="button" onClick={() => onOpen(c.id)} className="w-full text-left">
              <span className="line-clamp-2 text-xs">{c.title}</span>
              <span className="text-[10px] text-muted">{new Date(c.updatedAt).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" })} · {c.messages} msg{c.surface === "dock" ? " · painel" : ""}</span>
            </button>
            {confirm === c.id ? (
              <span className="mt-1 flex gap-1"><Button size="sm" variant="danger" onClick={() => remove(c.id)}>Apagar</Button><Button size="sm" variant="ghost" onClick={() => setConfirm(null)}>Cancelar</Button></span>
            ) : (
              <button type="button" onClick={() => setConfirm(c.id)} className="mt-0.5 text-[10px] text-muted hover:text-danger" aria-label={`Apagar a investigação ${c.title}`}><Trash2 size={11} className="mr-0.5 inline" />apagar</button>
            )}
          </li>
        ))}
      </ul>
      {list.length > 0 && (confirm === "all"
        ? <div className="mt-2 space-y-1 rounded-lg border border-danger/40 p-2 text-[11px]"><p>Apagar todas as suas investigações? O conteúdo é excluído de verdade (LGPD).</p><span className="flex gap-1"><Button size="sm" variant="danger" onClick={() => remove("all")}>Apagar todas</Button><Button size="sm" variant="ghost" onClick={() => setConfirm(null)}>Cancelar</Button></span></div>
        : <button type="button" onClick={() => setConfirm("all")} className="mt-2 text-[11px] text-muted hover:text-danger">Apagar todo o meu histórico</button>)}
      {err && <p className="mt-1 text-[11px] text-danger">{err}</p>}
    </Card>
  );
}

/* ------------------------------------------------------------------ painéis */

function AlertSettings({ prefs, domains }: { prefs: AlertPrefs; domains: { key: string; label: string }[] }) {
  const [p, setP] = useState(prefs);
  const [state, setState] = useState<"idle" | "saving" | "saved" | "error">("idle");
  const [msg, setMsg] = useState<string | null>(null);
  const save = async () => {
    setState("saving");
    try { const r = await api<AlertPrefs>("/api/brain/alerts", { method: "PUT", body: { enabled: p.enabled, domains: p.domains, minPriority: p.minPriority, frequency: p.frequency } }); setP(r); setState("saved"); setMsg("Preferências salvas."); }
    catch (e) { setState("error"); setMsg((e as Error).message); }
  };
  return (
    <div className="mt-4 space-y-3 border-t border-line pt-3 text-sm">
      <p className="text-xs text-muted">O Flávio monitora seus indicadores e avisa quando algo merece atenção. Você escolhe o quê, com que prioridade e com que frequência.</p>
      <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={p.enabled} onChange={(e) => setP({ ...p, enabled: e.target.checked })} /> Receber alertas proativos</label>
      <fieldset disabled={!p.enabled} className="space-y-3 disabled:opacity-50">
        <div className="flex flex-wrap gap-2" role="group" aria-label="Assuntos">
          {domains.map((d) => (
            <label key={d.key} className="flex items-center gap-1.5 rounded-full border border-line px-2.5 py-1 text-xs">
              <input type="checkbox" checked={p.domains.includes(d.key as never)} onChange={(e) => setP({ ...p, domains: (e.target.checked ? [...p.domains, d.key] : p.domains.filter((x) => x !== d.key)) as AlertPrefs["domains"] })} />{d.label}
            </label>
          ))}
        </div>
        <div className="grid gap-2 sm:grid-cols-2">
          <label className="text-xs">Prioridade mínima<Select value={p.minPriority} onChange={(e) => setP({ ...p, minPriority: e.target.value as AlertPrefs["minPriority"] })}><option value="high">Só alta</option><option value="medium">Média ou alta</option><option value="low">Todas</option></Select></label>
          <label className="text-xs">Frequência<Select value={p.frequency} onChange={(e) => setP({ ...p, frequency: e.target.value as AlertPrefs["frequency"] })}><option value="immediate">Imediata (cada alerta)</option><option value="daily">Resumo diário</option><option value="weekly">Resumo semanal</option></Select></label>
        </div>
      </fieldset>
      <div className="flex items-center gap-2"><Button size="sm" onClick={save} disabled={state === "saving"}>{state === "saving" ? "Salvando…" : "Salvar preferências"}</Button>{msg && <span className={cx("text-xs", state === "error" ? "text-danger" : "text-success")}>{msg}</span>}</div>
    </div>
  );
}

function Modules({ modules }: { modules: { label: string; module: string; allowed: boolean }[] }) {
  return (
    <div className="mt-4 border-t border-line pt-3">
      <p className="mb-2 text-xs text-muted">O que o Flávio pode consultar por você. Ele usa só ferramentas controladas, com as SUAS permissões, e nunca acessa o banco diretamente.</p>
      <ul className="grid gap-1 sm:grid-cols-2">
        {modules.map((m) => <li key={m.label} className="flex items-center gap-1.5 text-xs">{m.allowed ? <CheckCircle2 size={12} className="text-success" /> : <Lock size={12} className="text-muted" />}<span className={m.allowed ? "" : "text-muted"}>{m.label}</span><span className="text-[10px] text-muted">· {m.module}</span></li>)}
      </ul>
      <p className="mt-2 text-[11px] text-muted">Ainda não disponíveis: Market Radar, Business Benchmark, Document Intelligence, Customer 360 completo e Revenue Operations. Quando a pergunta depender deles, o Flávio diz o que falta.</p>
    </div>
  );
}

function Proactive({ items, onAsk }: { items: ProactiveItem[]; onAsk: (q: string) => void }) {
  return (
    <Card className="p-4">
      <p className="mb-2 flex items-center gap-2 text-sm font-semibold"><BellRing size={15} className="text-warning" />O que merece atenção agora</p>
      <ul className="space-y-2">
        {items.map((i) => (
          <li key={i.id} className="rounded-xl border border-line bg-bg-2/60 p-3 text-xs">
            <div className="flex flex-wrap items-center gap-1.5"><Badge tone={i.urgency === "alta" ? "danger" : i.urgency === "média" ? "warning" : "neutral"}>urgência {i.urgency}</Badge><span className="font-medium">{i.whatHappened}</span></div>
            {i.indicator && <p className="mt-1 text-muted">Indicador: {i.indicator}{i.impact ? ` · impacto: ${i.impact}` : ""}</p>}
            {i.evidence.length > 0 && <p className="mt-1 text-muted">Evidência: {i.evidence.join(" · ")}</p>}
            {i.recommendation && <p className="mt-1">Recomendação: {i.recommendation}</p>}
            <button type="button" onClick={() => onAsk(`Investigue: ${i.whatHappened.split(".")[0]}`)} className="mt-1.5 text-primary-2 hover:underline">Investigar com o Flávio</button>
          </li>
        ))}
      </ul>
    </Card>
  );
}

/* ------------------------------------------------------------------ resposta */

function Running() {
  const [n, setN] = useState(0);
  useEffect(() => { const t = setInterval(() => setN((x) => Math.min(x + 1, STEP_LABELS.length - 1)), 700); return () => clearInterval(t); }, []);
  return (
    <Card className="p-4" aria-busy="true">
      <p className="mb-2 flex items-center gap-2 text-sm"><Loader2 size={15} className="animate-spin text-primary-2" />Flávio investigando…</p>
      <ol className="space-y-1 text-xs">
        {STEP_LABELS.map((s, i) => <li key={s} className={cx("flex items-center gap-2", i > n && "text-muted/60")}>{i < n ? <CheckCircle2 size={12} className="text-success" /> : i === n ? <Loader2 size={12} className="animate-spin" /> : <CircleDashed size={12} />}{s}</li>)}
      </ol>
    </Card>
  );
}

function AssistantTurn({ turn, onAsk }: { turn: Turn; onAsk: (q: string) => void }) {
  if (turn.error) return <Card className="border-danger/40 p-4 text-sm"><AlertTriangle size={14} className="mr-1 inline text-danger" />{turn.text}</Card>;
  if (!turn.inv) {
    return (
      <Card className="p-4 text-sm">
        <div className="mb-2 flex flex-wrap gap-1.5"><Badge tone="neutral">Painel do Flávio</Badge>{turn.legacy?.intentLabel && <Badge tone="info">{turn.legacy.intentLabel}</Badge>}<Badge tone={turn.legacy?.mode === "ia" ? "primary" : "neutral"}>{turn.legacy?.mode === "ia" ? "IA" : "determinístico"}</Badge></div>
        <p className="whitespace-pre-line">{turn.text}</p>
        {turn.legacy?.sources?.length ? <p className="mt-2 text-[11px] text-muted">Fontes: {turn.legacy.sources.join(" · ")}</p> : null}
      </Card>
    );
  }
  return <InvestigationView inv={turn.inv} onAsk={onAsk} />;
}

function InvestigationView({ inv, onAsk }: { inv: Investigation; onAsk: (q: string) => void }) {
  const [tab, setTab] = useState<"analise" | "etapas" | "fontes" | "graficos">("analise");
  const blocked = inv.mode === "bloqueado" || inv.mode === "indisponivel";
  return (
    <Card className="p-4">
      <div className="mb-3 flex flex-wrap items-center gap-1.5">
        <FlavioAvatar size={24} />
        <Badge tone={inv.mode === "ia" ? "primary" : blocked ? "danger" : "neutral"}>{inv.modeLabel}</Badge>
        {inv.followUp && <Badge tone="info">continuação</Badge>}
        {inv.topicLabel && <Badge tone="neutral">{inv.topicLabel}</Badge>}
        <Badge tone="neutral">{inv.format === "curta" ? "resposta curta" : "análise completa"}</Badge>
        {inv.credits > 0 && <span className="text-[10px] text-muted">{inv.credits} crédito(s)</span>}
      </div>

      <section aria-label="Resposta executiva" className={cx("rounded-xl border p-3", blocked ? "border-danger/40 bg-danger/5" : "border-primary-2/40 bg-primary/5")}>
        <p className="mb-1 text-[11px] font-semibold uppercase tracking-wide text-muted">{blocked ? <><ShieldAlert size={12} className="mr-1 inline" />Não executado</> : "Resposta executiva"}</p>
        <p className="text-sm">{inv.executiveAnswer}</p>
      </section>

      {!blocked && (
        <>
          <div className="mt-3 flex flex-wrap gap-1" role="tablist" aria-label="Visões da resposta">
            {([["analise", "Análise"], ["etapas", `Etapas (${inv.steps.length})`], ["fontes", `Fontes (${inv.sources.length})`], ["graficos", `Gráficos (${inv.charts.length})`]] as const).map(([k, l]) => (
              <button key={k} type="button" role="tab" aria-selected={tab === k} onClick={() => setTab(k)} disabled={k === "graficos" && !inv.charts.length}
                className={cx("rounded-lg px-2.5 py-1 text-xs disabled:opacity-40", tab === k ? "bg-surface-2 text-fg" : "text-muted hover:text-fg")}>{l}</button>
            ))}
          </div>
          <div className="mt-3" role="tabpanel">
            {tab === "analise" && <Sections sections={inv.sections} />}
            {tab === "etapas" && <Steps inv={inv} />}
            {tab === "fontes" && <Sources sources={inv.sources} />}
            {tab === "graficos" && <div className="grid gap-3 md:grid-cols-2">{inv.charts.map((c) => <MiniChart key={c.title} chart={c} />)}</div>}
          </div>

          {inv.recommendations.length > 0 && <Recommendations recs={inv.recommendations} />}
          {inv.proposals.length > 0 && (
            <div className="mt-3"><p className="mb-1 text-[11px] font-semibold uppercase tracking-wide text-muted">Ações preparadas pela análise</p><div className="space-y-2">{inv.proposals.map((p) => <ProposalButton key={p.token} p={p} />)}</div></div>
          )}
        </>
      )}

      {(inv.limitations.length > 0 || inv.warnings.length > 0) && (
        <details className="mt-3 rounded-xl border border-warning/40 bg-warning/5 p-3 text-xs" open={blocked}>
          <summary className="cursor-pointer font-medium">Limitações e avisos ({inv.limitations.length + inv.warnings.length})</summary>
          <ul className="mt-2 list-disc space-y-1 pl-4">{[...inv.warnings, ...inv.limitations].map((l, i) => <li key={i}>{l}</li>)}</ul>
          {inv.missing.length > 0 && <p className="mt-2 text-muted">Dados que faltam: {inv.missing.join("; ")}.</p>}
        </details>
      )}

      {!blocked && inv.conversationId && (
        <div className="mt-3 flex flex-wrap items-center gap-2 border-t border-line pt-3 text-xs">
          <span className="text-muted">Continuar:</span>
          {["O que podemos fazer?", "Qual vendedor foi mais afetado?", "Quais são os riscos?"].map((q) => <button key={q} type="button" onClick={() => onAsk(q)} className="rounded-full border border-line px-2 py-0.5 text-muted hover:border-primary-2 hover:text-fg">{q}</button>)}
          <span className="ml-auto flex gap-2">
            <a href={`/api/brain/investigations/${inv.conversationId}/export?format=md`} className="flex items-center gap-1 text-primary-2 hover:underline"><Download size={12} />Relatório (.md)</a>
            <a href={`/api/brain/investigations/${inv.conversationId}/export?format=csv`} className="flex items-center gap-1 text-primary-2 hover:underline"><Download size={12} />Tabela (.csv)</a>
          </span>
        </div>
      )}
    </Card>
  );
}

function Sections({ sections }: { sections: AnswerSection[] }) {
  if (!sections.length) return <p className="text-xs text-muted">Sem itens além da resposta executiva.</p>;
  return (
    <div className="space-y-3">
      <p className="flex flex-wrap items-center gap-1 text-[10px] text-muted">Legenda: {Object.keys(NATURE_TONE).map((k) => <Badge key={k} tone={NATURE_TONE[k]}>{k}</Badge>)}</p>
      {sections.map((s, n) => (
        <section key={s.key}>
          <h3 className="mb-1 text-xs font-semibold uppercase tracking-wide text-muted">{n + 1}. {s.title}</h3>
          <ul className="space-y-1 text-sm">{s.items.map((i, k) => <li key={k} className="flex items-start gap-2"><Badge tone={NATURE_TONE[i.nature] ?? "info"} className="mt-0.5 shrink-0">{i.nature}</Badge><span>{i.text}</span></li>)}</ul>
        </section>
      ))}
    </div>
  );
}

function Steps({ inv }: { inv: Investigation }) {
  return (
    <ol className="space-y-1.5 text-xs">
      {inv.steps.map((s, i) => (
        <li key={s.key} className="flex items-start gap-2">
          {s.status === "ok" ? <CheckCircle2 size={13} className="mt-0.5 text-success" /> : s.status === "aviso" ? <AlertTriangle size={13} className="mt-0.5 text-warning" /> : <CircleDashed size={13} className="mt-0.5 text-muted" />}
          <span><b>{i + 1}. {s.label}.</b> <span className="text-muted">{s.detail}</span></span>
        </li>
      ))}
      <li className="pt-1 text-[11px] text-muted">Ferramentas consultadas: {inv.toolsUsed.join(", ") || "nenhuma"} · {new Date(inv.at).toLocaleString("pt-BR")}</li>
    </ol>
  );
}

function Sources({ sources }: { sources: SourceInfo[] }) {
  const [open, setOpen] = useState<string | null>(null);
  if (!sources.length) return <p className="text-xs text-muted">Nenhuma fonte consultada.</p>;
  return (
    <ul className="space-y-1.5 text-xs">
      {sources.map((s, i) => (
        <li key={`${s.tool}-${i}`} className="rounded-lg border border-line p-2">
          <button type="button" onClick={() => setOpen(open === `${s.tool}-${i}` ? null : `${s.tool}-${i}`)} className="flex w-full items-center gap-2 text-left" aria-expanded={open === `${s.tool}-${i}`}>
            {open === `${s.tool}-${i}` ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
            <span className="font-medium">{s.label}</span><span className="text-muted">· {s.module}</span>
            <Badge tone={DATA_TONE[s.dataStatus] ?? "neutral"} className="ml-auto">{DATA_LABEL[s.dataStatus] ?? s.dataStatus}</Badge>
          </button>
          {open === `${s.tool}-${i}` && (
            <dl className="mt-2 grid gap-x-3 gap-y-1 pl-5 sm:grid-cols-[120px_1fr]">
              <dt className="text-muted">Origem</dt><dd>{s.source}</dd>
              <dt className="text-muted">Período</dt><dd>{s.period ?? "—"}</dd>
              <dt className="text-muted">Consultado em</dt><dd>{new Date(s.queriedAt).toLocaleString("pt-BR")}</dd>
              {s.indicators.length > 0 && <><dt className="text-muted">Indicadores</dt><dd>{s.indicators.join(", ")}</dd></>}
              {s.method && <><dt className="text-muted">Método</dt><dd>{s.method}</dd></>}
              {s.assumptions.length > 0 && <><dt className="text-muted">Premissas</dt><dd>{s.assumptions.join(" · ")}</dd></>}
              <dt className="text-muted">Confiança</dt><dd>{s.confidence != null ? `${Math.round(s.confidence * 100)}%` : "não calculada"}</dd>
              {s.limitations.length > 0 && <><dt className="text-muted">Limitações</dt><dd>{s.limitations.join(" · ")}</dd></>}
              {s.missing.length > 0 && <><dt className="text-muted">Falta</dt><dd>{s.missing.join(" · ")}</dd></>}
            </dl>
          )}
        </li>
      ))}
    </ul>
  );
}

function MiniChart({ chart }: { chart: Chart }) {
  const fmt = (v: number) => chart.unit === "brl" ? v.toLocaleString("pt-BR", { style: "currency", currency: "BRL", maximumFractionDigits: 0 }) : chart.unit === "pct" ? `${v}%` : v.toLocaleString("pt-BR");
  return (
    <figure className="rounded-xl border border-line p-3">
      <figcaption className="mb-2 text-xs font-medium">{chart.title}</figcaption>
      <div className="h-48" role="img" aria-label={`${chart.title}: ${chart.points.map((p) => `${p.label} ${fmt(p.value)}`).join("; ")}`}>
        <ResponsiveContainer>
          <BarChart data={chart.points} margin={{ top: 4, right: 8, left: 8, bottom: 4 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
            <XAxis dataKey="label" tick={{ fontSize: 10 }} interval={0} angle={chart.points.length > 5 ? -20 : 0} height={chart.points.length > 5 ? 40 : 20} />
            <YAxis tick={{ fontSize: 10 }} tickFormatter={(v) => (chart.unit === "brl" ? `${Math.round(Number(v) / 1000)}k` : String(v))} width={42} />
            <Tooltip formatter={(v) => fmt(Number(v))} />
            <Bar dataKey="value" fill="var(--primary-2)" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </figure>
  );
}

function Recommendations({ recs }: { recs: Recommendation[] }) {
  return (
    <div className="mt-4">
      <p className="mb-1 text-[11px] font-semibold uppercase tracking-wide text-muted">Recomendações · transforme em ação (nada é feito sem sua confirmação)</p>
      <ul className="space-y-2">
        {recs.map((r) => (
          <li key={r.id} className="rounded-xl border border-line bg-bg-2/60 p-3 text-sm">
            <p>{r.text}</p>
            <div className="mt-2 flex flex-wrap gap-2">
              {r.proposals.map((p) => <ProposalButton key={p.token} p={p} compact />)}
              <a href="/simulador" className="inline-flex min-h-11 items-center rounded-lg border border-line px-3 text-xs text-muted hover:border-primary-2 hover:text-fg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary-2">Simular no Simulador</a>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

function ProposalButton({ p, compact = false }: { p: ActionProposal; compact?: boolean }) {
  const [st, setSt] = useState<"idle" | "review" | "running" | "done" | "error">("idle");
  const [msg, setMsg] = useState<string | null>(null);
  const [records, setRecords] = useState<{ kind: string; id: string; href: string }[]>([]);
  const [previewOk, setPreviewOk] = useState(false);
  const confirm = async () => {
    setSt("running");
    try {
      const r = await api<{ message: string; records: { kind: string; id: string; href: string }[] }>("/api/flavio/actions/confirm", { body: { token: p.token } });
      setSt("done"); setMsg(r.message); setRecords(r.records);
    } catch (e) { setSt("error"); setMsg((e as Error).message); }
  };
  if (!p.allowed) return <span className="inline-flex items-center gap-1 rounded-lg border border-line px-2 py-1 text-xs text-muted" title={`Requer a permissão ${p.permission}`}><Lock size={11} />{p.title} (sem permissão)</span>;
  if (st === "done") return <span className="inline-flex items-center gap-1 text-xs text-success"><CheckCircle2 size={12} />{msg} {records[0] && <a href={records[0].href} className="underline">Abrir</a>}</span>;
  if (st === "review" || st === "running" || st === "error") {
    return (
      <div className="w-full space-y-2 rounded-lg border border-primary-2/50 bg-primary/5 p-2.5 text-xs" role="group" aria-label={`Confirmar: ${p.title}`}>
        <p><b>{p.title}</b>{p.summary ? <span className="text-muted"> · {p.summary}</span> : null}</p>
        <p className="font-medium">Confira o que vai mudar antes de confirmar:</p>
        <ChangePreview token={p.token} onReady={setPreviewOk} />
        <p className="text-[11px] text-muted">Nada muda até você confirmar. O registro fica na auditoria em seu nome.</p>
        <div className="flex flex-wrap items-center gap-2">
          <button type="button" onClick={confirm} disabled={st === "running" || !previewOk} aria-label={`Confirmar e executar: ${p.title}`}
            className="min-h-11 rounded-lg bg-gradient-to-r from-primary to-navy px-4 text-sm font-medium text-white focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary-2 disabled:opacity-50">
            {st === "running" ? "Executando…" : "Confirmar e executar"}</button>
          <button type="button" onClick={() => { setSt("idle"); setPreviewOk(false); }} aria-label={`Cancelar: ${p.title}`}
            className="min-h-11 rounded-lg border border-line px-4 text-sm focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary-2">Cancelar</button>
        </div>
        {st === "error" && <p role="alert" className="text-danger">Não executado: {msg}</p>}
      </div>
    );
  }
  return (
    <button type="button" onClick={() => setSt("review")} aria-label={`Revisar e confirmar: ${p.title}`}
      className={`inline-flex min-h-11 items-center rounded-lg border border-line px-3 text-xs hover:border-primary-2 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary-2${compact ? "" : " font-medium"}`}>
      <Bot size={12} className="mr-1.5" aria-hidden />{p.title}</button>
  );
}
