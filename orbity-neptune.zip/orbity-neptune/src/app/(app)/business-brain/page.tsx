import { requirePageContext } from "@/server/auth/next";
import { flavioStatus } from "@/server/ai/flavio";
import { getInvestigation, listInvestigations } from "@/server/ai/flavio/conversations";
import { ALERT_DOMAINS, proactiveItems } from "@/server/ai/flavio/alerts";
import { toolCatalog } from "@/server/ai/flavio/tools";
import { BRAIN_SUGGESTIONS } from "@/server/ai/flavio/investigate";
import { PageHeader } from "@/components/ui";
import { BrainWorkspace } from "./workspace";

export const metadata = { title: "Pergunte ao Flávio" };
export const dynamic = "force-dynamic";

export default async function BusinessBrainPage({ searchParams }: { searchParams: Promise<{ c?: string; q?: string }> }) {
  const ctx = await requirePageContext("ai:use");
  const sp = await searchParams;
  const [status, investigations, proactive] = await Promise.all([flavioStatus(ctx), listInvestigations(ctx), proactiveItems(ctx)]);
  let initial: Awaited<ReturnType<typeof getInvestigation>> | null = null;
  if (sp.c) { try { initial = await getInvestigation(ctx, sp.c); } catch { initial = null; } }
  const catalog = toolCatalog(ctx);
  return (
    <div className="space-y-4">
      <PageHeader title="Pergunte ao Flávio" subtitle="Converse com o Flávio sobre a empresa. Ele investiga os módulos que você pode acessar, cruza os dados e mostra fontes, hipóteses e limitações. Você decide." />
      <BrainWorkspace
        status={{ available: status.available, mode: status.mode === "ia" ? "ia" : "deterministico", modeLabel: status.modeLabel, reason: status.reason, greeting: status.greeting }}
        investigations={investigations}
        initial={initial ? JSON.parse(JSON.stringify(initial)) : null}
        initialQuestion={!initial && sp.q ? sp.q.slice(0, 2000) : null}
        suggestions={BRAIN_SUGGESTIONS}
        proactive={proactive.items}
        prefs={proactive.prefs}
        alertDomains={ALERT_DOMAINS.map((d) => ({ key: d.key, label: d.label }))}
        modules={catalog.filter((t) => t.name !== "modulo_indisponivel").map((t) => ({ label: t.label, module: t.module, allowed: t.allowed }))}
      />
    </div>
  );
}
