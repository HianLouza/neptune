import { eq } from "drizzle-orm";
import { requirePageContext } from "@/server/auth/next";
import { organizations } from "@/server/db/schema";
import {
  agingReport, breakEvenReport, budgetVsActual, cashflowReport, crmWonRevenue, dreReport, financeIntegrationStatus, financialSnapshot,
  GROUP_LABELS, listCategories, listEntries, profitabilityReport, SUGGESTED_QUESTIONS, type DreMonth,
} from "@/server/domains/finance";
import { Badge, Card, CardTitle, Empty, PageHeader, Progress, Stat, Table, Td } from "@/components/ui";
import { ActionButton, Collapsible, FieldsForm } from "@/components/admin/actions";
import { date, money, pct } from "@/lib/format";
import { can } from "@/server/tenancy/context";
import { CashflowChart, EntryActions, FinanceAssistant, FinanceTabs } from "./finance-client";

export const metadata = { title: "Financeiro" };

const STATUS: Record<string, { label: string; tone: "success" | "warning" | "danger" | "neutral" | "info" }> = {
  open: { label: "Em aberto", tone: "info" }, paid: { label: "Pago", tone: "success" }, canceled: { label: "Cancelado", tone: "neutral" },
};

function EvidenceNote({ premises, limitations, confidence }: { premises?: string[]; limitations?: string[]; confidence: number }) {
  const label = confidence >= 0.75 ? "alta" : confidence >= 0.5 ? "média" : confidence > 0 ? "baixa" : "insuficiente";
  return (
    <details className="mt-3 rounded-lg border border-line/60 bg-bg-2/40 p-3 text-xs text-muted">
      <summary className="cursor-pointer">Premissas, limitações e confiança ({label})</summary>
      <ul className="mt-2 list-disc space-y-0.5 pl-5">{[...(premises ?? []), ...(limitations ?? [])].map((p, i) => <li key={i}>{p}</li>)}</ul>
    </details>
  );
}

export default async function FinanceiroPage({ searchParams }: { searchParams: Promise<{ status?: string; kind?: string }> }) {
  const ctx = await requirePageContext("finance:read");
  const sp = await searchParams;
  const canWrite = can(ctx, "finance:write");
  const o = { locale: ctx.locale, currency: ctx.currency, timezone: ctx.timezone };
  const m = (c: number) => money(c, o);
  const statusFilter = ["open", "paid", "canceled", "overdue"].includes(sp.status ?? "") ? sp.status : undefined;
  const kindFilter = ["receivable", "payable"].includes(sp.kind ?? "") ? sp.kind : undefined;

  const [snap, cats, entries, dre, cash, aging, byClient, byProduct, be, budget, integ, crm, [org]] = await Promise.all([
    financialSnapshot(ctx, 30), listCategories(ctx), listEntries(ctx, { status: statusFilter, kind: kindFilter, limit: 100 }),
    dreReport(ctx, 6), cashflowReport(ctx), agingReport(ctx), profitabilityReport(ctx, "client"), profitabilityReport(ctx, "product"),
    breakEvenReport(ctx), budgetVsActual(ctx), financeIntegrationStatus(ctx), crmWonRevenue(ctx, 30),
    ctx.db.select({ isDemo: organizations.isDemo }).from(organizations).where(eq(organizations.id, ctx.organizationId)),
  ]);

  const catOptions = cats.map((c) => ({ value: c.id, label: `${c.kind === "revenue" ? "Receita" : "Despesa"} · ${c.name}` }));
  const today = new Date().toISOString().slice(0, 10);
  const entryForm = (
    <FieldsForm url="/api/finance/entries" columns={3} reset submitLabel="Adicionar lançamento" success="Lançamento criado."
      fields={[
        { name: "kind", label: "Tipo", type: "select", defaultValue: "receivable", options: [{ value: "receivable", label: "Conta a receber" }, { value: "payable", label: "Conta a pagar" }] },
        { name: "description", label: "Descrição", required: true, placeholder: "Ex.: Mensalidade cliente X" },
        { name: "categoryId", label: "Categoria", type: "select", defaultValue: "", options: [{ value: "", label: "Sem categoria" }, ...catOptions], hint: "Deve combinar com o tipo (receita/despesa)." },
        { name: "amountCents", label: `Valor (${ctx.currency})`, required: true, transform: "cents", placeholder: "1500,00" },
        { name: "dueDate", label: "Vencimento", type: "date", required: true, defaultValue: today },
        { name: "costCenter", label: "Centro de custo", placeholder: "Opcional" },
        { name: "paid", label: "Já foi pago/recebido", type: "checkbox" },
      ]} />
  );

  const integrationBanner = (
    <div className="rounded-xl border border-warning/40 bg-warning/10 p-4 text-sm text-warning">
      {integ.anyConnected
        ? <>Provedores conectados: {integ.providers.filter((p) => p.connected).map((p) => p.label).join(", ")}. {integ.syncNote}</>
        : <>Nenhum banco, ERP ou meio de pagamento (Stripe, Mercado Pago, Asaas) está conectado: os números abaixo vêm apenas dos lançamentos cadastrados aqui.</>}
      {" "}A análise é gerencial e <strong>não substitui contabilidade, obrigações fiscais ou regulatórias</strong>.
    </div>
  );

  if (!snap.hasData) {
    return (
      <div className="mx-auto max-w-7xl space-y-6">
        <PageHeader title="Financeiro" subtitle="Financial Intelligence 360: contas a pagar e a receber, DRE gerencial, fluxo de caixa, inadimplência e rentabilidade." />
        {integrationBanner}
        <Card>
          <Empty title="Nenhum lançamento financeiro ainda.">
            <p>Cadastre contas a receber e a pagar (com categoria e vencimento). Com um mês completo de lançamentos pagos, o sistema calcula DRE, margem, ponto de equilíbrio e projeção de caixa.</p>
            {org?.isDemo && canWrite && <div className="mt-4 flex justify-center"><ActionButton url="/api/finance/demo" label="Carregar dados financeiros de demonstração" variant="primary" success="Dados de demonstração carregados." /></div>}
          </Empty>
          {canWrite ? <div className="mt-6">{entryForm}</div> : <p className="mt-4 text-xs text-muted">Você tem acesso somente leitura ao financeiro.</p>}
        </Card>
      </div>
    );
  }

  const prevRes = snap.previous.resultCents;
  const delta = (cur: number, prev: number) => (prev ? `${cur >= prev ? "+" : ""}${(((cur - prev) / Math.abs(prev)) * 100).toFixed(1)}% vs. 30 dias anteriores` : "sem base anterior");
  const DRE_LINES: { label: string; get: (d: DreMonth) => number | null; strong?: boolean; pct?: boolean }[] = [
    { label: "Receita bruta", get: (d) => d.receitaBruta, strong: true },
    { label: "(−) Deduções", get: (d) => -d.deducoes },
    { label: "Receita líquida", get: (d) => d.receitaLiquida, strong: true },
    { label: "(−) Custos variáveis", get: (d) => -d.custosVariaveis },
    { label: "Margem de contribuição", get: (d) => d.margemContribuicao, strong: true },
    { label: "Margem de contribuição (%)", get: (d) => d.margemContribuicaoPct, pct: true },
    { label: `(−) ${GROUP_LABELS.pessoal}`, get: (d) => -d.despesasFixas.pessoal },
    { label: `(−) ${GROUP_LABELS.marketing}`, get: (d) => -d.despesasFixas.marketing },
    { label: `(−) ${GROUP_LABELS.operacional}`, get: (d) => -d.despesasFixas.operacional },
    { label: `(−) ${GROUP_LABELS.outros}`, get: (d) => -d.despesasFixas.outros },
    { label: "Resultado operacional", get: (d) => d.resultadoOperacional, strong: true },
    { label: "(+) Receitas financeiras", get: (d) => d.receitasFinanceiras },
    { label: "(−) Despesas financeiras", get: (d) => -d.despesasFinanceiras },
    { label: "(−) Impostos sobre o resultado", get: (d) => -d.impostos },
    { label: "Resultado líquido", get: (d) => d.resultadoLiquido, strong: true },
  ];
  const monthLabel = (k: string) => new Intl.DateTimeFormat(ctx.locale, { month: "short", year: "2-digit", timeZone: "UTC" }).format(new Date(`${k}-15T12:00:00Z`));

  const tabs = [
    {
      key: "entries", label: "Lançamentos",
      content: (
        <Card>
          <CardTitle sub="Últimos 100 lançamentos pelo vencimento." action={
            <div className="flex flex-wrap gap-1 text-xs">
              {[["", "Todos"], ["open", "Em aberto"], ["overdue", "Vencidos"], ["paid", "Pagos"], ["canceled", "Cancelados"]].map(([v, l]) => (
                <a key={v} href={v ? `/financeiro?status=${v}` : "/financeiro"} className={`rounded-full border px-2.5 py-1 ${(statusFilter ?? "") === v ? "border-primary-2 text-fg" : "border-line text-muted hover:text-fg"}`}>{l}</a>
              ))}
            </div>
          }>Contas a pagar e a receber</CardTitle>
          {canWrite && <div className="mb-4"><Collapsible label="Novo lançamento">{entryForm}</Collapsible></div>}
          {entries.length ? (
            <Table head={["Descrição", "Tipo", "Categoria", "Vínculo", "Vencimento", "Valor", "Situação", ""]}>
              {entries.map((e) => {
                const overdue = e.status === "open" && new Date(e.dueDate) < new Date();
                const st = STATUS[e.status] ?? STATUS.open;
                return (
                  <tr key={e.id}>
                    <Td><span className="font-medium">{e.description}</span>{e.costCenter && <span className="block text-[11px] text-muted">{e.costCenter}</span>}{e.source === "demo" && <span className="block text-[11px] text-warning">Demonstração</span>}</Td>
                    <Td>{e.kind === "receivable" ? "A receber" : "A pagar"}</Td>
                    <Td className="text-muted">{e.categoryName ?? "Sem categoria"}</Td>
                    <Td className="text-muted">{e.companyName ?? e.productName ?? "—"}</Td>
                    <Td>{date(e.dueDate, o)}{e.paidAt && <span className="block text-[11px] text-muted">pago em {date(e.paidAt, o)}</span>}</Td>
                    <Td className={`whitespace-nowrap font-medium ${e.kind === "receivable" ? "text-success" : "text-danger"}`}>{e.kind === "receivable" ? "+" : "−"}{m(Number(e.amountCents))}</Td>
                    <Td>{overdue ? <Badge tone="danger">Vencido</Badge> : <Badge tone={st.tone}>{st.label}</Badge>}</Td>
                    <Td className="text-right">{canWrite && <EntryActions id={e.id} status={e.status} kind={e.kind} />}</Td>
                  </tr>
                );
              })}
            </Table>
          ) : <Empty title="Nenhum lançamento neste filtro." />}
        </Card>
      ),
    },
    {
      key: "dre", label: "DRE gerencial",
      content: (
        <Card>
          <CardTitle sub="Regime de caixa, por mês do pagamento. Últimos 6 meses.">Demonstração de resultado (gerencial)</CardTitle>
          <Table head={["Linha", ...dre.months.map((d) => monthLabel(d.month))]}>
            {DRE_LINES.map((l) => (
              <tr key={l.label} className={l.strong ? "bg-bg-2/40" : ""}>
                <Td className={l.strong ? "font-semibold" : "text-muted"}>{l.label}</Td>
                {dre.months.map((d) => {
                  const v = l.get(d);
                  return <Td key={d.month} className={`whitespace-nowrap text-right tabular-nums ${l.strong ? "font-semibold" : ""} ${v != null && v < 0 && l.strong ? "text-danger" : ""}`}>{l.pct ? pct(v, ctx.locale) : v === 0 ? "—" : m(v ?? 0)}</Td>;
                })}
              </tr>
            ))}
          </Table>
          <EvidenceNote premises={[...dre.evidence.assumptions, ...dre.evidence.calculations]} limitations={dre.evidence.limitations} confidence={dre.evidence.confidence} />
          <div className="mt-6 grid gap-4 md:grid-cols-3">
            <Stat label="Ponto de equilíbrio (receita bruta/mês)" value={be.computable ? m(be.breakEvenReceitaBruta!) : "—"} hint={be.computable ? `Média atual: ${m(be.avgReceitaBruta)}` : be.reason} />
            <Stat label="Índice de margem de contribuição" value={be.contributionRatio != null ? pct(be.contributionRatio * 100, ctx.locale) : "—"} hint={`Meses-base: ${be.basisMonths.join(", ") || "nenhum"}`} />
            <Stat label="Folga sobre o equilíbrio" value={be.gapReceitaBruta != null ? m(be.gapReceitaBruta) : "—"} hint="Receita bruta média − ponto de equilíbrio" />
          </div>
          {be.calculations.length > 0 && <EvidenceNote premises={[...be.calculations, ...be.premises]} confidence={be.evidence.confidence} />}
        </Card>
      ),
    },
    {
      key: "cash", label: "Fluxo de caixa",
      content: (
        <Card>
          <CardTitle sub="Próximas 13 semanas, a partir das contas em aberto.">Fluxo de caixa projetado</CardTitle>
          <div className="mb-4 grid gap-3 sm:grid-cols-4">
            <Stat label="Entradas confirmadas" value={m(cash.totalInflowCents)} />
            <Stat label="Saídas confirmadas" value={m(cash.totalOutflowCents)} />
            <Stat label="Saldo do período" value={m(cash.totalInflowCents - cash.totalOutflowCents)} />
            <Stat label="Vencidos fora da projeção" value={m(cash.overdueReceivableCents)} hint={`A pagar vencido: ${m(cash.overduePayableCents)}`} />
          </div>
          <CashflowChart buckets={cash.buckets} locale={ctx.locale} currency={ctx.currency} hasEstimate={!!cash.estimate} />
          <EvidenceNote premises={cash.premises} limitations={[...cash.evidence.missingData, ...cash.evidence.limitations]} confidence={cash.evidence.confidence} />
        </Card>
      ),
    },
    {
      key: "aging", label: "Inadimplência",
      content: (
        <div className="grid gap-6 lg:grid-cols-2">
          <Card>
            <CardTitle sub={aging.formula}>Recebíveis vencidos</CardTitle>
            <div className="mb-4 grid gap-3 sm:grid-cols-2">
              <Stat label="Taxa de inadimplência (90 dias)" value={pct(aging.ratePct, ctx.locale)} />
              <Stat label="Total vencido em aberto" value={m(aging.overdueCents)} hint={`${aging.overdueCount} títulos`} />
            </div>
            <div className="space-y-3">
              {aging.buckets.map((b) => (
                <div key={b.label}>
                  <div className="mb-1 flex justify-between text-xs"><span>{b.label} <span className="text-muted">({b.count})</span></span><span className="font-medium">{m(b.cents)}</span></div>
                  <Progress value={aging.overdueCents ? (b.cents / aging.overdueCents) * 100 : 0} tone="danger" />
                </div>
              ))}
            </div>
          </Card>
          <Card>
            <CardTitle sub="Clientes com maior valor vencido.">Por cliente</CardTitle>
            {aging.byClient.length ? (
              <Table head={["Cliente", "Títulos", "Vencido"]}>
                {aging.byClient.map((c) => <tr key={c.name}><Td>{c.name}</Td><Td>{c.count}</Td><Td className="font-medium text-danger">{m(c.cents)}</Td></tr>)}
              </Table>
            ) : <Empty title="Nenhum recebível vencido." />}
            <EvidenceNote limitations={aging.evidence.limitations} confidence={aging.evidence.confidence} />
          </Card>
        </div>
      ),
    },
    {
      key: "profit", label: "Rentabilidade",
      content: (
        <div className="grid gap-6 lg:grid-cols-2">
          {[byClient, byProduct].map((p) => (
            <Card key={p.by}>
              <CardTitle sub={`Últimos ${p.days} dias · margem direta (sem rateio de despesas fixas).`}>Rentabilidade por {p.by === "client" ? "cliente" : "produto"}</CardTitle>
              <p className="mb-3 text-xs text-warning">{p.note}</p>
              {p.rows.length ? (
                <Table head={[p.by === "client" ? "Cliente" : "Produto", "Receita", "Custos diretos", "Margem"]}>
                  {[...p.rows.slice(0, 8), ...(p.rows.length > 10 ? p.rows.slice(-2) : p.rows.slice(8, 10))].map((r) => (
                    <tr key={r.id}><Td>{r.name}</Td><Td>{m(r.revenueCents)}</Td><Td className="text-muted">{m(r.directCostsCents)}</Td>
                      <Td className={r.marginCents < 0 ? "font-medium text-danger" : "font-medium"}>{m(r.marginCents)} <span className="text-[11px] text-muted">{pct(r.marginPct, ctx.locale)}</span></Td></tr>
                  ))}
                </Table>
              ) : <Empty title="Nenhum lançamento vinculado.">Vincule lançamentos a {p.by === "client" ? "clientes" : "produtos"} para ver a margem.</Empty>}
              <EvidenceNote premises={p.evidence.assumptions} limitations={p.evidence.limitations} confidence={p.evidence.confidence} />
            </Card>
          ))}
        </div>
      ),
    },
    {
      key: "budget", label: "Orçamento",
      content: (
        <Card>
          <CardTitle sub={`Mês ${budget.month} · realizado = lançamentos pagos no mês.`}>Orçado x realizado</CardTitle>
          {canWrite && (
            <div className="mb-4"><Collapsible label="Definir orçamento">
              <FieldsForm url="/api/finance/budgets" columns={3} submitLabel="Salvar orçamento" success="Orçamento salvo."
                fields={[
                  { name: "categoryId", label: "Categoria", type: "select", defaultValue: catOptions[0]?.value ?? "", options: catOptions },
                  { name: "month", label: "Mês (AAAA-MM)", defaultValue: budget.month, required: true },
                  { name: "amountCents", label: `Valor orçado (${ctx.currency})`, transform: "cents", required: true },
                ]} />
            </Collapsible></div>
          )}
          {budget.rows.length ? (
            <Table head={["Categoria", "Orçado", "Realizado", "Variação", "Uso"]}>
              {budget.rows.map((r) => (
                <tr key={r.categoryId}>
                  <Td>{r.name} <span className="text-[11px] text-muted">{r.kind === "revenue" ? "receita" : "despesa"}</span></Td>
                  <Td>{m(r.budgetCents)}</Td><Td>{m(r.actualCents)}</Td>
                  <Td className={(r.kind === "expense" ? r.varianceCents > 0 : r.varianceCents < 0) ? "text-danger" : "text-success"}>{m(r.varianceCents)}</Td>
                  <Td className="w-40"><Progress value={r.usedPct ?? 0} tone={(r.usedPct ?? 0) > 100 ? (r.kind === "expense" ? "danger" : "success") : "primary"} /><span className="text-[11px] text-muted">{pct(r.usedPct, ctx.locale)}</span></Td>
                </tr>
              ))}
            </Table>
          ) : <Empty title="Nenhum orçamento definido para este mês.">{canWrite ? "Use \"Definir orçamento\" para cadastrar valores por categoria." : "Peça a um gestor para cadastrar o orçamento."}</Empty>}
        </Card>
      ),
    },
    {
      key: "assistant", label: "Assistente financeiro",
      content: (
        <Card>
          <CardTitle sub="Respostas calculadas a partir dos seus lançamentos, com premissas e fontes. Nada é inventado: se faltar um dado, o assistente pergunta.">Assistente financeiro</CardTitle>
          <FinanceAssistant suggestions={SUGGESTED_QUESTIONS} />
        </Card>
      ),
    },
  ];

  return (
    <div className="mx-auto max-w-7xl space-y-6">
      <PageHeader title="Financeiro" subtitle="Financial Intelligence 360: contas a pagar e a receber, DRE gerencial, fluxo de caixa, inadimplência e rentabilidade." />
      {integrationBanner}
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="Receita recebida (30 dias)" value={m(snap.revenueCents)} hint={delta(snap.revenueCents, snap.previous.revenueCents)} />
        <Stat label="Despesas pagas (30 dias)" value={m(snap.expensesCents)} hint={delta(snap.expensesCents, snap.previous.expensesCents)} />
        <Stat label="Resultado de caixa (30 dias)" value={<span className={snap.resultCents < 0 ? "text-danger" : ""}>{m(snap.resultCents)}</span>} hint={delta(snap.resultCents, prevRes)} />
        <Stat label="Margem (30 dias)" value={pct(snap.marginPct, ctx.locale)} hint="Resultado ÷ receita recebida" />
        <Stat label="A receber em aberto" value={m(snap.receivableOpenCents)} />
        <Stat label="A pagar em aberto" value={m(snap.payableOpenCents)} />
        <Stat label="Inadimplência" value={<span className={snap.overdueReceivableCents ? "text-danger" : ""}>{m(snap.overdueReceivableCents)}</span>} hint={`${snap.overdueReceivableCount} títulos vencidos`} />
        <Stat label="Saldo projetado (30 dias)" value={m(snap.next30.netCents)} hint={`Entradas ${m(snap.next30.inflowCents)} · saídas ${m(snap.next30.outflowCents)} (não inclui saldo bancário)`} />
      </div>
      <p className="text-xs text-muted">
        Para comparação: <strong>{crm.label}</strong> nos últimos 30 dias = {m(crm.cents)} em {crm.deals} negócios. Os indicadores acima são dinheiro efetivamente recebido ou pago.
      </p>
      <FinanceTabs tabs={tabs} />
    </div>
  );
}
