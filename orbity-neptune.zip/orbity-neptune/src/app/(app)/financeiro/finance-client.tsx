"use client";
import { useState, type ReactNode } from "react";
import { Bar, CartesianGrid, ComposedChart, Legend, Line, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Badge, Button, Input, cx } from "@/components/ui";
import { useAction, Feedback } from "@/components/ui/use-action";

/** Abas da tela financeira. Os painéis chegam prontos do servidor. */
export function FinanceTabs({ tabs }: { tabs: { key: string; label: string; content: ReactNode }[] }) {
  const [active, setActive] = useState(tabs[0]?.key);
  return (
    <div>
      <div role="tablist" aria-label="Seções do financeiro" className="mb-4 flex gap-1 overflow-x-auto border-b border-line">
        {tabs.map((t) => (
          <button key={t.key} role="tab" aria-selected={active === t.key} onClick={() => setActive(t.key)}
            className={cx("whitespace-nowrap border-b-2 px-3 py-2 text-sm font-medium transition", active === t.key ? "border-primary-2 text-fg" : "border-transparent text-muted hover:text-fg")}>
            {t.label}
          </button>
        ))}
      </div>
      {tabs.map((t) => <div key={t.key} role="tabpanel" hidden={active !== t.key}>{t.content}</div>)}
    </div>
  );
}

type Bucket = { label: string; inflowCents: number; outflowCents: number; cumulativeCents: number; estInflowCents: number; estOutflowCents: number };

export function CashflowChart({ buckets, locale, currency, hasEstimate }: { buckets: Bucket[]; locale: string; currency: string; hasEstimate: boolean }) {
  const [showEst, setShowEst] = useState(false);
  const cur = new Intl.NumberFormat(locale, { style: "currency", currency, maximumFractionDigits: 0 });
  const compact = new Intl.NumberFormat(locale, { notation: "compact", maximumFractionDigits: 1 });
  const rows = buckets.map((b) => ({
    label: b.label, entradas: b.inflowCents / 100, saidas: -b.outflowCents / 100, acumulado: b.cumulativeCents / 100,
    estEntradas: b.estInflowCents / 100, estSaidas: -b.estOutflowCents / 100,
  }));
  const names: Record<string, string> = { entradas: "Entradas confirmadas", saidas: "Saídas confirmadas", acumulado: "Saldo acumulado confirmado", estEntradas: "Entradas (estimativa recorrente)", estSaidas: "Saídas (estimativa recorrente)" };
  return (
    <div>
      {hasEstimate && (
        <label className="mb-2 flex items-center gap-2 text-xs text-muted">
          <input type="checkbox" checked={showEst} onChange={(e) => setShowEst(e.target.checked)} /> Mostrar estimativa recorrente <Badge tone="warning">Estimativa</Badge>
        </label>
      )}
      <div className="h-72 w-full" role="img" aria-label="Fluxo de caixa projetado por semana: entradas, saídas e saldo acumulado">
        <ResponsiveContainer>
          <ComposedChart data={rows} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
            <CartesianGrid stroke="var(--border)" strokeDasharray="3 3" vertical={false} />
            <XAxis dataKey="label" tick={{ fill: "var(--muted)", fontSize: 11 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fill: "var(--muted)", fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={(v) => compact.format(v)} width={52} />
            <Tooltip contentStyle={{ background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 10, color: "var(--text)" }}
              formatter={(v, n) => [cur.format(Math.abs(Number(v))), names[String(n)] ?? String(n)]} />
            <Legend formatter={(v) => <span style={{ color: "var(--muted)", fontSize: 12 }}>{names[String(v)] ?? String(v)}</span>} />
            <Bar dataKey="entradas" fill="#22c55e" radius={[4, 4, 0, 0]} />
            <Bar dataKey="saidas" fill="#ef4444" radius={[0, 0, 4, 4]} />
            {showEst && <Bar dataKey="estEntradas" fill="#22c55e" fillOpacity={0.3} />}
            {showEst && <Bar dataKey="estSaidas" fill="#ef4444" fillOpacity={0.3} />}
            <Line type="monotone" dataKey="acumulado" stroke="var(--primary-2)" strokeWidth={2.5} dot={{ r: 2.5 }} />
          </ComposedChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

type Answer = {
  intent: string; answer: string; calculations: string[]; premises: string[]; sources: string[]; missingData: string[];
  evidence: { confidence: number; limitations: string[] }; needsInput?: string;
};

export function FinanceAssistant({ suggestions }: { suggestions: string[] }) {
  const [q, setQ] = useState("");
  const [a, setA] = useState<Answer | null>(null);
  const { run, loading, error } = useAction();
  const ask = async (question: string) => {
    if (question.trim().length < 3) return;
    setQ(question);
    const r = await run<Answer>("/api/finance/assistant", { question }, { refresh: false });
    if (r) setA(r);
  };
  const conf = a?.evidence.confidence ?? 0;
  return (
    <div className="space-y-4">
      <form className="flex flex-col gap-2 sm:flex-row" onSubmit={(e) => { e.preventDefault(); ask(q); }}>
        <Input aria-label="Pergunta financeira" placeholder="Ex.: Posso contratar 3 funcionários com custo de R$ 6.500 cada?" value={q} onChange={(e) => setQ(e.target.value)} maxLength={500} />
        <Button type="submit" disabled={loading || q.trim().length < 3}>{loading ? "Calculando..." : "Perguntar"}</Button>
      </form>
      <div className="flex flex-wrap gap-2">
        {suggestions.map((s) => (
          <button key={s} type="button" onClick={() => ask(s)} className="rounded-full border border-line bg-bg-2 px-3 py-1 text-xs text-muted hover:border-primary-2 hover:text-fg">{s}</button>
        ))}
      </div>
      <Feedback error={error} />
      {a && (
        <div className="space-y-3 rounded-xl border border-line bg-bg-2/60 p-4 text-sm">
          <div className="flex flex-wrap items-center gap-2">
            <Badge tone="info">Cálculo determinístico</Badge>
            <Badge tone={conf >= 0.75 ? "success" : conf >= 0.5 ? "warning" : "neutral"}>Confiança: {conf >= 0.75 ? "alta" : conf >= 0.5 ? "média" : conf > 0 ? "baixa" : "insuficiente"}</Badge>
            {a.needsInput && <Badge tone="warning">Faltam informações</Badge>}
          </div>
          <p className="text-fg">{a.answer}</p>
          {a.calculations.length > 0 && <Section title="Cálculos" items={a.calculations} />}
          {a.premises.length > 0 && <Section title="Premissas" items={a.premises} />}
          {a.missingData.filter(Boolean).length > 0 && <Section title="Dados ausentes" items={a.missingData.filter(Boolean)} />}
          {a.sources.length > 0 && <p className="text-xs text-muted">Fontes: {a.sources.join(" · ")}</p>}
          <p className="text-[11px] text-muted">{a.evidence.limitations.join(" ")}</p>
        </div>
      )}
    </div>
  );
}

function Section({ title, items }: { title: string; items: string[] }) {
  return (
    <div>
      <p className="text-xs font-semibold uppercase tracking-wide text-muted">{title}</p>
      <ul className="mt-1 list-disc space-y-0.5 pl-5 text-xs text-fg/90">{items.map((i, k) => <li key={k}>{i}</li>)}</ul>
    </div>
  );
}

/** Ações de um lançamento: baixar (pagar/receber), cancelar ou reabrir. */
export function EntryActions({ id, status, kind }: { id: string; status: string; kind: string }) {
  const { run, loading, error } = useAction();
  const act = (action: "pay" | "cancel" | "reopen", success: string) => run(`/api/finance/entries/${id}`, { action }, { method: "PATCH", success });
  return (
    <span className="inline-flex flex-col items-end">
      <span className="flex gap-1">
        {status === "open" && <Button size="sm" variant="secondary" disabled={loading} onClick={() => act("pay", "Baixado.")}>{kind === "receivable" ? "Receber" : "Pagar"}</Button>}
        {status === "open" && <Button size="sm" variant="ghost" disabled={loading} onClick={() => act("cancel", "Cancelado.")}>Cancelar</Button>}
        {status !== "open" && <Button size="sm" variant="ghost" disabled={loading} onClick={() => act("reopen", "Reaberto.")}>Reabrir</Button>}
      </span>
      <Feedback error={error} />
    </span>
  );
}
