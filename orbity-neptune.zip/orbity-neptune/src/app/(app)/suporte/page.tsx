import { requirePageContext } from "@/server/auth/next";
import { listTickets, SLA_HOURS } from "@/server/domains/support";
import { Badge, Card, CardTitle, Empty, PageHeader, Table, Td } from "@/components/ui";
import { ActionSelect, FieldsForm } from "@/components/admin/actions";
import { SupportAssistant } from "@/components/admin/support-assistant";
import { date } from "@/lib/format";

export const metadata = { title: "Suporte" };

const PRIORITY: Record<string, string> = { low: "Baixa", medium: "Média", high: "Alta", urgent: "Urgente" };
const STATUS: Record<string, string> = { open: "Aberto", in_progress: "Em andamento", escalated: "Escalonado", resolved: "Resolvido" };

export default async function SuportePage() {
  const ctx = await requirePageContext("support:use");
  const o = { locale: ctx.locale, timezone: ctx.timezone };
  const tickets = await listTickets(ctx);
  const now = Date.now();

  return (
    <div className="mx-auto max-w-7xl space-y-6">
      <PageHeader title="Suporte" subtitle="Assistente de IA, chamados com SLA e atendimento humano." />
      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardTitle sub="Responde com base na documentação da plataforma. Se não souber, recomenda abrir um chamado.">Assistente de suporte</CardTitle>
          <SupportAssistant />
        </Card>
        <Card>
          <CardTitle sub={`SLA de primeira resposta: urgente ${SLA_HOURS.urgent}h · alta ${SLA_HOURS.high}h · média ${SLA_HOURS.medium}h · baixa ${SLA_HOURS.low}h`}>Abrir chamado</CardTitle>
          <FieldsForm url="/api/support" extra={{ action: "open" }} columns={2} submitLabel="Abrir chamado" success="Chamado aberto." reset
            fields={[
              { name: "subject", label: "Assunto", required: true },
              { name: "category", label: "Categoria", type: "select", defaultValue: "geral", options: [["geral", "Geral"], ["billing", "Billing"], ["integracoes", "Integrações"], ["ia", "IA"], ["crm", "CRM"], ["acesso", "Acesso"], ["bug", "Erro/bug"]].map(([value, label]) => ({ value, label })) },
              { name: "priority", label: "Prioridade", type: "select", defaultValue: "medium", options: Object.entries(PRIORITY).map(([value, label]) => ({ value, label })) },
              { name: "description", label: "Descrição", type: "textarea", required: true },
            ]} />
        </Card>
      </div>
      <Card>
        <CardTitle>Meus chamados</CardTitle>
        {tickets.length ? (
          <Table head={["Assunto", "Categoria", "Prioridade", "Status", "SLA", "Aberto em", "Satisfação"]}>
            {tickets.map((t) => {
              const overdue = t.status !== "resolved" && new Date(t.slaDueAt).getTime() < now;
              return (
                <tr key={t.id}>
                  <Td>{t.subject}</Td><Td className="text-xs">{t.category}</Td>
                  <Td><Badge tone={t.priority === "urgent" ? "danger" : t.priority === "high" ? "warning" : "neutral"}>{PRIORITY[t.priority] ?? t.priority}</Badge></Td>
                  <Td><Badge tone={t.status === "resolved" ? "success" : "info"}>{STATUS[t.status] ?? t.status}</Badge></Td>
                  <Td>{overdue ? <Badge tone="danger">Vencido</Badge> : <span className="text-xs">{date(t.slaDueAt, o, true)}</span>}</Td>
                  <Td className="text-xs">{date(t.createdAt, o, true)}</Td>
                  <Td>{t.satisfaction ? `${"★".repeat(t.satisfaction)}` : (
                    <ActionSelect label="Avaliar" url="/api/support" value="" options={[{ value: "", label: "Avaliar..." }, ...[5, 4, 3, 2, 1].map((n) => ({ value: String(n), label: "★".repeat(n) }))]}
                      bodyBase={{ action: "rate", id: t.id }} valueKey="satisfaction" numeric />
                  )}</Td>
                </tr>
              );
            })}
          </Table>
        ) : <Empty title="Nenhum chamado aberto." />}
      </Card>
    </div>
  );
}
