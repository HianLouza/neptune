import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { requirePageContext } from "@/server/auth/next";
import { getAgent } from "@/server/ai/agents/admin";
import { APPROVAL_THRESHOLD } from "@/server/ai/evaluation";
import { Badge, Card, CardTitle, Empty, PageHeader, SimBadge, Table, Td } from "@/components/ui";
import { AgentSettingsForm, EvalCases, FeedbackButtons, Playground, VersionsPanel } from "@/components/agents/agent-detail";
import { AgentToggle } from "@/components/agents/agent-toggle";
import { AUTONOMY_LABEL } from "@/components/agents/labels";
import { date } from "@/lib/format";

export async function generateMetadata({ params }: { params: Promise<{ key: string }> }) {
  return { title: `Agente ${(await params).key}` };
}

export default async function AgentPage({ params }: { params: Promise<{ key: string }> }) {
  const ctx = await requirePageContext("ai:use");
  const { key } = await params;
  const data = await getAgent(ctx, key).catch(() => null);
  if (!data) notFound();
  const { agent, versions, executions, cases, runs } = data;
  const canManage = ctx.permissions.includes("*") || ctx.permissions.includes("ai:manage");
  const lo = { locale: ctx.locale, timezone: ctx.timezone };

  return (
    <div className="mx-auto max-w-[1500px] space-y-5">
      <Link href="/agentes" className="inline-flex items-center gap-1 text-sm text-muted hover:text-fg"><ArrowLeft size={14} /> Agentes</Link>
      <PageHeader title={agent.name} subtitle={agent.objective} actions={<><Badge tone={agent.enabled ? "success" : "neutral"}>{agent.enabled ? "ativo" : "inativo"}</Badge><AgentToggle agentKey={agent.key} enabled={agent.enabled} canManage={canManage} /></>} />

      <div className="grid gap-5 lg:grid-cols-3">
        <Card>
          <CardTitle sub={`Identificador: ${agent.key}`}>Configuração</CardTitle>
          <dl className="mb-4 space-y-1 text-xs">
            <div><dt className="inline text-muted">Autonomia atual: </dt><dd className="inline">{AUTONOMY_LABEL[agent.autonomy]}</dd></div>
            <div><dt className="inline text-muted">Ferramentas: </dt><dd className="inline">{agent.tools.join(", ") || "—"}</dd></div>
            <div><dt className="inline text-muted">Permissões: </dt><dd className="inline">{agent.permissions.join(", ") || "—"}</dd></div>
            <div><dt className="inline text-muted">Memória/base: </dt><dd className="inline">contexto autorizado da organização (RAG isolado por tenant)</dd></div>
          </dl>
          <AgentSettingsForm agent={agent} canManage={canManage} canGovern={ctx.permissions.includes("*") || ctx.permissions.includes("ai:govern")} />
        </Card>
        <Card className="lg:col-span-2">
          <CardTitle sub="Execuções reais são registradas, cobradas em créditos e auditadas">Playground de teste</CardTitle>
          <Playground agentKey={agent.key} versions={versions.map((v) => v.version)} enabled={agent.enabled} />
        </Card>
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        <Card>
          <CardTitle sub="Versionamento com aprovação por avaliação e rollback">Versões do prompt</CardTitle>
          <VersionsPanel agentKey={agent.key} versions={versions} activeVersion={agent.activeVersion} canManage={canManage} threshold={APPROVAL_THRESHOLD} />
        </Card>
        <Card>
          <CardTitle sub="AI Evaluation Center — conjuntos de teste, incluindo adversariais">Casos de avaliação</CardTitle>
          <EvalCases agentKey={agent.key} cases={cases} canManage={canManage} />
          <div className="mt-5">
            <p className="mb-2 text-xs font-semibold text-muted">Histórico de avaliações</p>
            {runs.length ? (
              <Table head={["Data", "Versão", "Modelo", "Acertos", "Latência"]}>
                {runs.map((r) => (
                  <tr key={r.id}>
                    <Td>{date(r.createdAt, lo, true)}</Td><Td>v{r.promptVersion}</Td><Td>{r.model}{r.model.startsWith("local-") && <> <SimBadge /></>}</Td>
                    <Td><Badge tone={r.passed / r.total >= APPROVAL_THRESHOLD ? "success" : "danger"}>{r.passed}/{r.total}</Badge></Td><Td>{r.avgLatencyMs} ms</Td>
                  </tr>
                ))}
              </Table>
            ) : <Empty title="Nenhuma avaliação executada" />}
            {runs.some((r) => r.model.startsWith("local-")) && <p className="mt-2 text-[11px] text-warning">Avaliações com o provedor simulado não medem a qualidade de um LLM real.</p>}
          </div>
        </Card>
      </div>

      <Card>
        <CardTitle sub="Últimas 30 execuções deste agente">Histórico de execuções</CardTitle>
        {executions.length ? (
          <Table head={["Data", "Status", "Provedor / modelo", "Tokens", "Créditos", "Latência", "Entrada", "Feedback"]}>
            {executions.map((e) => (
              <tr key={e.id}>
                <Td className="whitespace-nowrap">{date(e.createdAt, lo, true)}</Td>
                <Td><Badge tone={e.status === "success" ? "success" : e.status === "blocked" || e.status === "error" ? "danger" : "warning"}>{e.status}</Badge></Td>
                <Td>{e.provider} / {e.model} {e.simulated && <SimBadge />}</Td>
                <Td>{e.inputTokens + e.outputTokens}</Td>
                <Td>{e.credits}</Td>
                <Td>{e.latencyMs} ms</Td>
                <Td className="max-w-xs truncate text-xs text-muted">{e.input}</Td>
                <Td><FeedbackButtons executionId={e.id} value={e.feedback} /></Td>
              </tr>
            ))}
          </Table>
        ) : <Empty title="Nenhuma execução ainda">Use o playground acima para testar o agente.</Empty>}
      </Card>
    </div>
  );
}
