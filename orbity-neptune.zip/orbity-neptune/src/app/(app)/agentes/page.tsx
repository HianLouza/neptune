import Link from "next/link";
import { and, count, eq, gte, sql } from "drizzle-orm";
import { requirePageContext } from "@/server/auth/next";
import { listAgents, providerStatus } from "@/server/ai/agents/admin";
import { aiExecutions } from "@/server/db/schema";
import { Badge, Card, CardTitle, PageHeader, SimBadge, Stat } from "@/components/ui";
import { AgentToggle } from "@/components/agents/agent-toggle";
import { num } from "@/lib/format";

import { AUTONOMY_LABEL } from "@/components/agents/labels";

export const metadata = { title: "IA & Agentes" };

export default async function AgentesPage() {
  const ctx = await requirePageContext("ai:use");
  const canManage = ctx.permissions.includes("*") || ctx.permissions.includes("ai:manage");
  const agents = await listAgents(ctx);
  const providers = providerStatus();
  const since = new Date(Date.now() - 30 * 864e5);
  const stats = await ctx.db.select({
    agentKey: aiExecutions.agentKey, n: count(),
    credits: sql<number>`coalesce(sum(${aiExecutions.credits}),0)::int`,
    blocked: sql<number>`count(*) filter (where ${aiExecutions.status} = 'blocked')::int`,
    simulated: sql<number>`count(*) filter (where ${aiExecutions.simulated})::int`,
    latency: sql<number>`coalesce(avg(${aiExecutions.latencyMs}),0)::int`,
    positive: sql<number>`count(*) filter (where ${aiExecutions.feedback} = 1)::int`,
    negative: sql<number>`count(*) filter (where ${aiExecutions.feedback} = -1)::int`,
  }).from(aiExecutions).where(and(eq(aiExecutions.organizationId, ctx.organizationId), gte(aiExecutions.createdAt, since))).groupBy(aiExecutions.agentKey);
  const tot = stats.reduce((a, s) => ({ n: a.n + s.n, credits: a.credits + s.credits, blocked: a.blocked + s.blocked, simulated: a.simulated + s.simulated }), { n: 0, credits: 0, blocked: 0, simulated: 0 });
  const realProvider = providers.some((p) => p.available && !p.simulated);

  return (
    <div className="mx-auto max-w-[1500px] space-y-5">
      <PageHeader title="IA & Agentes" subtitle="Centro de controle: agentes, versões de prompt, limites, avaliações e histórico de execuções." />

      <Card>
        <CardTitle sub="Camada independente de fornecedor com fallback automático na ordem abaixo">Provedores de IA</CardTitle>
        <div className="flex flex-wrap gap-3">
          {providers.map((p) => (
            <div key={p.name} className="flex items-center gap-2 rounded-xl border border-line bg-bg-2/60 px-4 py-2 text-sm">
              <span className={`h-2.5 w-2.5 rounded-full ${p.available ? "bg-success" : "bg-muted/50"}`} />
              <span className="font-medium">{p.name}</span>
              {p.simulated ? <SimBadge label="Simulação (sem LLM)" /> : <Badge tone={p.available ? "success" : "neutral"}>{p.available ? "configurado" : "requer credenciais"}</Badge>}
            </div>
          ))}
        </div>
        {!realProvider && <p className="mt-3 text-xs text-warning">Nenhum provedor de IA real configurado: todas as respostas são geradas em modo simulado (determinístico, sem custo). Configure ANTHROPIC_API_KEY ou OPENAI_API_KEY no ambiente.</p>}
      </Card>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Execuções (30 dias)" value={num(tot.n, ctx.locale)} />
        <Stat label="Créditos consumidos" value={num(tot.credits, ctx.locale)} />
        <Stat label="Bloqueios de segurança" value={num(tot.blocked, ctx.locale)} hint="Prompt injection e entradas inválidas" />
        <Stat label="Execuções simuladas" value={num(tot.simulated, ctx.locale)} />
      </div>

      <div className="grid gap-4 md:grid-cols-2 2xl:grid-cols-3">
        {agents.map((a) => {
          const s = stats.find((x) => x.agentKey === a.key);
          return (
            <Card key={a.id} className={a.enabled ? "" : "opacity-70"}>
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <Link href={`/agentes/${a.key}`} className="font-semibold hover:text-primary-2">{a.name}</Link>
                  <p className="text-xs text-muted"><code>{a.key}</code> · prompt v{a.activeVersion} · modelo {a.model}</p>
                </div>
                <Badge tone={a.enabled ? "success" : "neutral"}>{a.enabled ? "ativo" : "inativo"}</Badge>
              </div>
              <p className="mt-2 text-sm text-muted">{a.objective}</p>
              <div className="mt-3 flex flex-wrap gap-1.5">
                <Badge tone="primary">{AUTONOMY_LABEL[a.autonomy] ?? a.autonomy}</Badge>
                {a.tools.map((t) => <Badge key={t}>{t}</Badge>)}
              </div>
              <p className="mt-3 text-xs text-muted">
                Limites: {num(a.limits.maxTokensPerRun, ctx.locale)} tokens/execução · {num(a.limits.maxCreditsPerDay, ctx.locale)} créditos/dia
                {s ? ` · 30d: ${s.n} execuções, ${s.credits} créditos, ${s.latency} ms médio, 👍 ${s.positive} / 👎 ${s.negative}` : " · sem execuções em 30 dias"}
              </p>
              <div className="mt-4 flex items-center gap-2">
                <Link href={`/agentes/${a.key}`} className="rounded-lg border border-line bg-surface-2 px-3 py-1.5 text-xs font-medium hover:border-primary-2">Configurar e testar</Link>
                <AgentToggle agentKey={a.key} enabled={a.enabled} canManage={canManage} />
              </div>
            </Card>
          );
        })}
      </div>
      <p className="text-xs text-muted">Regra de governança: ações sensíveis (envio de mensagens externas, cobranças, webhooks) sempre exigem aprovação humana, independentemente do nível de autonomia.</p>
    </div>
  );
}
