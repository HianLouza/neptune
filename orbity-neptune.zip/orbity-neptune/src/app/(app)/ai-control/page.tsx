import { eq } from "drizzle-orm";
import { requirePageContext } from "@/server/auth/next";
import { controlPlaneOverview } from "@/server/ai/control-plane";
import { memberships, users } from "@/server/db/schema";
import { PageHeader } from "@/components/ui";
import { ControlPlaneClient } from "./control-plane-client";
import { aiSuggestionMetrics } from "@/server/ai/collab/metrics";
import { AiSuggestionMetricsCard } from "@/components/ai-collab/metrics-card";

export const metadata = { title: "Controle de IA" };

export default async function AiControlPage() {
  const ctx = await requirePageContext("ai:manage");
  const [data, suggestions] = await Promise.all([controlPlaneOverview(ctx), aiSuggestionMetrics(ctx, 30)]);
  const people = await ctx.db.select({ id: users.id, name: users.name }).from(memberships)
    .innerJoin(users, eq(users.id, memberships.userId)).where(eq(memberships.organizationId, ctx.organizationId)).orderBy(users.name);

  return (
    <div className="mx-auto max-w-[1500px] space-y-5">
      <PageHeader
        title="Controle de IA"
        subtitle="Governança da força de trabalho digital: níveis de autonomia, kill switch, orçamentos de IA, monitoramento e prevenção de conflitos."
      />
      <ControlPlaneClient
        data={JSON.parse(JSON.stringify(data))}
        people={people}
        locale={ctx.locale}
      />
      <AiSuggestionMetricsCard m={suggestions} title="Sugestões de IA: desempenho dos agentes e da equipe" />
    </div>
  );
}
