"use client";
import { useState } from "react";
import { Badge, Button, Card, CardTitle, Empty, Field, Input, Progress, Select, Stat, Table, Td, cx } from "@/components/ui";
import { Feedback, useAction } from "@/components/ui/use-action";

type Level = { level: number; key: string; label: string; description: string };
type Metrics = {
  agentKey: string; executions: number; success: number; fallback: number; blocked: number; errors: number; simulated: number;
  avgLatencyMs: number; tokens: number; credits: number; positive: number; negative: number; successRate: number | null;
  humanInterventions: { approved: number; rejected: number; pending: number } | null;
};
type Worker = {
  kind: "Agente digital"; key: string; name: string; function: string; domain: string; owner: { id: string; name: string } | null;
  tools: string[]; permissions: string[]; model: string; provider: string; autonomyLevel: number; autonomyLabel: string;
  status: string; enabled: boolean; limits: { maxTokensPerRun: number; maxCreditsPerDay: number }; monthlyCreditBudget: number | null;
  blockedBy: string | null; metrics: Metrics | null;
};
type Switch = { id: string; organizationId: string | null; scope: string; target: string; reason: string; active: boolean; createdAt: string; releasedAt: string | null };
type Budget = { id: string; scope: string; target: string; monthlyCredits: number; alertPct: number; hardStop: boolean; usedThisMonth: number; usedPct: number };
type Conflict = { kind: string; severity: "high" | "medium" | "low"; title: string; evidence: string; agents?: string[] };
export type ControlPlaneData = {
  canGovern: boolean; isPlatformAdmin: boolean; levels: Level[]; sensitiveActions: Record<string, string>;
  workforce: Worker[]; switches: Switch[]; budgets: Budget[]; conflicts: Conflict[];
};

const TABS = [
  ["workforce", "Força de trabalho digital"], ["governance", "Governança"], ["killswitch", "Kill switch"],
  ["budgets", "Orçamentos"], ["monitoring", "Monitoramento"], ["conflicts", "Conflitos"],
] as const;
type Tab = (typeof TABS)[number][0];

const STATUS_LABEL: Record<string, string> = { active: "Ativo", paused: "Pausado", suspended: "Suspenso", retired: "Aposentado" };
const STATUS_TONE: Record<string, "success" | "warning" | "danger" | "neutral"> = { active: "success", paused: "warning", suspended: "danger", retired: "neutral" };
const SCOPES: [string, string][] = [
  ["agent", "Um agente"], ["agent_domain", "Domínio de agentes"], ["all_ai", "Toda a IA da organização"], ["integration", "Uma integração"],
  ["tool", "Uma ferramenta"], ["workflow", "Uma automação (ID)"], ["action_category", "Uma categoria de ação"],
];
const ACTIONS: [string, string][] = [
  ["send_message", "Enviar mensagem"], ["webhook", "Chamar webhook"], ["create_task", "Criar tarefa"], ["notify", "Notificar equipe"],
  ["update_lead_status", "Atualizar status do lead"], ["log_activity", "Registrar atividade"],
];
const INTEGRATIONS = ["whatsapp", "email_smtp", "webchat", "instagram", "stripe", "mercadopago", "asaas", "hubspot", "salesforce", "pipedrive"];

export function ControlPlaneClient({ data, people, locale }: { data: ControlPlaneData; people: { id: string; name: string }[]; locale: string }) {
  const [tab, setTab] = useState<Tab>("workforce");
  const n = (v: number) => new Intl.NumberFormat(locale).format(v);
  const activeSwitches = data.switches.filter((s) => s.active);
  const blocked = data.workforce.filter((w) => w.blockedBy).length;

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Agentes digitais" value={n(data.workforce.length)} hint={`${blocked} interrompido(s) ou fora de operação`} />
        <Stat label="Kill switches ativos" value={n(activeSwitches.length)} hint={activeSwitches.length ? "Há interrupções em vigor" : "Nenhuma interrupção"} />
        <Stat label="Orçamentos de IA" value={n(data.budgets.length)} hint={data.budgets.some((b) => b.usedPct >= b.alertPct) ? "Algum orçamento passou do alerta" : "Dentro dos limites"} />
        <Stat label="Alertas de conflito" value={n(data.conflicts.length)} hint="Últimos 7 a 30 dias" />
      </div>

      {!data.canGovern && (
        <p className="rounded-xl border border-warning/30 bg-warning/10 px-4 py-2 text-xs text-warning">
          Você pode consultar o AI Control Plane, mas alterar autonomia, status, kill switches e orçamentos exige a permissão de governança de IA (administradores).
        </p>
      )}

      <div role="tablist" aria-label="Seções do AI Control Plane" className="flex flex-wrap gap-2">
        {TABS.map(([k, label]) => (
          <button key={k} role="tab" aria-selected={tab === k} onClick={() => setTab(k)}
            className={cx("rounded-lg border px-3 py-1.5 text-sm", tab === k ? "border-primary-2 bg-primary/20 text-fg" : "border-line text-muted hover:text-fg")}>
            {label}{k === "killswitch" && activeSwitches.length ? ` (${activeSwitches.length})` : k === "conflicts" && data.conflicts.length ? ` (${data.conflicts.length})` : ""}
          </button>
        ))}
      </div>

      {tab === "workforce" && <Workforce data={data} n={n} />}
      {tab === "governance" && <Governance data={data} people={people} />}
      {tab === "killswitch" && <KillSwitch data={data} locale={locale} />}
      {tab === "budgets" && <Budgets data={data} n={n} />}
      {tab === "monitoring" && <Monitoring data={data} n={n} />}
      {tab === "conflicts" && <Conflicts data={data} />}
    </div>
  );
}

function Workforce({ data, n }: { data: ControlPlaneData; n: (v: number) => string }) {
  return (
    <Card>
      <CardTitle sub="Cada agente digital tem identidade, função, responsável, ferramentas, permissões, autonomia, limites, custo e desempenho. Colaboradores humanos ficam em Administração.">Força de trabalho digital</CardTitle>
      <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
        {data.workforce.map((w) => (
          <div key={w.key} className="space-y-2 rounded-xl border border-line bg-bg-2/60 p-3 text-sm">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="font-semibold">{w.name}</p>
                <p className="text-xs text-muted">{w.key} · domínio {w.domain}</p>
              </div>
              <div className="flex gap-1">
                <Badge tone="info">Agente digital</Badge>
                <Badge tone={w.blockedBy ? "danger" : STATUS_TONE[w.status] ?? "neutral"}>{w.blockedBy ? "Interrompido" : STATUS_LABEL[w.status] ?? w.status}</Badge>
              </div>
            </div>
            <p className="text-muted">{w.function}</p>
            <dl className="grid grid-cols-2 gap-x-3 gap-y-1 text-xs">
              <dt className="text-muted">Autonomia</dt><dd>Nível {w.autonomyLevel} · {w.autonomyLabel}</dd>
              <dt className="text-muted">Responsável</dt><dd>{w.owner?.name ?? "Não definido"}</dd>
              <dt className="text-muted">Modelo / provedor</dt><dd>{w.model} · {w.provider}</dd>
              <dt className="text-muted">Limites</dt><dd>{n(w.limits.maxTokensPerRun)} tokens/execução · {n(w.limits.maxCreditsPerDay)} créditos/dia</dd>
              <dt className="text-muted">Orçamento mensal</dt><dd>{w.monthlyCreditBudget == null ? "Usa o da organização" : `${n(w.monthlyCreditBudget)} créditos`}</dd>
              <dt className="text-muted">30 dias</dt><dd>{w.metrics ? `${n(w.metrics.executions)} execuções · ${n(w.metrics.credits)} créditos · sucesso ${w.metrics.successRate ?? "—"}%` : "Sem execuções"}</dd>
            </dl>
            <div className="flex flex-wrap gap-1">{w.tools.map((t) => <Badge key={t}>{t}</Badge>)}</div>
            <p className="text-xs text-muted">Permissões: {w.permissions.join(", ") || "nenhuma"}</p>
            {w.blockedBy && <p className="text-xs text-danger">{w.blockedBy}</p>}
          </div>
        ))}
      </div>
    </Card>
  );
}

function Governance({ data, people }: { data: ControlPlaneData; people: { id: string; name: string }[] }) {
  return (
    <div className="space-y-4">
      <Card>
        <CardTitle sub="Ações sensíveis exigem aprovação humana em qualquer nível.">Níveis de autonomia</CardTitle>
        <ol className="grid gap-2 md:grid-cols-5">
          {data.levels.map((l) => (
            <li key={l.level} className="rounded-xl border border-line bg-bg-2/60 p-3 text-xs">
              <p className="font-semibold text-fg">{l.level}. {l.label}</p>
              <p className="mt-1 text-muted">{l.description}</p>
            </li>
          ))}
        </ol>
        <p className="mt-3 text-xs text-muted">Ações sensíveis: {Object.values(data.sensitiveActions).join(" · ")}.</p>
      </Card>
      <div className="grid gap-3 lg:grid-cols-2">
        {data.workforce.map((w) => <GovernanceCard key={w.key} w={w} data={data} people={people} />)}
      </div>
    </div>
  );
}

function GovernanceCard({ w, data, people }: { w: Worker; data: ControlPlaneData; people: { id: string; name: string }[] }) {
  const { run, loading, error, message } = useAction();
  const [level, setLevel] = useState(String(w.autonomyLevel));
  const [status, setStatus] = useState(w.status);
  const [owner, setOwner] = useState(w.owner?.id ?? "");
  const [budget, setBudget] = useState(w.monthlyCreditBudget == null ? "" : String(w.monthlyCreditBudget));
  const disabled = !data.canGovern || loading;
  const desc = data.levels.find((l) => String(l.level) === level)?.description;
  const save = () => run(`/api/ai-control/agents/${w.key}`, {
    autonomyLevel: Number(level), status, ownerUserId: owner || null, monthlyCreditBudget: budget === "" ? null : Number(budget),
  }, { method: "PATCH", success: "Governança atualizada e registrada na auditoria." });
  return (
    <Card>
      <CardTitle sub={`${w.key} · ${w.domain}`} action={<Badge tone={STATUS_TONE[w.status] ?? "neutral"}>{STATUS_LABEL[w.status] ?? w.status}</Badge>}>{w.name}</CardTitle>
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Nível de autonomia" hint={desc}>
          <Select value={level} onChange={(e) => setLevel(e.target.value)} disabled={disabled} aria-label={`Nível de autonomia de ${w.name}`}>
            {data.levels.map((l) => <option key={l.level} value={l.level}>{l.level}. {l.label}</option>)}
          </Select>
        </Field>
        <Field label="Status">
          <Select value={status} onChange={(e) => setStatus(e.target.value)} disabled={disabled} aria-label={`Status de ${w.name}`}>
            <option value="active">Ativo</option><option value="paused">Pausado</option><option value="suspended">Suspenso</option><option value="retired">Aposentado</option>
          </Select>
        </Field>
        <Field label="Responsável humano">
          <Select value={owner} onChange={(e) => setOwner(e.target.value)} disabled={disabled} aria-label={`Responsável por ${w.name}`}>
            <option value="">Não definido</option>
            {people.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
          </Select>
        </Field>
        <Field label="Orçamento mensal (créditos)" hint="Vazio = usa o orçamento da organização. Ao esgotar, o agente para.">
          <Input type="number" min={0} value={budget} onChange={(e) => setBudget(e.target.value)} disabled={disabled} aria-label={`Orçamento mensal de ${w.name}`} />
        </Field>
      </div>
      <div className="mt-3 flex items-center gap-2">
        <Button size="sm" onClick={save} disabled={disabled}>{loading ? "Salvando…" : "Salvar governança"}</Button>
        {!data.canGovern && <span className="text-xs text-muted">Somente administradores podem alterar.</span>}
      </div>
      <Feedback error={error} message={message} />
    </Card>
  );
}

function KillSwitch({ data, locale }: { data: ControlPlaneData; locale: string }) {
  const { run, loading, error, message } = useAction();
  const [scope, setScope] = useState("agent");
  const [target, setTarget] = useState(data.workforce[0]?.key ?? "");
  const [reason, setReason] = useState("");
  const [global, setGlobal] = useState(false);
  const [confirming, setConfirming] = useState(false);
  const [releasing, setReleasing] = useState<string | null>(null);
  const domains = [...new Set(data.workforce.map((w) => w.domain))];
  const changeScope = (s: string) => {
    setScope(s); setConfirming(false);
    setTarget(s === "agent" ? data.workforce[0]?.key ?? "" : s === "agent_domain" ? domains[0] ?? "" : s === "action_category" ? "send_message" : s === "integration" ? "whatsapp" : "");
  };
  const scopeLabel = SCOPES.find(([k]) => k === scope)?.[1] ?? scope;
  const activate = async () => {
    const ok = await run("/api/ai-control/kill-switches", { scope, target: scope === "all_ai" ? undefined : target, reason, global }, { success: "Kill switch acionado. A interrupção vale a partir de agora." });
    if (ok) { setConfirming(false); setReason(""); }
  };
  const fmt = (d: string) => new Date(d).toLocaleString(locale);

  return (
    <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.2fr)]">
      <Card className="border-danger/40">
        <CardTitle sub="Interrompe na hora agentes, integrações, ferramentas, automações ou categorias de ação. Fica registrado na auditoria.">Acionar kill switch</CardTitle>
        <div className="space-y-3">
          <Field label="O que interromper">
            <Select value={scope} onChange={(e) => changeScope(e.target.value)} disabled={!data.canGovern} aria-label="Escopo do kill switch">
              {SCOPES.map(([k, l]) => <option key={k} value={k}>{l}</option>)}
            </Select>
          </Field>
          {scope !== "all_ai" && (
            <Field label="Alvo">
              {scope === "agent" ? (
                <Select value={target} onChange={(e) => setTarget(e.target.value)} disabled={!data.canGovern} aria-label="Agente">
                  {data.workforce.map((w) => <option key={w.key} value={w.key}>{w.name}</option>)}
                </Select>
              ) : scope === "agent_domain" ? (
                <Select value={target} onChange={(e) => setTarget(e.target.value)} disabled={!data.canGovern} aria-label="Domínio">
                  {domains.map((d) => <option key={d} value={d}>{d}</option>)}
                </Select>
              ) : scope === "action_category" ? (
                <Select value={target} onChange={(e) => setTarget(e.target.value)} disabled={!data.canGovern} aria-label="Categoria de ação">
                  {ACTIONS.map(([k, l]) => <option key={k} value={k}>{l}</option>)}
                </Select>
              ) : scope === "integration" ? (
                <Select value={target} onChange={(e) => setTarget(e.target.value)} disabled={!data.canGovern} aria-label="Integração">
                  {INTEGRATIONS.map((i) => <option key={i} value={i}>{i}</option>)}
                </Select>
              ) : (
                <Input value={target} onChange={(e) => setTarget(e.target.value)} disabled={!data.canGovern} placeholder={scope === "workflow" ? "ID da automação" : "Nome da ferramenta (ex.: knowledge.search)"} aria-label="Alvo" />
              )}
            </Field>
          )}
          <Field label="Motivo" hint="Obrigatório. Aparece para a equipe e fica na auditoria.">
            <Input value={reason} onChange={(e) => setReason(e.target.value)} disabled={!data.canGovern} placeholder="Ex.: respostas incorretas sobre preço" aria-label="Motivo" />
          </Field>
          {data.isPlatformAdmin && (
            <label className="flex items-center gap-2 text-xs text-muted">
              <input type="checkbox" checked={global} onChange={(e) => setGlobal(e.target.checked)} /> Interrupção global (todas as organizações da plataforma)
            </label>
          )}
          {!confirming ? (
            <Button variant="danger" className="w-full py-3 text-base" disabled={!data.canGovern || reason.trim().length < 5 || (scope !== "all_ai" && !target.trim())} onClick={() => setConfirming(true)}>
              Interromper agora
            </Button>
          ) : (
            <div role="alertdialog" aria-label="Confirmar interrupção" className="space-y-2 rounded-xl border border-danger/50 bg-danger/10 p-3 text-sm">
              <p><b>Confirmar interrupção:</b> {scopeLabel}{scope !== "all_ai" ? ` · ${target}` : ""}{global ? " · GLOBAL" : ""}.</p>
              <p className="text-xs text-muted">As execuções afetadas serão bloqueadas até alguém liberar este kill switch.</p>
              <div className="flex gap-2">
                <Button variant="danger" onClick={activate} disabled={loading}>{loading ? "Acionando…" : "Confirmar interrupção"}</Button>
                <Button variant="secondary" onClick={() => setConfirming(false)} disabled={loading}>Cancelar</Button>
              </div>
            </div>
          )}
          {!data.canGovern && <p className="text-xs text-muted">Somente administradores com governança de IA podem acionar.</p>}
          <Feedback error={error} message={message} />
        </div>
      </Card>

      <Card>
        <CardTitle sub="Ativos primeiro. Interrupções globais são exibidas quando afetam sua organização.">Histórico de kill switches</CardTitle>
        {data.switches.length === 0 ? <Empty title="Nenhum kill switch acionado">Quando houver uma interrupção, ela aparece aqui.</Empty> : (
          <ul className="space-y-2">
            {data.switches.map((s) => (
              <li key={s.id} className="flex flex-wrap items-start justify-between gap-2 rounded-xl border border-line bg-bg-2/60 p-3 text-sm">
                <div className="min-w-0">
                  <p className="font-medium">{SCOPES.find(([k]) => k === s.scope)?.[1] ?? s.scope}{s.target !== "*" ? ` · ${s.target}` : ""} {!s.organizationId && <Badge tone="danger">Global</Badge>}</p>
                  <p className="text-xs text-muted">{s.reason}</p>
                  <p className="text-xs text-muted">Acionado em {fmt(s.createdAt)}{s.releasedAt ? ` · liberado em ${fmt(s.releasedAt)}` : ""}</p>
                </div>
                {s.active ? (
                  releasing === s.id ? (
                    <div className="flex gap-2">
                      <Button size="sm" onClick={async () => { await run(`/api/ai-control/kill-switches/${s.id}`, undefined, { method: "PATCH", success: "Kill switch liberado." }); setReleasing(null); }} disabled={loading}>Confirmar liberação</Button>
                      <Button size="sm" variant="ghost" onClick={() => setReleasing(null)}>Cancelar</Button>
                    </div>
                  ) : (
                    <Button size="sm" variant="secondary" disabled={!data.canGovern || (!s.organizationId && !data.isPlatformAdmin)} onClick={() => setReleasing(s.id)}>Liberar</Button>
                  )
                ) : <Badge>Liberado</Badge>}
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  );
}

function Budgets({ data, n }: { data: ControlPlaneData; n: (v: number) => string }) {
  const { run, loading, error, message } = useAction();
  const [scope, setScope] = useState("organization");
  const [target, setTarget] = useState("");
  const [monthly, setMonthly] = useState("");
  const [alertPct, setAlertPct] = useState("80");
  const [hardStop, setHardStop] = useState(true);
  const save = () => run("/api/ai-control/budgets", { scope, target: scope === "organization" ? undefined : target, monthlyCredits: Number(monthly), alertPct: Number(alertPct), hardStop }, { success: "Orçamento salvo." });
  return (
    <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.4fr)]">
      <Card>
        <CardTitle sub="Checado antes de cada chamada de IA. No limite rígido, a IA para sem cobrar; no flexível, segue com aviso.">Novo orçamento</CardTitle>
        <div className="space-y-3">
          <Field label="Escopo">
            <Select value={scope} onChange={(e) => { setScope(e.target.value); setTarget(e.target.value === "agent" ? data.workforce[0]?.key ?? "" : ""); }} disabled={!data.canGovern} aria-label="Escopo do orçamento">
              <option value="organization">Organização inteira</option><option value="agent">Um agente</option><option value="model">Um modelo</option>
            </Select>
          </Field>
          {scope === "agent" && (
            <Field label="Agente">
              <Select value={target} onChange={(e) => setTarget(e.target.value)} disabled={!data.canGovern} aria-label="Agente do orçamento">
                {data.workforce.map((w) => <option key={w.key} value={w.key}>{w.name}</option>)}
              </Select>
            </Field>
          )}
          {scope === "model" && (
            <Field label="Modelo" hint="Ex.: claude-opus-5-5">
              <Input value={target} onChange={(e) => setTarget(e.target.value)} disabled={!data.canGovern} aria-label="Modelo do orçamento" />
            </Field>
          )}
          <div className="grid grid-cols-2 gap-3">
            <Field label="Créditos por mês"><Input type="number" min={1} value={monthly} onChange={(e) => setMonthly(e.target.value)} disabled={!data.canGovern} aria-label="Créditos por mês" /></Field>
            <Field label="Alertar em (%)"><Input type="number" min={1} max={100} value={alertPct} onChange={(e) => setAlertPct(e.target.value)} disabled={!data.canGovern} aria-label="Percentual de alerta" /></Field>
          </div>
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={hardStop} onChange={(e) => setHardStop(e.target.checked)} disabled={!data.canGovern} /> Limite rígido (bloqueia ao esgotar)
          </label>
          <Button onClick={save} disabled={!data.canGovern || loading || !monthly || (scope !== "organization" && !target.trim())}>{loading ? "Salvando…" : "Salvar orçamento"}</Button>
          <Feedback error={error} message={message} />
        </div>
      </Card>
      <Card>
        <CardTitle sub="Consumo do mês corrente, calculado a partir das execuções registradas.">Orçamentos ativos</CardTitle>
        {data.budgets.length === 0 ? <Empty title="Nenhum orçamento definido">Sem orçamento, valem só o saldo de créditos e o limite diário de cada agente.</Empty> : (
          <ul className="space-y-3">
            {data.budgets.map((b) => (
              <li key={b.id} className="space-y-1 rounded-xl border border-line bg-bg-2/60 p-3 text-sm">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <p className="font-medium">{b.scope === "organization" ? "Organização" : b.scope === "agent" ? `Agente ${b.target}` : `Modelo ${b.target}`}</p>
                  <div className="flex items-center gap-2">
                    <Badge tone={b.hardStop ? "danger" : "warning"}>{b.hardStop ? "Rígido" : "Flexível"}</Badge>
                    <Button size="sm" variant="ghost" disabled={!data.canGovern || loading} onClick={() => run(`/api/ai-control/budgets/${b.id}`, undefined, { method: "DELETE", success: "Orçamento removido." })}>Remover</Button>
                  </div>
                </div>
                <Progress value={Math.min(100, b.usedPct)} tone={b.usedPct >= 100 ? "danger" : b.usedPct >= b.alertPct ? "warning" : "success"} />
                <p className="text-xs text-muted">{n(b.usedThisMonth)} de {n(b.monthlyCredits)} créditos ({b.usedPct}%) · alerta em {b.alertPct}%</p>
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  );
}

function Monitoring({ data, n }: { data: ControlPlaneData; n: (v: number) => string }) {
  const rows = data.workforce.filter((w) => w.metrics);
  return (
    <Card>
      <CardTitle sub="Últimos 30 dias. Intervenções humanas = decisões sobre pedidos de aprovação criados pelo agente.">Monitoramento por agente</CardTitle>
      {rows.length === 0 ? <Empty title="Sem execuções nos últimos 30 dias">As métricas aparecem quando os agentes forem usados.</Empty> : (
        <div className="overflow-x-auto">
          <Table head={["Agente", "Execuções", "Sucesso", "Bloqueios", "Falhas", "Simuladas", "Latência média", "Tokens", "Créditos", "Feedback", "Intervenções humanas"]}>
            {rows.map((w) => {
              const m = w.metrics!;
              const h = m.humanInterventions;
              return (
                <tr key={w.key} className="border-t border-line">
                  <Td><span className="font-medium">{w.name}</span></Td>
                  <Td>{n(m.executions)}</Td>
                  <Td>{m.successRate == null ? "—" : `${m.successRate}%`}</Td>
                  <Td>{n(m.blocked)}</Td>
                  <Td>{n(m.errors)}</Td>
                  <Td>{n(m.simulated)}</Td>
                  <Td>{n(m.avgLatencyMs)} ms</Td>
                  <Td>{n(m.tokens)}</Td>
                  <Td>{n(m.credits)}</Td>
                  <Td>👍 {m.positive} / 👎 {m.negative}</Td>
                  <Td>{h ? `${h.approved} aprovadas · ${h.rejected} rejeitadas · ${h.pending} pendentes` : "Nenhuma registrada"}</Td>
                </tr>
              );
            })}
          </Table>
        </div>
      )}
    </Card>
  );
}

function Conflicts({ data }: { data: ControlPlaneData }) {
  const tone = { high: "danger", medium: "warning", low: "info" } as const;
  const label = { high: "alta", medium: "média", low: "baixa" } as const;
  return (
    <Card>
      <CardTitle sub="Execuções duplicadas, excesso de chamadas, agentes com autonomia sobreposta e proteções de ciclo das automações.">Prevenção de conflitos</CardTitle>
      {data.conflicts.length === 0 ? <Empty title="Nenhum conflito detectado">A verificação roda a cada abertura desta tela.</Empty> : (
        <ul className="space-y-2">
          {data.conflicts.map((c, i) => (
            <li key={i} className="rounded-xl border border-line bg-bg-2/60 p-3 text-sm">
              <div className="flex flex-wrap items-center gap-2"><Badge tone={tone[c.severity]}>gravidade {label[c.severity]}</Badge><span className="font-medium">{c.title}</span></div>
              <p className="mt-1 text-xs text-muted">Evidência: {c.evidence}</p>
            </li>
          ))}
        </ul>
      )}
    </Card>
  );
}
