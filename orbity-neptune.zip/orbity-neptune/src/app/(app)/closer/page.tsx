import Link from "next/link";
import { eq } from "drizzle-orm";
import { requirePageContext } from "@/server/auth/next";
import { organizations } from "@/server/db/schema";
import { getConversation, listApprovals, listConversations, listKnowledge } from "@/server/domains/closer";
import { Badge, Card, Empty, PageHeader, cx } from "@/components/ui";
import { relative } from "@/lib/format";
import { ConversationView, type MessageOrigin } from "@/components/closer/conversation-view";
import { draftOriginsForMessages, getDraftForSubject } from "@/server/ai/collab";
import type { DraftViewData } from "@/components/ai-collab/types";
import { ApprovalsPanel, KnowledgePanel, SimulateInbound } from "@/components/closer/panels";
import { CHANNEL_LABEL, STATUS_LABEL, isSlaBreached, type Approval, type ConvDetail, type ConvItem, type KDoc } from "@/components/closer/types";

export const metadata = { title: "Propostas e fechamento" };

const ser = <T,>(v: unknown) => JSON.parse(JSON.stringify(v)) as T;
const FILTERS = [
  { key: "", label: "Todas" }, { key: "abertas", label: "Abertas" }, { key: "humano", label: "Aguardando humano" },
  { key: "sla", label: "SLA vencido" }, { key: "encerradas", label: "Encerradas" },
];

export default async function CloserPage({ searchParams }: { searchParams: Promise<{ filtro?: string; c?: string; aba?: string }> }) {
  const ctx = await requirePageContext("closer:read");
  const sp = await searchParams;
  const can = (p: string) => ctx.permissions.includes("*") || ctx.permissions.includes(p);
  const tab = sp.aba === "conhecimento" || sp.aba === "aprovacoes" ? sp.aba : "inbox";
  const filtro = sp.filtro ?? "";

  const [rows, approvals, docs, [org]] = await Promise.all([
    listConversations(ctx),
    listApprovals(ctx),
    tab === "conhecimento" ? listKnowledge(ctx) : Promise.resolve([]),
    ctx.db.select({ slug: organizations.slug }).from(organizations).where(eq(organizations.id, ctx.organizationId)),
  ]);
  const all: ConvItem[] = ser(rows.map((r) => ({ ...r.c, contactName: r.contactName, contactEmail: r.contactEmail })));
  const list = all.filter((c) =>
    filtro === "sla" ? isSlaBreached(c) : filtro === "humano" ? c.status === "handoff" : filtro === "abertas" ? c.status === "open" || c.status === "waiting" : filtro === "encerradas" ? c.status === "closed" : true);

  let selected: ConvDetail | null = null;
  let draft: DraftViewData | null = null;
  let origins: Record<string, MessageOrigin> = {};
  let notFound = false;
  if (tab === "inbox" && sp.c && /^[0-9a-f-]{36}$/i.test(sp.c)) {
    try {
      const d = await getConversation(ctx, sp.c);
      selected = ser({ ...d.c, contactName: d.contactName, contactEmail: d.contactEmail, contactPhone: d.contactPhone, messages: d.messages, channelReal: d.channelReal, channelConnected: d.channelConnected, outboundImplemented: d.outboundImplemented });
      const [dv, og] = await Promise.all([
        getDraftForSubject(ctx, "closer", d.c.id),
        draftOriginsForMessages(ctx, d.messages.filter((m) => m.direction === "outbound").map((m) => m.id)),
      ]);
      draft = dv ? ser<DraftViewData>(dv) : null;
      origins = og;
    } catch { notFound = true; }
  }
  const qs = (p: Record<string, string | undefined>) => {
    const u = new URLSearchParams();
    Object.entries({ filtro, ...p }).forEach(([k, v]) => v && u.set(k, v));
    return `/closer?${u}`;
  };
  const breaches = all.filter(isSlaBreached).length;

  return (
    <div className="mx-auto max-w-[1600px]">
      <PageHeader title="Propostas e fechamento" subtitle="Conversas com clientes, propostas e fechamento (Closer.AI). A IA propõe, você decide: gere quantas sugestões quiser, edite ou escreva a sua." />
      <nav className="mb-5 flex flex-wrap gap-2" aria-label="Seções do Closer.AI">
        {[["inbox", "Caixa de entrada"], ["aprovacoes", `Aprovações (${approvals.length})`], ["conhecimento", "Base de conhecimento"]].map(([k, l]) => (
          <Link key={k} href={k === "inbox" ? "/closer" : `/closer?aba=${k}`} className={cx("rounded-lg border px-3 py-1.5 text-sm", tab === k ? "border-primary-2 bg-primary/20 text-primary-2" : "border-line text-muted hover:text-fg")}>{l}</Link>
        ))}
      </nav>

      {tab === "aprovacoes" && <ApprovalsPanel items={ser<Approval[]>(approvals)} locale={ctx.locale} canDecide={can("approvals:decide")} />}
      {tab === "conhecimento" && <KnowledgePanel docs={ser<KDoc[]>(docs)} locale={ctx.locale} canWrite={can("closer:write")} />}

      {tab === "inbox" && (
        <div className="grid gap-5 lg:grid-cols-[340px_1fr]">
          <div className="space-y-4">
            <Card className="p-3">
              <div className="mb-3 flex flex-wrap gap-1.5">
                {FILTERS.map((f) => (
                  <Link key={f.key} href={qs({ filtro: f.key || undefined, c: sp.c })} className={cx("rounded-full border px-2.5 py-1 text-[11px]", filtro === f.key ? "border-primary-2 bg-primary/20 text-primary-2" : "border-line text-muted")}>
                    {f.label}{f.key === "sla" && breaches > 0 ? ` (${breaches})` : ""}
                  </Link>
                ))}
              </div>
              {!list.length ? <Empty title="Nenhuma conversa neste filtro." /> : (
                <ul className="max-h-[560px] space-y-1 overflow-y-auto">
                  {list.map((c) => (
                    <li key={c.id}>
                      <Link href={qs({ c: c.id })} className={cx("block rounded-lg border p-2.5", selected?.id === c.id ? "border-primary-2 bg-primary/10" : "border-transparent hover:bg-surface-2")}>
                        <div className="flex items-center justify-between gap-2">
                          <span className="truncate text-sm font-medium">{c.contactName ?? "Contato"}</span>
                          <span className="shrink-0 text-[10px] text-muted">{relative(c.lastMessageAt, ctx.locale)}</span>
                        </div>
                        <p className="truncate text-xs text-muted">{c.subject ?? "—"}</p>
                        <div className="mt-1.5 flex flex-wrap gap-1">
                          <Badge tone="info">{CHANNEL_LABEL[c.channel] ?? c.channel}</Badge>
                          {c.intent && <Badge tone="primary">{c.intent}</Badge>}
                          {c.status === "handoff" && <Badge tone="warning">{STATUS_LABEL.handoff}</Badge>}
                          {c.status === "closed" && <Badge>{STATUS_LABEL.closed}</Badge>}
                          {isSlaBreached(c) && <Badge tone="danger">SLA vencido</Badge>}
                        </div>
                      </Link>
                    </li>
                  ))}
                </ul>
              )}
            </Card>
            {can("closer:write") && org && <SimulateInbound orgSlug={org.slug} />}
          </div>
          <div>
            {selected ? (
              <ConversationView key={selected.id} conv={selected} locale={ctx.locale} canWrite={can("closer:write")} draft={draft} origins={origins} />
            ) : (
              <Card className="flex min-h-[400px] items-center justify-center">
                <Empty title={notFound ? "Conversa não encontrada." : "Selecione uma conversa"}>Escolha uma conversa à esquerda ou simule uma mensagem recebida.</Empty>
              </Card>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
