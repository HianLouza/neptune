import { requirePageContext } from "@/server/auth/next";
import { can } from "@/server/tenancy/context";
import { dashboardKpis, revenueForecast } from "@/server/domains/intelligence";
import { financialSnapshot } from "@/server/domains/finance/snapshot";
import { listInsights, ruleStats } from "@/server/intelligence-layer/insights";
import { listDecisions } from "@/server/intelligence-layer/decisions";
import { latestBriefing, PERIOD_LABEL, type BriefingContent, type BriefingPeriod } from "@/server/intelligence-layer/briefing";
import { BRAIN_SUGGESTIONS } from "@/server/ai/flavio/investigate";
import { listInvestigations } from "@/server/ai/flavio/conversations";
import { COMMAND_CENTER_WIDGETS, hiddenWidgets } from "@/server/intelligence-layer/widgets";
import { Badge, Card, CardTitle, Empty, PageHeader, Stat, Table, Td } from "@/components/ui";
import { PeriodSelect } from "@/components/dashboard/period-select";
import { money, num, pct, date } from "@/lib/format";
import { BrainEntry, BriefingButton, DecisionCard, InsightCard, NewDecisionForm, ScanButton, WidgetToggle, type DecisionView, type InsightView } from "./ui";

export const metadata = { title: "Visão gerencial" };

function delta(v: number | null, suffix = "%") {
  if (v == null) return "sem base de comparação";
  return `${v >= 0 ? "+" : ""}${String(v).replace(".", ",")}${suffix} vs. período anterior`;
}

const QUESTIONS: { key: keyof BriefingContent; label: string }[] = [
  { key: "acontecendo", label: "O que está acontecendo?" },
  { key: "mudou", label: "O que mudou?" },
  { key: "atencao", label: "O que merece atenção?" },
  { key: "oportunidades", label: "Onde existem oportunidades?" },
  { key: "decisoes", label: "Quais decisões precisam ser tomadas?" },
  { key: "melhorar", label: "O que pode ser melhorado?" },
];

export default async function CommandCenterPage({ searchParams }: { searchParams: Promise<{ periodo?: string }> }) {
  const ctx = await requirePageContext("intelligence:read");
  const sp = await searchParams;
  const days = [7, 30, 90].includes(Number(sp.periodo)) ? Number(sp.periodo) : 30;
  const o = { locale: ctx.locale, currency: ctx.currency, timezone: ctx.timezone };
  const financeAllowed = can(ctx, "finance:read");

  const [kpis, forecast, insightsRows, stats, decisionRows, briefing, hidden, investigations] = await Promise.all([
    dashboardKpis(ctx, days), revenueForecast(ctx), listInsights(ctx, { limit: 60 }), ruleStats(ctx), listDecisions(ctx), latestBriefing(ctx), hiddenWidgets(ctx),
    can(ctx, "ai:use") ? listInvestigations(ctx, { limit: 1 }) : Promise.resolve([]),
  ]);
  const fin = financeAllowed ? await financialSnapshot(ctx, days) : null;
  const show = (k: string) => !hidden.includes(k);

  const ticket = kpis.current.won ? Math.round(kpis.current.revenueCents / kpis.current.won) : null;
  const insights: InsightView[] = insightsRows.filter((i) => i.status !== "expired" && i.status !== "canceled").map((i) => ({
    id: i.id, ruleKey: i.ruleKey, domain: i.domain, nature: i.nature, title: i.title, summary: i.summary, priority: i.priority, status: i.status,
    recommendedAction: i.recommendedAction, link: i.link, evidence: i.evidence, createdAt: i.createdAt.toISOString(), executedAt: i.executedAt?.toISOString() ?? null,
    indicator: i.indicator ?? null, outcome: i.outcome ?? null, decisionNote: i.decisionNote,
  }));
  const active = insights.filter((i) => ["open", "accepted", "modified"].includes(i.status));
  const history = insights.filter((i) => !["open", "accepted", "modified"].includes(i.status)).slice(0, 10);
  const decisions: DecisionView[] = decisionRows.map((d) => ({
    id: d.id, title: d.title, problem: d.problem, status: d.status, chosenAlternative: d.chosenAlternative, rationale: d.rationale, result: d.result,
    alternatives: d.alternatives, createdBy: d.createdBy, createdAt: d.createdAt.toISOString(), reviewAt: d.reviewAt?.toISOString() ?? null, hasEvidence: !!d.evidence,
  }));
  const content = briefing?.content as BriefingContent | undefined;
  const finState = !financeAllowed ? "Sem permissão para dados financeiros" : !fin?.hasData ? "Sem lançamentos no Financeiro" : null;

  return (
    <div className="mx-auto max-w-[1600px] space-y-5">
      <PageHeader
        title="Visão gerencial"
        subtitle="A empresa inteira para quem gerencia: comercial e financeiro juntos, o que mudou, o que merece atenção e quais decisões tomar, com evidências. Para a rotina de vendas, use o Painel de vendas."
        actions={<><PeriodSelect value={days} /><WidgetToggle widgets={COMMAND_CENTER_WIDGETS.map((w) => ({ key: w.key, label: w.label }))} hidden={hidden} /></>}
      />

      {show("briefing") && (
        <Card glow>
          <CardTitle sub={briefing ? `Briefing ${PERIOD_LABEL[briefing.period as BriefingPeriod] ?? briefing.period} gerado em ${date(briefing.createdAt, o, true)} · fontes: ${content?.fontes.join(", ")}` : "Nenhum briefing gerado ainda."} action={<BriefingButton />}>
            Resumo executivo
          </CardTitle>
          {content ? (
            <ul className="space-y-1 text-sm">
              {[...content.acontecendo.slice(0, 2), ...content.atencao.slice(0, 2), ...content.decisoes.slice(0, 1)].map((t, i) => <li key={i}>• {t}</li>)}
            </ul>
          ) : <Empty title="Gere o primeiro briefing">O briefing resume indicadores, alertas e decisões pendentes a partir dos dados da organização.</Empty>}
        </Card>
      )}

      {show("kpis") && (
        <Card>
          <CardTitle sub={`Comercial: CRM (${days} dias). Financeiro: lançamentos do módulo Financeiro (regime de caixa).`}>Indicadores</CardTitle>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
            <Stat label="Receita de vendas" value={money(kpis.current.revenueCents, o)} hint={delta(kpis.delta.revenue)} />
            <Stat label="Pipeline aberto" value={money(forecast.pipelineTotalCents, o)} hint={`${num(forecast.openDeals, o.locale)} negócios`} />
            <Stat label="Leads" value={num(kpis.current.leads, o.locale)} hint={delta(kpis.delta.leads)} />
            <Stat label="Conversão" value={pct(kpis.current.conversionRate, o.locale)} hint={delta(kpis.delta.conversionPp, " p.p.")} />
            <Stat label="Ticket médio" value={ticket != null ? money(ticket, o) : "—"} hint={ticket == null ? "Sem vendas no período" : `${num(kpis.current.won, o.locale)} vendas`} />
            <Stat label="Previsão (base)" value={money(forecast.scenarios.base, o)} hint={`±${forecast.uncertaintyPct}% · amostra ${forecast.sampleSize}`} />
          </div>
          <div className="mt-3 grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
            {finState ? (
              <div className="col-span-2 rounded-xl border border-dashed border-line p-4 text-xs text-muted md:col-span-3 xl:col-span-4">
                <b className="text-fg">Financeiro indisponível:</b> {finState}. Despesas, margem, caixa projetado e inadimplência aparecem aqui quando houver lançamentos {financeAllowed && <a className="text-primary-2 underline" href="/financeiro">no Financeiro</a>}.
              </div>
            ) : (
              <>
                <Stat label="Despesas pagas" value={money(fin!.expensesCents, o)} hint={`${days} dias`} />
                <Stat label="Margem de caixa" value={pct(fin!.marginPct, o.locale)} hint={`Resultado ${money(fin!.resultCents, o)}`} />
                <Stat label="Caixa projetado 30d" value={money(fin!.next30.netCents, o)} hint={`Entradas ${money(fin!.next30.inflowCents, o)} · saídas ${money(fin!.next30.outflowCents, o)}`} />
                <Stat label="Inadimplência" value={money(fin!.overdueReceivableCents, o)} hint={`${fin!.overdueReceivableCount} título(s) vencido(s)`} />
              </>
            )}
            <Stat label="CAC / LTV" value="Indisponível" hint="Requer custos de marketing/vendas por canal e receita recorrente por cliente" />
            <Stat label="Churn / Retenção" value="Indisponível" hint="Requer assinaturas ou contratos recorrentes dos clientes" />
          </div>
        </Card>
      )}

      {show("questions") && (
        <Card>
          <CardTitle sub={content ? "Do último briefing gerado." : "Gere um briefing para responder às perguntas."}>As 6 perguntas do Command Center</CardTitle>
          <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
            {QUESTIONS.map((q) => (
              <div key={q.key} className="rounded-xl border border-line bg-bg-2/40 p-3">
                <p className="mb-1 text-xs font-semibold text-muted">{q.label}</p>
                {content && Array.isArray(content[q.key]) && (content[q.key] as string[]).length
                  ? <ul className="space-y-1 text-xs">{(content[q.key] as string[]).map((t, i) => <li key={i}>• {t}</li>)}</ul>
                  : <p className="text-xs text-muted">Sem dados ainda.</p>}
              </div>
            ))}
          </div>
        </Card>
      )}

      <div className="grid gap-5 xl:grid-cols-[3fr_2fr]">
        {show("insights") && (
          <Card>
            <CardTitle sub="Gerados por regras determinísticas sobre seus dados. Cada um traz fonte, cálculo, confiança e limitações." action={<ScanButton />}>
              Insights e recomendações ({active.length})
            </CardTitle>
            {active.length ? <ul className="space-y-3">{active.map((i) => <InsightCard key={i.id} i={i} locale={o.locale} />)}</ul>
              : <Empty title="Nenhum insight aberto">Clique em &quot;Analisar agora&quot; para avaliar as regras com os dados atuais.</Empty>}
            {history.length > 0 && (
              <details className="mt-4">
                <summary className="cursor-pointer text-xs text-muted">Histórico recente ({history.length})</summary>
                <ul className="mt-2 space-y-3">{history.map((i) => <InsightCard key={i.id} i={i} locale={o.locale} />)}</ul>
              </details>
            )}
          </Card>
        )}

        <div className="space-y-5">
          {show("decisions") && (
            <Card>
              <div id="decisoes" />
              <CardTitle sub="Alternativas, escolha, aprovação por outra pessoa (segregação de funções) e acompanhamento do resultado.">Decisões</CardTitle>
              {decisions.length ? <ul className="space-y-3">{decisions.slice(0, 12).map((d) => <DecisionCard key={d.id} d={d} currentUserId={ctx.userId} canApprove={can(ctx, "approvals:decide")} />)}</ul>
                : <p className="text-xs text-muted">Nenhuma decisão registrada.</p>}
              <details className="mt-3">
                <summary className="cursor-pointer text-xs text-muted">Registrar nova decisão</summary>
                <NewDecisionForm />
              </details>
            </Card>
          )}

          {show("rules") && (
            <Card>
              <CardTitle sub="Aprendizado: regras com ≥ 5 decisões e ≥ 70% de rejeição têm a prioridade reduzida automaticamente.">Precisão das regras</CardTitle>
              {stats.length ? (
                <Table head={["Regra", "Decididas", "Rejeição", "Melhorou/medidas", ""]}>
                  {stats.map((s) => (
                    <tr key={s.ruleKey}>
                      <Td>{s.label}</Td>
                      <Td>{s.decided}</Td>
                      <Td>{s.rejectionRate == null ? "—" : `${Math.round(s.rejectionRate * 100)}%`}</Td>
                      <Td>{s.improved}/{s.improved + s.worse}</Td>
                      <Td>{s.demoted && <Badge tone="warning">prioridade reduzida</Badge>}</Td>
                    </tr>
                  ))}
                </Table>
              ) : <p className="text-xs text-muted">Ainda não há decisões sobre insights.</p>}
            </Card>
          )}
        </div>
      </div>

      {show("brain") && (
        <Card>
          <CardTitle sub="Converse com o Flávio sobre a empresa: ele investiga os módulos que você pode acessar, cruza os dados e mostra fontes, hipóteses e limitações."
            action={<a href="/business-brain" className="text-xs text-primary-2 hover:underline">Abrir Business Brain</a>}>
            Business Brain · Flávio
          </CardTitle>
          {can(ctx, "ai:use")
            ? <BrainEntry suggestions={BRAIN_SUGGESTIONS.slice(0, 6)} lastInvestigation={investigations[0] ? { id: investigations[0].id, title: investigations[0].title } : null} />
            : <p className="text-xs text-muted">Seu perfil não tem a permissão ai:use, necessária para conversar com o Flávio.</p>}
        </Card>
      )}
    </div>
  );
}
