"use client";
import { useState, type ReactNode } from "react";
import { Badge, Button, Field, Input, Select, Textarea, cx } from "@/components/ui";
import { Feedback, useAction } from "@/components/ui/use-action";

/* ------------------------------------------------------------------ tipos serializáveis */

export type EvidenceView = {
  facts: { label: string; value: string; source: string; period?: string }[];
  assumptions: string[]; calculations: string[]; confidence: number; missingData: string[]; limitations: string[];
};
export type InsightView = {
  id: string; ruleKey: string; domain: string; nature: string; title: string; summary: string; priority: string; status: string;
  recommendedAction: string | null; link: string | null; evidence: EvidenceView; createdAt: string; executedAt: string | null;
  indicator: { metric: string; baseline: number; unit: string; direction: "up" | "down" } | null;
  outcome: { observed: number; measuredAt: string; verdict: string; note: string } | null;
  decisionNote: string | null;
};
export type DecisionView = {
  id: string; title: string; problem: string; status: string; chosenAlternative: string | null; rationale: string | null; result: string | null;
  alternatives: { name: string; description: string; estimatedImpact: string; risks: string }[]; createdBy: string; createdAt: string; reviewAt: string | null;
  hasEvidence: boolean;
};

const NATURE: Record<string, string> = { fact: "Fato", inference: "Inferência", estimate: "Estimativa", recommendation: "Recomendação" };
const PRIORITY: Record<string, { label: string; tone: "danger" | "warning" | "info" }> = { high: { label: "Alta", tone: "danger" }, medium: { label: "Média", tone: "warning" }, low: { label: "Baixa", tone: "info" } };
const STATUS: Record<string, string> = { open: "Aberto", accepted: "Aceito", modified: "Alterado", rejected: "Rejeitado", executed: "Executado", canceled: "Cancelado", expired: "Expirado" };
const VERDICT: Record<string, { label: string; tone: "success" | "neutral" | "danger" | "warning" }> = {
  improved: { label: "Melhorou", tone: "success" }, no_change: { label: "Sem mudança", tone: "neutral" }, worse: { label: "Piorou", tone: "danger" }, inconclusive: { label: "Inconclusivo", tone: "warning" },
};
const confLabel = (c: number) => (c >= 0.75 ? "alta" : c >= 0.5 ? "média" : c > 0 ? "baixa" : "insuficiente");

export function EvidenceBlock({ e }: { e: EvidenceView }) {
  return (
    <div className="space-y-2 rounded-lg border border-line bg-bg-2/60 p-3 text-xs">
      <p className="text-muted">Confiança: <b className="text-fg">{confLabel(e.confidence)}</b> ({Math.round(e.confidence * 100)}%)</p>
      {e.facts.length > 0 && (
        <ul className="space-y-1">
          {e.facts.map((x, i) => <li key={i}><b className="text-fg">{x.label}:</b> {x.value} <span className="text-muted">· {x.source}{x.period ? ` · ${x.period}` : ""}</span></li>)}
        </ul>
      )}
      {e.calculations.length > 0 && <List title="Cálculos" items={e.calculations} />}
      {e.assumptions.length > 0 && <List title="Premissas" items={e.assumptions} />}
      {e.missingData.length > 0 && <List title="Dados ausentes" items={e.missingData} />}
      {e.limitations.length > 0 && <List title="Limitações" items={e.limitations} />}
    </div>
  );
}
function List({ title, items }: { title: string; items: string[] }) {
  return <div><p className="font-medium text-muted">{title}</p><ul className="ml-4 list-disc">{items.map((t, i) => <li key={i}>{t}</li>)}</ul></div>;
}

/* ------------------------------------------------------------------ insights */

export function ScanButton() {
  const a = useAction();
  return (
    <div>
      <Button variant="secondary" size="sm" disabled={a.loading} onClick={async () => {
        const r = await a.run<{ created: number; refreshed: number; expired: number }>("/api/insights", {}, {});
        if (r) a.setMessage(`Análise concluída: ${r.created} novo(s), ${r.refreshed} atualizado(s), ${r.expired} expirado(s).`);
      }}>{a.loading ? "Analisando…" : "Analisar agora"}</Button>
      <Feedback error={a.error} message={a.message} />
    </div>
  );
}

export function InsightCard({ i, locale }: { i: InsightView; locale: string }) {
  const [open, setOpen] = useState(false);
  const [note, setNote] = useState("");
  const [mode, setMode] = useState<null | "reject" | "modify" | "decision">(null);
  const a = useAction();
  const p = PRIORITY[i.priority] ?? PRIORITY.medium;
  const act = (body: Record<string, unknown>, success: string) => a.run(`/api/insights/${i.id}`, body, { method: "PATCH", success });
  const active = ["open", "accepted", "modified"].includes(i.status);

  return (
    <li className="rounded-xl border border-line bg-bg-2/40 p-3">
      <div className="flex flex-wrap items-center gap-2">
        <Badge tone={p.tone}>{p.label}</Badge>
        <Badge tone="neutral">{NATURE[i.nature] ?? i.nature}</Badge>
        <Badge tone={i.status === "open" ? "primary" : "neutral"}>{STATUS[i.status] ?? i.status}</Badge>
        {i.outcome && <Badge tone={VERDICT[i.outcome.verdict]?.tone ?? "neutral"}>Resultado: {VERDICT[i.outcome.verdict]?.label ?? i.outcome.verdict}</Badge>}
      </div>
      <p className="mt-2 text-sm font-semibold text-fg">{i.title}</p>
      <p className="text-xs text-muted">{i.summary}</p>
      {i.recommendedAction && <p className="mt-1 text-xs"><b>Ação recomendada:</b> {i.recommendedAction}</p>}
      {i.indicator && <p className="mt-1 text-[11px] text-muted">Indicador: {i.indicator.metric} · linha de base {i.indicator.unit === "centavos" ? new Intl.NumberFormat(locale).format(i.indicator.baseline / 100) : i.indicator.baseline}{i.indicator.unit === "%" ? "%" : ""} ({i.indicator.direction === "up" ? "quanto maior, melhor" : "quanto menor, melhor"})</p>}
      {i.outcome && <p className="mt-1 text-[11px] text-muted">{i.outcome.note}</p>}
      {i.decisionNote && <p className="mt-1 text-[11px] text-muted">Nota: {i.decisionNote}</p>}

      <div className="mt-2 flex flex-wrap gap-2">
        <Button size="sm" variant="ghost" onClick={() => setOpen((v) => !v)} aria-expanded={open}>{open ? "Ocultar evidências" : "Ver evidências"}</Button>
        {i.link && <a href={i.link} className="inline-flex items-center rounded-lg px-3 py-1.5 text-xs text-muted hover:bg-surface-2 hover:text-fg">Abrir tela</a>}
        {i.status === "open" && <Button size="sm" disabled={a.loading} onClick={() => act({ action: "decide", status: "accepted" }, "Recomendação aceita.")}>Aceitar</Button>}
        {i.status === "open" && <Button size="sm" variant="secondary" onClick={() => setMode(mode === "modify" ? null : "modify")}>Alterar</Button>}
        {i.status === "open" && <Button size="sm" variant="secondary" onClick={() => setMode(mode === "reject" ? null : "reject")}>Rejeitar</Button>}
        {active && <Button size="sm" variant="secondary" disabled={a.loading} onClick={() => act({ action: "execute" }, "Marcada como executada. Meça o resultado após 7 dias.")}>Marcar executado</Button>}
        {i.status === "executed" && <Button size="sm" variant="secondary" disabled={a.loading} onClick={() => act({ action: "measure" }, "Resultado medido.")}>Medir resultado</Button>}
        {active && <Button size="sm" variant="ghost" onClick={() => setMode(mode === "decision" ? null : "decision")}>Registrar decisão</Button>}
      </div>

      {(mode === "reject" || mode === "modify") && (
        <div className="mt-2 flex flex-wrap items-end gap-2">
          <div className="min-w-60 flex-1"><Field label={mode === "reject" ? "Motivo (opcional)" : "O que foi alterado?"}><Input value={note} onChange={(e) => setNote(e.target.value)} maxLength={1000} /></Field></div>
          <Button size="sm" variant={mode === "reject" ? "danger" : "primary"} disabled={a.loading || (mode === "modify" && note.trim().length < 3)}
            onClick={async () => { if (await act({ action: "decide", status: mode === "reject" ? "rejected" : "modified", note: note || undefined }, mode === "reject" ? "Recomendação rejeitada." : "Alteração registrada.")) { setMode(null); setNote(""); } }}>
            Confirmar
          </Button>
        </div>
      )}
      {mode === "decision" && <NewDecisionForm insightId={i.id} defaultTitle={i.title} defaultProblem={i.summary} onDone={() => setMode(null)} />}
      {open && <div className="mt-2"><EvidenceBlock e={i.evidence} /></div>}
      <Feedback error={a.error} message={a.message} />
    </li>
  );
}

/* ------------------------------------------------------------------ decisões */

export function NewDecisionForm({ insightId, defaultTitle = "", defaultProblem = "", onDone }: { insightId?: string; defaultTitle?: string; defaultProblem?: string; onDone?: () => void }) {
  const a = useAction();
  const [title, setTitle] = useState(defaultTitle);
  const [problem, setProblem] = useState(defaultProblem);
  const [alts, setAlts] = useState(["", ""]);
  return (
    <form className="mt-2 space-y-2 rounded-lg border border-line p-3" onSubmit={async (e) => {
      e.preventDefault();
      const alternatives = alts.map((n) => n.trim()).filter((n) => n.length >= 2).map((name) => ({ name }));
      const r = await a.run("/api/decisions", { title, problem, alternatives, insightId }, { success: "Decisão registrada como rascunho." });
      if (r) { setTitle(""); setProblem(""); setAlts(["", ""]); onDone?.(); }
    }}>
      <Field label="Título"><Input value={title} onChange={(e) => setTitle(e.target.value)} minLength={3} maxLength={200} required /></Field>
      <Field label="Problema"><Textarea value={problem} onChange={(e) => setProblem(e.target.value)} minLength={3} maxLength={2000} required /></Field>
      {alts.map((v, idx) => (
        <Field key={idx} label={`Alternativa ${idx + 1}`}><Input value={v} onChange={(e) => setAlts(alts.map((x, j) => (j === idx ? e.target.value : x)))} maxLength={120} /></Field>
      ))}
      <div className="flex gap-2">
        {alts.length < 5 && <Button type="button" size="sm" variant="ghost" onClick={() => setAlts([...alts, ""])}>+ alternativa</Button>}
        <Button type="submit" size="sm" disabled={a.loading}>Criar decisão</Button>
      </div>
      <Feedback error={a.error} message={a.message} />
    </form>
  );
}

const DSTATUS: Record<string, { label: string; tone: "neutral" | "warning" | "success" | "danger" | "info" | "primary" }> = {
  draft: { label: "Rascunho", tone: "neutral" }, pending_approval: { label: "Aguardando aprovação", tone: "warning" }, approved: { label: "Aprovada", tone: "success" },
  rejected: { label: "Rejeitada", tone: "danger" }, monitoring: { label: "Em monitoramento", tone: "info" }, closed: { label: "Encerrada", tone: "primary" },
};

export function DecisionCard({ d, currentUserId, canApprove }: { d: DecisionView; currentUserId: string; canApprove: boolean }) {
  const a = useAction();
  const [choice, setChoice] = useState(d.chosenAlternative ?? d.alternatives[0]?.name ?? "");
  const [rationale, setRationale] = useState(d.rationale ?? "");
  const [text, setText] = useState("");
  const [review, setReview] = useState("");
  const send = (body: Record<string, unknown>, success: string) => a.run(`/api/decisions/${d.id}`, body, { method: "PATCH", success });
  const s = DSTATUS[d.status] ?? DSTATUS.draft;
  const isCreator = d.createdBy === currentUserId;

  return (
    <li className="rounded-xl border border-line bg-bg-2/40 p-3">
      <div className="flex flex-wrap items-center gap-2"><Badge tone={s.tone}>{s.label}</Badge>{d.hasEvidence && <Badge tone="neutral">com evidência</Badge>}</div>
      <p className="mt-2 text-sm font-semibold text-fg">{d.title}</p>
      <p className="text-xs text-muted">{d.problem}</p>
      {d.alternatives.length > 0 && <p className="mt-1 text-xs"><b>Alternativas:</b> {d.alternatives.map((x) => x.name).join(" · ")}</p>}
      {d.chosenAlternative && <p className="text-xs"><b>Escolhida:</b> {d.chosenAlternative}{d.rationale ? ` — ${d.rationale}` : ""}</p>}
      {d.result && <p className="text-xs"><b>Resultado:</b> {d.result}</p>}

      {d.status === "draft" && (
        <div className="mt-2 grid gap-2 sm:grid-cols-[1fr_2fr_auto] sm:items-end">
          <Field label="Alternativa escolhida">
            <Select value={choice} onChange={(e) => setChoice(e.target.value)} disabled={!d.alternatives.length}>
              {d.alternatives.length ? d.alternatives.map((x) => <option key={x.name} value={x.name}>{x.name}</option>) : <option value="">Sem alternativas</option>}
            </Select>
          </Field>
          <Field label="Justificativa"><Input value={rationale} onChange={(e) => setRationale(e.target.value)} maxLength={2000} /></Field>
          <div className="flex gap-2">
            <Button size="sm" variant="secondary" disabled={a.loading || !choice} onClick={() => send({ action: "edit", chosenAlternative: choice, rationale }, "Escolha salva.")}>Salvar</Button>
            <Button size="sm" disabled={a.loading || !d.chosenAlternative || !d.rationale} title={!d.chosenAlternative || !d.rationale ? "Salve a escolha e a justificativa antes" : undefined}
              onClick={() => send({ action: "submit" }, "Enviada para aprovação.")}>Enviar para aprovação</Button>
          </div>
        </div>
      )}
      {d.status === "pending_approval" && (
        canApprove && !isCreator ? (
          <div className="mt-2 flex flex-wrap items-end gap-2">
            <div className="min-w-60 flex-1"><Field label="Observação (obrigatória para rejeitar)"><Input value={text} onChange={(e) => setText(e.target.value)} maxLength={1000} /></Field></div>
            <Button size="sm" disabled={a.loading} onClick={() => send({ action: "approve", note: text || undefined }, "Decisão aprovada.")}>Aprovar</Button>
            <Button size="sm" variant="danger" disabled={a.loading || text.trim().length < 3} onClick={() => send({ action: "reject", note: text }, "Decisão rejeitada.")}>Rejeitar</Button>
          </div>
        ) : <p className="mt-2 text-[11px] text-muted">{isCreator ? "Segregação de funções: outra pessoa com permissão de aprovação precisa decidir." : "Você não tem permissão para aprovar decisões."}</p>
      )}
      {d.status === "approved" && (
        <div className="mt-2 flex flex-wrap items-end gap-2">
          <Field label="Revisar em"><Input type="date" value={review} onChange={(e) => setReview(e.target.value)} /></Field>
          <Button size="sm" variant="secondary" disabled={a.loading || !review} onClick={() => send({ action: "monitor", reviewAt: review }, "Decisão em monitoramento.")}>Monitorar</Button>
        </div>
      )}
      {(d.status === "approved" || d.status === "monitoring") && (
        <div className="mt-2 flex flex-wrap items-end gap-2">
          <div className="min-w-60 flex-1"><Field label="Resultado observado"><Input value={text} onChange={(e) => setText(e.target.value)} maxLength={2000} /></Field></div>
          <Button size="sm" disabled={a.loading || text.trim().length < 3} onClick={() => send({ action: "close", result: text }, "Decisão encerrada.")}>Encerrar</Button>
        </div>
      )}
      <Feedback error={a.error} message={a.message} />
    </li>
  );
}

/* ------------------------------------------------------------------ briefing */

export function BriefingButton() {
  const a = useAction();
  const [period, setPeriod] = useState("weekly");
  return (
    <div className="flex flex-wrap items-center gap-2">
      <Select value={period} onChange={(e) => setPeriod(e.target.value)} aria-label="Período do briefing" className="w-auto">
        <option value="daily">Diário</option><option value="weekly">Semanal</option><option value="monthly">Mensal</option><option value="quarterly">Trimestral</option>
      </Select>
      <Button size="sm" disabled={a.loading} onClick={() => a.run("/api/brain/briefings", { period }, { success: "Briefing gerado." })}>{a.loading ? "Gerando…" : "Gerar briefing"}</Button>
      <Feedback error={a.error} message={a.message} />
    </div>
  );
}

/* ------------------------------------------------------------------ Business Brain (entrada compacta para o Flávio) */

/** O Business Brain agora é o ambiente de investigação do Flávio (/business-brain). Aqui fica só a entrada. */
export function BrainEntry({ suggestions, lastInvestigation }: { suggestions: string[]; lastInvestigation: { id: string; title: string } | null }) {
  const [q, setQ] = useState("");
  const go = (question: string) => { window.location.href = `/business-brain?q=${encodeURIComponent(question)}`; };
  return (
    <div>
      <form className="flex gap-2" onSubmit={(e) => { e.preventDefault(); if (q.trim().length >= 2) go(q.trim()); }}>
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Pergunte qualquer coisa sobre a empresa. Ex.: Por que minha receita caiu?" maxLength={2000} aria-label="Pergunta ao Flávio no Business Brain" />
        <Button type="submit" disabled={q.trim().length < 2}>Investigar</Button>
      </form>
      <div className="mt-2 flex flex-wrap gap-1.5" role="list" aria-label="Perguntas sugeridas">
        {suggestions.map((s) => <button key={s} type="button" role="listitem" onClick={() => go(s)} className="rounded-full border border-line px-2.5 py-1 text-[11px] text-muted hover:border-primary-2 hover:text-fg">{s}</button>)}
      </div>
      {lastInvestigation && (
        <p className="mt-3 text-xs text-muted">Última investigação: <a className="text-primary-2 hover:underline" href={`/business-brain?c=${lastInvestigation.id}`}>{lastInvestigation.title}</a></p>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ personalização */

export function WidgetToggle({ widgets, hidden }: { widgets: { key: string; label: string }[]; hidden: string[] }) {
  const a = useAction();
  const [open, setOpen] = useState(false);
  const [h, setH] = useState(hidden);
  const save = async (next: string[]) => { setH(next); await a.run("/api/brain/widgets", { hidden: next }, {}); };
  return (
    <div className="relative">
      <Button size="sm" variant="secondary" onClick={() => setOpen((v) => !v)} aria-expanded={open}>Personalizar</Button>
      {open && (
        <div className="absolute right-0 z-20 mt-2 w-60 rounded-xl border border-line bg-surface p-3 shadow-xl">
          <p className="mb-2 text-xs text-muted">Mostrar no Command Center</p>
          {widgets.map((w) => (
            <label key={w.key} className={cx("flex items-center gap-2 py-1 text-sm", a.loading && "opacity-60")}>
              <input type="checkbox" checked={!h.includes(w.key)} disabled={a.loading}
                onChange={(e) => save(e.target.checked ? h.filter((x) => x !== w.key) : [...h, w.key])} />
              {w.label}
            </label>
          ))}
          <Feedback error={a.error} />
        </div>
      )}
    </div>
  );
}
