import Link from "next/link";
import { eq } from "drizzle-orm";
import { requirePageContext } from "@/server/auth/next";
import { organizations } from "@/server/db/schema";
import { listMembers, listRoles, listTeams } from "@/server/domains/admin";
import { auditTrail, dataLineage } from "@/server/domains/data-intelligence";
import { PERMISSIONS } from "@/server/permissions";
import { Badge, Card, CardTitle, Empty, PageHeader, Table, Td } from "@/components/ui";
import { ActionButton, ActionSelect, Collapsible, FieldsForm } from "@/components/admin/actions";
import { RoleEditor } from "@/components/admin/role-editor";
import { LgpdTool, CopyField } from "@/components/admin/lgpd";
import { date } from "@/lib/format";

export const metadata = { title: "Administração" };

export default async function AdminPage() {
  const ctx = await requirePageContext("admin:users");
  const can = (p: string) => ctx.permissions.includes("*") || ctx.permissions.includes(p);
  const o = { locale: ctx.locale, timezone: ctx.timezone };
  const [[org], members, roleList, teamList, logs, lineage] = await Promise.all([
    ctx.db.select().from(organizations).where(eq(organizations.id, ctx.organizationId)),
    listMembers(ctx), listRoles(ctx), listTeams(ctx),
    can("audit:read") ? auditTrail(ctx, 60) : Promise.resolve([]),
    can("audit:read") ? dataLineage(ctx) : Promise.resolve([]),
  ]);
  const base = process.env.APP_URL ?? "http://localhost:3000";
  const roleOpts = roleList.map((r) => ({ value: r.id, label: r.name }));
  const pending = members.filter((m) => m.status === "pending");
  const activeMembers = members.filter((m) => m.status === "active");

  return (
    <div className="mx-auto max-w-7xl space-y-6">
      <PageHeader title="Administração" subtitle={`Usuários, equipes, permissões, configurações e governança de dados de ${org.name}.`}
        actions={ctx.isPlatformAdmin ? <Link href="/admin/plataforma" className="text-sm text-primary-2 hover:underline">Painel global da plataforma →</Link> : undefined} />

      {pending.length > 0 && (
        <Card glow>
          <CardTitle sub="Cadastros individuais aguardando aprovação do administrador.">Aprovações pendentes ({pending.length})</CardTitle>
          <div className="space-y-2">
            {pending.map((m) => (
              <div key={m.membershipId} className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-line p-3">
                <span className="text-sm">{m.name} <span className="text-muted">· {m.email}</span></span>
                <span className="flex gap-2">
                  <ActionButton url="/api/admin" body={{ action: "membership", membershipId: m.membershipId, status: "active" }} label="Aprovar" variant="primary" success="Aprovado." />
                  <ActionButton url="/api/admin" body={{ action: "membership", membershipId: m.membershipId, status: "disabled" }} label="Recusar" variant="danger" confirm="Recusar este acesso?" />
                </span>
              </div>
            ))}
          </div>
        </Card>
      )}

      <Card>
        <CardTitle sub="Novos colaboradores se cadastram pelo link e ficam pendentes até sua aprovação.">Usuários ({members.length})</CardTitle>
        <div className="mb-4 max-w-xl"><CopyField value={`${base}/cadastro?convite=${org.slug}`} /></div>
        <Table head={["Nome", "E-mail", "Cargo", "Status", "2FA", "Último acesso", ""]}>
          {members.map((m) => (
            <tr key={m.membershipId}>
              <Td>{m.name}</Td><Td className="text-xs">{m.email}</Td>
              <Td>{m.userId === ctx.userId ? m.roleName : <ActionSelect label="Cargo" url="/api/admin" value={m.roleId} options={roleOpts} bodyBase={{ action: "membership", membershipId: m.membershipId }} valueKey="roleId" />}</Td>
              <Td><Badge tone={m.status === "active" ? "success" : m.status === "pending" ? "warning" : "neutral"}>{{ active: "Ativo", pending: "Pendente", disabled: "Desativado" }[m.status] ?? m.status}</Badge></Td>
              <Td>{m.totpEnabled ? <Badge tone="success">Ativo</Badge> : <Badge>Não</Badge>}</Td>
              <Td className="text-xs">{date(m.lastLoginAt, o, true)}</Td>
              <Td>{m.userId !== ctx.userId && (m.status === "active"
                ? <ActionButton url="/api/admin" body={{ action: "membership", membershipId: m.membershipId, status: "disabled" }} label="Desativar" variant="ghost" confirm={`Desativar ${m.name}? As sessões serão encerradas.`} />
                : m.status === "disabled" && <ActionButton url="/api/admin" body={{ action: "membership", membershipId: m.membershipId, status: "active" }} label="Reativar" variant="ghost" />)}</Td>
            </tr>
          ))}
        </Table>
      </Card>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardTitle>Equipes</CardTitle>
          <div className="mb-4"><FieldsForm url="/api/admin" extra={{ action: "create_team" }} fields={[{ name: "name", label: "Nova equipe", required: true }]} submitLabel="Criar equipe" success="Equipe criada." reset /></div>
          {teamList.length ? teamList.map((t) => (
            <div key={t.id} className="mb-3 rounded-lg border border-line p-3">
              <p className="font-medium">{t.name} <span className="text-xs text-muted">({t.members.length})</span></p>
              <div className="mt-2 flex flex-wrap gap-1">
                {t.members.map((mm) => <span key={mm.userId} className="inline-flex items-center gap-1"><Badge>{mm.name}</Badge><ActionButton url="/api/admin" body={{ action: "team_member", teamId: t.id, userId: mm.userId, add: false }} label="×" variant="ghost" /></span>)}
              </div>
              {activeMembers.some((m) => !t.members.some((x) => x.userId === m.userId)) && (
                <div className="mt-2 max-w-xs">
                  <ActionSelect label="Adicionar membro" url="/api/admin" value=""
                    options={[{ value: "", label: "+ Adicionar membro" }, ...activeMembers.filter((m) => !t.members.some((x) => x.userId === m.userId)).map((m) => ({ value: m.userId, label: m.name }))]}
                    bodyBase={{ action: "team_member", teamId: t.id, add: true }} valueKey="userId" />
                </div>
              )}
            </div>
          )) : <Empty title="Nenhuma equipe criada." />}
        </Card>

        <Card>
          <CardTitle>Configurações da organização</CardTitle>
          {can("admin:settings") ? (
            <FieldsForm url="/api/admin" extra={{ action: "org_settings" }} columns={2} success="Configurações salvas."
              fields={[
                { name: "name", label: "Nome", defaultValue: org.name, required: true },
                { name: "locale", label: "Idioma", type: "select", defaultValue: org.locale, options: [{ value: "pt-BR", label: "Português (Brasil)" }, { value: "en", label: "English" }, { value: "es", label: "Español" }] },
                { name: "currency", label: "Moeda", type: "select", defaultValue: org.currency, options: [{ value: "BRL", label: "Real (BRL)" }, { value: "USD", label: "Dólar (USD)" }, { value: "EUR", label: "Euro (EUR)" }] },
                { name: "timezone", label: "Fuso horário", defaultValue: org.timezone, placeholder: "America/Sao_Paulo" },
              ]} />
          ) : <p className="text-sm text-muted">Requer permissão admin:settings.</p>}
        </Card>
      </div>

      <Card>
        <CardTitle sub="Permissões por módulo e ação. Verificadas sempre no backend.">Cargos e permissões</CardTitle>
        <div className="space-y-4">
          {roleList.map((r) => (
            <div key={r.id} className="rounded-lg border border-line p-3">
              <div className="mb-2 flex items-center gap-2"><p className="font-medium">{r.name}</p>{r.isSystem && <Badge>Sistema</Badge>}<span className="text-xs text-muted">{r.permissions.length} permissões</span></div>
              <Collapsible label={r.isSystem ? "Ver permissões" : "Editar"}><RoleEditor all={PERMISSIONS} role={r} /></Collapsible>
            </div>
          ))}
          {can("admin:settings") && <Collapsible label="+ Novo cargo personalizado"><RoleEditor all={PERMISSIONS} /></Collapsible>}
        </div>
      </Card>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardTitle sub="Portabilidade e direitos dos titulares.">LGPD e dados</CardTitle>
          {can("export:data") && <a href="/api/export" className="mb-4 inline-flex rounded-lg border border-line bg-surface-2 px-3 py-1.5 text-xs hover:border-primary-2">Exportar todos os dados (JSON)</a>}
          {can("admin:settings") ? <LgpdTool /> : <p className="text-sm text-muted">Requer permissão admin:settings.</p>}
        </Card>
        <Card>
          <CardTitle sub="Origem, classificação e base legal dos dados importados.">Linhagem de dados</CardTitle>
          {lineage.length ? (
            <Table head={["Fonte", "Tipo", "Classificação", "Base legal", "Registros"]}>
              {lineage.map((d) => <tr key={d.id}><Td>{d.name}</Td><Td>{d.kind}</Td><Td><Badge>{d.classification}</Badge></Td><Td className="text-xs">{d.legalBasis ?? "—"}</Td><Td>{d.recordsImported}</Td></tr>)}
            </Table>
          ) : <Empty title="Nenhuma fonte registrada." />}
        </Card>
      </div>

      <Card>
        <CardTitle>Auditoria (últimos 60 registros)</CardTitle>
        {logs.length ? (
          <Table head={["Data", "Ator", "Ação", "Recurso", "IP"]}>
            {logs.map((l) => <tr key={l.id}><Td className="text-xs">{date(l.createdAt, o, true)}</Td><Td className="text-xs">{l.actorId?.startsWith("ai:") ? <Badge tone="primary">{l.actorId}</Badge> : members.find((m) => m.userId === l.actorId)?.name ?? l.actorId}</Td><Td className="text-xs">{l.action}</Td><Td className="text-xs">{l.resource}</Td><Td className="text-xs">{l.ip ?? "—"}</Td></tr>)}
          </Table>
        ) : <Empty title={can("audit:read") ? "Sem registros." : "Requer permissão audit:read."} />}
      </Card>
    </div>
  );
}
