import { redirect } from "next/navigation";
import { requirePageContext } from "@/server/auth/next";
import { auditPlatformAccess, listCoupons, listExperiments, listFlags, listIncidents, platformOverview } from "@/server/domains/platform";
import { CATEGORIES, PLAYBOOKS, SEVERITIES } from "@/server/domains/incidents";
import { Badge, Card, CardTitle, Empty, PageHeader, Stat, Table, Td } from "@/components/ui";
import { ActionButton, ActionSelect, Collapsible, FieldsForm } from "@/components/admin/actions";
import { date, money, num } from "@/lib/format";

export const metadata = { title: "Painel global" };

const SUB_TONE: Record<string, "success" | "info" | "warning" | "danger" | "neutral"> = { active: "success", trialing: "info", past_due: "warning", suspended: "danger", canceled: "neutral" };
const INC_STATUS: Record<string, string> = { investigating: "Investigando", identified: "Identificado", monitoring: "Monitorando", resolved: "Resolvido", postmortem: "Pós-incidente" };
const EXP_STATUS: Record<string, string> = { draft: "Rascunho", running: "Em execução", stopped: "Interrompido", concluded: "Concluído" };

export default async function PlataformaPage() {
  const ctx = await requirePageContext();
  if (!ctx.isPlatformAdmin) redirect("/dashboard?erro=permissao");
  await auditPlatformAccess(ctx, "painel_global");
  const o = { locale: ctx.locale, currency: ctx.currency, timezone: ctx.timezone };
  const [ov, flags, exps, incs, cps] = await Promise.all([platformOverview(ctx), listFlags(ctx), listExperiments(ctx), listIncidents(ctx), listCoupons(ctx)]);
  const orgOpts = ov.orgs.map((x) => ({ value: x.id, label: x.name }));

  return (
    <div className="mx-auto max-w-7xl space-y-6">
      <PageHeader title="Painel global ORBITY-NEPTUNE" subtitle="Acesso restrito a administradores da plataforma. Todo acesso e alteração é auditado." />

      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
        <Stat label="Organizações" value={num(ov.orgs.length, o.locale)} />
        <Stat label="MRR" value={ov.pricedActive ? money(ov.mrrCents, o) : "Preços a definir"} hint={ov.unpricedActive ? `${ov.unpricedActive} assinatura(s) ativa(s) em planos sem preço` : undefined} />
        <Stat label="ARR" value={ov.pricedActive ? money(ov.arrCents, o) : "Preços a definir"} />
        <Stat label="Ativas / Teste" value={`${ov.counts.active} / ${ov.counts.trialing}`} hint={`${ov.counts.pastDue} inadimplente(s) · ${ov.counts.suspended} suspensa(s)`} />
        <Stat label="Retenção" value={ov.retentionPct == null ? "—" : `${String(ov.retentionPct).replace(".", ",")}%`} hint={`${ov.counts.canceled} cancelamento(s) no total`} />
        <Stat label="Custo de IA" value={`${num(ov.ai.credits, o.locale)} créditos`} hint={`${num(ov.ai.tokens, o.locale)} tokens · ${num(ov.ai.runs, o.locale)} execuções (${num(ov.ai.simulated, o.locale)} simuladas)`} />
      </div>

      <Card>
        <CardTitle>Organizações</CardTitle>
        <Table head={["Organização", "Segmento", "Usuários", "Plano", "Assinatura", "Renovação", "Status", ""]}>
          {ov.orgs.map((x) => (
            <tr key={x.id}>
              <Td>{x.name} {x.isDemo && <Badge tone="warning">Demo</Badge>}</Td>
              <Td className="text-xs">{x.segment ?? "—"}</Td><Td>{x.users}</Td>
              <Td className="text-xs">{x.sub?.plan ?? "—"}</Td>
              <Td>{x.sub ? <Badge tone={SUB_TONE[x.sub.status] ?? "neutral"}>{x.sub.status}</Badge> : "—"}</Td>
              <Td className="text-xs">{date(x.sub?.periodEnd, o)}</Td>
              <Td><Badge tone={x.status === "active" ? "success" : "danger"}>{x.status === "active" ? "Ativa" : "Suspensa"}</Badge></Td>
              <Td>{x.id !== ctx.organizationId && (x.status === "active"
                ? <ActionButton url="/api/platform" body={{ action: "org_status", organizationId: x.id, status: "suspended" }} label="Suspender" variant="danger" confirm={`Suspender ${x.name}? Os usuários perderão acesso.`} />
                : <ActionButton url="/api/platform" body={{ action: "org_status", organizationId: x.id, status: "active" }} label="Reativar" />)}</Td>
            </tr>
          ))}
        </Table>
      </Card>

      <Card>
        <CardTitle sub="Feature flags não substituem autenticação nem autorização. Liberação por plano, segmento, organização ou rollout gradual.">Feature Management</CardTitle>
        <div className="space-y-3">
          {flags.map((f) => (
            <div key={f.id} className="rounded-lg border border-line p-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <p className="font-medium"><code>{f.key}</code> <Badge tone={f.enabled ? "success" : "neutral"}>{f.enabled ? "Ligada" : "Desligada"}</Badge> <Badge tone="info">{f.rolloutPct}% rollout</Badge></p>
                  <p className="text-xs text-muted">{f.description} · Planos: {f.plans.join(", ") || "todos"}</p>
                  {f.overrides.length > 0 && <p className="mt-1 text-xs text-muted">Exceções: {f.overrides.map((x) => `${x.orgName ?? "usuário"} (${x.enabled ? "on" : "off"})`).join(", ")}</p>}
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <ActionButton url="/api/platform" body={{ action: "save_flag", flag: { key: f.key, description: f.description, enabled: !f.enabled, rolloutPct: f.rolloutPct, plans: f.plans, segments: f.segments } }} label={f.enabled ? "Desligar (rollback)" : "Ligar"} />
                  <ActionSelect label="Exceção por organização" url="/api/platform" value="" options={[{ value: "", label: "Habilitar p/ organização..." }, ...orgOpts]} bodyBase={{ action: "flag_override", flagKey: f.key, enabled: true }} valueKey="organizationId" />
                </div>
              </div>
              <div className="mt-2">
                <Collapsible label="Editar">
                  <FieldsForm url="/api/platform" columns={2} success="Flag salva."
                    extra={{ action: "save_flag" }} nestUnder="flag" nestExtra={{ key: f.key, segments: f.segments }}
                    fields={[
                      { name: "description", label: "Descrição", defaultValue: f.description },
                      { name: "rolloutPct", label: "Rollout (%)", type: "number", defaultValue: f.rolloutPct },
                      { name: "plans", label: "Planos (vírgula; vazio = todos)", transform: "list", defaultValue: f.plans.join(", ") },
                      { name: "enabled", label: "Ligada", type: "checkbox", defaultValue: f.enabled },
                    ]} />
                  {f.overrides.map((x) => x.organizationId && <div key={x.id} className="mt-2"><ActionButton url="/api/platform" body={{ action: "flag_override", flagKey: f.key, organizationId: x.organizationId, enabled: null }} label={`Remover exceção: ${x.orgName}`} variant="ghost" /></div>)}
                </Collapsible>
              </div>
            </div>
          ))}
          <Collapsible label="+ Nova flag">
            <FieldsForm url="/api/platform" columns={2} success="Flag criada." reset extra={{ action: "save_flag" }} nestUnder="flag" nestExtra={{ segments: [] }}
              fields={[
                { name: "key", label: "Chave", placeholder: "nova_funcionalidade", required: true },
                { name: "description", label: "Descrição", required: true },
                { name: "rolloutPct", label: "Rollout (%)", type: "number", defaultValue: 0 },
                { name: "plans", label: "Planos (vírgula)", transform: "list" },
                { name: "enabled", label: "Ligada", type: "checkbox" },
              ]} />
          </Collapsible>
        </div>
      </Card>

      <Card>
        <CardTitle sub="Resultados só são declarados significativos com amostra mínima e p < 0,05. Caso contrário: INCONCLUSIVO.">Experimentation Center</CardTitle>
        <div className="space-y-3">
          {exps.length ? exps.map((e) => (
            <div key={e.id} className="rounded-lg border border-line p-3 text-sm">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <p className="font-medium"><code>{e.key}</code> <Badge tone={e.status === "running" ? "success" : "neutral"}>{EXP_STATUS[e.status] ?? e.status}</Badge></p>
                <div className="flex gap-2">
                  {e.status !== "running" && e.status !== "concluded" && <ActionButton url="/api/platform" body={{ action: "experiment_status", id: e.id, status: "running" }} label="Iniciar" />}
                  {e.status === "running" && <ActionButton url="/api/platform" body={{ action: "experiment_status", id: e.id, status: "stopped" }} label="Interromper" variant="danger" confirm="Interromper o experimento?" />}
                  {e.status !== "concluded" && <ActionButton url="/api/platform" body={{ action: "experiment_status", id: e.id, status: "concluded" }} label="Concluir" confirm="Concluir com a avaliação estatística atual?" />}
                </div>
              </div>
              <p className="mt-1 text-xs text-muted">Hipótese: {e.hypothesis}</p>
              <p className="text-xs text-muted">Público: {e.audience} · Métrica: {e.primaryMetric} · Responsável: {e.owner}</p>
              <div className="mt-2 flex flex-wrap gap-3 text-xs">{e.variants.map((v) => <span key={v.key}><strong>{v.key}</strong>: {v.conversions}/{v.exposures} ({v.exposures ? ((v.conversions / v.exposures) * 100).toFixed(1) : "0"}%)</span>)}</div>
              <p className={`mt-2 text-xs ${e.evaluation.conclusive ? "text-success" : "text-warning"}`}>{e.evaluation.message}</p>
              {e.conclusion && <p className="text-xs text-muted">Conclusão registrada: {e.conclusion}</p>}
            </div>
          )) : <Empty title="Nenhum experimento." />}
          <Collapsible label="+ Novo experimento">
            <FieldsForm url="/api/platform" columns={2} success="Experimento criado." reset extra={{ action: "create_experiment" }} nestUnder="experiment"
              fields={[
                { name: "key", label: "Chave", placeholder: "onboarding-v3", required: true },
                { name: "hypothesis", label: "Hipótese", required: true },
                { name: "objective", label: "Objetivo", required: true },
                { name: "audience", label: "Público/segmento", required: true },
                { name: "primaryMetric", label: "Métrica principal", required: true },
                { name: "owner", label: "Responsável", required: true },
                { name: "variantA", label: "Variante A", defaultValue: "controle" },
                { name: "variantB", label: "Variante B", defaultValue: "variante" },
              ]} />
          </Collapsible>
        </div>
      </Card>

      <Card>
        <CardTitle>Incident Management</CardTitle>
        <div className="mb-4 grid gap-2 md:grid-cols-2 xl:grid-cols-4">
          {Object.entries(SEVERITIES).map(([k, s]) => <div key={k} className="rounded-lg border border-line p-2 text-xs"><p className="font-semibold">{s.label}</p><p className="text-muted">{s.criteria}</p><p className="mt-1">{s.response}</p></div>)}
        </div>
        <div className="space-y-3">
          {incs.length ? incs.map((i) => (
            <div key={i.id} className="rounded-lg border border-line p-3 text-sm">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <p className="font-medium">{i.title}</p>
                <span className="flex gap-1"><Badge tone={i.severity === "sev1" ? "danger" : i.severity === "sev2" ? "warning" : "info"}>{i.severity.toUpperCase()}</Badge><Badge>{CATEGORIES[i.category as keyof typeof CATEGORIES] ?? i.category}</Badge><Badge tone={i.status === "resolved" ? "success" : "warning"}>{INC_STATUS[i.status] ?? i.status}</Badge></span>
              </div>
              {i.impact && <p className="mt-1 text-xs text-muted">Impacto: {i.impact}</p>}
              <ul className="mt-2 space-y-0.5 text-xs text-muted">{i.timeline.map((t, idx) => <li key={idx}>{date(t.at, o, true)} — {t.note}</li>)}</ul>
              {i.rootCause && <p className="mt-1 text-xs">Causa raiz: {i.rootCause}</p>}
              {PLAYBOOKS[i.category] && <details className="mt-2 text-xs"><summary className="cursor-pointer text-primary-2">Playbook</summary><ol className="mt-1 list-decimal pl-5 text-muted">{PLAYBOOKS[i.category].map((s) => <li key={s}>{s}</li>)}</ol></details>}
              <div className="mt-2">
                <Collapsible label="Atualizar">
                  <FieldsForm url="/api/platform" columns={2} success="Incidente atualizado." extra={{ action: "update_incident", id: i.id }} nestUnder="patch"
                    fields={[
                      { name: "status", label: "Status", type: "select", defaultValue: i.status, options: Object.entries(INC_STATUS).map(([value, label]) => ({ value, label })) },
                      { name: "note", label: "Nota na linha do tempo" },
                      { name: "rootCause", label: "Causa raiz", type: "textarea", defaultValue: i.rootCause ?? "" },
                      { name: "correctiveActions", label: "Plano corretivo", type: "textarea", defaultValue: i.correctiveActions ?? "" },
                    ]} />
                </Collapsible>
              </div>
            </div>
          )) : <Empty title="Nenhum incidente registrado." />}
          <Collapsible label="+ Registrar incidente">
            <FieldsForm url="/api/platform" columns={2} success="Incidente aberto." reset extra={{ action: "create_incident" }} nestUnder="incident"
              fields={[
                { name: "title", label: "Título", required: true },
                { name: "severity", label: "Severidade", type: "select", defaultValue: "sev3", options: Object.entries(SEVERITIES).map(([value, s]) => ({ value, label: s.label })) },
                { name: "category", label: "Categoria", type: "select", defaultValue: "availability", options: Object.entries(CATEGORIES).map(([value, label]) => ({ value, label })) },
                { name: "impact", label: "Impacto", type: "textarea" },
              ]} />
          </Collapsible>
        </div>
      </Card>

      <Card>
        <CardTitle sub="Descontos só podem ser criados por administradores da plataforma.">Cupons</CardTitle>
        <div className="mb-4">
          <FieldsForm url="/api/platform" columns={3} success="Cupom criado." reset extra={{ action: "create_coupon" }} nestUnder="coupon"
            fields={[
              { name: "code", label: "Código", placeholder: "PILOTO2026", required: true },
              { name: "percentOff", label: "Desconto (%)", type: "number", required: true },
              { name: "maxRedemptions", label: "Máx. usos", type: "number" },
            ]} />
        </div>
        {cps.length ? (
          <Table head={["Código", "Desconto", "Usos", "Expira", "Criado"]}>
            {cps.map((c) => <tr key={c.id}><Td><code>{c.code}</code></Td><Td>{c.percentOff}%</Td><Td>{c.redemptions}/{c.maxRedemptions ?? "∞"}</Td><Td className="text-xs">{date(c.expiresAt, o)}</Td><Td className="text-xs">{date(c.createdAt, o)}</Td></tr>)}
          </Table>
        ) : <Empty title="Nenhum cupom." />}
      </Card>
    </div>
  );
}
