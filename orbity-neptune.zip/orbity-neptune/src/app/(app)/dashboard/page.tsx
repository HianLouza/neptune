import Link from "next/link";
import { eq } from "drizzle-orm";
import { Users, ArrowRight, Zap, Flame, Network, TriangleAlert, CircleCheck, ChevronRight, SquareCheck, CalendarDays, Phone, EllipsisVertical, Clock, Target } from "lucide-react";
import { requirePageContext } from "@/server/auth/next";
import { users } from "@/server/db/schema";
import { aiActionSuggestions, mainGoalProgress, teamActivity } from "@/server/domains/intelligence";
import { dashboardBundle } from "@/server/domains/metrics";
import { pipelineBoard } from "@/server/domains/crm";
import { parseFilters } from "@/lib/metrics-filters";
import { money, num } from "@/lib/format";
import { t } from "@/lib/i18n";
import { DashboardExplorer } from "@/components/dashboard/explorer";
import { FlavioCard } from "@/components/flavio/flavio-card";
import { cx } from "@/components/ui";

export const metadata = { title: "Painel de vendas" };

const STAGE_STYLES: Record<string, string> = {
  violet: "from-primary/80 to-primary/40 border-primary/50",
  blue: "from-blue-600/80 to-blue-500/40 border-blue-500/50",
  amber: "from-amber-600/80 to-amber-500/40 border-amber-500/50",
  fuchsia: "from-navy/80 to-primary/40 border-primary/50",
  emerald: "from-emerald-600/80 to-emerald-500/40 border-emerald-500/50",
};

export default async function Dashboard({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const ctx = await requirePageContext();
  const sp = await searchParams;
  const filters = parseFilters(sp);
  const o = { locale: ctx.locale, currency: ctx.currency, timezone: ctx.timezone };
  const can = (p: string) => ctx.permissions.includes("*") || ctx.permissions.includes(p);
  const intel = can("intelligence:read");

  const [[me], bundle, board, actions, team, goal] = await Promise.all([
    ctx.db.select({ name: users.name }).from(users).where(eq(users.id, ctx.userId)),
    intel ? dashboardBundle(ctx, filters) : null,
    can("crm:read") ? pipelineBoard(ctx, 3) : null,
    intel ? aiActionSuggestions(ctx) : [],
    intel ? teamActivity(ctx) : null,
    intel ? mainGoalProgress(ctx) : null,
  ]);

  const actionIcon = (k: string) => ({ hot_leads: <Flame className="text-orange-400" />, automation: <Network className="text-accent" />, risk: <TriangleAlert className="text-danger" />, sla: <Clock className="text-warning" />, goal: <CircleCheck className="text-success" /> }[k] ?? <Zap />);

  return (
    <div className="mx-auto max-w-[1600px] space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">{t(o.locale, "dashboard.welcome")}</h1>
          <p className="mt-1 text-muted">{t(o.locale, "dashboard.subtitle")} <span className="text-fg/70">Olá, {me.name.split(" ")[0]}.</span></p>
        </div>
      </div>

      {!intel && <div className="card p-5 text-sm text-muted">Seu perfil não tem acesso aos indicadores. Use os módulos do menu lateral.</div>}

      {bundle && (
        <DashboardExplorer initial={bundle} initialFilters={filters} locale={o.locale} currency={o.currency}
          perms={{ crm: can("crm:read"), prospect: can("prospect:read"), exportData: can("export:data"), ai: can("ai:use") }} />
      )}

      <div className="grid gap-5 xl:grid-cols-[1fr_340px]">
        <div className="min-w-0 space-y-5">
          <div className="grid gap-5 lg:grid-cols-[1fr_300px] 2xl:grid-cols-[1fr_320px]">
            {board && (
              <section className="card min-w-0 p-5">
                <div className="mb-4 flex items-start justify-between">
                  <div><h2 className="text-lg font-semibold">Pipeline de Vendas</h2><p className="text-sm text-muted">Total: {num(board.columns.filter((c) => c.stage.kind === "open").reduce((a, c) => a + c.count, 0), o.locale)} oportunidades (posição atual, sem filtros)</p></div>
                  <Link href="/crm" className="flex items-center gap-1 text-sm text-primary-2 hover:underline">Ver pipeline completo <ArrowRight size={14} /></Link>
                </div>
                <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3 md:grid-cols-5">
                  {board.columns.filter((c) => c.stage.kind === "open").map((col) => (
                    <div key={col.stage.id} className={cx("overflow-hidden rounded-xl border bg-gradient-to-b to-bg-2/80", STAGE_STYLES[col.stage.color] ?? STAGE_STYLES.violet)}>
                      <div className="px-3 py-2"><p className="text-xs font-semibold text-white">{col.stage.name}</p><p className="text-lg font-bold text-white">{num(col.count, o.locale)}</p></div>
                      <div className="space-y-1.5 bg-bg-2/70 p-1.5">
                        {col.items.map((it) => (
                          <Link key={it.id} href={`/crm/oportunidade/${it.id}`} className="flex items-start justify-between rounded-lg border border-line bg-surface/80 p-2 hover:border-primary-2">
                            <span className="min-w-0"><span className="block truncate text-xs font-medium">{it.companyName ?? it.title}</span><span className="block text-[11px] text-muted">{money(Number(it.amountCents), o)}</span></span>
                            <EllipsisVertical size={14} className="mt-0.5 shrink-0 text-muted" />
                          </Link>
                        ))}
                        {col.count > col.items.length && <Link href={`/crm?etapa=${col.stage.id}`} className="block px-2 py-1 text-[11px] text-muted hover:text-fg">+ {num(col.count - col.items.length, o.locale)} mais</Link>}
                        {!col.count && <p className="px-2 py-2 text-[11px] text-muted">Vazio</p>}
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            )}
            {intel && (
              <section className="card p-5">
                <h2 className="mb-3 flex items-center gap-2 text-lg font-semibold"><Zap size={18} /> Ações sugeridas <span className="text-sm font-normal text-muted">(regras)</span></h2>
                <ul className="space-y-2">
                  {actions.map((a) => (
                    <li key={a.kind}>
                      <Link href={a.href} title={`Evidência: ${a.evidence}`} className="flex items-center gap-3 rounded-xl border border-line bg-surface-2/50 p-3 hover:border-primary-2">
                        <span className="shrink-0">{actionIcon(a.kind)}</span>
                        <span className="min-w-0 flex-1"><span className="block text-sm font-semibold">{a.title}</span><span className="block text-[11px] text-muted">{a.detail}</span></span>
                        <ChevronRight size={16} className="text-muted" />
                      </Link>
                    </li>
                  ))}
                </ul>
              </section>
            )}
          </div>

          {intel && team && (
            <div className="grid gap-5 lg:grid-cols-2">
              <section className="card p-5">
                <h2 className="mb-4 flex items-center gap-2 text-lg font-semibold"><Users size={18} /> Atividades do Time</h2>
                <div className="flex flex-wrap items-center gap-6">
                  <div>
                    <div className="flex -space-x-2">
                      {team.sellers.slice(0, 4).map((s) => <span key={s.id} title={s.name} className="flex h-9 w-9 items-center justify-center rounded-full border-2 border-bg bg-gradient-to-br from-primary to-navy text-xs font-bold text-white">{s.name.split(" ").map((x) => x[0]).slice(0, 2).join("")}</span>)}
                      {team.activeSellers > 4 && <span className="flex h-9 w-9 items-center justify-center rounded-full border-2 border-bg bg-primary text-xs font-bold text-white">+{team.activeSellers - 4}</span>}
                    </div>
                    <p className="mt-1 text-xs text-muted">{team.activeSellers} vendedores ativos</p>
                  </div>
                  {[[SquareCheck, team.tasksToday, "Tarefas hoje"], [CalendarDays, team.meetingsWeek, "Reuniões (7 dias)"], [Phone, team.followUpsWeek, "Follow-ups (7 dias)"]].map(([Icon, v, l]) => {
                    const I = Icon as typeof Phone;
                    return <div key={l as string} className="flex items-center gap-3 border-l border-line pl-6"><I size={22} className="text-muted" /><div><p className="text-xl font-bold">{num(v as number, o.locale)}</p><p className="text-xs text-muted">{l as string}</p></div></div>;
                  })}
                </div>
              </section>
              <section className="card p-5">
                <div className="mb-4 flex items-center justify-between">
                  <h2 className="flex items-center gap-2 text-lg font-semibold"><Target size={18} /> Metas do Período</h2>
                  <Link href="/tarefas" className="flex items-center gap-1 text-sm text-primary-2 hover:underline">Ver metas <ArrowRight size={14} /></Link>
                </div>
                {goal ? (
                  <>
                    <div className="mb-2 flex items-center justify-between text-sm">
                      <span><span className="mr-4">{goal.name}</span><span className="text-muted">{money(goal.achieved, o)} de {money(goal.target, o)}</span></span>
                      <span className="font-bold">{goal.pct}%</span>
                    </div>
                    <div className="h-3 overflow-hidden rounded-full bg-surface-2" role="progressbar" aria-valuenow={Math.min(100, goal.pct)} aria-valuemin={0} aria-valuemax={100} aria-label={`Progresso da meta ${goal.name}`}><div className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-green-400" style={{ width: `${Math.min(100, goal.pct)}%` }} /></div>
                  </>
                ) : <p className="text-sm text-muted">Nenhuma meta ativa. <Link href="/tarefas" className="text-primary-2 hover:underline">Criar meta</Link></p>}
              </section>
            </div>
          )}
        </div>
        <div className="xl:sticky xl:top-20 xl:self-start">{can("ai:use") && <FlavioCard />}</div>
      </div>
    </div>
  );
}
