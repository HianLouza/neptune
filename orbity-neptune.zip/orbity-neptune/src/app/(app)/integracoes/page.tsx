import { and, desc, eq, sql } from "drizzle-orm";
import { requirePageContext } from "@/server/auth/next";
import { listIntegrations, integrationLogsFor } from "@/server/domains/integrations";
import { events, organizations } from "@/server/db/schema";
import { EVENT_LABELS } from "@/server/events";
import { Badge, Card, CardTitle, Empty, PageHeader, Stat, Table, Td } from "@/components/ui";
import { ActionButton, Collapsible, FieldsForm } from "@/components/admin/actions";
import { date } from "@/lib/format";

export const metadata = { title: "Integrações" };

const STATUS: Record<string, { label: string; tone: "success" | "danger" | "neutral" | "warning" }> = {
  connected: { label: "Conectada", tone: "success" }, error: { label: "Erro", tone: "danger" }, disconnected: { label: "Desconectada", tone: "neutral" }, simulated: { label: "Simulada", tone: "warning" },
};
const FIELD_LABELS: Record<string, string> = { phoneNumberId: "Phone Number ID", accessToken: "Access Token", smtpUrl: "URL SMTP (smtp://usuario:senha@host:porta)", apiToken: "API Token", secretKey: "Secret Key", apiKey: "API Key" };

export default async function IntegracoesPage() {
  const ctx = await requirePageContext("integrations:read");
  const canManage = ctx.permissions.includes("*") || ctx.permissions.includes("integrations:manage");
  const o = { locale: ctx.locale, timezone: ctx.timezone };
  const [items, logs, [org], byStatus, dead] = await Promise.all([
    listIntegrations(ctx), integrationLogsFor(ctx),
    ctx.db.select({ slug: organizations.slug }).from(organizations).where(eq(organizations.id, ctx.organizationId)),
    ctx.db.select({ status: events.status, n: sql<number>`count(*)::int` }).from(events).where(eq(events.organizationId, ctx.organizationId)).groupBy(events.status),
    ctx.db.select().from(events).where(and(eq(events.organizationId, ctx.organizationId), sql`${events.status} in ('dead','failed')`)).orderBy(desc(events.createdAt)).limit(20),
  ]);
  const base = process.env.APP_URL ?? "http://localhost:3000";
  const categories = [...new Set(items.map((i) => i.category))];
  const count = (s: string) => byStatus.find((b) => b.status === s)?.n ?? 0;

  return (
    <div className="mx-auto max-w-7xl space-y-6">
      <PageHeader title="Central de Integrações" subtitle="Cada organização gerencia suas próprias credenciais (criptografadas em repouso). Uma integração só aparece como conectada após validação real com o provedor." />

      {categories.map((cat) => (
        <Card key={cat}>
          <CardTitle>{cat}</CardTitle>
          <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
            {items.filter((i) => i.category === cat).map((i) => {
              const st = STATUS[i.status] ?? STATUS.disconnected;
              return (
                <div key={i.provider} className="rounded-xl border border-line bg-bg-2/50 p-4">
                  <div className="flex items-start justify-between gap-2">
                    <p className="font-medium">{i.name}</p>
                    <Badge tone={st.tone}>{st.label}</Badge>
                  </div>
                  <p className="mt-1 text-xs text-muted">Autenticação: {i.auth === "oauth" ? "OAuth" : i.auth === "api_key" ? "Chave de API" : i.auth === "webhook" ? "Webhook" : "Nativa"}</p>
                  {i.note && <p className="mt-2 text-xs text-warning">{i.note}</p>}
                  {i.lastError && <p className="mt-2 text-xs text-danger">Último erro: {i.lastError}</p>}
                  {i.lastSyncAt && <p className="mt-1 text-[11px] text-muted">Última validação: {date(i.lastSyncAt, o, true)}</p>}
                  {canManage && i.auth === "api_key" && (
                    <div className="mt-3 flex flex-wrap gap-2">
                      <Collapsible label={i.status === "connected" ? "Atualizar credenciais" : "Conectar"}>
                        <FieldsForm url="/api/integrations" extra={{ action: "connect", provider: i.provider }} nestUnder="credentials"
                          fields={i.fields.map((f) => ({ name: f, label: FIELD_LABELS[f] ?? f, type: "password" as const, required: true }))}
                          submitLabel={i.connectable ? "Validar e conectar" : "Salvar credencial"} success="Processado — veja o status acima." />
                      </Collapsible>
                      {i.status !== "disconnected" && <ActionButton url="/api/integrations" body={{ action: "disconnect", provider: i.provider }} label="Desconectar" variant="danger" confirm={`Desconectar ${i.name}? As credenciais serão apagadas.`} />}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </Card>
      ))}

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardTitle sub="Use estas URLs para receber mensagens e eventos externos nesta organização.">Webhooks da organização</CardTitle>
          <div className="space-y-3 text-sm">
            <div><p className="text-xs text-muted">Webchat (POST)</p><code className="block break-all rounded-lg bg-bg-2 p-2 text-xs">{base}/api/webhooks/webchat?org={org.slug}</code></div>
            <div><p className="text-xs text-muted">WhatsApp Business Platform (verificação GET + eventos POST)</p><code className="block break-all rounded-lg bg-bg-2 p-2 text-xs">{base}/api/webhooks/whatsapp?org={org.slug}</code></div>
            <p className="text-xs text-muted">O token de verificação do WhatsApp é definido em WHATSAPP_VERIFY_TOKEN no servidor. Zapier, Make e n8n podem enviar eventos para o webhook genérico de webchat.</p>
          </div>
        </Card>
        <Card>
          <CardTitle sub="Retry com backoff exponencial; após o limite de tentativas o evento vai para a dead-letter queue.">Event Engine — monitor</CardTitle>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <Stat label="Pendentes" value={count("pending") + count("processing")} />
            <Stat label="Concluídos" value={count("done")} />
            <Stat label="Em retry" value={count("failed")} />
            <Stat label="Dead-letter" value={count("dead")} />
          </div>
        </Card>
      </div>

      <Card>
        <CardTitle>Eventos com falha / dead-letter</CardTitle>
        {dead.length ? (
          <Table head={["Evento", "Status", "Tentativas", "Último erro", "Criado", ""]}>
            {dead.map((e) => (
              <tr key={e.id}>
                <Td>{EVENT_LABELS[e.type] ?? e.type}</Td>
                <Td><Badge tone={e.status === "dead" ? "danger" : "warning"}>{e.status === "dead" ? "Dead-letter" : "Retry agendado"}</Badge></Td>
                <Td>{e.attempts}/{e.maxAttempts}</Td>
                <Td className="max-w-xs truncate text-xs text-muted">{e.lastError ?? "—"}</Td>
                <Td className="text-xs">{date(e.createdAt, o, true)}</Td>
                <Td>{canManage && <ActionButton url="/api/integrations/events" body={{ eventId: e.id }} label="Reprocessar" success="Reenfileirado." />}</Td>
              </tr>
            ))}
          </Table>
        ) : <Empty title="Nenhuma falha de processamento.">Todos os eventos foram processados com sucesso.</Empty>}
      </Card>

      <Card>
        <CardTitle>Logs de integrações</CardTitle>
        {logs.length ? (
          <Table head={["Data", "Nível", "Mensagem"]}>
            {logs.map((l) => <tr key={l.id}><Td className="text-xs">{date(l.createdAt, o, true)}</Td><Td><Badge tone={l.level === "error" ? "danger" : "info"}>{l.level}</Badge></Td><Td className="text-xs">{l.message}</Td></tr>)}
          </Table>
        ) : <Empty title="Sem registros ainda." />}
      </Card>
    </div>
  );
}
