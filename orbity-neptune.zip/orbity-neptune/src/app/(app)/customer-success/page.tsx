import { redirect } from "next/navigation";
import { desc, inArray } from "drizzle-orm";
import { requirePageContext } from "@/server/auth/next";
import { auditPlatformAccess, csOverview } from "@/server/domains/platform";
import { csInteractions } from "@/server/db/schema";
import { Badge, Card, CardTitle, Empty, PageHeader, Progress, Stat, Table, Td } from "@/components/ui";
import { Collapsible, FieldsForm } from "@/components/admin/actions";
import { date } from "@/lib/format";

export const metadata = { title: "Customer Success" };

const TONE: Record<string, "success" | "warning" | "danger" | "neutral"> = { "Saudável": "success", "Atenção": "warning", "Risco": "danger", "Crítico": "danger" };
const SIGNAL_LABELS: Record<string, string> = { access: "Frequência de acesso", activeUsers: "Usuários ativos", featureAdoption: "Adoção de funcionalidades", integrations: "Integrações ativas", results: "Resultados", tickets: "Chamados críticos (inverso)", billing: "Situação financeira" };

export default async function CustomerSuccessPage() {
  const ctx = await requirePageContext();
  if (!ctx.isPlatformAdmin) redirect("/dashboard?erro=permissao");
  await auditPlatformAccess(ctx, "customer_success");
  const o = { locale: ctx.locale, timezone: ctx.timezone };
  const { rows, counts, renewals, config } = await csOverview(ctx);
  const sorted = [...rows].sort((a, b) => a.health.score - b.health.score);
  const interactions = rows.length ? await ctx.db.select().from(csInteractions).where(inArray(csInteractions.organizationId, rows.map((r) => r.id))).orderBy(desc(csInteractions.createdAt)).limit(30) : [];
  const weights = config.weights as Record<string, number>;
  const th = config.thresholds as { healthy: number; attention: number; risk: number };
  const orgName = (id: string) => rows.find((r) => r.id === id)?.name ?? id;

  return (
    <div className="mx-auto max-w-7xl space-y-6">
      <PageHeader title="Customer Success" subtitle="Customer Health Score com critérios transparentes e configuráveis. A IA recomenda ações; comunicações externas sensíveis exigem aprovação humana." />

      <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
        {(["Saudável", "Atenção", "Risco", "Crítico"] as const).map((k) => <Stat key={k} label={k} value={counts[k] ?? 0} />)}
        <Stat label="Renovações em 30 dias" value={renewals.length} />
      </div>

      <Card>
        <CardTitle sub={`Limiares: Saudável ≥ ${th.healthy} · Atenção ≥ ${th.attention} · Risco ≥ ${th.risk} · abaixo = Crítico`}>Clientes por saúde</CardTitle>
        <div className="space-y-3">
          {sorted.map((r) => (
            <div key={r.id} className="rounded-xl border border-line p-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <p className="font-medium">{r.name} {r.isDemo && <Badge tone="warning">Demo</Badge>} <span className="text-xs text-muted">· {r.segment ?? "sem segmento"} · {r.plan ?? "sem plano"} · {r.subStatus ?? "—"}</span></p>
                <span className="flex items-center gap-2"><span className="text-xl font-bold">{r.health.score}</span><Badge tone={TONE[r.health.status] ?? "neutral"}>{r.health.status}</Badge></span>
              </div>
              <div className="mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
                {Object.entries(r.health.signals).map(([k, v]) => (
                  <div key={k}>
                    <div className="flex justify-between text-[11px] text-muted"><span>{SIGNAL_LABELS[k] ?? k}</span><span>{Math.round(v * 100)}% · peso {weights[k] ?? 0}</span></div>
                    <Progress value={v * 100} tone={v >= 0.7 ? "success" : v >= 0.4 ? "warning" : "danger"} />
                  </div>
                ))}
              </div>
              {r.health.recommendations.length > 0 && <ul className="mt-3 list-disc space-y-0.5 pl-5 text-xs text-muted">{r.health.recommendations.map((x) => <li key={x}>{x}</li>)}</ul>}
              <div className="mt-3">
                <Collapsible label="Registrar interação">
                  <FieldsForm url="/api/platform/cs" extra={{ action: "interaction", organizationId: r.id }} columns={2} success="Interação registrada." reset
                    fields={[
                      { name: "type", label: "Tipo", type: "select", defaultValue: "call", options: [{ value: "call", label: "Ligação" }, { value: "email", label: "E-mail" }, { value: "meeting", label: "Reunião" }, { value: "playbook", label: "Playbook" }, { value: "task", label: "Tarefa" }] },
                      { name: "note", label: "Anotação", type: "textarea", required: true },
                    ]} />
                </Collapsible>
              </div>
            </div>
          ))}
          {!rows.length && <Empty title="Nenhuma organização." />}
        </div>
      </Card>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardTitle>Renovações próximas</CardTitle>
          {renewals.length ? (
            <Table head={["Cliente", "Plano", "Fim do período", "Saúde"]}>
              {renewals.map((r) => <tr key={r.id}><Td>{r.name}</Td><Td>{r.plan ?? "—"}</Td><Td className="text-xs">{date(r.periodEnd, o)}</Td><Td><Badge tone={TONE[r.health.status] ?? "neutral"}>{r.health.status}</Badge></Td></tr>)}
            </Table>
          ) : <Empty title="Nenhuma renovação nos próximos 30 dias." />}
        </Card>
        <Card>
          <CardTitle>Histórico de relacionamento</CardTitle>
          {interactions.length ? (
            <ul className="space-y-2 text-sm">{interactions.map((i) => <li key={i.id} className="rounded-lg border border-line p-2"><p className="text-xs text-muted">{date(i.createdAt, o, true)} · {orgName(i.organizationId)} · {i.type}</p><p>{i.note}</p></li>)}</ul>
          ) : <Empty title="Nenhuma interação registrada." />}
        </Card>
      </div>

      <Card>
        <CardTitle sub="Pesos de 0 a 1 por sinal; o score é a média ponderada × 100.">Configuração do Health Score</CardTitle>
        <FieldsForm url="/api/platform/cs" columns={3} success="Configuração salva."
          extra={{ action: "config" }} shape={[{ key: "weights", prefix: "w_" }, { key: "thresholds", fields: ["healthy", "attention", "risk"] }]}
          fields={[
            ...Object.entries(weights).map(([k, v]) => ({ name: `w_${k}`, label: `Peso: ${SIGNAL_LABELS[k] ?? k}`, type: "number" as const, defaultValue: v })),
            { name: "healthy", label: "Limiar Saudável", type: "number", defaultValue: th.healthy },
            { name: "attention", label: "Limiar Atenção", type: "number", defaultValue: th.attention },
            { name: "risk", label: "Limiar Risco", type: "number", defaultValue: th.risk },
          ]} />
      </Card>
    </div>
  );
}
