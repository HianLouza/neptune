import { and, eq } from "drizzle-orm";
import { requirePageContext } from "@/server/auth/next";
import { listTasks } from "@/server/domains/crm";
import { goalsWithProgress, listCommissionRules } from "@/server/domains/goals";
import { sellerPerformance } from "@/server/domains/intelligence";
import { memberships, users } from "@/server/db/schema";
import { Badge, Card, CardTitle, Empty, PageHeader, Progress, Table, Td } from "@/components/ui";
import { CommissionRuleForm, CommissionSimulator, NewGoalForm, NewTaskForm, TaskActions, TaskFilter } from "@/components/goals/goals-ui";
import { GenerateAlertButton } from "@/components/task-alerts/alert-dialog";
import { listAlerts, STATUS_LABEL, type AlertStatus } from "@/server/domains/task-alerts";
import Link from "next/link";
import { date, money, num } from "@/lib/format";

export const metadata = { title: "Tarefas & Metas" };

const PRIORITY = { high: ["Alta", "danger"], medium: ["Média", "warning"], low: ["Baixa", "neutral"] } as const;
const METRIC = { revenue: "Receita", deals_won: "Negócios ganhos", leads: "Leads", meetings: "Reuniões" } as Record<string, string>;
const SCOPE = { organization: "Organização", team: "Equipe", user: "Vendedor", product: "Produto", channel: "Canal" } as Record<string, string>;

export default async function TarefasPage({ searchParams }: { searchParams: Promise<{ minhas?: string }> }) {
  const ctx = await requirePageContext("goals:read");
  const can = (p: string) => ctx.permissions.includes("*") || ctx.permissions.includes(p);
  const mine = (await searchParams).minhas === "1";
  const o = { locale: ctx.locale, currency: ctx.currency, timezone: ctx.timezone };
  const orgUsers = await ctx.db.select({ id: users.id, name: users.name }).from(memberships).innerJoin(users, eq(users.id, memberships.userId))
    .where(and(eq(memberships.organizationId, ctx.organizationId), eq(memberships.status, "active"))).orderBy(users.name);
  const canAlert = can("alerts:send");
  const [taskRows, goals, rules, ranking, alertRows, senderRow] = await Promise.all([
    can("crm:read") ? listTasks(ctx, mine) : Promise.resolve([]),
    goalsWithProgress(ctx),
    listCommissionRules(ctx),
    can("intelligence:read") ? sellerPerformance(ctx, 30) : Promise.resolve([]),
    canAlert ? listAlerts(ctx, { limit: 500 }) : Promise.resolve([]),
    ctx.db.select({ name: users.name }).from(users).where(eq(users.id, ctx.userId)),
  ]);
  // Último alerta por tarefa (para mostrar o estado real e abrir o histórico).
  const lastAlert = new Map<string, { id: string; status: string; count: number }>();
  for (const { a } of alertRows) { const cur = lastAlert.get(a.taskId); if (!cur) lastAlert.set(a.taskId, { id: a.id, status: a.status, count: 1 }); else cur.count++; }
  const senderName = senderRow[0]?.name ?? "Você";
  const now = Date.now();
  const open = taskRows.filter((r) => r.t.status === "open");
  const overdue = open.filter((r) => r.t.dueAt && r.t.dueAt.getTime() < now).length;
  const activeRule = rules.find((r) => r.active) ?? null;
  const userName = (id: string | null) => orgUsers.find((u) => u.id === id)?.name ?? id ?? "";
  const currencySymbol = new Intl.NumberFormat(o.locale, { style: "currency", currency: o.currency }).formatToParts(0).find((p) => p.type === "currency")?.value ?? o.currency;

  return (
    <div className="mx-auto max-w-[1500px] space-y-5">
      <PageHeader title="Tarefas & Metas" subtitle="Execução diária, metas por escopo, comissões auditáveis e ranking do time." />

      <div className="grid gap-5 lg:grid-cols-[1fr_380px]">
        <Card>
          <CardTitle sub={`${num(open.length, o.locale)} abertas · ${num(overdue, o.locale)} atrasadas (exibindo até 300)`} action={<TaskFilter mine={mine} />}>Tarefas</CardTitle>
          {taskRows.length ? (
            <Table head={["Ações", "Tarefa", "Prioridade", "Responsável", "Prazo", "Status"]}>
              {taskRows.slice(0, 300).map(({ t, assignee }) => {
                const late = t.status === "open" && t.dueAt && t.dueAt.getTime() < now;
                const la = lastAlert.get(t.id);
                return (
                  <tr key={t.id} id={`t-${t.id}`} className={`scroll-mt-24 target:ring-2 target:ring-primary-2 ${late ? "bg-danger/5" : ""}`}>
                    <Td>
                      <span className="inline-flex items-center gap-1">
                        {can("crm:write") && <TaskActions id={t.id} status={t.status} />}
                        {canAlert && t.status === "open" && (
                          <GenerateAlertButton senderName={senderName} users={orgUsers}
                            task={{ id: t.id, title: t.title, description: t.description, priority: t.priority, dueAt: t.dueAt?.toISOString() ?? null, assigneeId: t.assigneeId, assigneeName: assignee ?? null }} />
                        )}
                      </span>
                    </Td>
                    <Td className={t.status !== "open" ? "text-muted line-through" : ""}>{t.title}{t.description && <span className="block text-xs text-muted no-underline">{t.description}</span>}
                      {t.blockedReason && <span className="block text-xs text-warning no-underline">Bloqueada: {t.blockedReason}</span>}
                      {la && <Link href={`/alertas?tarefa=${t.id}#detalhe`} className="block text-[11px] text-primary-2 no-underline hover:underline">{la.count} alerta(s) · último: {STATUS_LABEL[la.status as AlertStatus]?.toLowerCase()} · ver histórico</Link>}
                    </Td>
                    <Td><Badge tone={PRIORITY[t.priority as keyof typeof PRIORITY]?.[1] ?? "neutral"}>{PRIORITY[t.priority as keyof typeof PRIORITY]?.[0] ?? t.priority}</Badge></Td>
                    <Td>{assignee ?? "—"}</Td>
                    <Td className={late ? "font-semibold text-danger" : ""}>{t.dueAt ? date(t.dueAt, o, true) : "—"}{late && " · atrasada"}</Td>
                    <Td><Badge tone={t.status === "done" ? "success" : t.status === "canceled" ? "neutral" : "info"}>{t.status === "done" ? "concluída" : t.status === "canceled" ? "cancelada" : "aberta"}</Badge></Td>
                  </tr>
                );
              })}
            </Table>
          ) : <Empty title={can("crm:read") ? "Nenhuma tarefa" : "Sem acesso às tarefas"} />}
        </Card>
        {can("crm:write") && (
          <Card><CardTitle>Nova tarefa</CardTitle><NewTaskForm users={orgUsers} /></Card>
        )}
      </div>

      <div className="grid gap-5 lg:grid-cols-[1fr_380px]">
        <Card>
          <CardTitle sub="Progresso calculado a partir de negócios ganhos no período; projeção linear pelo tempo decorrido">Metas</CardTitle>
          {goals.length ? (
            <div className="space-y-4">
              {goals.map((g) => {
                const fmtV = (v: number) => (g.metric === "revenue" ? money(v, o) : num(v, o.locale));
                const supported = g.metric === "revenue" || g.metric === "deals_won";
                const ended = g.periodEnd.getTime() < now;
                return (
                  <div key={g.id} className="rounded-xl border border-line bg-bg-2/60 p-4">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <p className="font-semibold">{g.name} <span className="text-xs font-normal text-muted">· {METRIC[g.metric]} · {SCOPE[g.scope]}{g.scope === "user" ? `: ${userName(g.scopeId)}` : g.scopeId ? `: ${g.scopeId}` : ""}</span></p>
                      <span className="text-xs text-muted">{date(g.periodStart, o)} – {date(g.periodEnd, o)}{ended && " (encerrada)"}</span>
                    </div>
                    {supported ? (
                      <>
                        <div className="mt-2 flex items-center justify-between text-sm"><span className="text-muted">{fmtV(g.achieved)} de {fmtV(g.targetValue)}</span><span className="font-bold">{g.pct}%</span></div>
                        <div className="mt-1"><Progress value={g.pct} tone={g.pct >= 100 ? "success" : g.projectedPct >= 100 ? "primary" : "warning"} /></div>
                        {!ended && <p className="mt-1 text-[11px] text-muted">Projeção no ritmo atual: {g.projectedPct}% {g.projectedPct < 100 ? "— abaixo da meta" : "— meta deve ser atingida"} (estimativa linear, não garantia)</p>}
                      </>
                    ) : <p className="mt-2 text-xs text-warning">Cálculo de progresso para esta métrica ainda não disponível.</p>}
                  </div>
                );
              })}
            </div>
          ) : <Empty title="Nenhuma meta cadastrada" />}
        </Card>
        {can("goals:manage") && <Card><CardTitle>Nova meta</CardTitle><NewGoalForm users={orgUsers} currencySymbol={currencySymbol} /></Card>}
      </div>

      <div className="grid gap-5 lg:grid-cols-3">
        <Card>
          <CardTitle sub="Cada alteração cria uma nova versão auditada">Regras de comissão</CardTitle>
          {rules.length ? (
            <Table head={["Regra", "Versão", "Taxa", "Acelerador", "Status"]}>
              {rules.map((r) => <tr key={r.id}><Td>{r.name}</Td><Td>v{r.version}</Td><Td>{r.ratePct}%</Td><Td>+{r.acceleratorPct} p.p.</Td><Td><Badge tone={r.active ? "success" : "neutral"}>{r.active ? "ativa" : "histórico"}</Badge></Td></tr>)}
            </Table>
          ) : <Empty title="Nenhuma regra de comissão" />}
          {can("goals:manage") && <div className="mt-4 border-t border-line pt-4"><CommissionRuleForm /></div>}
        </Card>
        <Card>
          <CardTitle sub={activeRule ? `Pré-preenchido com "${activeRule.name}" v${activeRule.version}` : "Informe a regra"}>Simulador de comissão</CardTitle>
          <CommissionSimulator rule={activeRule} locale={o.locale} currency={o.currency} />
        </Card>
        <Card>
          <CardTitle sub="Receita ganha nos últimos 30 dias">Ranking do time</CardTitle>
          {ranking.length ? (
            <ol className="space-y-2">
              {ranking.slice(0, 10).map((s, i) => (
                <li key={s.userId} className="flex items-center justify-between rounded-lg border border-line bg-bg-2/60 px-3 py-2 text-sm">
                  <span><span className="mr-2 font-bold text-muted">{i + 1}º</span>{s.name}</span>
                  <span className="text-right"><span className="block font-semibold">{money(s.revenue, o)}</span><span className="text-[11px] text-muted">{s.won} ganhos · conv. {s.winRate == null ? "n/d" : `${s.winRate}%`}</span></span>
                </li>
              ))}
            </ol>
          ) : <Empty title="Sem dados de vendas para o ranking" />}
        </Card>
      </div>
    </div>
  );
}
