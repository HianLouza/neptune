import Link from "next/link";
import { and, count, eq, gte, isNull } from "drizzle-orm";
import { Download } from "lucide-react";
import { requirePageContext } from "@/server/auth/next";
import { activeIcp } from "@/server/domains/prospect";
import { listProspectLeads } from "@/server/domains/prospect/queries";
import { leads } from "@/server/db/schema";
import { Card, CardTitle, Empty, Input, PageHeader, Select, Stat, Button, cx } from "@/components/ui";
import { IcpForm } from "@/components/prospect/icp-form";
import { LeadForm } from "@/components/prospect/lead-form";
import { CsvImport } from "@/components/prospect/csv-import";
import { LeadsTable, RescoreButton, type LeadRow } from "@/components/prospect/leads-table";
import { num } from "@/lib/format";

export const metadata = { title: "Prospect.AI" };

export default async function ProspectPage({ searchParams }: { searchParams: Promise<{ filtro?: string; lead?: string; q?: string; status?: string }> }) {
  const ctx = await requirePageContext("prospect:read");
  const sp = await searchParams;
  const can = (p: string) => ctx.permissions.includes("*") || ctx.permissions.includes(p);
  const hot = sp.filtro === "quentes";
  const status = ["new", "qualifying", "qualified", "disqualified", "converted"].includes(sp.status ?? "") ? sp.status : undefined;
  const q = sp.q?.trim().slice(0, 80) || undefined;
  const leadId = sp.lead && /^[0-9a-f-]{36}$/i.test(sp.lead) ? sp.lead : undefined;

  const org = ctx.organizationId;
  const [icp, rows, [total], [hotN], [unscored]] = await Promise.all([
    activeIcp(ctx),
    listProspectLeads(ctx, { hot, status, q, limit: 100 }),
    ctx.db.select({ n: count() }).from(leads).where(eq(leads.organizationId, org)),
    ctx.db.select({ n: count() }).from(leads).where(and(eq(leads.organizationId, org), gte(leads.score, 80))),
    ctx.db.select({ n: count() }).from(leads).where(and(eq(leads.organizationId, org), isNull(leads.score))),
  ]);
  let list = rows;
  if (leadId && !rows.some((r) => r.id === leadId)) list = [...(await listProspectLeads(ctx, { id: leadId })), ...rows];
  const data: LeadRow[] = list.map((r) => ({ ...r, createdAt: r.createdAt.toISOString() }));

  return (
    <div className="mx-auto max-w-[1500px]">
      <PageHeader title="Prospect.AI" subtitle="Defina seu ICP, importe e priorize leads com pontuação explicável e gere abordagens personalizadas."
        actions={<>
          {can("prospect:write") && <RescoreButton />}
          {can("export:data") && <a href="/api/prospect/export" className="inline-flex items-center gap-2 rounded-lg border border-line bg-surface-2 px-4 py-2 text-sm font-medium hover:border-primary-2"><Download size={16} /> Exportar CSV</a>}
        </>} />

      <div className="mb-5 grid grid-cols-2 gap-3 md:grid-cols-4">
        <Stat label="Leads na base" value={num(Number(total.n), ctx.locale)} />
        <Stat label="Leads quentes (score ≥ 80)" value={num(Number(hotN.n), ctx.locale)} hint={<Link href="/prospect?filtro=quentes" className="text-primary-2 hover:underline">Ver quentes</Link>} />
        <Stat label="Sem pontuação" value={num(Number(unscored.n), ctx.locale)} />
        <Stat label="ICP ativo" value={icp ? icp.name : "Não definido"} hint={icp ? "Usado no lead scoring" : "Defina para pontuar leads"} />
      </div>

      <div className="grid gap-5 xl:grid-cols-[1fr_380px]">
        <Card className="min-w-0">
          <CardTitle sub={`Mostrando ${data.length} de ${num(Number(total.n), ctx.locale)} — ordenados por score`}>Leads</CardTitle>
          <form className="mb-4 flex flex-wrap gap-2" action="/prospect">
            <Input name="q" defaultValue={q ?? ""} placeholder="Buscar por lead, empresa ou e-mail" className="max-w-xs" />
            <Select name="status" defaultValue={status ?? ""} className="max-w-48">
              <option value="">Todos os status</option><option value="new">Novos</option><option value="qualifying">Em qualificação</option>
              <option value="qualified">Qualificados</option><option value="disqualified">Desqualificados</option><option value="converted">Convertidos</option>
            </Select>
            {hot && <input type="hidden" name="filtro" value="quentes" />}
            <Button type="submit" variant="secondary">Filtrar</Button>
            <Link href={hot ? "/prospect" : "/prospect?filtro=quentes"} className={cx("inline-flex items-center rounded-lg border px-4 py-2 text-sm", hot ? "border-primary-2 bg-primary/20 text-primary-2" : "border-line text-muted hover:text-fg")}>🔥 Somente quentes</Link>
            {(q || status || hot) && <Link href="/prospect" className="inline-flex items-center px-2 text-sm text-muted hover:text-fg">Limpar</Link>}
          </form>
          {data.length ? (
            <LeadsTable rows={data} highlight={leadId} canWrite={can("prospect:write")} canConvert={can("crm:write")} locale={ctx.locale} currency={ctx.currency} />
          ) : (
            <Empty title="Nenhum lead encontrado">Crie um lead ou importe um CSV para começar.</Empty>
          )}
        </Card>

        <div className="space-y-5">
          <Card>
            <CardTitle sub="Critérios do cliente ideal usados na pontuação">Construtor de ICP</CardTitle>
            <IcpForm canWrite={can("prospect:write")} initial={icp ? { name: icp.name, ...icp.criteria } : null} />
          </Card>
          {can("prospect:write") && (
            <>
              <Card>
                <CardTitle sub="Validação, deduplicação e mapeamento assistido">Importar CSV</CardTitle>
                <CsvImport />
              </Card>
              <Card>
                <CardTitle>Novo lead</CardTitle>
                <LeadForm />
              </Card>
            </>
          )}
          <p className="px-1 text-xs text-muted">Fontes: dados fornecidos pela sua empresa (CSV, CRM, formulários) e integrações autorizadas. O ORBITY-NEPTUNE não mantém base universal de contatos.</p>
        </div>
      </div>
    </div>
  );
}
