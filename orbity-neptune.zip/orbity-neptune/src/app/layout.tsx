import type { Metadata, Viewport } from "next";
import "./globals.css";
import { getContext } from "@/server/auth/next";
import { userPreferences } from "@/server/db/schema";
import { eq } from "drizzle-orm";

export const metadata: Metadata = {
  title: { default: "ORBITY-NEPTUNE", template: "%s · ORBITY-NEPTUNE" },
  description: "Ecossistema de inteligência comercial, automação e crescimento com IA. INTELLIGENCE. AUTOMATION. GROWTH.",
  manifest: "/manifest.webmanifest",
  icons: { icon: "/icons/icon.svg" },
};
export const viewport: Viewport = { themeColor: "#061A2C", width: "device-width", initialScale: 1 };

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  let theme = "dark", locale = "pt-BR";
  const ctx = await getContext().catch(() => null);
  if (ctx) {
    locale = ctx.locale;
    const [p] = await ctx.db.select().from(userPreferences).where(eq(userPreferences.userId, ctx.userId));
    if (p?.theme) theme = p.theme;
  }
  return (
    <html lang={locale} data-theme={theme} suppressHydrationWarning>
      <body className="min-h-screen font-sans antialiased">{children}</body>
    </html>
  );
}
