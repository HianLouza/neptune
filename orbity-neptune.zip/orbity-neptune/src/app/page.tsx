import { redirect } from "next/navigation";
import { eq } from "drizzle-orm";
import { getContext } from "@/server/auth/next";
import { userPreferences } from "@/server/db/schema";

export const dynamic = "force-dynamic";

/** A tela inicial é a última tela acessada pelo usuário. */
export default async function Home() {
  const ctx = await getContext();
  if (!ctx) redirect("/login");
  const [p] = await ctx.db.select().from(userPreferences).where(eq(userPreferences.userId, ctx.userId));
  const last = p?.lastRoute;
  redirect(last && last.startsWith("/") && !last.startsWith("//") ? last : "/dashboard");
}
