import { requireApiContext } from "@/server/auth/next";
import { askFlavio } from "@/server/ai/flavio";
import { handle, readJson, assertSameOrigin } from "@/server/http";

export const dynamic = "force-dynamic";

/** POST { message, route?, filters?, conversationSince?, lastIntent? } — pergunta ao Flávio (análise + narrativa). */
export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("ai:use");
    return askFlavio(ctx, await readJson(req));
  });
}
