import { requireApiContext } from "@/server/auth/next";
import { flavioStatus } from "@/server/ai/flavio";
import { handle } from "@/server/http";

export const dynamic = "force-dynamic";

/** GET — disponibilidade do Flávio para o usuário atual (permissão, agente ativo, modo IA ou determinístico). */
export async function GET() {
  return handle(async () => flavioStatus(await requireApiContext()));
}
