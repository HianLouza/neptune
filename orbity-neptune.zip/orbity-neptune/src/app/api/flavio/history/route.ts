import { z } from "zod";
import { requireApiContext } from "@/server/auth/next";
import { eraseConversations, listConversations } from "@/server/ai/flavio";
import { handle, readJson, assertSameOrigin } from "@/server/http";

export const dynamic = "force-dynamic";

/** GET — conversas do próprio usuário com o Flávio (agrupadas por sessão). */
export async function GET() {
  return handle(async () => listConversations(await requireApiContext("ai:use")));
}

/** DELETE { from?, to? } — apaga o conteúdo das conversas do próprio usuário (todas ou um intervalo). */
export async function DELETE(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("ai:use");
    const body = z.object({ from: z.string().datetime().optional(), to: z.string().datetime().optional() }).parse(await readJson(req).catch(() => ({})));
    return eraseConversations(ctx, body.from && body.to ? { from: body.from, to: body.to } : undefined);
  });
}
