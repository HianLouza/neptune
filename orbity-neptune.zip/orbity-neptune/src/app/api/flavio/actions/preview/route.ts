import { z } from "zod";
import { requireApiContext } from "@/server/auth/next";
import { previewAction } from "@/server/ai/flavio/preview";
import { handle, readJson, assertSameOrigin } from "@/server/http";

export const dynamic = "force-dynamic";

/** POST { token } — prévia "antes → depois" de uma ação preparada pelo Flávio. Só lê dados; nada é executado. */
export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("ai:use");
    const { token } = z.object({ token: z.string().min(10).max(20000) }).parse(await readJson(req));
    return previewAction(ctx, token);
  });
}
