import { z } from "zod";
import { requireApiContext } from "@/server/auth/next";
import { confirmAction } from "@/server/ai/flavio/actions";
import { handle, readJson, assertSameOrigin } from "@/server/http";

export const dynamic = "force-dynamic";

/** POST { token } — executa uma ação preparada pelo Flávio, depois da confirmação explícita do usuário. */
export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("ai:use");
    const { token } = z.object({ token: z.string().min(10).max(20000) }).parse(await readJson(req));
    return confirmAction(ctx, token);
  });
}
