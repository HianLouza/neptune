import { requireApiContext } from "@/server/auth/next";
import { globalSearch } from "@/server/domains/crm";
import { handle } from "@/server/http";

export async function GET(req: Request) {
  return handle(async () => {
    const ctx = await requireApiContext("crm:read");
    const q = new URL(req.url).searchParams.get("q") ?? "";
    return q.trim().length < 2 ? [] : globalSearch(ctx, q.trim());
  });
}
