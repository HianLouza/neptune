/**
 * OAuth (Google / Microsoft) — Authorization Code + state anti-CSRF.
 * GET /api/auth/oauth/:provider            → redireciona ao provedor
 * GET /api/auth/oauth/:provider?code=...   → callback: cria/vincula usuário e inicia sessão
 * Sem credenciais configuradas → 501 com mensagem clara (dependência registrada).
 */
import { NextResponse } from "next/server";
import { cookies, headers } from "next/headers";
import { and, eq } from "drizzle-orm";
import { getDb } from "@/server/db/client";
import { authAccounts, memberships, users } from "@/server/db/schema";
import { createSession, provisionOrganization } from "@/server/auth/service";
import { setSessionCookie, clientIp } from "@/server/auth/next";
import { randomToken } from "@/server/auth/crypto";
import { audit } from "@/server/audit";

type Cfg = { id?: string; secret?: string; authorize: string; token: string; userinfo: string; scope: string };
function cfg(provider: string): Cfg | null {
  const tenant = process.env.MICROSOFT_TENANT || "common";
  if (provider === "google") return { id: process.env.GOOGLE_CLIENT_ID, secret: process.env.GOOGLE_CLIENT_SECRET, authorize: "https://accounts.google.com/o/oauth2/v2/auth", token: "https://oauth2.googleapis.com/token", userinfo: "https://openidconnect.googleapis.com/v1/userinfo", scope: "openid email profile" };
  if (provider === "microsoft") return { id: process.env.MICROSOFT_CLIENT_ID, secret: process.env.MICROSOFT_CLIENT_SECRET, authorize: `https://login.microsoftonline.com/${tenant}/oauth2/v2.0/authorize`, token: `https://login.microsoftonline.com/${tenant}/oauth2/v2.0/token`, userinfo: "https://graph.microsoft.com/oidc/userinfo", scope: "openid email profile" };
  return null;
}

export async function GET(req: Request, { params }: { params: Promise<{ provider: string }> }) {
  const { provider } = await params;
  const c = cfg(provider);
  if (!c) return NextResponse.json({ ok: false, error: "Provedor desconhecido." }, { status: 404 });
  if (!c.id || !c.secret) return NextResponse.json({ ok: false, error: `Login com ${provider === "google" ? "Google" : "Microsoft"} ainda não configurado (credenciais OAuth pendentes).` }, { status: 501 });
  const url = new URL(req.url);
  const redirectUri = `${process.env.APP_URL ?? url.origin}/api/auth/oauth/${provider}`;
  const jar = await cookies();
  const code = url.searchParams.get("code");
  if (!code) {
    const state = randomToken(16);
    jar.set("oauth_state", state, { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 600, path: "/" });
    const auth = new URL(c.authorize);
    auth.search = new URLSearchParams({ client_id: c.id, redirect_uri: redirectUri, response_type: "code", scope: c.scope, state, prompt: "select_account" }).toString();
    return NextResponse.redirect(auth);
  }
  if (!url.searchParams.get("state") || url.searchParams.get("state") !== jar.get("oauth_state")?.value) {
    return NextResponse.redirect(new URL("/login?erro=oauth_state", url.origin));
  }
  jar.delete("oauth_state");
  const tok = await fetch(c.token, { method: "POST", headers: { "content-type": "application/x-www-form-urlencoded" }, body: new URLSearchParams({ client_id: c.id, client_secret: c.secret, code, redirect_uri: redirectUri, grant_type: "authorization_code" }) });
  if (!tok.ok) return NextResponse.redirect(new URL("/login?erro=oauth_token", url.origin));
  const { access_token } = (await tok.json()) as { access_token: string };
  const info = (await (await fetch(c.userinfo, { headers: { authorization: `Bearer ${access_token}` } })).json()) as { sub: string; email?: string; name?: string };
  if (!info.email) return NextResponse.redirect(new URL("/login?erro=oauth_email", url.origin));
  const db = await getDb();
  const email = info.email.toLowerCase();
  const [linked] = await db.select().from(authAccounts).where(and(eq(authAccounts.provider, provider), eq(authAccounts.providerAccountId, info.sub)));
  let userId = linked?.userId;
  if (!userId) {
    const [existing] = await db.select().from(users).where(eq(users.email, email));
    if (existing) userId = existing.id;
    else {
      const [u] = await db.insert(users).values({ email, name: info.name ?? email.split("@")[0], emailVerifiedAt: new Date() }).returning();
      userId = u.id;
      await provisionOrganization(db, { name: `Empresa de ${u.name.split(" ")[0]}`, ownerId: u.id });
    }
    await db.insert(authAccounts).values({ userId, provider, providerAccountId: info.sub }).onConflictDoNothing();
  }
  const [m] = await db.select().from(memberships).where(and(eq(memberships.userId, userId), eq(memberships.status, "active"))).limit(1);
  const [u] = await db.select().from(users).where(eq(users.id, userId));
  const token = await createSession(db, userId, m?.organizationId ?? null, { ip: await clientIp(), userAgent: (await headers()).get("user-agent"), twoFactorPending: u.totpEnabled });
  await setSessionCookie(token);
  await audit(db, { organizationId: m?.organizationId, actorId: userId, action: `auth.login_${provider}`, resource: "session" });
  return NextResponse.redirect(new URL(u.totpEnabled ? "/login?2fa=1" : "/", url.origin));
}
