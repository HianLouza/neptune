import { z } from "zod";
import { headers } from "next/headers";
import { getDb } from "@/server/db/client";
import { registerUser, createSession } from "@/server/auth/service";
import { setSessionCookie, clientIp } from "@/server/auth/next";
import { handle, readJson, assertSameOrigin } from "@/server/http";

export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    const body = z.object({
      name: z.string().trim().min(2).max(120),
      email: z.string().email(),
      password: z.string().min(1).max(200),
      organizationName: z.string().trim().max(120).optional(),
      inviteOrgSlug: z.string().max(80).optional(),
      acceptTerms: z.literal(true, { message: "É necessário aceitar os termos e a política de privacidade." }),
    }).parse(await readJson(req));
    const db = await getDb();
    const { user, organizationId } = await registerUser(db, body);
    const token = await createSession(db, user.id, organizationId, { ip: await clientIp(), userAgent: (await headers()).get("user-agent") });
    await setSessionCookie(token);
    return { pendingApproval: !organizationId };
  }, { status: 201 });
}
