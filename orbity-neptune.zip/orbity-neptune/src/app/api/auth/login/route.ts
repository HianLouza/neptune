import { z } from "zod";
import { headers } from "next/headers";
import { getDb } from "@/server/db/client";
import { login } from "@/server/auth/service";
import { setSessionCookie, clientIp } from "@/server/auth/next";
import { handle, readJson, assertSameOrigin } from "@/server/http";

export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    const body = z.object({ email: z.string().email(), password: z.string().min(1).max(200) }).parse(await readJson(req));
    const r = await login(await getDb(), { ...body, ip: await clientIp(), userAgent: (await headers()).get("user-agent") });
    await setSessionCookie(r.token);
    return { requires2fa: r.requires2fa, hasOrganization: r.hasOrganization };
  });
}
