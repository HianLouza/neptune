import { requireApiContext } from "@/server/auth/next";
import { handle } from "@/server/http";

export async function GET() {
  return handle(async () => {
    const c = await requireApiContext();
    return { userId: c.userId, organizationId: c.organizationId, role: c.roleKey, permissions: c.permissions, locale: c.locale, currency: c.currency };
  });
}
