import { z } from "zod";
import { eq } from "drizzle-orm";
import { getDb } from "@/server/db/client";
import { completeTwoFactor } from "@/server/auth/service";
import { getSessionToken, requireApiContext } from "@/server/auth/next";
import { generateSecret, otpauthUrl, verifyTotp } from "@/server/auth/totp";
import { users } from "@/server/db/schema";
import { audit } from "@/server/audit";
import { handle, readJson, HttpError } from "@/server/http";

/** POST { action: "verify" | "setup" | "enable" | "disable", code? } */
export async function POST(req: Request) {
  return handle(async () => {
    const body = z.object({ action: z.enum(["verify", "setup", "enable", "disable"]), code: z.string().max(10).optional() }).parse(await readJson(req));
    const db = await getDb();
    if (body.action === "verify") {
      const token = await getSessionToken();
      if (!token) throw new HttpError(401, "Sessão expirada.");
      await completeTwoFactor(db, token, body.code ?? "");
      return { ok: true };
    }
    const ctx = await requireApiContext();
    const [u] = await db.select().from(users).where(eq(users.id, ctx.userId));
    if (body.action === "setup") {
      if (u.totpEnabled) throw new HttpError(409, "2FA já está ativo. Desative antes de reconfigurar.");
      const secret = generateSecret();
      await db.update(users).set({ totpSecret: secret }).where(eq(users.id, u.id));
      return { secret, otpauth: otpauthUrl(secret, u.email) };
    }
    if (!u.totpSecret || !verifyTotp(u.totpSecret, body.code ?? "")) throw new HttpError(400, "Código inválido.");
    const enable = body.action === "enable";
    await db.update(users).set({ totpEnabled: enable, totpSecret: enable ? u.totpSecret : null }).where(eq(users.id, u.id));
    await audit(db, { organizationId: ctx.organizationId, actorId: u.id, action: enable ? "auth.2fa_enabled" : "auth.2fa_disabled", resource: "user", resourceId: u.id });
    return { enabled: enable };
  });
}
