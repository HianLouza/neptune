import { getDb } from "@/server/db/client";
import { revokeSession } from "@/server/auth/service";
import { getSessionToken, clearSessionCookie } from "@/server/auth/next";
import { handle } from "@/server/http";

export async function POST() {
  return handle(async () => {
    const token = await getSessionToken();
    if (token) await revokeSession(await getDb(), token);
    await clearSessionCookie();
    return { ok: true };
  });
}
