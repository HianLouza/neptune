import { sql } from "drizzle-orm";
import { NextResponse } from "next/server";
import { getDb } from "@/server/db/client";
import { events } from "@/server/db/schema";
import { providerChain } from "@/server/ai/providers";

export const dynamic = "force-dynamic";

/** Health check (observabilidade): banco, fila e provedores de IA disponíveis. */
export async function GET() {
  const started = Date.now();
  try {
    const db = await getDb();
    await db.execute(sql`select 1`);
    const q = await db.select({ status: events.status, n: sql<number>`count(*)::int` }).from(events).groupBy(events.status);
    return NextResponse.json({
      status: "ok", db: "ok", dbDriver: process.env.DATABASE_URL ? "postgres" : "pglite", latencyMs: Date.now() - started,
      queue: Object.fromEntries(q.map((r) => [r.status, r.n])), aiProviders: providerChain().map((p) => p.name),
    });
  } catch (e) {
    return NextResponse.json({ status: "error", error: (e as Error).message }, { status: 503 });
  }
}
