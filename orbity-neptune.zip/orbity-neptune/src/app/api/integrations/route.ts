import { z } from "zod";
import { requireApiContext } from "@/server/auth/next";
import { connectIntegration, disconnectIntegration, listIntegrations } from "@/server/domains/integrations";
import { handle, readJson, assertSameOrigin } from "@/server/http";

export async function GET() {
  return handle(async () => listIntegrations(await requireApiContext("integrations:read")));
}

/** POST { action: "connect", provider, credentials } | { action: "disconnect", provider } */
export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("integrations:manage");
    const b = z.discriminatedUnion("action", [
      z.object({ action: z.literal("connect"), provider: z.string().min(2).max(40), credentials: z.record(z.string(), z.string().max(2000)) }),
      z.object({ action: z.literal("disconnect"), provider: z.string().min(2).max(40) }),
    ]).parse(await readJson(req));
    return b.action === "connect" ? connectIntegration(ctx, b.provider, b.credentials) : disconnectIntegration(ctx, b.provider);
  });
}
