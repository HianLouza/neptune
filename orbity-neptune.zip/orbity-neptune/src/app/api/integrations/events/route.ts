import { z } from "zod";
import { requireApiContext } from "@/server/auth/next";
import { replayEvent } from "@/server/events";
import { kickOutbox } from "@/server/events/handlers";
import { audit } from "@/server/audit";
import { handle, readJson, assertSameOrigin, HttpError } from "@/server/http";

/** POST { eventId } — recuperação manual: devolve evento da dead-letter queue para a fila. */
export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("integrations:manage");
    const { eventId } = z.object({ eventId: z.string().uuid() }).parse(await readJson(req));
    const ok = await replayEvent(ctx.db, eventId, ctx.organizationId);
    if (!ok) throw new HttpError(404, "Evento não encontrado.");
    await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "event.replayed", resource: "event", resourceId: eventId });
    kickOutbox(ctx.db);
    return { ok: true };
  });
}
