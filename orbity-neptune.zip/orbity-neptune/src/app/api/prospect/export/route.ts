import { NextResponse } from "next/server";
import { requireApiContext } from "@/server/auth/next";
import { exportLeadsCsv } from "@/server/domains/prospect/queries";
import { handle } from "@/server/http";

/** Exportação de leads em CSV (exige export:data; registrada na auditoria). */
export async function GET() {
  try {
    const ctx = await requireApiContext("export:data");
    const csv = await exportLeadsCsv(ctx);
    return new NextResponse(csv, {
      headers: {
        "content-type": "text/csv; charset=utf-8",
        "content-disposition": `attachment; filename="leads-${new Date().toISOString().slice(0, 10)}.csv"`,
        "cache-control": "no-store",
      },
    });
  } catch (err) {
    return handle(async () => { throw err; });
  }
}
