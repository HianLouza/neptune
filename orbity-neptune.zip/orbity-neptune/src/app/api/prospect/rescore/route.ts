import { requireApiContext } from "@/server/auth/next";
import { rescoreAll } from "@/server/domains/prospect";
import { handle, assertSameOrigin } from "@/server/http";

export async function POST() {
  return handle(async () => {
    await assertSameOrigin();
    return rescoreAll(await requireApiContext("prospect:write"));
  });
}
