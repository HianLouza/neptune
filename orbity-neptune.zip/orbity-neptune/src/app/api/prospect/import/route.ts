import { z } from "zod";
import { requireApiContext } from "@/server/auth/next";
import { importCsv } from "@/server/domains/prospect";
import { kickOutbox } from "@/server/events/handlers";
import { handle, readJson, assertSameOrigin } from "@/server/http";

const body = z.object({
  csv: z.string().min(1).max(5_000_000),
  dryRun: z.boolean().default(true),
  sourceName: z.string().trim().max(120).optional(),
  legalBasis: z.enum(["consentimento", "legitimo_interesse", "execucao_contrato"]),
  mapping: z.record(z.string(), z.number().int().min(0).max(200)).optional(),
});

/** Importação CSV: dryRun=true valida e mostra prévia (nada é gravado); dryRun=false importa. */
export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("prospect:write");
    const b = body.parse(await readJson(req));
    const report = await importCsv(ctx, b.csv, { dryRun: b.dryRun, sourceName: b.sourceName, legalBasis: b.legalBasis, mapping: b.mapping });
    if (!b.dryRun) kickOutbox(ctx.db);
    return { ...report, errors: report.errors.slice(0, 100), dryRun: b.dryRun };
  });
}
