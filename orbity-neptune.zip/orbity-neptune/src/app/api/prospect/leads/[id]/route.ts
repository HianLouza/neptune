import { z } from "zod";
import { requireApiContext } from "@/server/auth/next";
import { convertLead, updateLeadStatus } from "@/server/domains/crm";
import { draftOutreach, qualifyLead } from "@/server/domains/prospect";
import { kickOutbox } from "@/server/events/handlers";
import { handle, readJson, assertSameOrigin } from "@/server/http";

const body = z.discriminatedUnion("action", [
  z.object({ action: z.literal("qualify") }),
  z.object({ action: z.literal("status"), status: z.enum(["new", "qualifying", "qualified", "disqualified"]) }),
  z.object({ action: z.literal("convert"), amountCents: z.coerce.number().int().min(0).max(1e13) }),
  z.object({ action: z.literal("outreach"), channel: z.enum(["email", "whatsapp", "linkedin"]) }),
]);

/** Ações sobre um lead: qualificar, alterar status, converter em oportunidade, gerar rascunho de abordagem (não envia). */
export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    await assertSameOrigin();
    const { id } = await params;
    z.string().uuid().parse(id);
    const b = body.parse(await readJson(req));
    const ctx = await requireApiContext(b.action === "convert" ? "crm:write" : "prospect:write");
    switch (b.action) {
      case "qualify": { const r = await qualifyLead(ctx, id); kickOutbox(ctx.db); return r; }
      case "status": { const r = await updateLeadStatus(ctx, id, b.status); kickOutbox(ctx.db); return r; }
      case "convert": { const r = await convertLead(ctx, id, b.amountCents); kickOutbox(ctx.db); return r; }
      case "outreach": {
        const r = await draftOutreach(ctx, id, b.channel);
        return { ...r, notice: "Rascunho gerado. Nenhuma mensagem foi enviada — o envio exige revisão e aprovação humana." };
      }
    }
  });
}
