import { requireApiContext } from "@/server/auth/next";
import { createLead } from "@/server/domains/crm";
import { listProspectLeads, scoreOneLead } from "@/server/domains/prospect/queries";
import { kickOutbox } from "@/server/events/handlers";
import { handle, readJson, assertSameOrigin } from "@/server/http";

export async function GET(req: Request) {
  return handle(async () => {
    const ctx = await requireApiContext("prospect:read");
    const sp = new URL(req.url).searchParams;
    return listProspectLeads(ctx, { hot: sp.get("filtro") === "quentes", status: sp.get("status") ?? undefined, q: sp.get("q") ?? undefined });
  });
}

/** Cria lead (com empresa/contato deduplicados) e calcula o score pelo ICP ativo. */
export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("prospect:write");
    const lead = await createLead(ctx, await readJson(req));
    const scored = await scoreOneLead(ctx, lead.id);
    kickOutbox(ctx.db);
    return { ...lead, score: scored?.score ?? null };
  }, { status: 201 });
}
