import { requireApiContext } from "@/server/auth/next";
import { saveIcp, rescoreAll, activeIcp } from "@/server/domains/prospect";
import { handle, readJson, assertSameOrigin } from "@/server/http";

export async function GET() {
  return handle(async () => activeIcp(await requireApiContext("prospect:read")));
}

/** Salva o ICP ativo e recalcula a pontuação de todos os leads. */
export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("prospect:write");
    const icp = await saveIcp(ctx, await readJson(req));
    const r = await rescoreAll(ctx);
    return { icp, rescored: r.updated };
  });
}
