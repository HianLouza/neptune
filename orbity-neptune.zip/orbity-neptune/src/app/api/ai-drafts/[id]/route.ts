import { z } from "zod";
import { requireApiContext } from "@/server/auth/next";
import { DISCARD_REASONS, OPERATIONS, discardVersion, getDraft, markCopied, regenerate, restoreVersion, saveManualEdit, sendDraft, takeOverManually } from "@/server/ai/collab";
import { kickOutbox } from "@/server/events/handlers";
import { assertSameOrigin, handle, readJson } from "@/server/http";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const ctx = await requireApiContext();
    const { id } = await params;
    return getDraft(ctx, z.string().uuid().parse(id));
  });
}

const body = z.discriminatedUnion("action", [
  z.object({ action: z.literal("regenerate"), operation: z.enum(OPERATIONS), instruction: z.string().max(1000).nullish(), baseVersionId: z.string().uuid().nullish(),
    selection: z.object({ start: z.number().int(), end: z.number().int() }).nullish() }),
  z.object({ action: z.literal("edit"), content: z.string().max(5000), baseVersionId: z.string().uuid().nullish() }),
  z.object({ action: z.literal("restore"), versionId: z.string().uuid() }),
  z.object({ action: z.literal("discard"), versionId: z.string().uuid(), reason: z.enum(DISCARD_REASONS).nullish(), note: z.string().max(500).nullish() }),
  z.object({ action: z.literal("manual"), content: z.string().max(5000).nullish() }),
  z.object({ action: z.literal("send"), versionId: z.string().uuid() }),
  z.object({ action: z.literal("copy"), versionId: z.string().uuid() }),
]);

/** Ações do funcionário sobre o rascunho. Toda geração cria uma nova versão; nada é sobrescrito. */
export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext();
    const id = z.string().uuid().parse((await params).id);
    const b = body.parse(await readJson(req));
    switch (b.action) {
      case "regenerate": return regenerate(ctx, id, b);
      case "edit": return saveManualEdit(ctx, id, b);
      case "restore": return restoreVersion(ctx, id, b.versionId);
      case "discard": return discardVersion(ctx, id, b);
      case "manual": return takeOverManually(ctx, id, { content: b.content });
      case "copy": return markCopied(ctx, id, b);
      case "send": { const r = await sendDraft(ctx, id, b); kickOutbox(ctx.db); return r; }
    }
  });
}
