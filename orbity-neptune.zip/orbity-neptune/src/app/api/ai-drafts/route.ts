import { z } from "zod";
import { requireApiContext } from "@/server/auth/next";
import { createDraft, getDraftForSubject, MODULES, startManualDraft } from "@/server/ai/collab";
import { assertSameOrigin, handle, readJson } from "@/server/http";

/** GET ?module=closer&subjectId=… — rascunho em andamento do assunto (ou null). */
export async function GET(req: Request) {
  return handle(async () => {
    const u = new URL(req.url).searchParams;
    const q = z.object({ module: z.enum(MODULES), subjectId: z.string().uuid(), channel: z.string().max(30).nullish() }).parse({ module: u.get("module"), subjectId: u.get("subjectId"), channel: u.get("channel") });
    const ctx = await requireApiContext();
    return getDraftForSubject(ctx, q.module, q.subjectId, q.channel);
  });
}

/**
 * POST { module, subjectId, channel?, manual?, content? } — gera a primeira sugestão da IA (ou abre um rascunho manual).
 * Nada é enviado: envio é uma ação separada, com as permissões e aprovações da organização.
 */
export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext();
    const b = z.object({ module: z.enum(MODULES), subjectId: z.string().uuid(), channel: z.string().max(30).nullish(), manual: z.boolean().optional(), content: z.string().max(5000).optional() }).parse(await readJson(req));
    return b.manual ? startManualDraft(ctx, b) : createDraft(ctx, b);
  });
}
