import { requireApiContext } from "@/server/auth/next";
import { listScenarios, saveScenario } from "@/server/domains/strategy";
import { assertSameOrigin, handle, readJson } from "@/server/http";

/** GET — cenários salvos com responsáveis e aprovações. */
export async function GET() {
  return handle(async () => listScenarios(await requireApiContext("strategy:read")));
}

/** POST { name, kind, variables } — salva o cenário (a base é recalculada no servidor). */
export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("strategy:write");
    return saveScenario(ctx, await readJson(req));
  }, { status: 201 });
}
