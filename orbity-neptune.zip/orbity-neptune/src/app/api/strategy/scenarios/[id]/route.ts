import { requireApiContext } from "@/server/auth/next";
import { updateScenarioStatus } from "@/server/domains/strategy";
import { assertSameOrigin, handle, readJson } from "@/server/http";

type P = { params: Promise<{ id: string }> };

/** PATCH { action: submit | approve | reject } — aprovação exige approvals:decide e outra pessoa que não o autor. */
export async function PATCH(req: Request, { params }: P) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("strategy:read");
    return updateScenarioStatus(ctx, (await params).id, await readJson(req));
  });
}
