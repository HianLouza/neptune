import { requireApiContext } from "@/server/auth/next";
import { runSimulation } from "@/server/domains/strategy";
import { assertSameOrigin, handle, readJson } from "@/server/http";

/** POST { ...variáveis } — simula sem salvar. */
export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("strategy:read");
    return runSimulation(ctx, await readJson(req));
  });
}
