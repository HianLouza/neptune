import { requireApiContext } from "@/server/auth/next";
import { buildBaseline } from "@/server/domains/strategy";
import { handle } from "@/server/http";

/** GET — linha de base da simulação, construída com dados reais (CRM e, se houver, financeiro), com evidências. */
export async function GET() {
  return handle(async () => buildBaseline(await requireApiContext("strategy:read")));
}
