import { requireApiContext } from "@/server/auth/next";
import { decideExtension } from "@/server/domains/task-alerts";
import { handle, readJson, assertSameOrigin } from "@/server/http";

/** PATCH { decision: "approve" | "reject" | "counter", counterDueAt?, note? } — decisão do gestor (o Flávio só recomenda). */
export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    await assertSameOrigin();
    return decideExtension(await requireApiContext("alerts:send"), (await params).id, await readJson(req));
  });
}
