import { requireApiContext } from "@/server/auth/next";
import { listExtensions, requestExtension } from "@/server/domains/task-alerts";
import { handle, readJson, assertSameOrigin } from "@/server/http";

/** GET ?status=pending — gestores veem todas; colaboradores, só as próprias. */
export async function GET(req: Request) {
  return handle(async () => listExtensions(await requireApiContext(), new URL(req.url).searchParams.get("status") ?? undefined));
}

/** POST { taskId, alertId?, requestedDueAt, justification, blockers?, impact? } */
export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    return requestExtension(await requireApiContext(), await readJson(req));
  }, { status: 201 });
}
