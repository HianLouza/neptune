import { z } from "zod";
import { requireApiContext } from "@/server/auth/next";
import { askFlavio } from "@/server/ai/flavio";
import { handle, readJson, assertSameOrigin } from "@/server/http";

/**
 * Compatibilidade: o antigo assistente "ORBITY AI" agora é o Flávio (mesmo agente "executive", sem segundo motor).
 * O histórico enviado pelo navegador é ignorado: o Flávio lê o histórico confiável do servidor.
 */
export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("ai:use");
    const b = z.object({ message: z.string().trim().min(1).max(2000), route: z.string().max(300).optional() }).passthrough().parse(await readJson(req));
    const a = await askFlavio(ctx, { message: b.message, route: b.route ?? "/dashboard" });
    return { ...a, status: a.mode === "bloqueado" ? "blocked" : a.mode === "ia" ? "success" : "fallback" };
  });
}
