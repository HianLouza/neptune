import { z } from "zod";
import { requireApiContext } from "@/server/auth/next";
import { runAgent } from "@/server/ai/orchestrator";
import { handle, readJson, assertSameOrigin } from "@/server/http";

/** POST { input, context?, promptVersion? } — playground de teste do agente (execução registrada e auditada). */
export async function POST(req: Request, { params }: { params: Promise<{ key: string }> }) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("ai:use");
    const b = z.object({
      input: z.string().trim().min(1).max(4000),
      context: z.string().max(20000).optional(),
      promptVersion: z.coerce.number().int().min(1).optional(),
    }).parse(await readJson(req));
    return runAgent(ctx, { agentKey: (await params).key, input: b.input, context: b.context, promptVersion: b.promptVersion });
  });
}
