import { z } from "zod";
import { requireApiContext } from "@/server/auth/next";
import { runEvaluation } from "@/server/ai/evaluation";
import { handle, readJson, assertSameOrigin } from "@/server/http";

/** POST { version } — executa o conjunto de avaliação (inclui casos adversariais) contra a versão. */
export async function POST(req: Request, { params }: { params: Promise<{ key: string }> }) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("ai:manage");
    const { version } = z.object({ version: z.coerce.number().int().min(1) }).parse(await readJson(req));
    return runEvaluation(ctx, (await params).key, version);
  });
}
