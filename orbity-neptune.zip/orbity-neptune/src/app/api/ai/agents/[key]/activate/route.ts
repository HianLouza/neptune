import { z } from "zod";
import { requireApiContext } from "@/server/auth/next";
import { activatePromptVersion } from "@/server/ai/evaluation";
import { handle, readJson, assertSameOrigin } from "@/server/http";

/** POST { version } — ativa (ou faz rollback para) uma versão aprovada. */
export async function POST(req: Request, { params }: { params: Promise<{ key: string }> }) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("ai:manage");
    const { version } = z.object({ version: z.coerce.number().int().min(1) }).parse(await readJson(req));
    return activatePromptVersion(ctx, (await params).key, version);
  });
}
