import { requireApiContext } from "@/server/auth/next";
import { getAgent, updateAgent } from "@/server/ai/agents/admin";
import { handle, readJson, assertSameOrigin } from "@/server/http";

type P = { params: Promise<{ key: string }> };

/** GET — detalhes do agente (versões, execuções, casos e avaliações). */
export async function GET(_req: Request, { params }: P) {
  return handle(async () => getAgent(await requireApiContext("ai:use"), (await params).key));
}

/** PATCH { enabled?, autonomy?, model?, maxTokensPerRun?, maxCreditsPerDay? } */
export async function PATCH(req: Request, { params }: P) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("ai:manage");
    return updateAgent(ctx, (await params).key, await readJson(req));
  });
}
