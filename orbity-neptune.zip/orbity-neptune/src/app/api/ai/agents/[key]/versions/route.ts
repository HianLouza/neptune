import { z } from "zod";
import { requireApiContext } from "@/server/auth/next";
import { createPromptVersion } from "@/server/ai/evaluation";
import { handle, readJson, assertSameOrigin } from "@/server/http";

/** POST { systemPrompt } — cria nova versão (rascunho; ativação exige avaliação aprovada). */
export async function POST(req: Request, { params }: { params: Promise<{ key: string }> }) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("ai:manage");
    const { systemPrompt } = z.object({ systemPrompt: z.string().trim().min(20).max(20000) }).parse(await readJson(req));
    return createPromptVersion(ctx, (await params).key, systemPrompt);
  }, { status: 201 });
}
