import { z } from "zod";
import { requireApiContext } from "@/server/auth/next";
import { setExecutionFeedback } from "@/server/ai/agents/admin";
import { handle, readJson, assertSameOrigin } from "@/server/http";

/** POST { value: 1 | -1 } — feedback contínuo do usuário sobre uma execução de IA. */
export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("ai:use");
    const { value } = z.object({ value: z.union([z.literal(1), z.literal(-1)]) }).parse(await readJson(req));
    return setExecutionFeedback(ctx, (await params).id, value);
  });
}
