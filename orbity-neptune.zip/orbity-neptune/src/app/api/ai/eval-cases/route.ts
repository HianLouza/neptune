import { z } from "zod";
import { requireApiContext } from "@/server/auth/next";
import { addEvalCase, deleteEvalCase } from "@/server/ai/agents/admin";
import { handle, readJson, assertSameOrigin } from "@/server/http";

/** POST { agentKey, name, input, mustInclude[], mustNotInclude[], adversarial } */
export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("ai:manage");
    return addEvalCase(ctx, await readJson(req));
  }, { status: 201 });
}

/** DELETE { id } */
export async function DELETE(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("ai:manage");
    const { id } = z.object({ id: z.string().uuid() }).parse(await readJson(req));
    return deleteEvalCase(ctx, id);
  });
}
