import { requireApiContext } from "@/server/auth/next";
import { seedDemoFinance } from "@/server/domains/finance/demo";
import { audit } from "@/server/audit";
import { handle, assertSameOrigin, HttpError } from "@/server/http";

/** POST — carrega dados financeiros de DEMONSTRAÇÃO. Só para organizações de demonstração e fora de produção. */
export async function POST() {
  return handle(async () => {
    await assertSameOrigin();
    if (process.env.APP_ENV === "production") throw new HttpError(403, "Indisponível em produção.");
    const ctx = await requireApiContext("finance:write");
    const r = await seedDemoFinance(ctx.db, ctx.organizationId);
    if (r.skipped) throw new HttpError(409, r.skipped);
    await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "finance.demo_data.loaded", resource: "organization", resourceId: ctx.organizationId, metadata: { created: r.created }, ip: ctx.ip });
    return r;
  }, { status: 201 });
}
