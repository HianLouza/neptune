import { requireApiContext } from "@/server/auth/next";
import { createCategory, listCategories } from "@/server/domains/finance";
import { handle, readJson, assertSameOrigin } from "@/server/http";

/** GET — categorias (cria as padrão na primeira chamada). */
export async function GET() {
  return handle(async () => listCategories(await requireApiContext("finance:read")));
}

/** POST { name, kind: "revenue" | "expense", group } */
export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("finance:write");
    return createCategory(ctx, await readJson(req));
  }, { status: 201 });
}
