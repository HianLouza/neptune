import { requireApiContext } from "@/server/auth/next";
import { agingReport, breakEvenReport, cashflowReport, dreReport, profitabilityReport } from "@/server/domains/finance";
import { handle, HttpError } from "@/server/http";

/** GET ?type=dre|cashflow|aging|profitability|breakeven [&months=6] [&by=client|product] [&days=180] */
export async function GET(req: Request) {
  return handle(async () => {
    const ctx = await requireApiContext("finance:read");
    const sp = new URL(req.url).searchParams;
    switch (sp.get("type")) {
      case "dre": return dreReport(ctx, Math.min(24, Math.max(1, Number(sp.get("months") ?? 6) || 6)));
      case "cashflow": return cashflowReport(ctx);
      case "aging": return agingReport(ctx);
      case "profitability": return profitabilityReport(ctx, sp.get("by") === "product" ? "product" : "client", Math.min(730, Math.max(7, Number(sp.get("days") ?? 180) || 180)));
      case "breakeven": return breakEvenReport(ctx);
      default: throw new HttpError(400, "Tipo de relatório inválido. Use dre, cashflow, aging, profitability ou breakeven.");
    }
  });
}
