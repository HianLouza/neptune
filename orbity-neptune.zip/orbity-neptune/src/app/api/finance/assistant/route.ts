import { z } from "zod";
import { requireApiContext } from "@/server/auth/next";
import { answerFinancialQuestion } from "@/server/domains/finance";
import { audit } from "@/server/audit";
import { handle, readJson, assertSameOrigin } from "@/server/http";

/** POST { question } — assistente financeiro determinístico (cálculos, premissas, fontes e evidência). */
export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("finance:read");
    const { question } = z.object({ question: z.string().trim().min(3).max(500) }).parse(await readJson(req));
    const a = await answerFinancialQuestion(ctx, question);
    await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "finance.assistant.asked", resource: "finance_assistant", metadata: { intent: a.intent }, ip: ctx.ip });
    return a;
  });
}
