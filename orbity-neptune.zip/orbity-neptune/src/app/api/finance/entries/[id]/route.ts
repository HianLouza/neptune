import { requireApiContext } from "@/server/auth/next";
import { getEntry, updateEntry } from "@/server/domains/finance";
import { handle, readJson, assertSameOrigin } from "@/server/http";

/** GET — um lançamento da organização. */
export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => getEntry(await requireApiContext("finance:read"), (await params).id));
}

/** PATCH { action: "pay", paidAt? } | { action: "cancel", reason? } | { action: "reopen" } | { action: "update", data: {...} } */
export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("finance:write");
    return updateEntry(ctx, (await params).id, await readJson(req));
  });
}
