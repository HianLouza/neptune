import { requireApiContext } from "@/server/auth/next";
import { createEntry, listEntries } from "@/server/domains/finance";
import { handle, readJson, assertSameOrigin } from "@/server/http";

/** GET ?kind=receivable|payable&status=open|paid|canceled|overdue&categoryId&from&to&limit — lançamentos financeiros. */
export async function GET(req: Request) {
  return handle(async () => {
    const ctx = await requireApiContext("finance:read");
    const q = Object.fromEntries(new URL(req.url).searchParams);
    return listEntries(ctx, q);
  });
}

/** POST { kind, description, categoryId?, costCenter?, amountCents, dueDate, paidAt?, companyId?, productId?, opportunityId? } */
export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("finance:write");
    return createEntry(ctx, await readJson(req));
  }, { status: 201 });
}
