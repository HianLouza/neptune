import { requireApiContext } from "@/server/auth/next";
import { budgetVsActual, setBudget } from "@/server/domains/finance";
import { handle, readJson, assertSameOrigin } from "@/server/http";

/** GET ?month=AAAA-MM — orçado x realizado por categoria. */
export async function GET(req: Request) {
  return handle(async () => {
    const ctx = await requireApiContext("finance:read");
    return budgetVsActual(ctx, new URL(req.url).searchParams.get("month") ?? undefined);
  });
}

/** POST { categoryId, month: "AAAA-MM", amountCents } — cria ou atualiza o orçamento do mês. */
export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("finance:write");
    return setBudget(ctx, await readJson(req));
  });
}
