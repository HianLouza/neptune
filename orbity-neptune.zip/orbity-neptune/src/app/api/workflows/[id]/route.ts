import { z } from "zod";
import { requireApiContext } from "@/server/auth/next";
import { saveWorkflow, setWorkflowStatus, workflowDetail } from "@/server/workflows/engine";
import { assertSameOrigin, handle, readJson } from "@/server/http";

type P = { params: Promise<{ id: string }> };
const uuid = z.string().uuid();

export async function GET(_req: Request, { params }: P) {
  return handle(async () => workflowDetail(await requireApiContext("automations:read"), uuid.parse((await params).id)));
}

/** Salva NOVA VERSÃO da definição (versões anteriores ficam no histórico — rollback = salvar uma versão antiga). */
export async function PUT(req: Request, { params }: P) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("automations:write");
    return saveWorkflow(ctx, await readJson(req), uuid.parse((await params).id));
  });
}

/** Publica (active), pausa (paused) ou volta para rascunho (draft). Publicar exige automations:publish. */
export async function PATCH(req: Request, { params }: P) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("automations:read");
    const b = z.object({ status: z.enum(["active", "paused", "draft"]) }).parse(await readJson(req));
    return setWorkflowStatus(ctx, uuid.parse((await params).id), b.status);
  });
}
