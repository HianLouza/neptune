import { z } from "zod";
import { requireApiContext } from "@/server/auth/next";
import { simulateWorkflow } from "@/server/workflows/engine";
import { assertSameOrigin, handle, readJson } from "@/server/http";

/** Simulação SEM efeitos colaterais: percorre a definição atual com um payload de exemplo. */
export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("automations:read");
    const b = z.object({ payload: z.record(z.string(), z.unknown()).default({}) }).parse(await readJson(req));
    return simulateWorkflow(ctx, z.string().uuid().parse((await params).id), b.payload);
  });
}
