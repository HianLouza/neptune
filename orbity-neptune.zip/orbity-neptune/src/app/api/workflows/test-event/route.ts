import { z } from "zod";
import { requireApiContext } from "@/server/auth/next";
import { emitTestEvent } from "@/server/workflows/engine";
import { EVENT_LABELS } from "@/server/events";
import { kickOutbox } from "@/server/events/handlers";
import { assertSameOrigin, handle, readJson } from "@/server/http";

/** Publica um evento de TESTE (payload marcado com _test) — dispara automações ativas reais com efeitos reais. */
export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("automations:write");
    const b = z.object({
      type: z.string().refine((t) => t in EVENT_LABELS, "Evento desconhecido."),
      payload: z.record(z.string(), z.unknown()).default({}),
    }).parse(await readJson(req));
    const eventId = await emitTestEvent(ctx, b.type, b.payload);
    kickOutbox(ctx.db);
    return { eventId };
  }, { status: 201 });
}
