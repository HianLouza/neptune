import { z } from "zod";
import { requireApiContext } from "@/server/auth/next";
import { reprocessRun } from "@/server/workflows/engine";
import { kickOutbox } from "@/server/events/handlers";
import { assertSameOrigin, handle } from "@/server/http";

/** Reprocessa uma execução com falha (recuperação manual). */
export async function POST(_req: Request, { params }: { params: Promise<{ runId: string }> }) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("automations:write");
    const r = await reprocessRun(ctx, z.string().uuid().parse((await params).runId));
    kickOutbox(ctx.db);
    return r;
  });
}
