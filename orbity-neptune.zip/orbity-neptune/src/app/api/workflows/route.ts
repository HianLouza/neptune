import { z } from "zod";
import { requireApiContext } from "@/server/auth/next";
import { listWorkflows, saveWorkflow } from "@/server/workflows/engine";
import { TEMPLATES, draftFromText } from "@/server/workflows/templates";
import { assertSameOrigin, handle, readJson, HttpError } from "@/server/http";

export async function GET() {
  return handle(async () => listWorkflows(await requireApiContext("automations:read")));
}

/**
 * Cria automação (sempre como RASCUNHO — publicação é uma ação separada).
 * Body: { templateKey } | { text } (linguagem natural) | { name, triggerEvent, definition, description? }
 */
export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("automations:write");
    const b = await readJson(req);
    const pick = z.object({ templateKey: z.string().max(60).optional(), text: z.string().trim().min(5).max(1000).optional() }).parse({ templateKey: b?.templateKey, text: b?.text });
    if (pick.templateKey) {
      const t = TEMPLATES.find((x) => x.key === pick.templateKey);
      if (!t) throw new HttpError(404, "Modelo não encontrado.");
      return saveWorkflow(ctx, { name: t.name, description: t.description, triggerEvent: t.triggerEvent, definition: t.definition });
    }
    if (pick.text) {
      const d = draftFromText(pick.text);
      if (!d) throw new HttpError(422, "Não identifiquei o gatilho. Mencione um evento, ex.: \"quando um lead for criado\", \"quando uma oportunidade for perdida\", \"quando chegar mensagem\".");
      return saveWorkflow(ctx, { name: d.name, description: d.description, triggerEvent: d.triggerEvent, definition: d.definition });
    }
    return saveWorkflow(ctx, b);
  }, { status: 201 });
}
