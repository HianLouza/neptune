import { requireApiContext } from "@/server/auth/next";
import { taskHistory } from "@/server/domains/task-alerts";
import { handle } from "@/server/http";

/** GET — histórico completo de alertas e interações da tarefa. */
export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => taskHistory(await requireApiContext(), (await params).id));
}
