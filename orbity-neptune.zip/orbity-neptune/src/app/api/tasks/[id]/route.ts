import { z } from "zod";
import { requireApiContext } from "@/server/auth/next";
import { setTaskStatus } from "@/server/domains/crm";
import { handle, readJson, assertSameOrigin } from "@/server/http";

/** PATCH { status: "open" | "done" | "canceled" } */
export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("crm:write");
    const { status } = z.object({ status: z.enum(["open", "done", "canceled"]) }).parse(await readJson(req));
    return setTaskStatus(ctx, (await params).id, status);
  });
}
