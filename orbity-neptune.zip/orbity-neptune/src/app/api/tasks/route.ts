import { requireApiContext } from "@/server/auth/next";
import { createTask, listTasks } from "@/server/domains/crm";
import { handle, readJson, assertSameOrigin } from "@/server/http";

/** GET ?mine=1 — lista tarefas. */
export async function GET(req: Request) {
  return handle(async () => {
    const ctx = await requireApiContext("crm:read");
    return listTasks(ctx, new URL(req.url).searchParams.get("mine") === "1");
  });
}

/** POST { title, description?, priority, dueAt?, assigneeId?, opportunityId? } */
export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("crm:write");
    return createTask(ctx, await readJson(req));
  }, { status: 201 });
}
