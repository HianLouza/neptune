import { z } from "zod";
import { requireApiContext } from "@/server/auth/next";
import { changePlan, forecastSpend, generateInvoice, setOverageAuthorization } from "@/server/domains/billing";
import { audit } from "@/server/audit";
import { handle, readJson, assertSameOrigin } from "@/server/http";

export async function GET() {
  return handle(async () => {
    const ctx = await requireApiContext("billing:read");
    return forecastSpend(ctx.db, ctx.organizationId);
  });
}

/** POST { action: "change_plan", planKey } | { action: "overage", authorized, capCents } | { action: "invoice" } */
export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("billing:manage");
    const b = z.discriminatedUnion("action", [
      z.object({ action: z.literal("change_plan"), planKey: z.enum(["starter", "growth", "business", "enterprise"]) }),
      z.object({ action: z.literal("overage"), authorized: z.boolean(), capCents: z.coerce.number().int().min(0).max(1e10) }),
      z.object({ action: z.literal("invoice") }),
    ]).parse(await readJson(req));
    if (b.action === "change_plan") { const p = await changePlan(ctx, b.planKey); return { plan: p.name }; }
    if (b.action === "overage") { await setOverageAuthorization(ctx, b.authorized, b.capCents); return { ok: true }; }
    const inv = await generateInvoice(ctx.db, ctx.organizationId);
    await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "billing.invoice_requested", resource: "invoice", resourceId: inv?.id ?? null });
    return inv;
  });
}
