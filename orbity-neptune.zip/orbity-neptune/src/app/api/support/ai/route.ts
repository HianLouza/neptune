import { z } from "zod";
import { requireApiContext } from "@/server/auth/next";
import { runAgent } from "@/server/ai/orchestrator";
import { handle, readJson, assertSameOrigin } from "@/server/http";

/** Base de ajuda da plataforma usada como contexto autorizado do agente de suporte. */
const HELP = [
  "Prospect.AI: defina o ICP, importe leads por CSV (colunas empresa, contato, e-mail, telefone, segmento, região), recalcule scores e gere abordagens (envio exige aprovação).",
  "Closer.AI: caixa de entrada compartilhada; respostas sugeridas pela IA ficam pendentes de aprovação humana. Mensagens só são entregues com integração real conectada.",
  "Integrações: conecte WhatsApp Business Platform, HubSpot, Pipedrive, Stripe, Mercado Pago e Asaas informando as credenciais; o sistema valida com o provedor.",
  "Billing: créditos de IA são debitados por execução; excedentes só ocorrem se autorizados no Billing e até o teto definido.",
  "Segurança: ative 2FA em Configurações > Segurança com um aplicativo autenticador.",
  "Administração: aprove colaboradores pendentes, crie equipes e cargos personalizados, exporte dados (LGPD).",
  "Automações: crie a partir de modelos, editor ou linguagem natural; publique para ativar; ações sensíveis exigem aprovação.",
].join("\n");

export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("support:use");
    const b = z.object({ message: z.string().trim().min(2).max(2000) }).parse(await readJson(req));
    const out = await runAgent(ctx, { agentKey: "support", input: b.message, context: HELP });
    const uncertain = out.status !== "success" && out.status !== "fallback" || /n[aã]o (sei|encontrei|tenho informa)/i.test(out.text) || out.simulated;
    return { ...out, suggestTicket: uncertain };
  });
}
