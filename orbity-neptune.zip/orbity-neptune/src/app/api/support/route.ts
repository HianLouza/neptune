import { z } from "zod";
import { requireApiContext } from "@/server/auth/next";
import { openTicket, rateTicket, listTickets } from "@/server/domains/support";
import { handle, readJson, assertSameOrigin } from "@/server/http";

export async function GET() {
  return handle(async () => listTickets(await requireApiContext("support:use")));
}

/** POST { action: "open", subject, description, category, priority } | { action: "rate", id, satisfaction } */
export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("support:use");
    const b = z.object({ action: z.enum(["open", "rate"]) }).passthrough().parse(await readJson(req));
    if (b.action === "rate") {
      const r = z.object({ id: z.string().uuid(), satisfaction: z.number().int() }).parse(b);
      return rateTicket(ctx, r.id, r.satisfaction);
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    return openTicket(ctx, b as any);
  }, { status: 200 });
}
