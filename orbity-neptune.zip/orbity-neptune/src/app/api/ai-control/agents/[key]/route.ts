import { requireApiContext } from "@/server/auth/next";
import { setAgentGovernance } from "@/server/ai/control-plane";
import { assertSameOrigin, handle, readJson } from "@/server/http";

type P = { params: Promise<{ key: string }> };

/** PATCH { autonomyLevel?, status?, ownerUserId?, domain?, monthlyCreditBudget?, permissions?, tools? } — somente ai:govern. */
export async function PATCH(req: Request, { params }: P) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("ai:govern");
    return setAgentGovernance(ctx, (await params).key, await readJson(req));
  });
}
