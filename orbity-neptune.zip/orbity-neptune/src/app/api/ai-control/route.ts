import { requireApiContext } from "@/server/auth/next";
import { controlPlaneOverview } from "@/server/ai/control-plane";
import { handle } from "@/server/http";

/** GET — visão completa do AI Control Plane (força de trabalho digital, kill switches, orçamentos, conflitos). */
export async function GET() {
  return handle(async () => controlPlaneOverview(await requireApiContext("ai:manage")));
}
