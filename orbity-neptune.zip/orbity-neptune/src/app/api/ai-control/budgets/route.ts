import { requireApiContext } from "@/server/auth/next";
import { listBudgets, upsertBudget } from "@/server/ai/control-plane";
import { assertSameOrigin, handle, readJson } from "@/server/http";

/** GET — orçamentos de IA com consumo do mês. */
export async function GET() {
  return handle(async () => listBudgets(await requireApiContext("ai:manage")));
}

/** POST { scope: organization|agent|model, target?, monthlyCredits, alertPct?, hardStop? } — cria ou atualiza. */
export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("ai:govern");
    return upsertBudget(ctx, await readJson(req));
  });
}
