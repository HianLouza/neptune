import { requireApiContext } from "@/server/auth/next";
import { deleteBudget } from "@/server/ai/control-plane";
import { assertSameOrigin, handle } from "@/server/http";

type P = { params: Promise<{ id: string }> };

/** DELETE — remove o orçamento. */
export async function DELETE(_req: Request, { params }: P) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("ai:govern");
    return deleteBudget(ctx, (await params).id);
  });
}
