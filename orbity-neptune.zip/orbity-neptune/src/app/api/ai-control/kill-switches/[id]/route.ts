import { requireApiContext } from "@/server/auth/next";
import { releaseKillSwitch } from "@/server/ai/control-plane";
import { assertSameOrigin, handle } from "@/server/http";

type P = { params: Promise<{ id: string }> };

/** PATCH — libera (desativa) o kill switch. */
export async function PATCH(_req: Request, { params }: P) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("ai:govern");
    return releaseKillSwitch(ctx, (await params).id);
  });
}
