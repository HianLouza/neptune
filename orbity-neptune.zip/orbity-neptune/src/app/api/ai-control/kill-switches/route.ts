import { requireApiContext } from "@/server/auth/next";
import { activateKillSwitch, listKillSwitches } from "@/server/ai/control-plane";
import { assertSameOrigin, handle, readJson } from "@/server/http";

/** GET — kill switches da organização (e globais ativos). */
export async function GET() {
  return handle(async () => listKillSwitches(await requireApiContext("ai:manage")));
}

/** POST { scope, target?, reason, global? } — aciona um kill switch (ai:govern; global só admin da plataforma). */
export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("ai:govern");
    return activateKillSwitch(ctx, await readJson(req));
  }, { status: 201 });
}
