import { requireApiContext } from "@/server/auth/next";
import { conflictReport } from "@/server/ai/control-plane";
import { handle } from "@/server/http";

/** GET — relatório de prevenção de conflitos (duplicidades, excesso de chamadas, sobreposição, ciclos). */
export async function GET() {
  return handle(async () => conflictReport(await requireApiContext("ai:manage")));
}
