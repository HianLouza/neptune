import { requireApiContext } from "@/server/auth/next";
import { agentMetrics } from "@/server/ai/control-plane";
import { handle } from "@/server/http";

/** GET ?days=30 — métricas por agente (execuções, falhas, latência, tokens, créditos, feedback, intervenções humanas). */
export async function GET(req: Request) {
  return handle(async () => {
    const ctx = await requireApiContext("ai:manage");
    const d = Number(new URL(req.url).searchParams.get("days") ?? 30);
    return agentMetrics(ctx, [7, 30, 90].includes(d) ? d : 30);
  });
}
