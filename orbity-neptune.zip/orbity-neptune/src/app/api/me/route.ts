import { z } from "zod";
import { requireApiContext } from "@/server/auth/next";
import { updateProfile, revokeMySession, listMySessions } from "@/server/domains/admin";
import { handle, readJson, assertSameOrigin } from "@/server/http";

export async function GET() {
  return handle(async () => listMySessions(await requireApiContext()));
}

/** POST { action: "profile", name, jobTitle, locale, timezone } | { action: "revoke_session", sessionId } */
export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext();
    const b = z.object({ action: z.enum(["profile", "revoke_session"]) }).passthrough().parse(await readJson(req));
    if (b.action === "revoke_session") return revokeMySession(ctx, z.object({ sessionId: z.string().uuid() }).parse(b).sessionId);
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    return updateProfile(ctx, b as any);
  });
}
