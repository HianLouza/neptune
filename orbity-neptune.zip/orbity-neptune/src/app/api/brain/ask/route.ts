import { z } from "zod";
import { requireApiContext } from "@/server/auth/next";
import { handle, readJson, assertSameOrigin } from "@/server/http";
import { askBrain } from "@/server/intelligence-layer/brain";

/** POST { question } — Business Brain: resposta executiva em 10 partes, com evidências. */
export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("intelligence:read");
    const { question } = z.object({ question: z.string().trim().min(3).max(500) }).parse(await readJson(req));
    return askBrain(ctx, question);
  });
}
