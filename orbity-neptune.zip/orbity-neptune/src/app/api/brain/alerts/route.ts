import { requireApiContext } from "@/server/auth/next";
import { handle, readJson, assertSameOrigin } from "@/server/http";
import { ALERT_DOMAINS, getAlertPrefs, setAlertPrefs } from "@/server/ai/flavio/alerts";

export const dynamic = "force-dynamic";

/** GET — preferências de alerta proativo do usuário nesta organização. */
export async function GET() {
  return handle(async () => ({ prefs: await getAlertPrefs(await requireApiContext("ai:use")), domains: ALERT_DOMAINS }));
}

/** PUT { enabled?, domains?, minPriority?, frequency? } — salva as preferências (auditado). */
export async function PUT(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    return setAlertPrefs(await requireApiContext("ai:use"), await readJson(req));
  });
}
