import { requireApiContext } from "@/server/auth/next";
import { handle } from "@/server/http";
import { ruleStats, INSIGHT_RULES } from "@/server/intelligence-layer/insights";

/** GET — catálogo de regras e precisão (feedback de aceite/rejeição e resultados medidos). */
export async function GET() {
  return handle(async () => {
    const ctx = await requireApiContext("intelligence:read");
    return { rules: INSIGHT_RULES, stats: await ruleStats(ctx) };
  });
}
