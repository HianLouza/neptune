import { z } from "zod";
import { eq } from "drizzle-orm";
import { userPreferences } from "@/server/db/schema";
import { requireApiContext } from "@/server/auth/next";
import { handle, readJson, assertSameOrigin } from "@/server/http";
import { COMMAND_CENTER_WIDGETS } from "@/server/intelligence-layer/widgets";

/** POST { hidden: string[] } — widgets ocultos do Command Center (por usuário, em user_preferences.ai_personalization). */
export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("intelligence:read");
    const keys = COMMAND_CENTER_WIDGETS.map((w) => w.key) as [string, ...string[]];
    const { hidden } = z.object({ hidden: z.array(z.enum(keys)).max(keys.length) }).parse(await readJson(req));
    const [cur] = await ctx.db.select().from(userPreferences).where(eq(userPreferences.userId, ctx.userId));
    const aiPersonalization = { ...(cur?.aiPersonalization ?? {}), commandCenter: { hidden } };
    await ctx.db.insert(userPreferences).values({ userId: ctx.userId, aiPersonalization })
      .onConflictDoUpdate({ target: userPreferences.userId, set: { aiPersonalization, updatedAt: new Date() } });
    return { hidden };
  });
}
