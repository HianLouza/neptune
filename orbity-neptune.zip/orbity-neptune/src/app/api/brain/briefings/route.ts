import { z } from "zod";
import { requireApiContext } from "@/server/auth/next";
import { handle, readJson, assertSameOrigin } from "@/server/http";
import { generateBriefing, listBriefings } from "@/server/intelligence-layer/briefing";

export async function GET() {
  return handle(async () => listBriefings(await requireApiContext("intelligence:read"), 20));
}

/** POST { period: "daily" | "weekly" | "monthly" | "quarterly" } — gera e salva um briefing executivo. */
export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("intelligence:read");
    const { period } = z.object({ period: z.enum(["daily", "weekly", "monthly", "quarterly"]) }).parse(await readJson(req));
    return generateBriefing(ctx, period);
  }, { status: 201 });
}
