import { NextResponse } from "next/server";
import { requireApiContext } from "@/server/auth/next";
import { audit } from "@/server/audit";
import { getInvestigation } from "@/server/ai/flavio/conversations";
import { investigationToCsv, investigationToMarkdown } from "@/server/ai/flavio/investigate";

export const dynamic = "force-dynamic";

/** GET ?format=md|csv — exporta a investigação (relatório com seções, fontes e limitações). Auditado. */
export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const ctx = await requireApiContext("ai:use");
    const inv = await getInvestigation(ctx, (await params).id);
    const format = new URL(req.url).searchParams.get("format") === "csv" ? "csv" : "md";
    await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "flavio.investigation.exported", resource: "flavio_conversation", resourceId: inv.id, metadata: { format }, ip: ctx.ip });
    const body = format === "csv" ? investigationToCsv(inv.messages) : investigationToMarkdown(inv.title, inv.messages);
    const name = `orbity-business-brain-${new Date().toISOString().slice(0, 10)}.${format}`;
    return new NextResponse(body, { headers: { "content-type": format === "csv" ? "text/csv; charset=utf-8" : "text/markdown; charset=utf-8", "content-disposition": `attachment; filename="${name}"`, "cache-control": "no-store" } });
  } catch (e) {
    const status = (e as { status?: number }).status ?? 500;
    return NextResponse.json({ ok: false, error: status === 500 ? "Erro ao exportar." : (e as Error).message }, { status });
  }
}
