import { requireApiContext } from "@/server/auth/next";
import { handle, assertSameOrigin } from "@/server/http";
import { deleteInvestigations, getInvestigation } from "@/server/ai/flavio/conversations";

export const dynamic = "force-dynamic";

/** GET — uma investigação do próprio usuário, com mensagens e respostas estruturadas. */
export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => getInvestigation(await requireApiContext("ai:use"), (await params).id));
}

/** DELETE — apaga a investigação (do próprio usuário). */
export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    await assertSameOrigin();
    return deleteInvestigations(await requireApiContext("ai:use"), (await params).id);
  });
}
