import { requireApiContext } from "@/server/auth/next";
import { handle, assertSameOrigin } from "@/server/http";
import { deleteInvestigations, listInvestigations } from "@/server/ai/flavio/conversations";

export const dynamic = "force-dynamic";

/** GET — investigações do próprio usuário (Business Brain e painel do Flávio). */
export async function GET() {
  return handle(async () => listInvestigations(await requireApiContext("ai:use")));
}

/** DELETE — apaga TODAS as investigações do próprio usuário nesta organização (LGPD). */
export async function DELETE() {
  return handle(async () => {
    await assertSameOrigin();
    return deleteInvestigations(await requireApiContext("ai:use"));
  });
}
