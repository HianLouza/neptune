import { requireApiContext } from "@/server/auth/next";
import { handle } from "@/server/http";
import { proactiveItems } from "@/server/ai/flavio/alerts";

export const dynamic = "force-dynamic";

/** GET — o que merece atenção agora, segundo as preferências do usuário (o que aconteceu, indicador, impacto, evidência, urgência, recomendação). */
export async function GET() {
  return handle(async () => proactiveItems(await requireApiContext("ai:use")));
}
