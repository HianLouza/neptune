import { requireApiContext } from "@/server/auth/next";
import { handle, readJson, assertSameOrigin } from "@/server/http";
import { investigate } from "@/server/ai/flavio/investigate";

export const dynamic = "force-dynamic";

/** POST { question, conversationId?, surface? } — Business Brain via Flávio: investigação com ferramentas, evidências e contexto. */
export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("ai:use");
    return investigate(ctx, await readJson(req));
  });
}
