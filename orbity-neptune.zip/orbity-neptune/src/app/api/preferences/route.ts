import { z } from "zod";
import { userPreferences } from "@/server/db/schema";
import { requireApiContext } from "@/server/auth/next";
import { handle, readJson } from "@/server/http";

export async function POST(req: Request) {
  return handle(async () => {
    const ctx = await requireApiContext();
    const b = z.object({
      lastRoute: z.string().regex(/^\/[a-zA-Z0-9\-/_]*$/).max(200).optional(),
      theme: z.enum(["dark", "light"]).optional(),
      favorites: z.array(z.string().max(200)).max(30).optional(),
    }).parse(await readJson(req));
    await ctx.db.insert(userPreferences).values({ userId: ctx.userId, ...b })
      .onConflictDoUpdate({ target: userPreferences.userId, set: { ...b, updatedAt: new Date() } });
    return { ok: true };
  });
}
