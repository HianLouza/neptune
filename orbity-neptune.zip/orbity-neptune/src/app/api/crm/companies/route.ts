import { requireApiContext } from "@/server/auth/next";
import { upsertCompany } from "@/server/domains/crm";
import { listCompanies } from "@/server/domains/crm/queries";
import { handle, readJson, assertSameOrigin } from "@/server/http";

export async function GET(req: Request) {
  return handle(async () => listCompanies(await requireApiContext("crm:read"), new URL(req.url).searchParams.get("q") ?? undefined));
}

/** Cria empresa (deduplicada por nome normalizado/domínio). */
export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    return upsertCompany(await requireApiContext("crm:write"), await readJson(req));
  }, { status: 201 });
}
