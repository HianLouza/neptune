import { requireApiContext } from "@/server/auth/next";
import { upsertContact } from "@/server/domains/crm";
import { listContacts } from "@/server/domains/crm/queries";
import { handle, readJson, assertSameOrigin } from "@/server/http";

export async function GET(req: Request) {
  return handle(async () => listContacts(await requireApiContext("crm:read"), new URL(req.url).searchParams.get("q") ?? undefined));
}

/** Cria contato (deduplicado por e-mail; registra base legal LGPD). */
export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    return upsertContact(await requireApiContext("crm:write"), await readJson(req));
  }, { status: 201 });
}
