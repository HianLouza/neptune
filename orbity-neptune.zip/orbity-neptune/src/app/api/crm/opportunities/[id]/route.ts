import { z } from "zod";
import { requireApiContext } from "@/server/auth/next";
import { createTask, logActivity, moveOpportunity, opportunityDetail, scheduleMeeting, sendProposal } from "@/server/domains/crm";
import { kickOutbox } from "@/server/events/handlers";
import { handle, readJson, assertSameOrigin } from "@/server/http";

const body = z.discriminatedUnion("action", [
  z.object({ action: z.literal("move"), stageId: z.string().uuid(), lostReason: z.string().trim().min(2).max(300).optional() }),
  z.object({ action: z.literal("activity"), type: z.enum(["call", "email", "meeting", "note", "whatsapp", "follow_up"]), subject: z.string(), body: z.string().optional() }),
  z.object({ action: z.literal("task"), title: z.string(), priority: z.enum(["low", "medium", "high"]).default("medium"), dueAt: z.string().optional(), assigneeId: z.string().uuid().optional() }),
  z.object({ action: z.literal("meeting"), title: z.string().min(2).max(200), startsAt: z.string() }),
  z.object({ action: z.literal("proposal"), title: z.string().trim().min(2).max(200), amountCents: z.coerce.number().int().min(0).max(1e13) }),
]);

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const { id } = await params;
    return opportunityDetail(await requireApiContext("crm:read"), z.string().uuid().parse(id));
  });
}

/** Ações sobre a oportunidade: mover etapa, registrar atividade, criar tarefa, agendar reunião, enviar proposta. */
export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    await assertSameOrigin();
    const id = z.string().uuid().parse((await params).id);
    const ctx = await requireApiContext("crm:write");
    const b = body.parse(await readJson(req));
    let result: unknown;
    switch (b.action) {
      case "move": result = await moveOpportunity(ctx, id, b.stageId, b.lostReason); break;
      case "activity": result = await logActivity(ctx, { type: b.type, subject: b.subject, body: b.body, opportunityId: id }); break;
      case "task": result = await createTask(ctx, { title: b.title, priority: b.priority, dueAt: b.dueAt ? new Date(b.dueAt) : undefined, assigneeId: b.assigneeId, opportunityId: id }); break;
      case "meeting": result = await scheduleMeeting(ctx, { title: b.title, startsAt: b.startsAt, opportunityId: id }); break;
      case "proposal": result = await sendProposal(ctx, id, b.title, b.amountCents); break;
    }
    kickOutbox(ctx.db);
    return result;
  });
}
