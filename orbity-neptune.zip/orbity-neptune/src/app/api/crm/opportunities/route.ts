import { requireApiContext } from "@/server/auth/next";
import { createOpportunity } from "@/server/domains/crm";
import { kanban } from "@/server/domains/crm/queries";
import { kickOutbox } from "@/server/events/handlers";
import { handle, readJson, assertSameOrigin } from "@/server/http";

export async function GET(req: Request) {
  return handle(async () => {
    const ctx = await requireApiContext("crm:read");
    const sp = new URL(req.url).searchParams;
    return kanban(ctx, { stageId: sp.get("etapa") ?? undefined, stale: sp.get("filtro") === "paradas", q: sp.get("q") ?? undefined });
  });
}

export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("crm:write");
    const o = await createOpportunity(ctx, await readJson(req));
    kickOutbox(ctx.db);
    return o;
  }, { status: 201 });
}
