import { z } from "zod";
import { eq } from "drizzle-orm";
import { requireApiContext } from "@/server/auth/next";
import { organizations, products } from "@/server/db/schema";
import { saveIcp } from "@/server/domains/prospect";
import { audit } from "@/server/audit";
import { handle, readJson } from "@/server/http";

const schema = z.object({
  name: z.string().trim().min(2).max(120),
  segment: z.string().trim().min(2).max(80),
  size: z.enum(["2-10", "11-30", "31-100", "100+"]),
  products: z.array(z.string().trim().min(2).max(120)).max(20).default([]),
  objectives: z.array(z.string().max(80)).max(10).default([]),
  salesProcess: z.enum(["consultiva", "transacional", "mista"]).default("consultiva"),
  targetSegments: z.array(z.string().trim().min(1).max(80)).max(20).default([]),
  targetRegions: z.array(z.string().trim().min(1).max(40)).max(30).default([]),
  timezone: z.string().max(60).default("America/Sao_Paulo"),
});

/** Assistente de configuração da organização (onboarding guiado). */
export async function POST(req: Request) {
  return handle(async () => {
    const ctx = await requireApiContext("admin:settings");
    const b = schema.parse(await readJson(req));
    await ctx.db.update(organizations).set({
      name: b.name, segment: b.segment, size: b.size, timezone: b.timezone, onboardingCompleted: true,
      settings: { objectives: b.objectives, salesProcess: b.salesProcess }, updatedAt: new Date(),
    }).where(eq(organizations.id, ctx.organizationId));
    if (b.products.length) await ctx.db.insert(products).values(b.products.map((p) => ({ organizationId: ctx.organizationId, name: p, kind: "service" })));
    if (b.targetSegments.length || b.targetRegions.length) {
      await saveIcp(ctx, { name: "ICP inicial (onboarding)", segments: b.targetSegments, regions: b.targetRegions, sizes: [], technologies: [], needs: b.objectives });
    }
    await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "organization.onboarded", resource: "organization", resourceId: ctx.organizationId });
    return { ok: true };
  });
}
