import { requireApiContext } from "@/server/auth/next";
import { createGoal, goalsWithProgress } from "@/server/domains/goals";
import { handle, readJson, assertSameOrigin } from "@/server/http";

/** GET — metas com progresso e projeção. */
export async function GET() {
  return handle(async () => goalsWithProgress(await requireApiContext("goals:read")));
}

/** POST { name, metric, scope, scopeId?, targetValue, periodStart, periodEnd } */
export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("goals:manage");
    return createGoal(ctx, await readJson(req));
  }, { status: 201 });
}
