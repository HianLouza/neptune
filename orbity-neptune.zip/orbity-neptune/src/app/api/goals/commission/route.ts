import { z } from "zod";
import { requireApiContext } from "@/server/auth/next";
import { calculateCommission, listCommissionRules, saveCommissionRule } from "@/server/domains/goals";
import { handle, readJson, assertSameOrigin } from "@/server/http";

/** GET — regras de comissão (todas as versões). */
export async function GET() {
  return handle(async () => listCommissionRules(await requireApiContext("goals:read")));
}

/** POST { name, ratePct, acceleratorPct } — nova versão da regra (auditada).
 *  POST { simulate: { ratePct, acceleratorPct, achieved, target } } — simulação sem persistência. */
export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    const body = await readJson(req);
    if (body && typeof body === "object" && "simulate" in body) {
      await requireApiContext("goals:read");
      const s = z.object({ ratePct: z.number().min(0).max(100), acceleratorPct: z.number().min(0).max(100), achieved: z.number().min(0), target: z.number().positive() }).parse(body.simulate);
      return { commission: calculateCommission(s, s.achieved, s.target) };
    }
    const ctx = await requireApiContext("goals:manage");
    return saveCommissionRule(ctx, body);
  });
}
