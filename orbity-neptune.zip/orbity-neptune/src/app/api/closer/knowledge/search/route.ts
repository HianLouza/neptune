import { requireApiContext } from "@/server/auth/next";
import { searchKnowledge } from "@/server/domains/closer";
import { handle, HttpError } from "@/server/http";

/** Teste da busca semântica — sempre restrita à organização do usuário. */
export async function GET(req: Request) {
  return handle(async () => {
    const ctx = await requireApiContext("closer:read");
    const q = (new URL(req.url).searchParams.get("q") ?? "").trim().slice(0, 500);
    if (q.length < 2) throw new HttpError(400, "Digite ao menos 2 caracteres.");
    const rows = await searchKnowledge(ctx.db, ctx.organizationId, q, 5, 0);
    return rows.map((r) => ({ title: r.title, content: r.content, similarity: Number(r.similarity) }));
  });
}
