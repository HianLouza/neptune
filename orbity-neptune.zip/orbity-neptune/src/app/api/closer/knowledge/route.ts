import { requireApiContext } from "@/server/auth/next";
import { addKnowledge, listKnowledge } from "@/server/domains/closer";
import { assertSameOrigin, handle, readJson } from "@/server/http";

export async function GET() {
  return handle(async () => listKnowledge(await requireApiContext("closer:read")));
}

/** Adiciona documento à base de conhecimento (dividido em trechos + embeddings pgvector). Validação no domínio. */
export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("closer:write");
    return addKnowledge(ctx, await readJson(req));
  }, { status: 201 });
}
