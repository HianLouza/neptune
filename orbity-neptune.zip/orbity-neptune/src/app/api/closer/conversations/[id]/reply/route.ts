import { z } from "zod";
import { requireApiContext } from "@/server/auth/next";
import { sendReply } from "@/server/domains/closer";
import { kickOutbox } from "@/server/events/handlers";
import { assertSameOrigin, handle, readJson } from "@/server/http";

/** Resposta enviada por um humano. Sem integração real do canal, retorna `delivered: false` + aviso. */
export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("closer:write");
    const { id } = await params;
    const b = z.object({ body: z.string().trim().min(1).max(5000) }).parse(await readJson(req));
    const r = await sendReply(ctx, z.string().uuid().parse(id), b.body, "user");
    kickOutbox(ctx.db);
    return r;
  });
}
