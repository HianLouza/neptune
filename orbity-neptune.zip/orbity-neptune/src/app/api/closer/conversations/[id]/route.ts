import { z } from "zod";
import { requireApiContext } from "@/server/auth/next";
import { getConversation, setConversationStatus } from "@/server/domains/closer";
import { assertSameOrigin, handle, readJson } from "@/server/http";

type P = { params: Promise<{ id: string }> };

export async function GET(_req: Request, { params }: P) {
  return handle(async () => {
    const ctx = await requireApiContext("closer:read");
    const { id } = await params;
    return getConversation(ctx, z.string().uuid().parse(id));
  });
}

/** Altera status (open | waiting | handoff | closed) e/ou liga/desliga a IA da conversa. */
export async function PATCH(req: Request, { params }: P) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("closer:write");
    const { id } = await params;
    const b = z.object({ status: z.enum(["open", "waiting", "handoff", "closed"]).optional(), aiEnabled: z.boolean().optional() })
      .refine((v) => v.status !== undefined || v.aiEnabled !== undefined, "Nada para alterar.").parse(await readJson(req));
    return setConversationStatus(ctx, z.string().uuid().parse(id), b);
  });
}
