import { z } from "zod";
import { requireApiContext } from "@/server/auth/next";
import { suggestAiReply } from "@/server/domains/closer";
import { assertSameOrigin, handle } from "@/server/http";

/** IA sugere resposta com base na base de conhecimento. Cria aprovação PENDENTE — nada é enviado. */
export async function POST(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("closer:write");
    const { id } = await params;
    return suggestAiReply(ctx, z.string().uuid().parse(id));
  });
}
