import { z } from "zod";
import { requireApiContext } from "@/server/auth/next";
import { summarizeConversation } from "@/server/domains/closer";
import { assertSameOrigin, handle } from "@/server/http";

export async function POST(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("closer:read");
    const { id } = await params;
    return summarizeConversation(ctx, z.string().uuid().parse(id));
  });
}
