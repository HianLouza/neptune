import { requireApiContext } from "@/server/auth/next";
import { listConversations } from "@/server/domains/closer";
import { handle } from "@/server/http";

export async function GET(req: Request) {
  return handle(async () => {
    const ctx = await requireApiContext("closer:read");
    const status = new URL(req.url).searchParams.get("status") ?? undefined;
    return listConversations(ctx, status && ["open", "waiting", "handoff", "closed"].includes(status) ? status : undefined);
  });
}
