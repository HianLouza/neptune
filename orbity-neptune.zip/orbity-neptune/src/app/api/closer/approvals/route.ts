import { requireApiContext } from "@/server/auth/next";
import { listApprovals } from "@/server/domains/closer";
import { handle } from "@/server/http";

export async function GET(req: Request) {
  return handle(async () => {
    const ctx = await requireApiContext("closer:read");
    const s = new URL(req.url).searchParams.get("status") ?? "pending";
    return listApprovals(ctx, ["pending", "approved", "rejected"].includes(s) ? s : "pending");
  });
}
