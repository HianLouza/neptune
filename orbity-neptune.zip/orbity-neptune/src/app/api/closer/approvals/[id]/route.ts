import { z } from "zod";
import { requireApiContext } from "@/server/auth/next";
import { decideApproval } from "@/server/domains/closer";
import { kickOutbox } from "@/server/events/handlers";
import { assertSameOrigin, handle, readJson } from "@/server/http";

/** Decisão humana sobre ação sensível (mensagem da IA ou passo de automação). */
export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("approvals:decide");
    const { id } = await params;
    const b = z.object({ approve: z.boolean(), editedBody: z.string().max(5000).optional() }).parse(await readJson(req));
    const r = await decideApproval(ctx, z.string().uuid().parse(id), b.approve, b.editedBody);
    kickOutbox(ctx.db);
    return r;
  });
}
