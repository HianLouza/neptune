import { requireApiContext } from "@/server/auth/next";
import { CHANNEL_LABEL, channelAvailability } from "@/server/domains/task-alerts";
import { handle } from "@/server/http";

/** GET — disponibilidade REAL de cada canal para a organização (com o motivo quando indisponível). */
export async function GET() {
  return handle(async () => {
    const ctx = await requireApiContext("alerts:send");
    const a = await channelAvailability(ctx.db, ctx.organizationId);
    return Object.entries(a).map(([key, v]) => ({ key, label: CHANNEL_LABEL[key as keyof typeof CHANNEL_LABEL], ...v }));
  });
}
