import { requireApiContext } from "@/server/auth/next";
import { runAlertAutomation } from "@/server/domains/task-alerts";
import { audit } from "@/server/audit";
import { handle, assertSameOrigin } from "@/server/http";

/** POST — executa agora a automação/escalonamento desta organização (o worker faz o mesmo a cada minuto). Idempotente. */
export async function POST() {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("alerts:manage");
    const stats = await runAlertAutomation(ctx.db, ctx.organizationId);
    await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "task_alert.automation_run_manual", resource: "organization", resourceId: ctx.organizationId, metadata: { ...stats } });
    return stats;
  });
}
