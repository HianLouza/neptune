import { requireApiContext } from "@/server/auth/next";
import { generateAlertMessage } from "@/server/domains/task-alerts";
import { handle, readJson, assertSameOrigin } from "@/server/http";

/** POST { taskId, kind, tone?, instruction?, variant?, previous? } — o Flávio SUGERE a mensagem; nada é enviado. */
export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    return generateAlertMessage(await requireApiContext("alerts:send"), await readJson(req));
  });
}
