import { requireApiContext } from "@/server/auth/next";
import { executionIntelligence } from "@/server/domains/task-alerts";
import { handle } from "@/server/http";

/** GET ?days=90 — fatos, inferências e recomendações sobre execução e alertas (nunca avalia pessoas). */
export async function GET(req: Request) {
  return handle(async () => {
    const ctx = await requireApiContext("alerts:send");
    const days = Math.min(365, Math.max(7, Number(new URL(req.url).searchParams.get("days")) || 90));
    return executionIntelligence(ctx, days);
  });
}
