import { requireApiContext } from "@/server/auth/next";
import { respondToAlert } from "@/server/domains/task-alerts";
import { handle, readJson, assertSameOrigin } from "@/server/http";

/** POST { alertId?, taskId?, kind, message?, progressPct?, evidenceUrl? } — resposta/atualização do responsável. */
export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    return respondToAlert(await requireApiContext(), await readJson(req));
  }, { status: 201 });
}
