import { requireApiContext } from "@/server/auth/next";
import { listMyAlerts } from "@/server/domains/task-alerts";
import { handle } from "@/server/http";

/** GET — alertas recebidos pelo usuário logado. */
export async function GET() {
  return handle(async () => listMyAlerts(await requireApiContext()));
}
