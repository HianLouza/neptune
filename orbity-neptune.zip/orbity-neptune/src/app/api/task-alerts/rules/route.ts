import { requireApiContext } from "@/server/auth/next";
import { createRule, listRules } from "@/server/domains/task-alerts";
import { handle, readJson, assertSameOrigin } from "@/server/http";

export async function GET() {
  return handle(async () => listRules(await requireApiContext("alerts:manage")));
}

export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    return createRule(await requireApiContext("alerts:manage"), await readJson(req));
  }, { status: 201 });
}
