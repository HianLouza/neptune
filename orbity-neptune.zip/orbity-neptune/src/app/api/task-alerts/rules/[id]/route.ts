import { requireApiContext } from "@/server/auth/next";
import { deleteRule, updateRule } from "@/server/domains/task-alerts";
import { handle, readJson, assertSameOrigin } from "@/server/http";

type P = { params: Promise<{ id: string }> };

export async function PATCH(req: Request, { params }: P) {
  return handle(async () => {
    await assertSameOrigin();
    return updateRule(await requireApiContext("alerts:manage"), (await params).id, await readJson(req));
  });
}

export async function DELETE(_req: Request, { params }: P) {
  return handle(async () => {
    await assertSameOrigin();
    return deleteRule(await requireApiContext("alerts:manage"), (await params).id);
  });
}
