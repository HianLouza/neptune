import { requireApiContext } from "@/server/auth/next";
import { createAlert, listAlerts } from "@/server/domains/task-alerts";
import { handle, readJson, assertSameOrigin } from "@/server/http";

/** GET — Central de Alertas (gestor) ou, para colaboradores, apenas os alertas recebidos. Filtros por query string. */
export async function GET(req: Request) {
  return handle(async () => {
    const ctx = await requireApiContext();
    const q = Object.fromEntries(new URL(req.url).searchParams.entries());
    return listAlerts(ctx, q);
  });
}

/** POST — cria (e envia, agenda ou salva como rascunho) um alerta individual. */
export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("alerts:send");
    return createAlert(ctx, await readJson(req));
  }, { status: 201 });
}
