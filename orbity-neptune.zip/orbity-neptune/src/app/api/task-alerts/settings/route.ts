import { requireApiContext } from "@/server/auth/next";
import { getTone, setTone } from "@/server/domains/task-alerts";
import { handle, readJson, assertSameOrigin } from "@/server/http";

/** GET/PUT — tom de comunicação das mensagens (organização, equipe e tipo de alerta). */
export async function GET() {
  return handle(async () => getTone(await requireApiContext("alerts:send")));
}

export async function PUT(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    return setTone(await requireApiContext("alerts:manage"), await readJson(req));
  });
}
