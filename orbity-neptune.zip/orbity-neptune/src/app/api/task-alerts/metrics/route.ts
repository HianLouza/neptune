import { requireApiContext } from "@/server/auth/next";
import { alertCenterMetrics } from "@/server/domains/task-alerts";
import { handle } from "@/server/http";

export async function GET() {
  return handle(async () => alertCenterMetrics(await requireApiContext("alerts:send")));
}
