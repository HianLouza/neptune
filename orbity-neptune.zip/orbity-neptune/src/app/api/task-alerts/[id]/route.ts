import { z } from "zod";
import { requireApiContext } from "@/server/auth/next";
import { cancelAlert, getAlertDetail, markAlertRead, sendAlertNow } from "@/server/domains/task-alerts";
import { handle, readJson, assertSameOrigin } from "@/server/http";

type P = { params: Promise<{ id: string }> };

/** GET — detalhe do alerta com tarefa, histórico, respostas e prorrogações. */
export async function GET(_req: Request, { params }: P) {
  return handle(async () => getAlertDetail(await requireApiContext(), (await params).id));
}

/** PATCH { action: "cancel" | "send_now" | "read", reason? } */
export async function PATCH(req: Request, { params }: P) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext();
    const id = (await params).id;
    const b = z.object({ action: z.enum(["cancel", "send_now", "read"]), reason: z.string().max(300).optional() }).parse(await readJson(req));
    if (b.action === "read") return markAlertRead(ctx, id);
    if (b.action === "send_now") return sendAlertNow(ctx, id);
    return cancelAlert(ctx, id, b.reason);
  });
}
