import { and, desc, eq, isNull, or } from "drizzle-orm";
import { notifications } from "@/server/db/schema";
import { requireApiContext } from "@/server/auth/next";
import { handle } from "@/server/http";

const mine = (orgId: string, userId: string) =>
  and(eq(notifications.organizationId, orgId), or(isNull(notifications.userId), eq(notifications.userId, userId)));

export async function GET() {
  return handle(async () => {
    const ctx = await requireApiContext();
    return ctx.db.select().from(notifications).where(mine(ctx.organizationId, ctx.userId)).orderBy(desc(notifications.createdAt)).limit(30);
  });
}

/** Marca todas como lidas. */
export async function POST() {
  return handle(async () => {
    const ctx = await requireApiContext();
    await ctx.db.update(notifications).set({ readAt: new Date() }).where(and(mine(ctx.organizationId, ctx.userId), isNull(notifications.readAt)));
    return { ok: true };
  });
}
