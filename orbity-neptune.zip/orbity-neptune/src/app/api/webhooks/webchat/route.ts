/**
 * Webchat público (widget do site do cliente).
 * POST { orgSlug, name, email?, message } → registra mensagem recebida no Closer.AI.
 * Proteções: validação zod, limite por IP (em memória — em produção usar Redis/edge), organização ativa.
 */
import { z } from "zod";
import { and, eq } from "drizzle-orm";
import { getDb } from "@/server/db/client";
import { organizations } from "@/server/db/schema";
import { receiveInbound } from "@/server/domains/closer";
import { kickOutbox } from "@/server/events/handlers";
import { clientIp } from "@/server/auth/next";
import { handle, readJson, HttpError } from "@/server/http";

const WINDOW_MS = 60_000, MAX_PER_WINDOW = 20;
const g = globalThis as unknown as { __webchatRate?: Map<string, { n: number; reset: number }> };
const hits = (g.__webchatRate ??= new Map());

function rateLimit(key: string) {
  const now = Date.now();
  const h = hits.get(key);
  if (!h || h.reset < now) { hits.set(key, { n: 1, reset: now + WINDOW_MS }); return; }
  if (++h.n > MAX_PER_WINDOW) throw new HttpError(429, "Muitas mensagens. Aguarde um minuto.");
}

const schema = z.object({
  orgSlug: z.string().trim().min(2).max(80),
  name: z.string().trim().min(2).max(120),
  email: z.string().trim().email().max(200).optional().or(z.literal("")),
  message: z.string().trim().min(1).max(4000),
});

export async function POST(req: Request) {
  return handle(async () => {
    rateLimit((await clientIp()) ?? "unknown");
    const b = schema.parse(await readJson(req));
    const db = await getDb();
    const [org] = await db.select({ id: organizations.id }).from(organizations).where(and(eq(organizations.slug, b.orgSlug), eq(organizations.status, "active")));
    if (!org) throw new HttpError(404, "Organização não encontrada.");
    const r = await receiveInbound(db, org.id, { channel: "webchat", from: { name: b.name, email: b.email || undefined }, body: b.message });
    kickOutbox(db);
    return { conversationId: r.conversationId, received: true };
  }, { status: 201 });
}
