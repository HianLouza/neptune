/**
 * Webhook oficial da WhatsApp Business Platform (Cloud API).
 * GET  → verificação (hub.challenge) com WHATSAPP_VERIFY_TOKEN.
 * POST → mensagens recebidas. Organização identificada pelo phone_number_id da integração conectada.
 *        Assinatura X-Hub-Signature-256 validada com WHATSAPP_APP_SECRET (obrigatório em produção).
 *        Sempre responde 200 para a Meta (evita reentregas em loop); erros vão para log estruturado.
 * Idempotência: mensagens já registradas (mesmo externalId) são ignoradas.
 */
import crypto from "node:crypto";
import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { getDb } from "@/server/db/client";
import { integrations, messages, integrationLogs } from "@/server/db/schema";
import { receiveInbound } from "@/server/domains/closer";
import { decrypt } from "@/server/auth/crypto";
import { kickOutbox } from "@/server/events/handlers";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const u = new URL(req.url).searchParams;
  const token = process.env.WHATSAPP_VERIFY_TOKEN;
  if (token && u.get("hub.mode") === "subscribe" && u.get("hub.verify_token") === token) {
    return new NextResponse(u.get("hub.challenge") ?? "", { status: 200, headers: { "content-type": "text/plain" } });
  }
  return new NextResponse("Forbidden", { status: 403 });
}

type WaPayload = {
  entry?: { changes?: { value?: {
    metadata?: { phone_number_id?: string };
    contacts?: { wa_id?: string; profile?: { name?: string } }[];
    messages?: { id?: string; from?: string; type?: string; text?: { body?: string } }[];
  } }[] }[];
};

const log = (level: string, msg: string, extra: Record<string, unknown> = {}) =>
  console[level === "error" ? "error" : "log"](JSON.stringify({ level, at: new Date().toISOString(), src: "webhook.whatsapp", msg, ...extra }));

function validSignature(raw: string, header: string | null) {
  const secret = process.env.WHATSAPP_APP_SECRET;
  // Sem segredo: aceito só fora de produção (desenvolvimento/testes). Em produção, payload sem assinatura verificável é descartado.
  if (!secret) return process.env.NODE_ENV !== "production" && process.env.APP_ENV !== "production";
  if (!header?.startsWith("sha256=")) return false;
  const expected = crypto.createHmac("sha256", secret).update(raw).digest("hex");
  const got = header.slice(7);
  return got.length === expected.length && crypto.timingSafeEqual(Buffer.from(got), Buffer.from(expected));
}

export async function POST(req: Request) {
  const raw = await req.text();
  try {
    if (!validSignature(raw, req.headers.get("x-hub-signature-256"))) { log("warn", "assinatura inválida"); return NextResponse.json({ ok: true }); }
    const payload = JSON.parse(raw) as WaPayload;
    const db = await getDb();
    const conns = await db.select().from(integrations).where(and(eq(integrations.provider, "whatsapp"), eq(integrations.status, "connected")));
    const orgFor = (phoneNumberId: string) => conns.find((c) => {
      if (c.config?.phoneNumberId === phoneNumberId) return true;
      if (!c.encryptedCredentials) return false;
      try { return (JSON.parse(decrypt(c.encryptedCredentials)) as { phoneNumberId?: string }).phoneNumberId === phoneNumberId; } catch { return false; }
    });
    let received = 0;
    for (const entry of payload.entry ?? []) for (const ch of entry.changes ?? []) {
      const v = ch.value;
      const pnid = v?.metadata?.phone_number_id;
      if (!v?.messages?.length || !pnid) continue;
      const integ = orgFor(pnid);
      if (!integ) { log("warn", "phone_number_id sem integração conectada", { pnid }); continue; }
      for (const m of v.messages) {
        if (!m.id) continue;
        const [dup] = await db.select({ id: messages.id }).from(messages).where(and(eq(messages.organizationId, integ.organizationId), eq(messages.externalId, m.id))).limit(1);
        if (dup) continue;
        const contact = v.contacts?.find((c) => c.wa_id === m.from);
        const body = m.type === "text" ? (m.text?.body ?? "") : `[mensagem do tipo "${m.type}" — conteúdo não suportado ainda]`;
        await receiveInbound(db, integ.organizationId, { channel: "whatsapp", from: { name: contact?.profile?.name ?? m.from ?? "Contato WhatsApp", phone: m.from }, body, externalId: m.id });
        received++;
      }
      if (received) await db.insert(integrationLogs).values({ organizationId: integ.organizationId, integrationId: integ.id, level: "info", message: `${received} mensagem(ns) recebida(s) via webhook.` });
    }
    if (received) kickOutbox(db);
  } catch (err) {
    log("error", "falha ao processar webhook", { err: (err as Error).message });
  }
  return NextResponse.json({ ok: true });
}
