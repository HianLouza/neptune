import { z } from "zod";
import { requireApiContext } from "@/server/auth/next";
import { handle, readJson, assertSameOrigin } from "@/server/http";
import { decideInsight, getInsight, markExecuted, measureOutcome } from "@/server/intelligence-layer/insights";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => getInsight(await requireApiContext("intelligence:read"), (await params).id));
}

const body = z.discriminatedUnion("action", [
  z.object({ action: z.literal("decide"), status: z.enum(["accepted", "rejected", "modified", "canceled"]), note: z.string().max(1000).optional() }),
  z.object({ action: z.literal("execute"), note: z.string().max(1000).optional() }),
  z.object({ action: z.literal("measure") }),
]);

/** PATCH { action: "decide", status, note? } | { action: "execute", note? } | { action: "measure" } */
export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("intelligence:read");
    const id = (await params).id;
    const b = body.parse(await readJson(req));
    if (b.action === "decide") return decideInsight(ctx, id, { status: b.status, note: b.note });
    if (b.action === "execute") return markExecuted(ctx, id, b.note);
    return measureOutcome(ctx, id);
  });
}
