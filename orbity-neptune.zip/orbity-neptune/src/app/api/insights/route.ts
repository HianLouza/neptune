import { z } from "zod";
import { requireApiContext } from "@/server/auth/next";
import { handle, assertSameOrigin } from "@/server/http";
import { listInsights, scanInsights } from "@/server/intelligence-layer/insights";
import { kickOutbox } from "@/server/events/handlers";

/** GET ?status=open,accepted — insights da Intelligence Layer (com evidência). */
export async function GET(req: Request) {
  return handle(async () => {
    const ctx = await requireApiContext("intelligence:read");
    const raw = new URL(req.url).searchParams.get("status");
    const status = raw ? z.array(z.enum(["open", "accepted", "modified", "rejected", "executed", "canceled", "expired"])).parse(raw.split(",")) : undefined;
    return listInsights(ctx, { status });
  });
}

/** POST — executa a varredura de regras agora (upsert sem duplicar, expira condições resolvidas). */
export async function POST() {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("intelligence:read");
    const r = await scanInsights(ctx);
    kickOutbox(ctx.db);
    return r;
  });
}
