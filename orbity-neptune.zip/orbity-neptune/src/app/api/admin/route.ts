import { z } from "zod";
import { requireApiContext } from "@/server/auth/next";
import { createTeam, saveRole, setTeamMember, updateMembership, updateOrgSettings, orgSettingsInput } from "@/server/domains/admin";
import { eraseDataSubject, findDataSubject } from "@/server/domains/data-intelligence";
import { handle, readJson, assertSameOrigin, HttpError } from "@/server/http";

const schema = z.discriminatedUnion("action", [
  z.object({ action: z.literal("membership"), membershipId: z.string().uuid(), status: z.enum(["active", "disabled"]).optional(), roleId: z.string().uuid().optional() }),
  z.object({ action: z.literal("create_team"), name: z.string() }),
  z.object({ action: z.literal("team_member"), teamId: z.string().uuid(), userId: z.string().uuid(), add: z.boolean() }),
  z.object({ action: z.literal("save_role"), roleId: z.string().uuid().optional(), name: z.string(), permissions: z.array(z.string()) }),
  z.object({ action: z.literal("org_settings") }).merge(orgSettingsInput),
  z.object({ action: z.literal("lgpd_lookup"), email: z.string().email() }),
  z.object({ action: z.literal("lgpd_erase"), email: z.string().email(), confirm: z.literal("EXCLUIR", { message: 'Digite "EXCLUIR" para confirmar.' }) }),
]);

export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("admin:users");
    const b = schema.parse(await readJson(req));
    switch (b.action) {
      case "membership": return updateMembership(ctx, b.membershipId, { status: b.status, roleId: b.roleId });
      case "create_team": return createTeam(ctx, b.name);
      case "team_member": return setTeamMember(ctx, b.teamId, b.userId, b.add);
      case "save_role": return saveRole(ctx, b);
      case "org_settings": { const { action: _a, ...rest } = b; return updateOrgSettings(ctx, rest); }
      case "lgpd_lookup": {
        const r = await findDataSubject(ctx, b.email);
        if (!r) throw new HttpError(404, "Nenhum titular encontrado com este e-mail.");
        return { name: r.contact.name, email: r.contact.email, phone: r.contact.phone, legalBasis: r.contact.legalBasis, consentStatus: r.contact.consentStatus, conversations: r.conversations };
      }
      case "lgpd_erase": return eraseDataSubject(ctx, b.email);
    }
  });
}
