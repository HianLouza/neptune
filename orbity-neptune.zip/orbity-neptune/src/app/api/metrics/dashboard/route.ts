import { requireApiContext } from "@/server/auth/next";
import { dashboardBundle } from "@/server/domains/metrics";
import { strictFiltersFromUrl } from "@/server/domains/metrics/http";
import { handle } from "@/server/http";

export const dynamic = "force-dynamic";

/** GET ?periodo=&de=&ate=&comparar=&vendedor=&equipe=&campanha=&origem=&etapa= — dados do dashboard interativo. */
export async function GET(req: Request) {
  return handle(async () => {
    const ctx = await requireApiContext("intelligence:read");
    return dashboardBundle(ctx, strictFiltersFromUrl(new URL(req.url).searchParams));
  });
}
