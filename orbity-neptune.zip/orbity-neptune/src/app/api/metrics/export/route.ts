import { NextResponse } from "next/server";
import { ZodError } from "zod";
import { requireApiContext } from "@/server/auth/next";
import { audit } from "@/server/audit";
import { buildMetricsCsv } from "@/server/domains/metrics/export";
import { strictFiltersFromUrl } from "@/server/domains/metrics/http";

export const dynamic = "force-dynamic";

/**
 * GET ?tipo=resumo|serie|segmentacao|registros (+ dimensao, metrica, inicio, fim, janela) + filtros globais → CSV do resultado filtrado.
 * Exportação de REGISTROS exige também `export:data`. Toda exportação é auditada.
 */
export async function GET(req: Request) {
  try {
    const ctx = await requireApiContext("intelligence:read");
    const sp = new URL(req.url).searchParams;
    const f = strictFiltersFromUrl(sp);
    const out = await buildMetricsCsv(ctx, f, sp);
    await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "metrics.exported_csv", resource: "metrics", metadata: { tipo: out.kind, filtros: f, dimensao: sp.get("dimensao"), metrica: sp.get("metrica") }, ip: ctx.ip });
    return new NextResponse(out.csv, {
      headers: { "content-type": "text/csv; charset=utf-8", "content-disposition": `attachment; filename="orbity-${out.name}-${new Date().toISOString().slice(0, 10)}.csv"`, "cache-control": "no-store" },
    });
  } catch (e) {
    if (e instanceof ZodError) return NextResponse.json({ ok: false, error: "Filtros inválidos.", issues: e.issues.map((i) => ({ path: i.path.join("."), message: i.message })) }, { status: 400 });
    const status = (e as { status?: number }).status ?? 500;
    return NextResponse.json({ ok: false, error: status === 500 ? "Erro ao exportar." : (e as Error).message }, { status });
  }
}
