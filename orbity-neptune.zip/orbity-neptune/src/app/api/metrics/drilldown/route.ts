import { requireApiContext } from "@/server/auth/next";
import { metricsDrilldown } from "@/server/domains/metrics";
import { drillRequestFromUrl, strictFiltersFromUrl } from "@/server/domains/metrics/http";
import { handle } from "@/server/http";

export const dynamic = "force-dynamic";

/**
 * GET ?metrica=leads|opportunities|won|lost|closed|revenue|open_pipeline&inicio=&fim=&janela=current|previous&limite=&deslocamento=
 * + filtros globais. Retorna os registros que compõem o indicador (exige permissão de CRM/Prospect além de intelligence:read).
 */
export async function GET(req: Request) {
  return handle(async () => {
    const ctx = await requireApiContext("intelligence:read");
    const sp = new URL(req.url).searchParams;
    return metricsDrilldown(ctx, strictFiltersFromUrl(sp), drillRequestFromUrl(sp));
  });
}
