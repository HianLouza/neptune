import { NextResponse } from "next/server";
import { requireApiContext } from "@/server/auth/next";
import { exportOrganizationData } from "@/server/domains/data-intelligence";

export const dynamic = "force-dynamic";

/** Portabilidade (LGPD): exportação completa dos dados da organização em JSON. */
export async function GET() {
  try {
    const ctx = await requireApiContext("export:data");
    const data = await exportOrganizationData(ctx);
    return new NextResponse(JSON.stringify(data, null, 2), {
      headers: { "content-type": "application/json; charset=utf-8", "content-disposition": `attachment; filename="orbity-export-${new Date().toISOString().slice(0, 10)}.json"`, "cache-control": "no-store" },
    });
  } catch (e) {
    const status = (e as { status?: number }).status ?? 500;
    return NextResponse.json({ ok: false, error: status === 500 ? "Erro ao exportar." : (e as Error).message }, { status });
  }
}
