import { z } from "zod";
import { requireApiContext } from "@/server/auth/next";
import {
  requirePlatform, setOrganizationStatus, saveFlag, setFlagOverride, createExperiment, setExperimentStatus, createIncident, patchIncident, createCoupon,
} from "@/server/domains/platform";
import { handle, readJson, assertSameOrigin } from "@/server/http";

const schema = z.discriminatedUnion("action", [
  z.object({ action: z.literal("org_status"), organizationId: z.string().uuid(), status: z.enum(["active", "suspended"]) }),
  z.object({ action: z.literal("save_flag"), flag: z.record(z.string(), z.unknown()) }),
  z.object({ action: z.literal("flag_override"), flagKey: z.string().max(60), organizationId: z.string().uuid(), enabled: z.boolean().nullable() }),
  z.object({ action: z.literal("create_experiment"), experiment: z.record(z.string(), z.unknown()) }),
  z.object({ action: z.literal("experiment_status"), id: z.string().uuid(), status: z.enum(["running", "stopped", "concluded"]), conclusion: z.string().max(1000).optional() }),
  z.object({ action: z.literal("create_incident"), incident: z.record(z.string(), z.unknown()) }),
  z.object({ action: z.literal("update_incident"), id: z.string().uuid(), patch: z.record(z.string(), z.unknown()) }),
  z.object({ action: z.literal("create_coupon"), coupon: z.record(z.string(), z.unknown()) }),
]);

/** Ações do painel global. Toda rota verifica isPlatformAdmin no servidor e audita a mutação. */
export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext();
    requirePlatform(ctx);
    const b = schema.parse(await readJson(req));
    switch (b.action) {
      case "org_status": return setOrganizationStatus(ctx, b.organizationId, b.status);
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      case "save_flag": return saveFlag(ctx, b.flag as any);
      case "flag_override": return setFlagOverride(ctx, b.flagKey, b.organizationId, b.enabled);
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      case "create_experiment": return createExperiment(ctx, b.experiment as any);
      case "experiment_status": return setExperimentStatus(ctx, b.id, b.status, b.conclusion);
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      case "create_incident": return createIncident(ctx, b.incident as any);
      case "update_incident": return patchIncident(ctx, b.id, b.patch as Record<string, string>);
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      case "create_coupon": return createCoupon(ctx, b.coupon as any);
    }
  });
}
