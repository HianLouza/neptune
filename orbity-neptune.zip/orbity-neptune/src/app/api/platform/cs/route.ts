import { z } from "zod";
import { requireApiContext } from "@/server/auth/next";
import { requirePlatform, csLogInteraction, saveHealthConfig } from "@/server/domains/platform";
import { handle, readJson, assertSameOrigin } from "@/server/http";

/** POST { action: "interaction", organizationId, type, note } | { action: "config", weights, thresholds } */
export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext();
    requirePlatform(ctx);
    const b = z.object({ action: z.enum(["interaction", "config"]) }).passthrough().parse(await readJson(req));
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    return b.action === "interaction" ? csLogInteraction(ctx, b as any) : saveHealthConfig(ctx, b as any);
  });
}
