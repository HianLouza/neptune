import { requireApiContext } from "@/server/auth/next";
import { handle, readJson, assertSameOrigin } from "@/server/http";
import { createDecision, listDecisions } from "@/server/intelligence-layer/decisions";

export async function GET() {
  return handle(async () => listDecisions(await requireApiContext("intelligence:read")));
}

/** POST { title, problem, alternatives?, insightId?, scenarioId?, reviewAt? } */
export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("intelligence:read");
    return createDecision(ctx, await readJson(req));
  }, { status: 201 });
}
