import { requireApiContext } from "@/server/auth/next";
import { handle, readJson, assertSameOrigin } from "@/server/http";
import { getDecision, transitionDecision } from "@/server/intelligence-layer/decisions";
import { kickOutbox } from "@/server/events/handlers";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => getDecision(await requireApiContext("intelligence:read"), (await params).id));
}

/** PATCH { action: "edit" | "submit" | "approve" | "reject" | "monitor" | "close", ... } */
export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("intelligence:read");
    const r = await transitionDecision(ctx, (await params).id, await readJson(req));
    kickOutbox(ctx.db);
    return r;
  });
}
