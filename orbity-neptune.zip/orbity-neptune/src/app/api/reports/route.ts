import { NextResponse } from "next/server";
import { requireApiContext } from "@/server/auth/next";
import { buildReport, reportQuery, reportToCsv } from "@/server/domains/reporting";
import { runAgent } from "@/server/ai/orchestrator";
import { audit } from "@/server/audit";
import { recordUsage } from "@/server/domains/billing";
import { handle, readJson, assertSameOrigin } from "@/server/http";

/** GET ?type=&days=&format=json|csv — gera o relatório; CSV para download. */
export async function GET(req: Request) {
  const sp = new URL(req.url).searchParams;
  if (sp.get("format") === "csv") {
    try {
      const ctx = await requireApiContext("intelligence:read");
      const q = reportQuery.parse({ type: sp.get("type") ?? undefined, days: sp.get("days") ?? undefined });
      const r = await buildReport(ctx, q.type, q.days);
      await audit(ctx.db, { organizationId: ctx.organizationId, actorId: ctx.userId, action: "report.exported_csv", resource: "report", metadata: { type: q.type, days: q.days } });
      return new NextResponse(reportToCsv(r), {
        headers: { "content-type": "text/csv; charset=utf-8", "content-disposition": `attachment; filename="relatorio-${q.type}-${q.days}d.csv"` },
      });
    } catch (e) {
      const status = (e as { status?: number }).status ?? 400;
      return NextResponse.json({ ok: false, error: (e as Error).message }, { status });
    }
  }
  return handle(async () => {
    const ctx = await requireApiContext("intelligence:read");
    const q = reportQuery.parse({ type: sp.get("type") ?? undefined, days: sp.get("days") ?? undefined });
    return buildReport(ctx, q.type, q.days);
  });
}

/** POST { type, days } — resumo executivo do relatório gerado pelo agente de Relatórios. */
export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("ai:use");
    const q = reportQuery.parse(await readJson(req));
    const r = await buildReport(ctx, q.type, q.days);
    await recordUsage(ctx.db, ctx.organizationId, "reports", 1);
    return runAgent(ctx, {
      agentKey: "reporting",
      input: `Escreva um resumo gerencial do "${r.title}" em até 6 tópicos, destacando variações relevantes, riscos e próximos passos. Use apenas os dados fornecidos.`,
      context: r.context,
    });
  });
}
