import { z } from "zod";
import { requireApiContext } from "@/server/auth/next";
import { naturalLanguageQuery } from "@/server/domains/intelligence";
import { handle, readJson, assertSameOrigin } from "@/server/http";

/** POST { q } — consulta em linguagem natural mapeada para métricas conhecidas (sem SQL gerado por IA). */
export async function POST(req: Request) {
  return handle(async () => {
    await assertSameOrigin();
    const ctx = await requireApiContext("intelligence:read");
    const { q } = z.object({ q: z.string().trim().min(2).max(500) }).parse(await readJson(req));
    return naturalLanguageQuery(ctx, q);
  });
}
