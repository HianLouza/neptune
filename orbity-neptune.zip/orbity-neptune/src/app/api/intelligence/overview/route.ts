import { requireApiContext } from "@/server/auth/next";
import { dashboardKpis, funnelAnalysis, leadOrigins, recommendations, revenueForecast, sellerPerformance } from "@/server/domains/intelligence";
import { handle } from "@/server/http";

/** GET ?days=30 — visão consolidada do Sales Intelligence (para integrações/BI). */
export async function GET(req: Request) {
  return handle(async () => {
    const ctx = await requireApiContext("intelligence:read");
    const d = Number(new URL(req.url).searchParams.get("days") ?? 30);
    const days = [7, 30, 90].includes(d) ? d : 30;
    const [kpis, funnel, sellers, origins, forecast, recs] = await Promise.all([
      dashboardKpis(ctx, days), funnelAnalysis(ctx), sellerPerformance(ctx, days), leadOrigins(ctx, days), revenueForecast(ctx), recommendations(ctx),
    ]);
    return { days, kpis, funnel, sellers, origins, forecast, recommendations: recs };
  });
}
