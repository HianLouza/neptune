"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { api } from "@/lib/api-client";
import { Button, Field, Input, Select } from "@/components/ui";

const OBJECTIVES = ["Gerar mais leads", "Aumentar conversão", "Responder mais rápido", "Automatizar follow-up", "Prever receita", "Organizar o funil"];
const SEGMENTS = ["Tecnologia", "Consultoria", "Agência", "Distribuidor", "Serviços", "Saúde", "Educação", "Indústria", "Outro"];

export default function Onboarding() {
  const router = useRouter();
  const [step, setStep] = useState(0);
  const [f, setF] = useState({ name: "", segment: "Tecnologia", size: "2-10", products: "", objectives: [] as string[], salesProcess: "consultiva", targetSegments: "", targetRegions: "" });
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const list = (s: string) => s.split(",").map((x) => x.trim()).filter(Boolean);

  const finish = async () => {
    setLoading(true); setError(null);
    try {
      await api("/api/onboarding", { body: { ...f, products: list(f.products), targetSegments: list(f.targetSegments), targetRegions: list(f.targetRegions), timezone: Intl.DateTimeFormat().resolvedOptions().timeZone } });
      router.push("/dashboard");
    } catch (e) { setError((e as Error).message); } finally { setLoading(false); }
  };

  const steps = [
    <div key="0" className="space-y-4">
      <Field label="Nome da empresa"><Input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></Field>
      <Field label="Segmento"><Select value={f.segment} onChange={(e) => setF({ ...f, segment: e.target.value })}>{SEGMENTS.map((s) => <option key={s}>{s}</option>)}</Select></Field>
      <Field label="Tamanho da equipe"><Select value={f.size} onChange={(e) => setF({ ...f, size: e.target.value })}>{["2-10", "11-30", "31-100", "100+"].map((s) => <option key={s}>{s}</option>)}</Select></Field>
    </div>,
    <div key="1" className="space-y-4">
      <Field label="Produtos e serviços" hint="Separe por vírgula"><Input value={f.products} onChange={(e) => setF({ ...f, products: e.target.value })} placeholder="Consultoria, Implantação, Suporte" /></Field>
      <Field label="Processo comercial"><Select value={f.salesProcess} onChange={(e) => setF({ ...f, salesProcess: e.target.value })}><option value="consultiva">Venda consultiva</option><option value="transacional">Transacional</option><option value="mista">Mista</option></Select></Field>
      <div>
        <p className="mb-2 text-xs font-medium text-muted">Objetivos</p>
        <div className="flex flex-wrap gap-2">{OBJECTIVES.map((o) => {
          const on = f.objectives.includes(o);
          return <button type="button" key={o} onClick={() => setF({ ...f, objectives: on ? f.objectives.filter((x) => x !== o) : [...f.objectives, o] })} className={`rounded-full border px-3 py-1 text-xs ${on ? "border-primary-2 bg-primary/20 text-primary-2" : "border-line text-muted"}`}>{o}</button>;
        })}</div>
      </div>
    </div>,
    <div key="2" className="space-y-4">
      <p className="text-sm text-muted">Defina seu cliente ideal (ICP). O Prospect.AI usará estes critérios para pontuar leads — você poderá refinar depois.</p>
      <Field label="Segmentos-alvo" hint="Separe por vírgula"><Input value={f.targetSegments} onChange={(e) => setF({ ...f, targetSegments: e.target.value })} placeholder="Tecnologia, Saúde" /></Field>
      <Field label="Regiões/UF-alvo" hint="Separe por vírgula"><Input value={f.targetRegions} onChange={(e) => setF({ ...f, targetRegions: e.target.value })} placeholder="SP, RJ, MG" /></Field>
      <p className="text-xs text-muted">Próximos passos após concluir: importar leads (CSV), conectar WhatsApp/e-mail e convidar sua equipe.</p>
    </div>,
  ];
  const titles = ["Sua empresa", "Oferta e objetivos", "Cliente ideal"];

  return (
    <div>
      <p className="text-xs text-muted">Etapa {step + 1} de {steps.length}</p>
      <h1 className="mt-1 text-2xl font-bold">{titles[step]}</h1>
      <div className="mt-2 flex gap-1">{steps.map((_, i) => <span key={i} className={`h-1 flex-1 rounded-full ${i <= step ? "bg-primary-2" : "bg-surface-2"}`} />)}</div>
      <div className="mt-6">{steps[step]}</div>
      {error && <p role="alert" className="mt-3 text-sm text-danger">{error}</p>}
      <div className="mt-6 flex justify-between">
        <Button variant="ghost" disabled={step === 0} onClick={() => setStep(step - 1)}>Voltar</Button>
        {step < steps.length - 1 ? <Button onClick={() => setStep(step + 1)} disabled={step === 0 && f.name.trim().length < 2}>Continuar</Button>
          : <Button onClick={finish} disabled={loading}>{loading ? "Salvando..." : "Concluir"}</Button>}
      </div>
    </div>
  );
}
