"use client";
import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { api } from "@/lib/api-client";
import { Button, Field, Input } from "@/components/ui";
import { OAuthButtons } from "../oauth-buttons";

export default function LoginPage() {
  const router = useRouter();
  const [step, setStep] = useState<"credentials" | "2fa">("credentials");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [code, setCode] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true); setError(null);
    try {
      if (step === "credentials") {
        const r = await api<{ requires2fa: boolean; hasOrganization: boolean }>("/api/auth/login", { body: { email, password } });
        if (r.requires2fa) { setStep("2fa"); return; }
        router.push(r.hasOrganization ? "/" : "/cadastro?pendente=1");
      } else {
        await api("/api/auth/2fa", { body: { action: "verify", code } });
        router.push("/");
      }
    } catch (err) { setError((err as Error).message); } finally { setLoading(false); }
  };

  return (
    <div>
      <h1 className="text-2xl font-bold">{step === "credentials" ? "Entrar" : "Verificação em duas etapas"}</h1>
      <p className="mt-1 text-sm text-muted">{step === "credentials" ? "Acesse sua conta ORBITY-NEPTUNE." : "Digite o código de 6 dígitos do seu aplicativo autenticador."}</p>
      <form onSubmit={submit} className="mt-6 space-y-4">
        {step === "credentials" ? (
          <>
            <Field label="E-mail"><Input type="email" autoComplete="email" required value={email} onChange={(e) => setEmail(e.target.value)} /></Field>
            <Field label="Senha"><Input type="password" autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)} /></Field>
          </>
        ) : (
          <Field label="Código"><Input inputMode="numeric" pattern="\d{6}" maxLength={6} autoFocus required value={code} onChange={(e) => setCode(e.target.value)} /></Field>
        )}
        {error && <p role="alert" className="text-sm text-danger">{error}</p>}
        <Button type="submit" disabled={loading} className="w-full">{loading ? "Entrando..." : step === "credentials" ? "Entrar" : "Verificar"}</Button>
      </form>
      {step === "credentials" && (
        <>
          <OAuthButtons />
          <p className="mt-6 text-center text-sm text-muted">Não tem conta? <Link href="/cadastro" className="text-primary-2 hover:underline">Teste grátis por 7 dias</Link></p>
        </>
      )}
    </div>
  );
}
