import { Logo } from "@/components/layout/logo";

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <div className="hidden flex-col justify-between border-r border-line bg-bg-2/60 p-12 lg:flex">
        <Logo />
        <div>
          <p className="text-4xl font-extrabold leading-tight">Seu ecossistema de<br /><span className="bg-gradient-to-r from-accent to-primary-2 bg-clip-text text-transparent">inteligência comercial</span>.</p>
          <p className="mt-4 max-w-md text-muted">Encontrar → Qualificar → Atender → Converter → Analisar → Recomendar → Evoluir.</p>
        </div>
        <p className="text-xs tracking-[0.3em] text-muted">INTELLIGENCE. AUTOMATION. GROWTH.</p>
      </div>
      <div className="flex items-center justify-center p-6">
        <div className="w-full max-w-md">
          <div className="mb-8 lg:hidden"><Logo /></div>
          {children}
        </div>
      </div>
    </div>
  );
}
