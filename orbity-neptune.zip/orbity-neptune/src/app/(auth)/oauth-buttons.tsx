"use client";
import { useState } from "react";

// Login social: só funciona com credenciais OAuth configuradas (variáveis GOOGLE_ e MICROSOFT_). Sem elas, o usuário é avisado.
export function OAuthButtons() {
  const [msg, setMsg] = useState<string | null>(null);
  const go = async (provider: "google" | "microsoft") => {
    const r = await fetch(`/api/auth/oauth/${provider}`, { redirect: "manual" });
    if (r.type === "opaqueredirect" || r.status === 0 || r.status === 307 || r.status === 302) { window.location.href = `/api/auth/oauth/${provider}`; return; }
    const j = await r.json().catch(() => ({}));
    setMsg(j.error ?? "Provedor indisponível.");
  };
  return (
    <div className="mt-6">
      <div className="flex items-center gap-3 text-xs text-muted"><span className="h-px flex-1 bg-line" />ou continue com<span className="h-px flex-1 bg-line" /></div>
      <div className="mt-4 grid grid-cols-2 gap-3">
        <button type="button" onClick={() => go("google")} className="rounded-lg border border-line bg-surface-2 py-2 text-sm hover:border-primary-2">Google</button>
        <button type="button" onClick={() => go("microsoft")} className="rounded-lg border border-line bg-surface-2 py-2 text-sm hover:border-primary-2">Microsoft</button>
      </div>
      {msg && <p className="mt-2 text-xs text-warning">{msg}</p>}
    </div>
  );
}
