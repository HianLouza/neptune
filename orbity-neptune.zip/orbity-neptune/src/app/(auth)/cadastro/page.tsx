"use client";
import { Suspense, useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { api } from "@/lib/api-client";
import { Button, Field, Input } from "@/components/ui";
import { OAuthButtons } from "../oauth-buttons";

function Cadastro() {
  const router = useRouter();
  const sp = useSearchParams();
  const invite = sp.get("convite") ?? undefined;
  const pending = sp.get("pendente");
  const [f, setF] = useState({ name: "", email: "", password: "", organizationName: "" });
  const [accept, setAccept] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [waiting, setWaiting] = useState(!!pending);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setLoading(true); setError(null);
    try {
      const r = await api<{ pendingApproval: boolean }>("/api/auth/register", { body: { ...f, inviteOrgSlug: invite, acceptTerms: accept } });
      if (r.pendingApproval) setWaiting(true); else router.push("/onboarding");
    } catch (err) { setError((err as Error).message); } finally { setLoading(false); }
  };

  if (waiting) return (
    <div>
      <h1 className="text-2xl font-bold">Aguardando aprovação</h1>
      <p className="mt-2 text-sm text-muted">Seu cadastro foi registrado. Um administrador da organização precisa aprovar seu acesso. Você receberá acesso assim que for aprovado.</p>
      <Link href="/login" className="mt-6 inline-block text-primary-2 hover:underline">Voltar ao login</Link>
    </div>
  );

  return (
    <div>
      <h1 className="text-2xl font-bold">{invite ? "Solicitar acesso à organização" : "Comece seu teste de 7 dias"}</h1>
      <p className="mt-1 text-sm text-muted">Sem cartão de crédito. Prospect.AI, Closer.AI e Sales Intelligence incluídos.</p>
      <form onSubmit={submit} className="mt-6 space-y-4">
        <Field label="Seu nome"><Input required minLength={2} value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></Field>
        <Field label="E-mail profissional"><Input type="email" required value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></Field>
        <Field label="Senha" hint="Mínimo de 10 caracteres, com letras e números."><Input type="password" required minLength={10} autoComplete="new-password" value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} /></Field>
        {!invite && <Field label="Nome da empresa"><Input required value={f.organizationName} onChange={(e) => setF({ ...f, organizationName: e.target.value })} /></Field>}
        <label className="flex items-start gap-2 text-xs text-muted">
          <input type="checkbox" checked={accept} onChange={(e) => setAccept(e.target.checked)} className="mt-0.5" />
          <span>Li e aceito os Termos de Uso e a Política de Privacidade (LGPD). Meus dados serão usados para prestação do serviço.</span>
        </label>
        {error && <p role="alert" className="text-sm text-danger">{error}</p>}
        <Button type="submit" disabled={loading || !accept} className="w-full">{loading ? "Criando..." : "Criar conta"}</Button>
      </form>
      <OAuthButtons />
      <p className="mt-6 text-center text-sm text-muted">Já tem conta? <Link href="/login" className="text-primary-2 hover:underline">Entrar</Link></p>
    </div>
  );
}

export default function Page() { return <Suspense><Cadastro /></Suspense>; }
