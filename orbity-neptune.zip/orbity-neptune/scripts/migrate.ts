try { process.loadEnvFile(".env"); } catch { /* opcional */ }
import { createDb } from "../src/server/db/client";
import { runMigrations } from "../src/server/db/migrate";
import { seedCore } from "../src/server/db/seed-core";

(async () => {
  const { db, close } = await createDb();
  await runMigrations(db);
  await seedCore(db);
  console.log("Migrações aplicadas.");
  await close();
})().catch((e) => { console.error(e); process.exit(1); });
