/**
 * Seed incremental do Master Prompt 4.0 (ciclo 1) para bancos de DESENVOLVIMENTO já existentes.
 * Aplica as migrações novas e carrega dados financeiros de demonstração na organização de demonstração
 * (slug minha-empresa-demo) somente se ela ainda não tiver lançamentos.
 *
 * Atenção: com PGlite (sem DATABASE_URL), PARE o servidor de desenvolvimento antes de rodar —
 * dois processos abrindo a mesma pasta de dados podem corromper o banco. Com o servidor ligado,
 * use o botão "Carregar dados financeiros de demonstração" na tela Financeiro.
 */
try { process.loadEnvFile(".env"); } catch { /* opcional */ }
import { eq } from "drizzle-orm";
import { createDb } from "../src/server/db/client";
import { runMigrations } from "../src/server/db/migrate";
import { organizations } from "../src/server/db/schema";
import { seedDemoFinance } from "../src/server/domains/finance/demo";

if (process.env.APP_ENV === "production") { console.error("Seed de demonstração bloqueado em produção."); process.exit(1); }

async function main() {
  const { db, close } = await createDb();
  try {
    await runMigrations(db);
    const [org] = await db.select().from(organizations).where(eq(organizations.slug, "minha-empresa-demo"));
    if (!org) { console.log("Organização de demonstração não encontrada. Rode `npm run db:seed` primeiro."); return; }
    const r = await seedDemoFinance(db, org.id);
    console.log(r.skipped ? `Nada a fazer: ${r.skipped}` : `✅ ${r.created} lançamentos financeiros de demonstração criados em "${org.name}".`);
  } finally { await close(); }
}

main().catch((e) => { console.error(e); process.exit(1); });
