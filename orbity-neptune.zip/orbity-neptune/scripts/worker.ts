/**
 * Worker do Event Engine: processa o outbox continuamente (retry, backoff, DLQ).
 * Também executa a varredura proativa da Intelligence Layer (insights) de cada organização a cada 15 minutos.
 */
try { process.loadEnvFile(".env"); } catch { /* opcional */ }
import { createDb } from "../src/server/db/client";
import { runMigrations } from "../src/server/db/migrate";
import { processPending } from "../src/server/events";
import { registerAllHandlers } from "../src/server/events/handlers";
import { scanInsights } from "../src/server/intelligence-layer/insights";
import { activeOrganizationIds, systemContextFor } from "../src/server/intelligence-layer/system-context";

import { runAlertAutomation } from "../src/server/domains/task-alerts";

const INSIGHT_SCAN_EVERY_MS = 15 * 60_000;
const ALERT_TICK_EVERY_MS = 60_000; // alertas agendados, lembretes automáticos e escalonamento (Task Intelligence)

(async () => {
  const { db } = await createDb();
  await runMigrations(db);
  registerAllHandlers();
  console.log(JSON.stringify({ level: "info", msg: "worker iniciado" }));
  let lastScan = 0, lastAlertTick = 0;
  for (;;) {
    const s = await processPending(db, { limit: 100 });
    if (s.processed || s.failed || s.dead) console.log(JSON.stringify({ level: "info", msg: "outbox", ...s }));

    if (Date.now() - lastAlertTick >= ALERT_TICK_EVERY_MS) {
      lastAlertTick = Date.now();
      for (const orgId of await activeOrganizationIds(db)) {
        try {
          const r = await runAlertAutomation(db, orgId);
          if (r.dispatched || r.created || r.escalated || r.goalNotices) console.log(JSON.stringify({ level: "info", msg: "task-alerts", organizationId: orgId, ...r }));
        } catch (err) {
          console.error(JSON.stringify({ level: "error", msg: "task-alerts.automation", organizationId: orgId, err: String(err) }));
        }
      }
    }

    if (Date.now() - lastScan >= INSIGHT_SCAN_EVERY_MS) {
      lastScan = Date.now();
      for (const orgId of await activeOrganizationIds(db)) {
        try {
          const ctx = await systemContextFor(db, orgId);
          if (!ctx) continue;
          const r = await scanInsights(ctx);
          if (r.created || r.expired) console.log(JSON.stringify({ level: "info", msg: "insights", organizationId: orgId, ...r }));
        } catch (err) {
          console.error(JSON.stringify({ level: "error", msg: "insights.scan", organizationId: orgId, err: String(err) }));
        }
      }
    }
    await new Promise((r) => setTimeout(r, 2000));
  }
})().catch((e) => { console.error(e); process.exit(1); });
