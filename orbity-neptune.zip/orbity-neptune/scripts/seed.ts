/**
 * Seed de DESENVOLVIMENTO.
 * - Dados de referência (planos, flags, métricas).
 * - Admin global da plataforma.
 * - Organização de DEMONSTRAÇÃO (is_demo = true, banner visível na interface) espelhando o layout de referência.
 * Nunca execute em produção: o script aborta se APP_ENV=production.
 */
try { process.loadEnvFile(".env"); } catch { /* opcional */ }
import { eq } from "drizzle-orm";
import { createDb } from "../src/server/db/client";
import { runMigrations } from "../src/server/db/migrate";
import { seedCore } from "../src/server/db/seed-core";
import * as s from "../src/server/db/schema";
import { hashPassword } from "../src/server/auth/password";
import { provisionOrganization } from "../src/server/auth/service";
import { scoreLead } from "../src/server/domains/prospect";
import { addKnowledge } from "../src/server/domains/closer";
import { contextFor } from "../src/server/auth/service";
import { TEMPLATES } from "../src/server/workflows/templates";
import { embed } from "../src/server/ai/embeddings";
import { seedDemoFinance } from "../src/server/domains/finance/demo";

/** Credenciais de teste para ambiente LOCAL (documentadas no README). */
export const DEMO_PASSWORD = process.env.DEMO_PASSWORD || "Neptune2026demo";

if (process.env.APP_ENV === "production") { console.error("Seed de demonstração bloqueado em produção."); process.exit(1); }

let rnd = 42;
const rand = () => ((rnd = (rnd * 1103515245 + 12345) % 2 ** 31) / 2 ** 31);
const pick = <T,>(a: T[]) => a[Math.floor(rand() * a.length)];
const daysAgo = (d: number) => new Date(Date.now() - d * 864e5 - Math.floor(rand() * 864e5 * 0.9));
async function batch<T>(rows: T[], fn: (chunk: T[]) => Promise<unknown>, size = 400) { for (let i = 0; i < rows.length; i += size) await fn(rows.slice(i, i + size)); }

async function main() {
  const { db, close } = await createDb();
  await runMigrations(db);
  await seedCore(db);

  const [already] = await db.select().from(s.users).where(eq(s.users.email, "admin@orbity.local"));
  if (already) { console.log("Seed já aplicado. Use `npm run db:reset` para recriar."); await close(); return; }

  const pw = await hashPassword(DEMO_PASSWORD);
  const [admin] = await db.insert(s.users).values({ name: "Hian Admin", email: "admin@orbity.local", passwordHash: pw, isPlatformAdmin: true, jobTitle: "Administrador" }).returning();
  const org = await provisionOrganization(db, { name: "Minha Empresa", ownerId: admin.id, segment: "Tecnologia", size: "11-30", isDemo: true });
  await db.update(s.organizations).set({ onboardingCompleted: true, slug: "minha-empresa-demo" }).where(eq(s.organizations.id, org.id));

  // Assinatura ativa no plano Business para a demonstração.
  const [business] = await db.select().from(s.plans).where(eq(s.plans.key, "business"));
  await db.update(s.subscriptions).set({ planId: business.id, status: "active", trialEndsAt: null }).where(eq(s.subscriptions.organizationId, org.id));
  await db.update(s.creditWallets).set({ balance: 96000, monthlyAllowance: 300000, usedThisPeriod: 204000 }).where(eq(s.creditWallets.organizationId, org.id));

  // Vendedores (12 ativos)
  const names = ["Ana Souza", "Bruno Lima", "Carla Mendes", "Diego Rocha", "Elisa Prado", "Felipe Araújo", "Gabriela Nunes", "Henrique Dias", "Isabela Costa", "João Pereira", "Karina Alves"];
  const [memberRole] = await db.select().from(s.roles).where(eq(s.roles.organizationId, org.id)).then((r) => r.filter((x) => x.key === "member"));
  const sellers = [admin];
  for (const n of names) {
    const [u] = await db.insert(s.users).values({ name: n, email: `${n.split(" ")[0].toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "")}@minhaempresa.demo`, passwordHash: pw, jobTitle: "Executivo(a) de Vendas" }).returning();
    await db.insert(s.memberships).values({ organizationId: org.id, userId: u.id, roleId: memberRole.id, status: "active" });
    sellers.push(u);
  }
  const [team] = await db.insert(s.teams).values({ organizationId: org.id, name: "Time Comercial" }).returning();
  await db.insert(s.teamMembers).values(sellers.map((u) => ({ teamId: team.id, userId: u.id })));

  // ICP
  const icpCriteria = { segments: ["Tecnologia", "Consultoria", "Saúde", "Logística", "Educação"], regions: ["SP", "RJ", "MG", "PR"], sizes: [], minEmployees: 10, maxEmployees: 500, technologies: ["HubSpot", "Google Workspace"], needs: ["Aumentar conversão", "Automatizar follow-up"] };
  await db.insert(s.icpProfiles).values({ organizationId: org.id, name: "ICP Principal B2B", criteria: icpCriteria });

  // Empresas
  const segs = ["Tecnologia", "Consultoria", "Saúde", "Logística", "Educação", "Varejo", "Indústria", "Agronegócio"];
  const regions = ["SP", "RJ", "MG", "PR", "RS", "BA", "SC", "GO"];
  const prefixes = ["Alfa", "Beta", "Orion", "Vega", "Nova", "Prime", "Atlas", "Delta", "Sigma", "Lumen", "Terra", "Polo", "Ápice", "Vértice", "Zênite"];
  const suffixes = ["Tech", "Soluções", "Consultoria", "Logística", "Saúde", "Digital", "Group", "Serviços", "Distribuidora", "Educação"];
  const companyRows = [] as (typeof s.companies.$inferInsert)[];
  const featured = ["Grupo Alfa", "TechSolutions", "Construtora Rio", "Moveis Prime", "Logística Sul", "Clínica Vida", "FastDistribuidora", "AgroMax", "Hotel Central", "Indústria Beta", "Comercial Líder", "EducaMais", "Rede Saúde", "Grupo Orion", "Varejo Total"];
  const used = new Set<string>();
  for (const f of featured) { used.add(f); companyRows.push({ organizationId: org.id, name: f, normalizedName: f.toLowerCase().replace(/[^a-z0-9]/g, ""), segment: pick(segs), region: pick(regions), employees: 20 + Math.floor(rand() * 300), technologies: rand() > 0.5 ? ["HubSpot"] : [], source: "seed_demo" }); }
  while (companyRows.length < 1200) {
    const n = `${pick(prefixes)} ${pick(suffixes)} ${Math.floor(rand() * 900 + 100)}`;
    if (used.has(n)) continue; used.add(n);
    companyRows.push({ organizationId: org.id, name: n, normalizedName: n.toLowerCase().replace(/[^a-z0-9]/g, ""), segment: pick(segs), region: pick(regions), employees: 2 + Math.floor(rand() * 600), technologies: rand() > 0.6 ? ["Google Workspace"] : [], source: "seed_demo" });
  }
  const comps: (typeof s.companies.$inferSelect)[] = [];
  await batch(companyRows, async (c) => { comps.push(...(await db.insert(s.companies).values(c).returning())); });

  // Leads: 4.892 no período atual, 3.706 no anterior; origens 42/18/14/12/14.
  const sources = [...Array(42).fill("prospect_ai"), ...Array(18).fill("website"), ...Array(14).fill("whatsapp"), ...Array(12).fill("referral"), ...Array(7).fill("import"), ...Array(7).fill("manual")];
  const leadRows = [] as (typeof s.leads.$inferInsert)[];
  const mkLead = (createdAt: Date) => {
    const c = pick(comps), src = pick(sources);
    const { score, explanation } = scoreLead(icpCriteria, { segment: c.segment, region: c.region, employees: c.employees, technologies: c.technologies, hasEmail: rand() > 0.3, hasPhone: rand() > 0.5, source: src });
    return { organizationId: org.id, companyId: c.id, title: c.name, source: src, score: Math.min(score, 79), scoreExplanation: explanation, status: pick(["new", "new", "qualifying", "qualified"]), ownerId: pick(sellers).id, createdAt, updatedAt: createdAt };
  };
  // Crescimento ao longo do mês para a curva do gráfico.
  for (let i = 0; i < 4892; i++) leadRows.push(mkLead(daysAgo(Math.floor(Math.pow(rand(), 0.8) * 30))));
  for (let i = 0; i < 3706; i++) leadRows.push(mkLead(daysAgo(30 + Math.floor(rand() * 30))));
  const hot = leadRows.slice(0, 5);
  hot.forEach((l) => { l.score = 82 + Math.floor(rand() * 15); l.status = "qualified"; });
  await batch(leadRows, (c) => db.insert(s.leads).values(c));

  // Funil
  const stages = await db.select().from(s.pipelineStages).where(eq(s.pipelineStages.organizationId, org.id));
  const st = (n: string) => stages.find((x) => x.name === n)!;
  const [pipe] = await db.select().from(s.pipelines).where(eq(s.pipelines.organizationId, org.id));
  const oppRows = [] as (typeof s.opportunities.$inferInsert)[];
  const feat: Record<string, [string, number][]> = {
    "Novos Leads": [["Grupo Alfa", 75000], ["TechSolutions", 42000], ["Construtora Rio", 120000]],
    "Qualificação": [["Moveis Prime", 56000], ["Logística Sul", 38000], ["Clínica Vida", 24000]],
    "Proposta": [["FastDistribuidora", 98000], ["AgroMax", 150000], ["Hotel Central", 62000]],
    "Negociação": [["Indústria Beta", 210000], ["Comercial Líder", 86000], ["EducaMais", 54000]],
    "Fechamento": [["Rede Saúde", 320000], ["Grupo Orion", 180000], ["Varejo Total", 95000]],
  };
  const counts: Record<string, number> = { "Novos Leads": 482, "Qualificação": 308, "Proposta": 274, "Negociação": 187, "Fechamento": 177 };
  for (const [stageName, n] of Object.entries(counts)) {
    for (const [cn, amount] of feat[stageName]) {
      const c = comps.find((x) => x.name === cn)!;
      oppRows.push({ organizationId: org.id, pipelineId: pipe.id, stageId: st(stageName).id, companyId: c.id, title: cn, amountCents: amount * 100, ownerId: pick(sellers).id, source: pick(sources), createdAt: daysAgo(Math.floor(rand() * 25)), lastActivityAt: daysAgo(Math.floor(rand() * 3)) });
    }
    for (let i = 3; i < n; i++) {
      const c = pick(comps);
      oppRows.push({ organizationId: org.id, pipelineId: pipe.id, stageId: st(stageName).id, companyId: c.id, title: c.name, amountCents: Math.round((8000 + rand() * 40000)) * 100, ownerId: pick(sellers).id, source: pick(sources), createdAt: daysAgo(Math.floor(rand() * 29)), lastActivityAt: daysAgo(Math.floor(rand() * 4)) });
    }
  }
  // 3 oportunidades paradas (risco de perda)
  oppRows.slice(20, 23).forEach((o) => { o.lastActivityAt = daysAgo(8); });
  // Ganhas: 387 no período totalizando R$ 1.240.500; 274 no período anterior (R$ 849.700). Perdidas: 1.041 / 820.
  const won = (n: number, total: number, from: number, to: number) => {
    const weights = Array.from({ length: n }, () => 0.4 + rand());
    const sum = weights.reduce((a, b) => a + b, 0);
    let acc = 0;
    weights.forEach((w, i) => {
      const amount = i === n - 1 ? total - acc : Math.round((w / sum) * total);
      acc += amount;
      const closed = daysAgo(from + Math.floor(Math.pow(rand(), 0.85) * (to - from)));
      const c = pick(comps);
      oppRows.push({ organizationId: org.id, pipelineId: pipe.id, stageId: st("Ganho").id, companyId: c.id, title: c.name, amountCents: amount * 100, status: "won", closedAt: closed, ownerId: pick(sellers).id, source: pick(sources), createdAt: new Date(closed.getTime() - 20 * 864e5) });
    });
  };
  won(387, 1240500, 0, 30); won(274, 849700, 30, 60);
  const lost = (n: number, from: number, to: number) => { for (let i = 0; i < n; i++) { const c = pick(comps); const closed = daysAgo(from + Math.floor(rand() * (to - from))); oppRows.push({ organizationId: org.id, pipelineId: pipe.id, stageId: st("Perdido").id, companyId: c.id, title: c.name, amountCents: Math.round(10000 + rand() * 30000) * 100, status: "lost", lostReason: pick(["Preço", "Concorrente", "Sem orçamento", "Timing"]), closedAt: closed, ownerId: pick(sellers).id, createdAt: new Date(closed.getTime() - 15 * 864e5) }); } };
  lost(1041, 0, 30); lost(820, 30, 60);
  await batch(oppRows, (c) => db.insert(s.opportunities).values(c));

  // Meta do período: R$ 1.500.000
  await db.insert(s.goals).values({ organizationId: org.id, name: "Vendas do mês", metric: "revenue", scope: "organization", targetValue: 150000000, periodStart: new Date(Date.now() - 30 * 864e5), periodEnd: new Date(Date.now() + 864e5) });
  await db.insert(s.commissionRules).values({ organizationId: org.id, name: "Comissão padrão", ratePct: 5, acceleratorPct: 2, createdBy: admin.id });

  // Atividades do time: 256 tarefas hoje, 42 reuniões na semana, 118 follow-ups
  const today = new Date(); today.setHours(10, 0, 0, 0);
  await batch(Array.from({ length: 256 }, (_, i) => ({ organizationId: org.id, title: pick(["Ligar para lead", "Enviar proposta", "Follow-up", "Atualizar CRM", "Preparar reunião"]), assigneeId: pick(sellers).id, dueAt: new Date(today.getTime() + (i % 8) * 3600e3), priority: pick(["low", "medium", "high"]) })), (c) => db.insert(s.tasks).values(c));
  await batch(Array.from({ length: 42 }, () => ({ organizationId: org.id, title: "Reunião de descoberta", startsAt: new Date(Date.now() + rand() * 6 * 864e5), userId: pick(sellers).id })), (c) => db.insert(s.meetings).values(c));
  await batch(Array.from({ length: 118 }, () => ({ organizationId: org.id, type: "follow_up", subject: "Follow-up realizado", userId: pick(sellers).id, occurredAt: daysAgo(Math.floor(rand() * 6)) })), (c) => db.insert(s.activities).values(c));

  // Closer.AI: base de conhecimento + conversas
  const ctx = (await contextFor(db, admin.id, org.id))!;
  await addKnowledge(ctx, { title: "Política comercial", kind: "policy", content: "Atendemos empresas B2B em todo o Brasil. Prazo de implantação padrão: 15 dias úteis. Pagamento via boleto ou cartão. Descontos somente com aprovação do gestor comercial. Suporte em horário comercial, de segunda a sexta, das 9h às 18h." });
  await addKnowledge(ctx, { title: "Perguntas frequentes", kind: "faq", content: "Vocês oferecem teste gratuito? Sim, 7 dias de teste. Como funciona a implantação? Um especialista conduz o onboarding em reuniões semanais. Há fidelidade? Planos mensais sem fidelidade; planos anuais têm desconto." });
  const contactsData = [["Mariana Lopes", "mariana@grupoalfa.demo", "Olá, gostaria de saber o preço para 10 usuários."], ["Rafael Gomes", "rafael@agromax.demo", "Podemos agendar uma demonstração na quinta?"], ["Patrícia Ramos", "patricia@clinicavida.demo", "Quero falar com um humano, por favor."], ["Lucas Martins", "lucas@educamais.demo", "Vocês têm teste gratuito?"]];
  for (const [i, [n, e, b]] of contactsData.entries()) {
    const [c] = await db.insert(s.contacts).values({ organizationId: org.id, name: n, email: e, source: "webchat", legalBasis: "legitimo_interesse" }).returning();
    const intent = /pre[cç]o/.test(b) ? "Preço / orçamento" : /agendar/.test(b) ? "Agendar reunião" : /humano/.test(b) ? "Pediu humano" : "Dúvida geral";
    const [cv] = await db.insert(s.conversations).values({ organizationId: org.id, channel: ["webchat", "whatsapp", "email", "webchat"][i], contactId: c.id, subject: b.slice(0, 60), intent, status: /humano/.test(b) ? "handoff" : "open", slaDueAt: new Date(Date.now() + (i === 0 ? -10 : 20) * 60_000) }).returning();
    await db.insert(s.messages).values({ organizationId: org.id, conversationId: cv.id, direction: "inbound", author: "contact", body: b, status: "delivered" });
  }

  // Automações: modelo "nutrição" ativo + "grande negócio" em rascunho
  for (const [i, tk] of ["nutricao", "grande-negocio"].entries()) {
    const t = TEMPLATES.find((x) => x.key === tk)!;
    const [wf] = await db.insert(s.workflows).values({ organizationId: org.id, name: t.name, description: t.description, triggerEvent: t.triggerEvent, status: i === 0 ? "active" : "draft", createdBy: admin.id }).returning();
    await db.insert(s.workflowVersions).values({ organizationId: org.id, workflowId: wf.id, version: 1, definition: t.definition });
  }

  // Financial Intelligence 360: ~6 meses de lançamentos de DEMONSTRAÇÃO (source = "demo")
  const fin = await seedDemoFinance(db, org.id);
  console.log(`   Financeiro de demonstração: ${fin.created} lançamentos${fin.skipped ? ` (${fin.skipped})` : ""}`);

  // Clientes adicionais (demonstração) para o painel global de Customer Success
  for (const [n, seg, status] of [["Consultoria Horizonte", "Consultoria", "active"], ["Agência Pixel", "Agências", "trialing"], ["Distribuidora Norte", "Distribuidores", "past_due"]] as const) {
    const [u] = await db.insert(s.users).values({ name: `Admin ${n}`, email: `admin@${n.toLowerCase().replace(/[^a-z]/g, "")}.demo`, passwordHash: pw }).returning();
    const o = await provisionOrganization(db, { name: n, ownerId: u.id, segment: seg, size: "2-10", isDemo: true });
    await db.update(s.subscriptions).set({ status }).where(eq(s.subscriptions.organizationId, o.id));
  }

  // Incidente e experimento de exemplo (administração global)
  await db.insert(s.incidents).values({ title: "Latência elevada no envio de e-mails (exemplo)", category: "integrations", severity: "sev3", status: "monitoring", impact: "Envio de e-mails com atraso de até 5 minutos.", ownerId: admin.id, timeline: [{ at: new Date().toISOString(), by: admin.id, note: "Incidente de demonstração criado pelo seed" }] });
  await db.insert(s.experiments).values({ key: "onboarding-v2", hypothesis: "Onboarding guiado por IA aumenta ativação em 7 dias.", objective: "Ativação", audience: "Novas organizações", variants: [{ key: "controle", weight: 50, exposures: 64, conversions: 21 }, { key: "ia_guiado", weight: 50, exposures: 61, conversions: 27 }], primaryMetric: "activation_7d", owner: "Produto", status: "running", startsAt: new Date(Date.now() - 10 * 864e5) });

  void embed;
  console.log("\n✅ Seed concluído.");
  console.log("   Organização de DEMONSTRAÇÃO: Minha Empresa (is_demo = true)");
  console.log("   Login: admin@orbity.local  — senha de desenvolvimento definida em DEMO_PASSWORD (padrão no scripts/seed.ts)\n");
  await close();
}

main().catch((e) => { console.error(e); process.exit(1); });
