try { process.loadEnvFile(".env"); } catch { /* opcional */ }
import fs from "node:fs";
if (process.env.APP_ENV === "production" || process.env.DATABASE_URL) { console.error("Reset permitido apenas com PGlite local."); process.exit(1); }
fs.rmSync(process.env.PGLITE_DIR || "./.data/pglite", { recursive: true, force: true });
console.log("Banco local removido. Rode `npm run db:seed`.");
