# Changelog

## [0.4.0] — ORBITY Task Intelligence (2026-11-16)
### Adicionado
- **Alertas individuais por tarefa**: botão "Gerar alerta" ao lado de Concluir (ícone com tooltip em telas pequenas), painel com
  destinatário automático, prioridade (baixa/média/alta/urgente), envio imediato, agendado ou rascunho, e confirmação explícita.
- **Mensagens com o Flávio** (tipo, tom, orientação, novas versões ilimitadas dentro dos créditos, edição manual; sugestão original
  guardada). Sem IA configurada o texto é local e rotulado "simulado".
- **Estados reais**: rascunho, agendado, enviado, entregue, lido, respondido, falhou, cancelado. Canais externos (push, e-mail,
  WhatsApp) aparecem como indisponíveis porque não há envio real implementado; nada é marcado como enviado sem ter sido.
- **Automação e escalonamento** por regras (antes/no/após o vencimento, sem atualização, prioritária pendente, meta em risco),
  com horário permitido, máximo de lembretes, intervalo mínimo e parada por resposta, conclusão ou bloqueio justificado.
- **Respostas do colaborador** (confirmar, andamento, impedimento, ajuda, justificar, concluir) e **prorrogação** com recomendação
  do Flávio e decisão do gestor (aprovar, rejeitar ou propor data).
- **Central de Alertas** (`/alertas`): indicadores, filtros, histórico completo por tarefa, inteligência de execução e ferramenta
  `execucao_e_alertas` no Flávio. Permissões novas: `alerts:send`, `alerts:manage`.
- Migração `0003_task_intelligence`; matriz de requisitos em `docs/task-intelligence/MATRIZ-REQUISITOS.md`.

## [0.3.0] — Adições ao Master Prompt 4.0 (2026-11-16)
### Adicionado
- **Colaboração humano × IA nas sugestões** (Closer.AI e Prospect.AI, serviço transversal `src/server/ai/collab`):
  sugestões ilimitadas e versionadas (nada é sobrescrito), Assistente de Respostas com 10 operações + instrução livre,
  melhorar só o trecho selecionado, Descartar com as opções A (gerar outra), B (com instruções) e C (escrever manualmente),
  histórico com comparação, recuperação e combinação de versões, recuperação de texto não salvo, envio com confirmação,
  bloqueio de envio duplicado e política de aprovação (texto humano envia direto; texto da IA: gestor envia, colaborador
  pede aprovação). Mensagem enviada registra se foi sugestão sem alterações, editada ou escrita pela equipe.
  Alerta para valores/condições que não estão nas fontes. Métricas de sugestões no AI Control Plane e no Sales Intelligence.
- **Business Brain integrado ao Flávio** (`/business-brain`): perguntas livres, motor de investigação em 10 etapas com
  ferramentas que respeitam as permissões do usuário (CRM, funil, vendedores, canais, metas, Closer.AI, insights, decisões,
  Financeiro, Simulador, uso de IA), resposta adaptativa (curta ou até 10 seções) com fato/inferência/estimativa/hipótese/
  recomendação, fontes detalhadas, gráficos, continuidade de contexto, investigações salvas, exportação (.md/.csv), ações
  com confirmação (tarefa, decisão, cenário), alertas proativos configuráveis por usuário. Com chave da Anthropic, usa um
  ciclo governado de ferramentas (Claude); sem chave, planejador determinístico.
- Migração `0002_colaboracao_flavio`: `ai_drafts`, `ai_draft_versions`, `flavio_conversations`, `flavio_messages`.
### Corrigido
- Gerador simulado não repete mais a pergunta da base de conhecimento e o tom formal trata "vocês" corretamente.
- Alertas usados pelo Flávio são recalculados quando estão desatualizados (mais de 15 minutos).

## [0.2.0] — Master Prompt 4.0, ciclo 1 (2026-11-10)
Fase 0 (auditoria, matriz, backlog priorizado, roadmap, catálogos e planos) em `docs/v4/`. Itens do ciclo escolhidos pela
regra de priorização (valor 25%, receita 25%, diferenciação 20%, viabilidade 15%, manutenção 15%).
### Adicionado
- **Command Center** (`/command-center`): KPIs comerciais e financeiros, as 6 perguntas executivas, briefing
  diário/semanal/mensal/trimestral, widgets por usuário. CAC/LTV/churn aparecem como "Indisponível" com o dado que falta.
- **Intelligence Layer**: Evidence Engine (fonte, período, cálculos, premissas, confiança, dados ausentes, limitações),
  12 regras de insight com deduplicação e expiração, Decision Engine (alternativas, aprovação com segregação de funções),
  Outcome Engine (aceito/rejeitado/executado + resultado medido) e ajuste de prioridade por feedback.
- **Business Brain**: 10 perguntas do §7.2 com resposta em 10 partes, separando fatos, inferências, estimativas e
  recomendações. A IA real (quando configurada) só reescreve o resumo; os números são determinísticos.
- **Financial Intelligence** (`/financeiro`): contas a pagar/receber, categorias, DRE gerencial, fluxo de caixa projetado,
  inadimplência, rentabilidade por cliente/produto, ponto de equilíbrio, orçamento vs. realizado e assistente financeiro.
- **Strategy Simulator** (`/simulador`): base real, preço/volume/conversão/custos/contratações/marketing/perda de clientes,
  cenários otimista/base/pessimista, sensibilidade, salvar, comparar e aprovar.
- **AI Control Plane** (`/ai-control`): 5 níveis de autonomia, pausar/suspender/aposentar agentes, kill switch (agente,
  domínio, toda a IA, integração, ferramenta, automação, categoria de ação; global só pela plataforma), orçamentos de IA,
  monitoramento, força de trabalho digital e relatório de conflitos.
- Permissões novas: `finance:read/write`, `strategy:read/write`, `ai:govern` (só administradores). Cargos de sistema
  existentes recebem as permissões novas automaticamente na migração.
- Migração `0001_ciclo1_v4` (9 tabelas novas + colunas de governança em `ai_agents`).
### Corrigido
- Mensagem do Closer.AI não é mais marcada como "enviada" sem chamada real ao provedor (D-01).
- Ação sensível de automação aprovada agora executa e a automação retoma; antes da aprovação os passos seguintes não rodam;
  webhook só para https público (proteção SSRF) (D-03).
- Webhook do WhatsApp exige assinatura (`WHATSAPP_APP_SECRET`) em produção.
- `next.config.ts` aceita `NEXT_DIST_DIR` para build em pasta separada.

## [Não lançado] — Prompts 34 e 35 (2026-11-10)
### Adicionado
- Serviço central de métricas (`src/server/domains/metrics`): definições auditáveis, filtros por período personalizado,
  comparação (período anterior ou ano anterior), vendedor, equipe, campanha, origem e etapa; séries, segmentação,
  drill-down até leads e oportunidades e exportação CSV do resultado filtrado (com proteção contra fórmulas e auditoria).
- APIs `/api/metrics/dashboard`, `/api/metrics/drilldown`, `/api/metrics/export`.
- Dashboard interativo: filtros globais na URL, cards com drill-down, série com comparação, segmentação com filtro cruzado,
  legenda interativa, navegação por teclado e toque, tabela alternativa, estados de carregamento, vazio e erro, atualização a cada minuto.
- Gráficos do Sales Intelligence passam a usar o mesmo componente interativo.
- Flávio, Assistente de Inteligência Comercial: painel lateral persistente, contexto da tela e dos filtros, análises
  determinísticas com fontes, período e critérios, narrativa pelo orquestrador existente (agente `executive`) quando há
  provedor de IA, fallback determinístico, histórico com exclusão, ações preparadas com confirmação explícita, assinatura,
  validade, revalidação de permissão e auditoria (`/api/flavio/*`).
- 21 testes de integração (`tests/integration/metrics-flavio.test.ts`).
### Alterado
- `dashboardKpis` delega ao serviço central de métricas (mesmos números em card, relatório e Flávio).
- O assistente "ORBITY AI" do dashboard foi substituído pelo Flávio; `/api/ai/chat` agora delega ao Flávio.
- `runAgent` aceita `persona` opcional (acrescida ao prompt do agente).
- Removidos emoji do título do dashboard e o símbolo de aviso Unicode do banner de demonstração (agora ícone Lucide).

## [0.1.0] — 2026-11-09
### Adicionado
- Fundação: Next.js 15, Drizzle ORM, PostgreSQL/PGlite + pgvector, ~55 tabelas, migrações versionadas.
- Identidade: cadastro, login, sessões, 2FA TOTP, OAuth Google/Microsoft (requer credenciais), convite com aprovação.
- Multi-tenancy com isolamento testado; permissões por cargo verificadas no backend; auditoria.
- CRM central, Prospect.AI, Closer.AI, Sales Intelligence, Relatórios.
- Event Engine (outbox, idempotência, retry/backoff, DLQ) e Workflow Engine (versionamento, simulação, aprovações, anti-loop).
- IA independente de provedor, 12 agentes, guardrails, AI Evaluation Center com governança de versões.
- Billing (planos, entitlements, créditos, excedentes autorizados, faturas), metas e comissões.
- Admin da empresa, painel global, Customer Success (Health Score), feature flags, experimentos, incidentes, suporte.
- Documentação, matriz de requisitos e CI.
